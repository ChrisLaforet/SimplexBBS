/* s_file.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 2 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_file.c_v  $
**                       $Date:   25 Oct 1992 14:09:26  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>
#include "simplex.h"


char _far *weekday_table[7] =
	{
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
	};


char _far *months_table[12] = 
	{
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec",
	};


static char _far tbuf[512];



void send_ansifile(char *destpath,char *filename,int nostop)
	{
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	strcpy(buffer,destpath);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		_makepath(buffer,drive,path,fname,"ANS");
		if (!access(buffer,0))
			{
			_makepath(buffer,"","",filename,"ANS");
			if (nostop)
				send_file(destpath,buffer,1,p_handler);
			else 
				send_file(destpath,buffer,1,ps_handler);
			return;
			}
		}
	_makepath(buffer,"","",filename,"ASC");
	if (nostop)
		send_file(destpath,buffer,1,p_handler);
	else 
		send_file(destpath,buffer,1,ps_handler);
	if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE),NULL);		/* reset any strange colors */
	}



char *parse_long(long lval)
	{
	static char _far buffer[25];
	long dividend = lval;
	int result;
	int tval;
	char *cptr;

	cptr = buffer;
	do
		{
		result = (int)(dividend % 1000L);
		dividend /= 1000L;
		if (!dividend && result < 10)
			*cptr++ = (char)(result + '0');
		else if (!dividend && result < 100)
			{
			tval = result % 10;
			*cptr++ = (char)(tval + '0');
			tval = result / 10;
			*cptr++ = (char)(tval + '0');
			}
		else
			{
			tval = result % 10;
			*cptr++ = (char)(tval + '0');
			tval = (result % 100) / 10;
			*cptr++ = (char)(tval + '0');
			tval = result / 100;
			*cptr++ = (char)(tval + '0');
			}
		if (dividend)
			*cptr++ = ',';
		}
	while (dividend);

	*cptr = '\0';
	strrev(buffer);		/* now to invert the string */
	return buffer;
	}



int send_file(char *path,char *filename,int interp,int (*handler)(int key))
	{
	char buffer[100];
	char *cptr;
	char *cptr1;
	long cur_time = projected_time(0L);
	long tlong;
	DATE_T date;
	TIME_T time;
	int tmore = user.user_flags & USER_MORE ? 1 : 0;
	int count;
	int total;
	int temp;
	int rtn;
	int val;
	int end;
	int key;
	FILE *fd;

	strcpy(buffer,path);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,filename);
	if (fd = openf(buffer,"rb"))
		{
		send_string("\r\n",NULL);
		while (fgets(buffer,sizeof(buffer),fd))
			{
			end = 0;
			total = (int)strlen(buffer);
			cptr = buffer;
			while (end < total)
				{
				if (interp)
					{
					if (*cptr)
						{
						if (*cptr == '`')
							{
							++cptr;
							++end;
							if (*cptr)		/* if not skip! */
								{
								switch (*cptr++)
									{
									case '`':
										strcpy(tbuf,"`");
										break;
									case 'A':
										strcpy(tbuf,user.user_name);
										break;
									case 'B':
										strcpy(tbuf,user_firstname);
										break;
									case 'C':
										strcpy(tbuf,user_lastname);
										break;
									case 'D':
										strcpy(tbuf,user.user_city);
										break;
									case 'E':
										if (user.user_home[0])
											strcpy(tbuf,user.user_home);
										else
											strcpy(tbuf,"              ");
										break;
									case 'F':
										if (user.user_data[0])
											strcpy(tbuf,user.user_data);
										else 
											strcpy(tbuf,"              ");
										break;
									case 'G':
										strcpy(tbuf,user.user_password);
										break;
									case 'H':
										sprintf(tbuf,"%u",(int)user.user_priv);
										break;
									case 'I':
										for (count = 0, val = 1; count < 16; count++)
											{
											if (user.user_uflags & val)
												tbuf[count] = (char)('A' + count);
											else 
												tbuf[count] = (char)('a' + count);
											val <<= 1;
											}
										tbuf[count] = (char)'\0';
										break;

									case 'M':
										if (user_baud)
											sprintf(tbuf,"%u",user_baud);
										else
											strcpy(tbuf,"Local");
										break;
									case 'N':
										sprintf(tbuf,"%s",user.user_flags & USER_ANSI ? "On " : "Off");
										break;
									case 'O':
										sprintf(tbuf,"%s",user.user_flags & USER_MORE ? "On " : "Off");
										break;
									case 'P':
										sprintf(tbuf,"%s",user.user_flags & USER_CLS ? "On " : "Off");
										break;
									case 'Q':
										sprintf(tbuf,"%s",user.user_flags & USER_EDITOR ? "Ansi" : "Line");
										break;
									case 'R':
										sprintf(tbuf,"%s",user.user_flags & USER_EXPERT ? "On " : "Off");
										break;
									case 'S':
										sprintf(tbuf,"%d",user.user_screenlen);
										break;
									case 'T':
										sprintf(tbuf,"$%d.%02d",user.user_credit / 100,user.user_credit % 100);
										break;
									case 'U':
										sprintf(tbuf,"%u",(unsigned int)cfg.cfg_minbaud);
										break;
									case 'V':
										sprintf(tbuf,"%u",(unsigned int)cfg.cfg_ansibaud);
										break;
									case 'W':
										sprintf(tbuf,"%02u:%02u",cfg.cfg_yellstart >> 11,(cfg.cfg_yellstart >> 5) & 0x3f);
										break;
									case 'X':
										sprintf(tbuf,"%02u:%02u",cfg.cfg_yellstop >> 11,(cfg.cfg_yellstop >> 5) & 0x3f);
										break;
									case 'Y':
										sprintf(tbuf,"%02u:%02u",cfg.cfg_dlstart >> 11,(cfg.cfg_dlstart >> 5) & 0x3f);
										break;
									case 'Z':
										sprintf(tbuf,"%02u:%02u",cfg.cfg_dlstop >> 11,(cfg.cfg_dlstop >> 5) & 0x3f);
										break;

									case 'a':
										temp = ((user.user_firstdate >> 5) & 0xf) - 1;
										if (temp && (temp >= 12 || temp < 0))
											temp = 11;
										sprintf(tbuf,"%02u %s %02u",user.user_firstdate & 0x1f,months_table[temp],(((unsigned int)user.user_firstdate >> 9) + 80) % 100);
										break;
									case 'b':
										temp = ((user_lastdate >> 5) & 0xf) - 1;
										if (temp && (temp >= 12 || temp < 0))
											temp = 11;
										sprintf(tbuf,"%02u %s %02u",user_lastdate & 0x1f,months_table[temp],(((unsigned int)user_lastdate >> 9) + 80) % 100);
										break;
									case 'c':
										sprintf(tbuf,"%02u:%02u",user_lasttime >> 11,(user_lasttime >> 5) & 0x3f);
										break;
									case 'd':
										sprintf(tbuf,"%u min 00 sec",logon_times[(int)user.user_priv]);
										break;
									case 'e':
										tlong = (user.user_timeused * 60L) + (cur_time - login_time);
										sprintf(tbuf,"%lu min %02lu sec",tlong / 60L,tlong % 60L);
										break;
									case 'f':
										tlong = user_time;
										sprintf(tbuf,"%lu min %02lu sec",tlong / 60L,tlong % 60L);
										break;
									case 'g':
										tlong = cur_time - login_time;
										sprintf(tbuf,"%lu min %02lu sec",tlong / 60L,tlong % 60L);
										break;
									case 'h':
										cptr1 = parse_long((long)user.user_upload);
										sprintf(tbuf,"%s",cptr1);
										break;
									case 'i':
										cptr1 = parse_long(user.user_uploadbytes);
										sprintf(tbuf,"%s",cptr1);
										break;
									case 'j':
										cptr1 = parse_long((long)user.user_dnload);
										sprintf(tbuf,"%s",cptr1);
										break;
									case 'k':
										cptr1 = parse_long((long)user.user_dnloadbytes);
										sprintf(tbuf,"%s",cptr1);
										break;
									case 'l':
										sprintf(tbuf,"%u",user.user_calls);
										break;
									case 'm':
										sprintf(tbuf,"%lu",user.user_msgread);
										break;
									case 'n':
										sprintf(tbuf,"%lu",user.user_msgsent);
										break;

									case 'p':
										sprintf(tbuf,"%s",weekday_table[get_cday()]);
										break;
									case 'q':
										sprintf(tbuf,"%3.3s",weekday_table[get_cday()]);
										break;
									case 'r':
										date = get_cdate();
										temp = ((date >> 5) & 0xf) - 1;
										if (temp && (temp >= 12 || temp < 0))
											temp = 11;
										sprintf(tbuf,"%02u %s %02u",date & 0x1f,months_table[temp],((date >> 9) + 80) % 100);
										break;
									case 's':
										time = get_ctime();
										sprintf(tbuf,"%02u:%02u",time >> 11,(time >> 5) & 0x3f);
										break;
									case 't':
										sprintf(tbuf,"%d",yells);
										break;
									case 'u':
										cptr1 = parse_long(filelength(fileno(userfd)) / (long)sizeof(struct user));
										sprintf(tbuf,"%s",cptr1);
										break;
									case 'v':
										strcpy(tbuf,last_user);
										break;
									case 'w':
										strcpy(tbuf,cfg.cfg_bbsname);
										break;
									case 'x':
										strcpy(tbuf,cfg.cfg_sysopname);
										break;

									case '@':
										if (user.user_alias[0][0])
											strcpy(tbuf,user.user_alias[0]);
										else
											strcpy(tbuf,"Alias #1 undefined");
										break;
									case '#':
										if (user.user_alias[1][0])
											strcpy(tbuf,user.user_alias[1]);
										else
											strcpy(tbuf,"Alias #2 undefined");
										break;
									case '%':
										if (user.user_alias[2][0])
											strcpy(tbuf,user.user_alias[0]);
										else
											strcpy(tbuf,"Alias #3 undefined");
										break;
									case '&':
										if (user.user_alias[3][0])
											strcpy(tbuf,user.user_alias[3]);
										else
											strcpy(tbuf,"Alias #4 undefined");
										break;

									case '0':
										tmore = 0;
										tbuf[0] = '\0';
										break;
									case '1':
										if (user.user_flags & USER_MORE)
											tmore = 1;
										tbuf[0] = '\0';
										break;
									case '2':
										if (handler == ps_handler)
											handler = p_handler;
										tbuf[0] = '\0';
										break;
									case '3':
										if (handler == p_handler)
											handler = ps_handler;
										tbuf[0] = '\0';
										break;
									case '4':
										purge_input(cfg.cfg_port);
										while (1)
											{
											key = get_char();
											if (key == '\r' || key == '\n')
												break;
											}
										tbuf[0] = '\0';
										cur_line = 0;		/* reset current line to 0 for more */
										break;
									case '5':
										strcpy(tbuf,"\f");
										break;
									case '6':
										strcpy(tbuf,"\a");
										break;
									case '7':
										strcpy(tbuf,"\b");
										break;
									}
								++end;
								}
							}
						else
							{
							if (*cptr == '\x1a' && !*(cptr + 1))		/* Ctrl-Z */
								{
								tbuf[0] = (char)'\0';
								++cptr;
								}
							else
								{
								tbuf[0] = *cptr++;
								tbuf[1] = (char)'\0';
								++end;
								}
							}
						}
					else
						{
						end = total;
						break;
						}
					}
				else
					{
					strcpy(tbuf,buffer);
					end = total;
					}
				if (!tmore)
					cur_line = 0;
				if (tbuf[0])
					{
					if (rtn = send_buffer(tbuf,(int)strlen(tbuf),handler))
						{
						closef(fd);
						send_string("\r\n",NULL);
						return rtn;
						}
					}
				}
			}
		closef(fd);
		send_string("\r\n",NULL);
		}
	return 0;
	}


