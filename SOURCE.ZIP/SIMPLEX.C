/* simplex.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 26 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/simplex.c_v  $
**                       $Date:   25 Oct 1992 14:09:28  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <share.h>
#include <io.h>
#include <ctype.h>
#include <direct.h>
#include <signal.h>
#ifdef PROTECTED
	#define INCL_FILEMGR
	#define INCL_DOSPROCESS
	#define INCL_DOSSIGNALS
	#define INCL_DOSMISC
	#include <os2.h>
#elif defined(__ZTC__)
	#include <cerror.h>
	#include <dos.h>
#else
	#include <dos.h>
#endif
#ifdef XSPAWN
	#include <xspawn.h>
#endif
#include "simplex.h"



char _far bbspath[256];
FILE *userfd;
FILE *uinfofd;
FILE *cfgfd;
FILE *logfd;
FILE *msghfd;					/* message headers */
FILE *msglfd;					/* message link - msg area to number */
FILE *msgbfd;					/* message body */
FILE *msgdfd;					/* message data */
FILE *msgrfd;					/* message last-read pointers */
FILE *combfd;					/* combination message data file */
FILE *nlstfd;					/* nodelist file */
FILE *nidxfd;					/* nodelist index */
struct cfg _far cfg;
short _far logon_times[256];	/* table of allowed time per day by priv level */
int total_users;
int fossil_init = 0;
int init_flag = 1;				/* initiialize flag */
int local_flag = 0;				/* true if local mode */
int exit_flag = 0;				/* exit after use flag */
int event_exit = 0;				/* exit is an event-generated exit */
int hangup_flag = 1;			/* do not hangup before exit */
int time_flag = 0;				/* set this as user's time */
int ringback_flag = 0;			/* set this to do ringback algorithm */
int answer_flag = 0;			/* set this to answer the phone immediately without waiting for a ring! */
int drop_flag = 0;				/* set this to read user's info from file */
int echomail_entered = 0;
int netmail_entered = 0;
int port = -1;
int locked_flag = 0;			/* locked baud rate flag.  If set use locked_baud and do not change it. */
unsigned int locked_baud;
unsigned int user_baud;
int ringback_rings = 3;			/* number of rings before ringback arms */
int errorlevel = 0;				/* exit errorlevel - changed if mail entered or event occurs */
#ifndef PROTECTED
	int stdout_flag = 1;		/* close stdout flag */
#endif
int share_installed = 0;

int field_color = WHITE | BRIGHT | ON_BLUE;		/* entry field color */
int menu_color = WHITE | BRIGHT;				/* submenu color */
int status_color[4] =			/* status line colors */
	{
		ON_WHITE,				/* regular lowkey */
		ON_WHITE,				/* regular hilite */
		ON_WHITE,				/* special hilite */
		ON_WHITE | BLINK,		/* urgent hilite */
	};




#ifdef __ZTC__
unsigned _stack = 10240;			/* this is needed by the Zortech compiler */
#endif




#ifndef PROTECTED

static char _far _handles[255];

int extend_file_handles(int number)		/* gives more than 20 handles */
	{
	union REGS registers;
	char far *ptr = (char far *)(long)(_psp << 16L);
	char far *cur_handles;
	int kludge_flag = 0;
	int number_of_handles = 0;

	if (number > 255)
		return -1; 	/* invalid number of handles */
//	if (*(int far *)(ptr + 0x32) >= number)
//		return 0;		/* no need to allocate */
	if (_osmajor > 3 || (_osmajor == 3 && _osminor >= 30))  /* greater than or equal DOS 3.30 */
		{
		registers.h.ah = 0x67;
		registers.x.bx = number;
		intdos(&registers,&registers);
		if (registers.x.cflag & 1)
			kludge_flag = 1;
		else
			number_of_handles = number;
		}
	else
		kludge_flag = 1;
	if (kludge_flag)
		{
		if (_osmajor < 3)
			return 0;		/* unable to allocate more than 20 in DOS 2.xx */
		else
			number_of_handles = number;
		cur_handles = (char far *)((long)(*(int far *)(ptr + 0x36) << 16L) + (long)*(int far *)(ptr + 0x34));

		memmove(_handles,cur_handles,*(int far *)(ptr + 0x32));
		memset(_handles + *(int far *)(ptr + 0x32),0xff,number_of_handles - *(int far *)(ptr + 0x32));
		*(unsigned char far *)(ptr + 0x32) = (unsigned char)number_of_handles;
		*(int far *)(ptr + 0x34) = (int)((long)_handles & 0xffffL);
		*(int far *)(ptr + 0x36) = (int)((long)(void far *)_handles >> 16L);
		}
	return number_of_handles;
	}
#endif



void exit_list(void)
	{
	char buffer[100];


#if defined(PROTECTED) && defined(MULTICHAT)
	close_mc();
#endif
	if (!local_flag)
		{
		if (fossil_init && hangup_flag)
			{
			hangup();
			if (check_cd(cfg.cfg_port))
				hangup();
			if (cfg.cfg_busy[0])
				{
				raise_dtr(cfg.cfg_port);
				enable_flowctrl(cfg.cfg_port,1,0,0);		/* cts-rts and NO xon-xoff */
				set_baud(cfg.cfg_port,locked_flag ? locked_baud : cfg.cfg_baud);
				send_modem(cfg.cfg_busy);
				}
			}

		if (fossil_init)
			deinit_fossil(cfg.cfg_port);
		}
	stop_timer();
	log_entry(L_STOP,NULL);
	bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */
	fcloseall();

	deinit_menus();		/* free all memory */
	deinit_msgs();
	deinit_fileareas();
	free_urgent();
	free_mark();
	deinit_topics();
	free_msglines();

	sprintf(buffer,"\"%s\" is now offline!",cfg.cfg_bbsname);
	_error(E_NOTICE,buffer);
	fprintf(stderr,"\n\n");
	}



#ifdef __ZTC__


int _far _cdecl critical_error(int *ax,int *di)
	{
	*ax = 0;		/* return ignore error */
	}


#elif !defined(PROTECTED)


int critical_error(unsigned int deverr,unsigned int errcode,unsigned int far *devhdr)
	{
	_hardretn((errcode & 0xff) + 0x12); 	/* return error number - resumes as though aborted */
	}


#endif



void signal_trap(int signo)
	{
	/* this function does nothing except receive
	** calls from SIGINT and SIGBREAK.  This is
	** done this way since not all compilers handle
	** SIG_IGN correctly.
	*/
	}



int is_share(void)
	{
#if defined(PROTECTED)
	return 1;
#else
	union REGS registers;

	if (_osmajor < 3)
		return 0;
	registers.x.ax = 0x1000;
	int86(0x2f,&registers,&registers);		/* check multiplex interrupt */
	if (registers.h.al != 0xff)
		return 0;
	return 1;
#endif
	}



int main(int argc,char *argv[])
	{
	char buffer[100];
	char *cptr;
#ifdef PROTECTED
	PIDINFO pids;
	PFNSIGHANDLER prev_ctrlc;
	USHORT prev_action;
#endif
	int count;
	int tval;

	init_screen();
	bios_clrblk(0x0,((bottom_line + 3) << 8) | 0x4f,WHITE);
	bios_setcurpos(0x0);

#ifdef PROTECTED
	#ifdef MULTICHAT
		fprintf(stderr,"SIMPLEX/2-M (v %u.%02u.%02u%s of %s): A BBS for OS/2 with MultiChat.\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""),__DATE__);
	#else
		fprintf(stderr,"SIMPLEX/2 (v %u.%02u.%02u%s of %s): A Bulletin Board System for OS/2.\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""),__DATE__);
	#endif
#elif defined(__ZTC__)
	fprintf(stderr,"SIMPLEX/S (v %u.%02u.%02u%s of %s): A Bulletin Board System for DOS.\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""),__DATE__);
#else
	fprintf(stderr,"SIMPLEX (v %u.%02u.%02u%s of %s): A Bulletin Board System for DOS.\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""),__DATE__);
#endif
	fprintf(stderr,"Copyright (c) 1989-93, Chris Laforet and Chris Laforet Software.\n");
	fprintf(stderr,"All Rights Reserved.\n\n");

	bios_setcurpos(0x400);

#ifdef XSPAWN
	_swap = 1;			/* no swap by default */
#endif

#ifdef PROTECTED
	DosSetSigHandler(NULL,&prev_ctrlc,&prev_action,SIGA_IGNORE,SIG_CTRLC);
	DosSetSigHandler(NULL,&prev_ctrlc,&prev_action,SIGA_IGNORE,SIG_CTRLBREAK);

	DosSetMaxFH(30);

	DosGetPID(&pids);		/* Now to increase increase our priority */

	if (_osmajor == 10 && _osminor < 20)		/* if OS/2 version less than 1.20 make it timecritical */
		{
		fprintf(stderr,"\a\aFatal error: Simplex requires OS/2 version 1.3 or higher.\n\n");
		return 1;
		}
	else 
		DosSetPrty(PRTYS_PROCESSTREE,PRTYC_FOREGROUNDSERVER,PRTYD_MINIMUM,pids.pid);
#else
	signal(SIGINT,signal_trap);	   		/* first, down with Ctrl-C */
	signal(SIGBREAK,signal_trap);  		/* then down with Ctrl-Break */

	#ifndef __WATCOMC__
		extend_file_handles(30);		/* Smart Watcom already does it for us!! */
	#endif
#endif

#ifdef __WATCOMC__
	if (_grow_handles(30) < 30)			/* get at least 30 file handles */
		{
		fprintf(stderr,"\a\aFatal error: Unable to allocate 30 file handles.\n\n");
		return 1;
		}
#endif

	/* let's turn off hard error processing */
#ifdef PROTECTED
	DosError(0);
#elif defined(__ZTC__)
	_cerror_handler = critical_error;
	cerror_open();
#else
	_harderr(critical_error);	/* int 24h handler */
#endif

	/* parse command line */
	for (count = 1; count < argc; count++)
		{
		cptr = argv[count];
		if (*cptr == '-' || *cptr == '/')
			{
			++cptr;
			switch (*cptr++)
				{
				case 'A':
				case 'a':
					answer_flag = 1;
					exit_flag = 1;				/* exit immediately afterwards */
					break;
				case 'L':			/* Local login */
				case 'l':
					init_flag = 0;
					user_baud = 0;
					local_flag = 1;
					exit_flag = 1;				/* exit immediately afterwards */
					break;
				case 'B': 			/* baud rate - we are on line */
				case 'b':
					init_flag = 0;
					user_baud = (unsigned int)atoi(cptr);
					switch (user_baud)
						{
						case 0:
						case 300:
						case 1200:
						case 2400:
						case 4800:
						case 9600:
						case 19200:
						case 38400:
							break;
						default:
							if (user_baud < 300)
								user_baud = 300;
							else if (user_baud < 1200)
								user_baud = 1200;
							else if (user_baud < 2400)
								user_baud = 2400;
							else if (user_baud < 4800)
								user_baud = 4800;
							else if (user_baud < 9600)
								user_baud = 9600;
							else if (user_baud < 19200)
								user_baud = 19200;
							else if (user_baud < 38400)
								user_baud = (int)38400U;
							break;
						}
					break;
#ifdef XSPAWN
				case 'O':			/* swap out memory before spawning */
				case 'o':
					_required = 0;
					_swap = 0;
					if (*cptr == 'D' || *cptr == 'd')
						_useems = 1;
					else if (*cptr == 'E' || *cptr == 'e')
						_useems = 0;
					else
						_useems = 0;

					if (cptr = getenv("TEMP"))		/* now for our swappath */
						strcpy(bbspath,cptr);
					else if (cptr = getenv("TMP"))
						strcpy(bbspath,cptr);
					else
						getcwd(bbspath,sizeof(bbspath));
					if (!(_swappath = malloc(strlen(bbspath) + 1)))
						{
						fprintf(stderr,"Fatal Error: Out of memory to allocate swappath.\n");
						return 1;
						}
					strcpy(_swappath,bbspath);
					break;
#endif
				case 'M': 			/* locked baud rate */
				case 'm':
					locked_flag = 1;
					locked_baud = (unsigned int)atoi(cptr);
					switch (locked_baud)
						{
						case 0:
						case 300:
						case 1200:
						case 2400:
						case 4800:
						case 9600:
						case 19200:
						case 38400:
							break;
						default:
							if (locked_baud < 300)
								locked_baud = 300;
							else if (locked_baud < 1200)
								locked_baud = 1200;
							else if (locked_baud < 2400)
								locked_baud = 2400;
							else if (locked_baud < 4800)
								locked_baud = 4800;
							else if (locked_baud < 9600)
								locked_baud = 9600;
							else if (locked_baud < 19200)
								locked_baud = 19200;
							else 
								locked_baud = (int)38400U;
							break;
						}
					break;
				case 'D':			/* Drop in with info in simplex.usr file */
				case 'd':
					drop_flag = 1;
					exit_flag = 1;
					break;
				case 'P':
				case 'p':
					port = atoi(cptr);
					break;
				case 'H':			/* do not hangup after call */
				case 'h':
					hangup_flag = 0;
					break;
				case 'R':
				case 'r':
					ringback_flag = 1;
					if (*cptr && isdigit(*cptr))
						{
						tval = atoi(cptr);
						if (tval >= 2 && tval <= 9)
							ringback_rings = tval;
						}
					break;
#ifndef PROTECTED
				case 'S':
				case 's':
					stdout_flag = 0;
					break;
#endif
				case 'T':
				case 't':
					time_flag = atoi(cptr);
					break;
				case 'X':			/* exit after call */
				case 'x':
					exit_flag = 1;
					break;
				case '?':
					fprintf(stderr,"Usage flags are as follows:\n\n");
					fprintf(stderr,"\t-A      Answer the phone immediately upon startup (Don't wait for ring)\n");
					fprintf(stderr,"\t-Bxxxx  Startup at the specified baud (User is online)\n");
					fprintf(stderr,"\t-D      Drop in to Simplex with user's info in simplex.usr (sets -X).\n");
#ifdef XSPAWN
					fprintf(stderr,"\t-O      Swap out to EMS or Disk when spawning external processes\n");
					fprintf(stderr,"\t-OD     Swap out to Disk when spawning external processes\n");
					fprintf(stderr,"\t-OE     Swap out to EMS when spawning external processes\n");
#endif
					fprintf(stderr,"\t-H      Do not hangup before exiting\n");
					fprintf(stderr,"\t-L      Startup in local mode (same as -B0 -X)\n");
#ifdef PROTECTED
					fprintf(stderr,"\t-Pxxx   Use the specified comm handle (already open)\n");
#else
					fprintf(stderr,"\t-Pxxx   Use the specified comm port\n");
#endif
					fprintf(stderr,"\t-Mxxxx  Locked baud rate. Set port to baud ignoring connect strings.\n");
					fprintf(stderr,"\t-R[x]   Do ringback model of call answering (optionally set number\n");
					fprintf(stderr,"\t        of rings to arm system [2-9].  Default is 3).\n");
#ifndef PROTECTED
					fprintf(stderr,"\t-S      Do not close stdout and reopen it to NUL\n");
#endif
					fprintf(stderr,"\t-Txxx   Set maximum time user is allowed on system\n");
					fprintf(stderr,"\t-X      Exit after carrier is lost or after logoff\n\n");
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */
					exit(1);
					break;
				}
			}
		}
	if ((!hangup_flag || time_flag) && !exit_flag)		/* no hangup flag must accompany exit! */
		hangup_flag = 1;

	if (cptr = getenv("SIMPLEX"))		/* now for our path */
		strcpy(bbspath,cptr);
	else
		getcwd(bbspath,sizeof(bbspath));

	if (bbspath[0] && bbspath[strlen(bbspath) - 1] != P_CSEP)
		strcat(bbspath,P_SSEP);

	if (share_installed = is_share())
		fprintf(stderr,"Detected networking/file-sharing conditions.\n");

	sprintf(buffer,"%ssimplex.log",bbspath);		/* now, open the usage log */
	if (!(logfd = fopen(buffer,"r+b")))
		{
		_error(E_NOTICE,"Creating new log file!");
		if (!(logfd = fopen(buffer,"w+b")))
			{
			_error(E_NOTICE,"Unable to open or create log file!");
			exit(1);
			}
		else
			{
			fprintf(logfd,"--------------------------------------------------\r\n");
#ifdef PROTECTED
	#ifdef MULTICHAT
			fprintf(logfd,"SIMPLEX/2-M BBS: Version %u.%02u.%02u%s Usage Log\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0? "�" : ""));
	#else
			fprintf(logfd,"SIMPLEX/2 BBS: Version %u.%02u.%02u%s Usage Log\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""));
	#endif
#elif defined(__ZTC__)
			fprintf(logfd,"SIMPLEX/S BBS: Version %u.%02u.%02u%s Usage Log\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0? "�" : ""));
#else
			fprintf(logfd,"SIMPLEX BBS: Version %u.%02u.%02u%s Usage Log\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "�" : ""));
#endif
			fprintf(logfd,"--------------------------------------------------\r\n");
			}
		}

	fseek(logfd,0L,SEEK_END);
	fprintf(logfd,"\r\n");
	log_entry(L_START,NULL);

	init_menus();
	open_files(0);

	if (!start_timer())
		_error(E_FATAL,"Unable to start timer...Aborting!");

	bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* prepare status lines */
	atexit(exit_list);

#if defined(PROTECTED) && defined(MULTICHAT)
	open_mc();
#endif

#ifndef PROTECTED
	reinit_screen();		/* now we have the cfg structure */
#endif

	start_bbs();

	if (echomail_entered && netmail_entered)
		{
		sprintf(buffer,"Echomail and Netmail entered -- exiting with errorlevel 5.");
		_error(E_NOTICE,buffer);
		errorlevel = 5;
		}
	else if (echomail_entered)
		{
		sprintf(buffer,"Echomail entered -- exiting with errorlevel 4.");
		_error(E_NOTICE,buffer);
		errorlevel = 4;
		}
	else if (netmail_entered)
		{
		sprintf(buffer,"Netmail entered -- exiting with errorlevel 3.");
		_error(E_NOTICE,buffer);
		errorlevel = 3;
		}
	else if (event_exit)
		{
		sprintf(buffer,"Event exit for \"%s\" with errorlevel %u.",next_etitle,errorlevel);
		_error(E_NOTICE,buffer);
		}
	else if (exit_flag)
		{
		sprintf(buffer,"Exit requested on command line -- exiting with errorlevel 2.");
		_error(E_NOTICE,buffer);
		errorlevel = 2;		/* errorlevel 2 if exit option was on command line */
		}
	else
		{
		sprintf(buffer,"Simplex exiting with errorlevel %u.",errorlevel);
		_error(E_NOTICE,buffer);
		}

	return errorlevel;
	}



void open_files(int type)
	{
	struct ut tut;
	char buffer[270];
	short count;
	short kount;
	int fh;

	sprintf(buffer,"%sconfig.bbs",bbspath);			/* now, open the configuration */
	if (!(cfgfd = fopen(buffer,"r+b")))
		_error(E_FATAL,"Unable to open configuration file...Aborting!");
	if (!fread(&cfg,1,sizeof(struct cfg),cfgfd))
		_error(E_FATAL,"Unable to read configuration file...Aborting!");

	sprintf(buffer,"Configuration file read - configured under version %lu.%02lu.%02lu.\r\n",cfg.cfg_version >> 16L,(cfg.cfg_version >> 8L) & 0xffL,cfg.cfg_version & 0xffL);
	_error(E_NOTICE,buffer);

	for (count = 0; count < cfg.cfg_uts; count++)			/* lets read in configured times */
		{
		if (fread(&tut,sizeof(struct ut),1,cfgfd))
			{
			if (tut.ut_priv < 256)
				{
				if (tut.ut_time > 1440)		/* 24 hours in minutes */
					tut.ut_time = 1440;
				else if (!tut.ut_time)
					tut.ut_time = 1;
				for (kount = tut.ut_priv; kount < 256; kount++)
					logon_times[kount] = tut.ut_time;
				}
			}
		}

	/* set up the colors! */
	switch (cfg.cfg_status)
		{
		case COLOR_ONBLUE:
			status_color[0] = WHITE | ON_BLUE;
			status_color[1] = WHITE | BRIGHT | ON_BLUE;
			status_color[2] = BROWN | BRIGHT | ON_BLUE;
			status_color[3] = GREEN | BRIGHT | BLINK | ON_BLUE;
			break;
		case COLOR_ONRED:
			status_color[0] = WHITE | ON_RED;
			status_color[1] = WHITE | BRIGHT | ON_RED;
			status_color[2] = BROWN | BRIGHT | ON_RED;
			status_color[3] = GREEN | BRIGHT | BLINK | ON_RED;
			break;
		case COLOR_ONBROWN:
			status_color[0] = WHITE | ON_BROWN;
			status_color[1] = WHITE | BRIGHT | ON_BROWN;
			status_color[2] = BROWN | BRIGHT | ON_BROWN;
			status_color[3] = GREEN | BRIGHT | BLINK | ON_BROWN;
			break;
		case COLOR_ONCYAN:
			status_color[0] = ON_CYAN;
			status_color[1] = WHITE | BRIGHT | ON_CYAN;
			status_color[2] = BROWN | BRIGHT | ON_CYAN;
			status_color[3] = BLINK | ON_CYAN;
			break;
		case COLOR_ONWHITE:
		default:
			status_color[0] = ON_WHITE;
			status_color[1] = ON_WHITE;
			status_color[2] = ON_WHITE;
			status_color[3] = ON_WHITE | BLINK;
			break;
		}

	switch (cfg.cfg_field)
		{
		case COLOR_ONRED:
			field_color = WHITE | BRIGHT | ON_RED;
			break;
		case COLOR_ONBROWN:
			field_color = WHITE | BRIGHT | ON_BROWN;
			break;
		case COLOR_ONCYAN:
			field_color = WHITE | BRIGHT | ON_CYAN;
			break;
		case COLOR_ONBLUE:
		default:
			field_color = WHITE | BRIGHT | ON_BLUE;
			break;
		}

	switch (cfg.cfg_menu)
		{
		case COLOR_GREEN:
			menu_color = GREEN | BRIGHT;
			break;
		case COLOR_CYAN:
			menu_color = CYAN | BRIGHT;
			break;
		case COLOR_MAGENTA:
			menu_color = MAGENTA | BRIGHT;
			break;
		case COLOR_YELLOW:
			menu_color = BROWN | BRIGHT;
			break;
		case COLOR_WHITE:
		default:
			menu_color = WHITE | BRIGHT;
			break;
		}

	if (port != -1)
		{
#ifndef PROTECTED
		cfg.cfg_port = port - 1;
#endif
		}
	fclose(cfgfd);
	
	sprintf(buffer,"%suserlist.bbs",bbspath);	   	/* now, open the user list */
	if (!(userfd = fopen(buffer,"r+b")))
		_error(E_FATAL,"Unable to open user file...Aborting!");

	total_users = (int)(filelength(fileno(userfd)) / (long)sizeof(struct user));

	sprintf(buffer,"%snongrata.bbs",bbspath);		/* now, open and get unwanted users */
	load_nongrata(buffer);

	sprintf(buffer,"%sbadalias.bbs",bbspath);		/* now, open and get bad alias names/stems */
	load_badalias(buffer);

	sprintf(buffer,"%smsgarea.bbs",bbspath); 		/* now, open and get message area */
	if (load_msgareas(buffer))
		{
		sprintf(buffer,"%smsghead.bbs",bbspath); 		/* now, open and get message headers */
		if (!(msghfd = fopen(buffer,"r+b")))
			{
			_error(E_WARNING,"Unable to open message header file...Creating!");
			if (!(msghfd = fopen(buffer,"w+b")))
				_error(E_FATAL,"Unable to create message header file...Aborting!");
			sprintf(buffer,"%smsgdata.bbs",bbspath); 		/* now, unlink message data file */
			if (access(buffer,0) != -1)
				{
				if (unlink(buffer))
					_error(E_FATAL,"Unable to delete message data file...Aborting!");
				}
			sprintf(buffer,"%smsgbody.bbs",bbspath); 		/* now, open and get message body */
			if (!(msgbfd = fopen(buffer,"w+b")))
				_error(E_FATAL,"Unable to create message body file...Aborting!");
			}
		else
			{
			sprintf(buffer,"%smsgbody.bbs",bbspath); 		/* now, open and get message body */
			if (!(msgbfd = fopen(buffer,"r+b")))
				_error(E_FATAL,"Unable to open message body file...Aborting!");
			}

		sprintf(buffer,"%smsgdata.bbs",bbspath); 		/* now, open message data file */
		if (access(buffer,0) == -1)
			{
			if (!(msgdfd = fopen(buffer,"w+b")))
				_error(E_FATAL,"Unable to create message data file...Aborting!");
			_error(E_WARNING,"Rebuilding message data file!");
			build_msgdata();
			}
		else
			{
			if (!(msgdfd = fopen(buffer,"r+b")))
				_error(E_FATAL,"Unable to open message data file...Aborting!");
			load_msgdata();
			}
		sprintf(buffer,"%smsglink.bbs",bbspath); 		/* now, open message link file */
		if (access(buffer,0) == -1)
			{
			if (!(msglfd = fopen(buffer,"w+b")))
				_error(E_FATAL,"Unable to create message link file...Aborting!");
			_error(E_WARNING,"Rebuilding message link file!");
			build_msglink();
			}
		else
			{
			if (!(msglfd = fopen(buffer,"r+b")))
				_error(E_FATAL,"Unable to open message link file...Aborting!");
			check_msglink();
			}
		sprintf(buffer,"%smsgread.bbs",bbspath);		/* now open message last read pointer file */
		if (access(buffer,0) == -1)
			{
			if (!(msgrfd = fopen(buffer,"w+b")))
				_error(E_FATAL,"Unable to create message lastread file...Aborting!");
			_error(E_WARNING,"Rebuilding message lastread file!");
			build_msglast();
			}
		else
			{
			if (!(msgrfd = fopen(buffer,"r+b")))
				_error(E_FATAL,"Unable to open message lastread file...Aborting!");
			if (!type)
				check_msglast();
			}
		if (check_netmail_area())
			{
			strcpy(buffer,cfg.cfg_nodepath);
			if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			strcat(buffer,"nodelist.dat");		/* now open nodelist file */
			if (share_installed)
				fh = sopen(buffer,O_RDONLY | O_BINARY,SH_DENYNO);
			else
				fh = open(buffer,O_RDONLY | O_BINARY);
			if (fh == -1)
				_error(E_FATAL,"Unable to open nodelist file...Aborting!");
			if (!(nlstfd = fdopen(fh,"rb")))
				_error(E_FATAL,"Unable to open nodelist file...Aborting!");

			strcpy(buffer,cfg.cfg_nodepath);
			if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			strcat(buffer,"nodelist.idx");		/* now open nodelist index file */
			if (share_installed)
				fh = sopen(buffer,O_RDONLY | O_BINARY,SH_DENYNO);
			else
				fh = open(buffer,O_RDONLY | O_BINARY);
			if (fh == -1)
				_error(E_FATAL,"Unable to open nodelist index file...Aborting!");
			if (!(nidxfd = fdopen(fh,"rb")))
				_error(E_FATAL,"Unable to open nodelist index file...Aborting!");
			}
		else
			{
			nlstfd = NULL;		/* used in closing files */
			nidxfd = NULL;
			}
		sprintf(buffer,"%smsgcomb.bbs",bbspath); 		/* now, open and get combination file */
		if (!(combfd = fopen(buffer,"r+b")))
			{
			_error(E_WARNING,"Unable to open combined message info file...Creating!");
			if (!(combfd = fopen(buffer,"w+b")))
				_error(E_WARNING,"Unable to create combined message info file...Aborting!");
			}
		}
	else
		{
		msghfd = NULL;		/* used in closing files */
		msgbfd = NULL;
		msgdfd = NULL;
		msglfd = NULL;
		msgrfd = NULL;
		combfd = NULL;
		_error(E_WARNING,"There are no message areas on this system!");
		}

	sprintf(buffer,"%sfilearea.bbs",bbspath); 		/* now, open and get file area */
	if (!load_fileareas(buffer))
		_error(E_WARNING,"There are no file areas on this system!");

	sprintf(buffer,"%sevents.bbs",bbspath); 		/* now, open and get event times */
	load_events(buffer);

	sprintf(buffer,"%suserinfo.bbs",bbspath); 		/* now, open and last user's info */
	if (!(uinfofd = fopen(buffer,"r+b")))
		{
		if (!(uinfofd = fopen(buffer,"w+b")))
			_error(E_FATAL,"Unable to open or create userinfo.bbs!");
		}

	strcpy(buffer,cfg.cfg_menupath);		/* check for main menu */
	if (buffer[0])
		{
		if (bbspath[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,"main.mnu");
	if (access(buffer,0) == -1)
		_error(E_FATAL,"Unable to find menu file \"main.mnu\"...Aborting!");

#ifndef PROTECTED
	if (stdout_flag)
		freopen("nul","w",stdout);		/* stdout is now pointing to the null device (for fossil signon message!) */
#endif
	}




