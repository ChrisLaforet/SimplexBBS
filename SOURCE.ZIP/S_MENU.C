/* s_menu.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 3 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_menu.c_v  $
**                       $Date:   25 Oct 1992 14:07:22  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include "simplex.h"


#define MENUTOP				100
#define MENU_REDRAW			-1
#define MENU_ERROR			-2
#define MENU_QUIT			-3
#define MENU_SKIP			-4

#define M_NORMAL			0
#define M_QUIT				1
#define M_RET				2




struct mac
	{
	char mac_letter;		/* letter of macro */
	char *mac_macro; 		/* macro string for macro letter */
	};


struct ms
	{
	char ms_name[10];		/* name of menu file */
	struct mac *ms_macros;
	int ms_curmacros;
	int ms_maxmacros;
	};



static struct ms _far menustack[MENUTOP];
static int _far menucurrent = 0;
static char _far hotkeys[200];		/* temporary!!  This must be allocated */
struct m _far menu;
extern jmp_buf reset_bbs;



int menu_handler(int key)
	{
	char *cptr = hotkeys;

	key = toupper(key);
	while (*cptr)
		{
		if (toupper((int)*cptr) == key)
			return key;
		++cptr;
		}
	return 0;
	}



void deinit_menus(void)		/* frees up memory */
	{
	int count;

	if (menu.m_curlines)
		{
		for (count = 0; count < menu.m_curlines; count++)
			free(menu.m_lines[count]);
		menu.m_curlines = 0;
		}
	}



void init_menus(void)
	{
	memset(&menu,0,sizeof(struct m));
	}



void parse_ms_macros(int current,char *cmdline)
	{
	char buffer[70];
	char *cptr;
	char letter;

	while (*cmdline)
		{
		if (isalpha(*cmdline) && *(cmdline + 1) == '=')
			{
			letter = (char)toupper(*cmdline);
			cptr = buffer;
			cmdline += 2;
			while (*cmdline && *cmdline != ' ')
				{
				if (*cmdline == '_')
					*cptr++ = ' ';
				else
					*cptr++ = *cmdline;

				++cmdline;
				}
			*cptr = (char)'\0';

			if (strlen(buffer))
				{
				if (menustack[current].ms_curmacros >= menustack[current].ms_maxmacros)
					{
					if (!(menustack[current].ms_macros = realloc(menustack[current].ms_macros,(menustack[current].ms_maxmacros += 5) * sizeof(struct mac))))
						{
						system_message("Fatal error loading template macros: Out of memory!");
						menustack[current].ms_macros = NULL;
						menustack[current].ms_curmacros = 0;
						menustack[current].ms_maxmacros = 0;
						return;
						}
					}
				if (!(menustack[current].ms_macros[menustack[current].ms_curmacros].mac_macro = malloc((strlen(buffer) + 1) * sizeof(char))))
					{
					system_message("Fatal error loading template macros: Out of memory!");
					menustack[current].ms_macros = NULL;
					menustack[current].ms_curmacros = 0;
					menustack[current].ms_maxmacros = 0;
					return;
					}
				strcpy(menustack[current].ms_macros[menustack[current].ms_curmacros].mac_macro,buffer);
				menustack[current].ms_macros[menustack[current].ms_curmacros].mac_letter = letter;
				++menustack[current].ms_curmacros;
				}
			}
		else 
			++cmdline;
		}
	return;
	}



void expand_data(char *dest,char *src,int current)
	{
	char *cptr;
	int count;
	int found;

	dest[0] = (char)'\0';
	if (menustack[current].ms_maxmacros)
		{
		cptr = src;
		while (*cptr)
			{
			if (*cptr != '$')
				{
				dest[strlen(dest) + 1] = '\0';
				dest[strlen(dest)] = *cptr;
				}
			else
				{
				found = 0;
				if (isupper(*(cptr + 1)))
					{
					for (count = 0; count < menustack[current].ms_maxmacros; count++)
						{
						if (*(cptr + 1) == menustack[current].ms_macros[count].mac_letter)
							{
							strcpy(dest + strlen(dest),menustack[current].ms_macros[count].mac_macro);
							found = 1;
							break;
							}
						}
					}
				if (!found)
					{
					dest[strlen(dest) + 1] = '\0';
					dest[strlen(dest)] = *cptr;
					}
				else 
					++cptr;		/* need to skip over $ and letter */
				}
			++cptr;
			}
		}
	else
		strcpy(dest,src);
	}



int do_menuitem(int which)
	{
	char buffer[100];
	char buffer1[70];
	char password[16];
	char tpassword[16];
	char data[255];
	char *cptr;
	char *cptr1;
	int replies;
	int attempt;
	int count;
	int kount;
	int tval;
	int retval = M_NORMAL;
	int tflag;
	int area;
	int days;
	int type;
	int rtn;
	int ok;
#ifdef SAUDI_NET
	int land = 0;
	int all = 1;
#endif

	type = (int)menu.m_lines[which]->menu_type;
	expand_data(data,menu.m_lines[which]->menu_data,menucurrent);
	cptr = data;		/* expanded data line */

	switch (type)
		{
		case MENU_SHOW:
			#ifdef MULTICHAT
				set_mc_location("");
			#endif
			break;
		case MENU_CALL:
			#ifdef MULTICHAT
				set_mc_location("");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			while (*cptr && *cptr <= ' ')
				++cptr;
			cptr1 = password;

			if (*cptr && *cptr != '/')		/* template begins with a / slash */
				{
				while (*cptr && *cptr > ' ')
					{
					*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (strlen(password) >= 15)
						break;
					}
				}
			else 
				*cptr1 = '\0';

			if (strlen(password))
				{
				ok = 0;
				attempt = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				sprintf(buffer,"\r\n\r\nThe menu \"%s\" is password-restricted.\r\n",buffer1);
				send_string(buffer,NULL);
				send_string("In order to access this area, you must provide\r\n",NULL);
				send_string("the correct password:\r\n\r\n",NULL);
				do
					{
					cur_line = 0;		/* defeats more */
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE | BRIGHT),NULL);
					send_string("\rPassword (ENTER=Exit)? ",NULL);
					get_password(tpassword,15);
					if (tpassword[0])
						{
						if (!stricmp(tpassword,password))
							ok = 1;
						else
							{
							sprintf(buffer,"\"%s\" provided to access \"%s\".",tpassword,buffer1);
							log_entry(L_INVALID_AREA_PWD,buffer);
							}
						}
					++attempt;
					}
				while (tpassword[0] && !ok && attempt < cfg.cfg_pwdtries);
				}
			else
				ok = 1;

			if (ok)
				{
				if (menucurrent >= (MENUTOP - 1))
					{
					sprintf(buffer,"Unable to call menu \"%s\" - stack is full!",buffer1);
					_error(E_ERROR,buffer);
					system_message(buffer);
					}
				else
					{
					++menucurrent;
					strcpy(menustack[menucurrent].ms_name,buffer1);
					menustack[menucurrent].ms_macros = NULL;
					menustack[menucurrent].ms_curmacros = 0;
					menustack[menucurrent].ms_maxmacros = 0;

					parse_ms_macros(menucurrent,cptr);
					retval = M_RET;
					}
				}
			break;
		case MENU_GOTO:
			#ifdef MULTICHAT
				set_mc_location("");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			while (*cptr && *cptr <= ' ')
				++cptr;
			cptr1 = password;

			if (*cptr && *cptr != '/')
				{
				while (*cptr && *cptr > ' ')
					{
					*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (strlen(password) >= 15)
						break;
					}
				}
			else 
				*cptr1 = '\0';
			if (strlen(password))
				{
				ok = 0;
				attempt = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				sprintf(buffer,"\r\n\r\nThe menu \"%s\" is password-restricted.\r\n",buffer1);
				send_string(buffer,NULL);
				send_string("In order to access this area, you must provide\r\n",NULL);
				send_string("the correct password:\r\n\r\n",NULL);
				do
					{
					cur_line = 0;		/* defeats more */
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE | BRIGHT),NULL);
					send_string("\rPassword (ENTER=Exit)? ",NULL);
					get_password(tpassword,15);
					if (tpassword[0])
						{
						if (!stricmp(tpassword,password))
							ok = 1;
						else
							{
							sprintf(buffer,"\"%s\" provided to access \"%s\".",tpassword,buffer1);
							log_entry(L_INVALID_AREA_PWD,buffer);
							}
						}
					++attempt;
					}
				while (tpassword[0] && !ok && attempt < cfg.cfg_pwdtries);
				}
			else
				ok = 1;

			if (ok)
				{
				menucurrent = 0;
				strcpy(menustack[0].ms_name,buffer1);
				menustack[0].ms_macros = NULL;
				menustack[0].ms_curmacros = 0;
				menustack[0].ms_maxmacros = 0;

				parse_ms_macros(0,cptr);
				retval = M_RET;
				}
			break;
		case MENU_REPLACE:
			#ifdef MULTICHAT
				set_mc_location("");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			while (*cptr && *cptr <= ' ')
				++cptr;
			cptr1 = password;

			if (*cptr && *cptr != '/')		/* template begins with a / slash */
				{
				while (*cptr && *cptr > ' ')
					{
					*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (strlen(password) >= 15)
						break;
					}
				}
			else 
				*cptr1 = '\0';

			if (strlen(password))
				{
				ok = 0;
				attempt = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				sprintf(buffer,"\r\n\r\nThe menu \"%s\" is password-restricted.\r\n",buffer1);
				send_string(buffer,NULL);
				send_string("In order to access this area, you must provide\r\n",NULL);
				send_string("the correct password:\r\n\r\n",NULL);
				do
					{
					cur_line = 0;		/* defeats more */
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE | BRIGHT),NULL);
					send_string("\rPassword (ENTER=Exit)? ",NULL);
					get_password(tpassword,15);
					if (tpassword[0])
						{
						if (!stricmp(tpassword,password))
							ok = 1;
						else
							{
							sprintf(buffer,"\"%s\" provided to access \"%s\".",tpassword,buffer1);
							log_entry(L_INVALID_AREA_PWD,buffer);
							}
						}
					++attempt;
					}
				while (tpassword[0] && !ok && attempt < cfg.cfg_pwdtries);
				}
			else
				ok = 1;

			if (ok)			/* replace current menu! */
				{
				strcpy(menustack[menucurrent].ms_name,buffer1);

				if (menustack[menucurrent].ms_maxmacros)
					free(menustack[menucurrent].ms_macros);
				menustack[menucurrent].ms_macros = NULL;
				menustack[menucurrent].ms_curmacros = 0;
				menustack[menucurrent].ms_maxmacros = 0;

				parse_ms_macros(menucurrent,cptr);
				}
			break;
		case MENU_RET:
			#ifdef MULTICHAT
				set_mc_location("");
			#endif
			if (menucurrent)
				{
				if (menustack[menucurrent].ms_maxmacros)
					free(menustack[menucurrent].ms_macros);

				--menucurrent;
				retval = M_RET;
				}
			break;

		case MENU_ENTER:
			#ifdef MULTICHAT
				set_mc_location("Message Editor");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				area = atoi(buffer1);
				cptr1 = NULL;
				while (*cptr)
					{
					while (*cptr && (*cptr != '/' && *cptr != '-'))
						++cptr;
					if (*cptr == '/' || *cptr == '-')
						{
						++cptr;
						if (*cptr == 'L' || *cptr == 'l')
							retval = M_QUIT;
						else if (*cptr == 'T' || *cptr == 't')
							{
							++cptr;
							if (*cptr == '=')
								{
								++cptr;
								cptr1 = buffer;
								while (*cptr && *cptr > ' ')
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								cptr1 = buffer;
								while (*cptr1)
									{
									if (*cptr1 == '_')
										*cptr1 = ' ';
									++cptr1;
									}
								cptr1 = buffer;
								}
							}
						}
					}
				dispatch_message(user.user_name,cptr1,NULL,area,user.user_priv,user.user_uflags,0,0,0,0,0,0);
				}
			break;
		case MENU_READ:
			#ifdef MULTICHAT
				set_mc_location("Message Reader");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				read_messages(atoi(buffer1),user.user_priv,user.user_uflags);
			break;
		case MENU_SCAN:
			#ifdef MULTICHAT
				set_mc_location("Message Scanner");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				scan(atoi(buffer1));
			break;
		case MENU_QSCAN:
			#ifdef MULTICHAT
				set_mc_location("Message Scanner");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				quickscan(atoi(buffer1));
			break;
		case MENU_USERLIST:
			#ifdef MULTICHAT
				set_mc_location("Userlist Scanner");
			#endif
			search_userlist();
			break;
		case MENU_NETSEARCH:
			#ifdef MULTICHAT
				set_mc_location("Netlist Scanner");
			#endif
			search_nodelist();
			break;
		case MENU_FREQ:
			#ifdef MULTICHAT
				set_mc_location("File-Request Generator");
			#endif
			make_freq();
			break;

#ifdef SAUDI_NET

		case MENU_SAUDI:
			#ifdef MULTICHAT
				set_mc_location("Message Editor");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				area = atoi(buffer1);
				cptr1 = NULL;
				while (*cptr)
					{
					while (*cptr && (*cptr != '/' && *cptr != '-'))
						++cptr;
					if (*cptr == '/' || *cptr == '-')
						{
						++cptr;
						if (*cptr == 'L' || *cptr == 'l')
							land = 1;
						else if (*cptr == 'A' || *cptr == 'a')
							all = 0;
						++cptr;
						}
					}
				enter_saudi(area,all,land);
				}
			break;

#endif

		case MENU_LIST:
			#ifdef MULTICHAT
				set_mc_location("Filearea Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				tflag = 1;
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr == '/' || *cptr == '-')
					{
					if (!strnicmp(cptr + 1,"NU",2))
						tflag = 0;
					}
				list_filearea(atoi(buffer1),0,tflag);
				}
			break;
		case MENU_REVLIST:
			#ifdef MULTICHAT
				set_mc_location("Filearea Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				tflag = 1;
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr == '/' || *cptr == '-')
					{
					if (!strnicmp(cptr + 1,"NU",2))
						tflag = 0;
					}
				list_filearea(atoi(buffer1),1,tflag);
				}
			break;
		case MENU_UPLOAD:
			#ifdef MULTICHAT
				set_mc_location("Upload");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				recv_file(atoi(buffer1));
			break;
		case MENU_DOWNLOAD:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (xmit_file(atoi(buffer1)))
					retval = M_QUIT;
				}
			break;
		case MENU_DOWNLOAD_FILE:
			#ifdef MULTICHAT
				set_mc_location("Download");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				area = atoi(buffer1);
				while (*cptr && *cptr <= ' ')
					++cptr;
				if (*cptr)
					{
					cptr1 = buffer1;
					while (*cptr && *cptr > ' ')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						rtn = xmit_onefile(area,buffer1,1);
						if (rtn == 2 || rtn == 3)
							{
							retval = M_QUIT;
							purge_input(cfg.cfg_port);
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN | BRIGHT),NULL);
							send_string("\r\n\r\n\aPreparing to hangup after download.  Press any key to abort hangup....",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(BROWN | BRIGHT),NULL);
							for (count = 10; retval && count > 0; count--)
								{
								if (count <= 5)
									send_string("\a",NULL);

								sprintf(buffer,"%u ",count);
								send_string(buffer,NULL);
								for (kount = 0; kount < 4; kount++)
									{
									sleep(240);		/* 1/4 sec + latency */

									if (user_baud)
										{
										if (peek_input(cfg.cfg_port) != -1)
											{
											read_input(cfg.cfg_port);
											retval = M_NORMAL;
											break;
											}
										else if (get_kb())
											{
											retval = M_NORMAL;
											break;
											}
										}
									else
										{
										if (get_kb())
											{
											retval = M_NORMAL;
											break;
											}
										}
									}
								for (kount = 0; kount < (int)strlen(buffer); kount++)
									send_string("\b",NULL);
								}
							send_string("\r\n\r\n",NULL);
							}
						}
					}
				}
			break;
		case MENU_RAW:
			#ifdef MULTICHAT
				set_mc_location("File Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				raw_filearea(atoi(buffer1));
			break;
		case MENU_CONTENTS:
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				show_contents(atoi(buffer1));
			break;
		case MENU_NEW:
			#ifdef MULTICHAT
				set_mc_location("File Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			tflag = 1;
			if (*cptr)
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr == '/' || *cptr == '-')
					{
					if (!strnicmp(cptr + 1,"NU",2))
						tflag = 0;
					}
				}
			if (buffer1[0])
				list_newfiles(atoi(buffer1),tflag);
			else
				list_newfiles(0,tflag);
			break;
		case MENU_SRCHNAME:
			#ifdef MULTICHAT
				set_mc_location("File Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			tflag = 1;
			if (*cptr)
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr == '/' || *cptr == '-')
					{
					if (!strnicmp(cptr + 1,"NU",2))
						tflag = 0;
					}
				}
			if (buffer1[0])
				search_filename(atoi(buffer1),tflag);
			else
				search_filename(0,tflag);
			break;
		case MENU_SRCHKEY:
			#ifdef MULTICHAT
				set_mc_location("File Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			tflag = 1;
			if (*cptr)
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr == '/' || *cptr == '-')
					{
					if (!strnicmp(cptr + 1,"NU",2))
						tflag = 0;
					}
				}
			if (buffer1[0])
				search_keyword(atoi(buffer1),tflag);
			else
				search_keyword(0,tflag);
			break;
		case MENU_KILL:
			#ifdef MULTICHAT
				set_mc_location("File Lister");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				kill_files(atoi(buffer1));
			break;
		case MENU_READFILE:
			#ifdef MULTICHAT
				set_mc_location("File Reader");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				read_files(atoi(buffer1));
			break;
		case MENU_MOVEFILES:
			#ifdef MULTICHAT
				set_mc_location("File Mover");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				move_files(atoi(buffer1));
			break;

		case MENU_XMITXMODEM:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					{
					if (xmit_files(atoi(buffer1),PROT_DIRECT))
						retval = M_QUIT;
					}
				else if (xmit_files(atoi(buffer1),PROT_XMODEM))
					retval  = M_QUIT;
				}
			break;
		case MENU_XMITXMODEM1K:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					{
					if (xmit_files(atoi(buffer1),PROT_DIRECT))
						retval = M_QUIT;
					}
				else if (xmit_files(atoi(buffer1),PROT_XMODEM1K))
					retval  = M_QUIT;
				}
			break;
		case MENU_XMITYMODEM:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					{
					if (xmit_files(atoi(buffer1),PROT_DIRECT))
						retval = M_QUIT;
					}
				else if (xmit_files(atoi(buffer1),PROT_YMODEM))
					retval  = M_QUIT;
				}
			break;
		case MENU_XMITYMODEMG:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					{
					if (xmit_files(atoi(buffer1),PROT_DIRECT))
						retval = M_QUIT;
					}
				else if (xmit_files(atoi(buffer1),PROT_YMODEMG))
					retval  = M_QUIT;
				}
			break;
		case MENU_XMITZMODEM:
			#ifdef MULTICHAT
				set_mc_location("Download Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					{
					if (xmit_files(atoi(buffer1),PROT_DIRECT))
						retval = M_QUIT;
					}
				else if (xmit_files(atoi(buffer1),PROT_ZMODEM))
					retval  = M_QUIT;
				}
			break;

		case MENU_RECVXMODEM:
			#ifdef MULTICHAT
				set_mc_location("Upload Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					recv_files(atoi(buffer1),PROT_DIRECT);
				else 
					recv_files(atoi(buffer1),PROT_XMODEM);
				}
			break;
		case MENU_RECVXMODEM1K:
			#ifdef MULTICHAT
				set_mc_location("Upload Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					recv_files(atoi(buffer1),PROT_DIRECT);
				else 
					recv_files(atoi(buffer1),PROT_XMODEM1K);
				}
			break;
		case MENU_RECVYMODEM:
			#ifdef MULTICHAT
				set_mc_location("Upload Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					recv_files(atoi(buffer1),PROT_DIRECT);
				else 
					recv_files(atoi(buffer1),PROT_YMODEM);
				}
			break;
		case MENU_RECVYMODEMG:
			#ifdef MULTICHAT
				set_mc_location("Upload Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					recv_files(atoi(buffer1),PROT_DIRECT);
				else 
					recv_files(atoi(buffer1),PROT_YMODEMG);
				}
			break;
		case MENU_RECVZMODEM:
			#ifdef MULTICHAT
				set_mc_location("Upload Protocol");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				if (!user_baud)
					recv_files(atoi(buffer1),PROT_DIRECT);
				else 
					recv_files(atoi(buffer1),PROT_ZMODEM);
				}
			break;

		case MENU_SHOWFILE:
		case MENU_SHOWHOT:		/* show with hotkeys is useless as a menu option! */
			#ifdef MULTICHAT
				set_mc_location("File Reader");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';		
			if (buffer1[0])
				send_ansifile(cfg.cfg_screenpath,buffer1,0);
			break;
		case MENU_SHOWWAIT:
			#ifdef MULTICHAT
				set_mc_location("File Reader");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				send_ansifile(cfg.cfg_screenpath,buffer1,0);
				get_enter();
				}
			break;
		case MENU_QUESTION:
			#ifdef MULTICHAT
				set_mc_location("Questionnaire");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				do_questionnaire(buffer1);
			break;
		case MENU_QUOTE:
			#ifdef MULTICHAT
				set_mc_location("Viewing Quote");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				do_quote(buffer1,1);
			break;


		case MENU_CITY:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_citystate();
			break;
		case MENU_PASSWORD:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_password();
			break;
		case MENU_CLS:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_cls();
			break;
		case MENU_MORE:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_more();
			break;
		case MENU_SCREENLEN:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_screenlen();
			break;
		case MENU_ANSI:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_ansi();
			break;
		case MENU_EDITOR:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_editor();
			break;
		case MENU_EXPERT:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_expert();
			break;
		case MENU_DATAPHONE:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_dataphone();
			break;
		case MENU_HOMEPHONE:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_homephone();
			break;
		case MENU_CHGADD1:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_address1();
			break;
		case MENU_CHGADD2:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_address2();
			break;
		case MENU_CHGCITY:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_city();
			break;
		case MENU_CHGSTATE:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_state();
			break;
		case MENU_CHGZIP:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_zip();
			break;
		case MENU_CHGALIAS:
			#ifdef MULTICHAT
				set_mc_location("Configuration Editor");
			#endif
			change_aliases();
			break;


		case MENU_ADENTER:
			#ifdef MULTICHAT
				set_mc_location("Message Editor");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				days = 0;
				replies = 0;
				while (*cptr)
					{
					while (*cptr && (*cptr != '/' && *cptr != '-'))
						++cptr;
					if (*cptr == '/' || *cptr == '-')
						{
						++cptr;
						if (*cptr == 'R' || *cptr == 'r')
							{
							++cptr;
							if (*cptr == '=')
								{
								++cptr;
								cptr1 = buffer;
								while (*cptr && isdigit(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								replies = atoi(buffer);
								if (!get_msgarea(replies))		/* not valid message area */
									replies = 0;
								}
							}
						else if (*cptr == 'D' || *cptr == 'd')
							{
							++cptr;
							if (*cptr == '=')
								{
								++cptr;
								cptr1 = buffer;
								while (*cptr && isdigit(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								days = atoi(buffer);
								}
							}
						}
					}
				if (days)
					enter_ads(buffer1,days,replies);
				}
			break;
		case MENU_ADREAD:
			#ifdef MULTICHAT
				set_mc_location("Message Reader");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				replies = 0;
				while (*cptr)
					{
					while (*cptr && (*cptr != '/' && *cptr != '-'))
						++cptr;
					if (*cptr == '/' || *cptr == '-')
						{
						++cptr;
						if (*cptr == 'R' || *cptr == 'r')
							{
							++cptr;
							if (*cptr == '=')
								{
								++cptr;
								cptr1 = buffer;
								while (*cptr && isdigit(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								replies = atoi(buffer);
								if (!get_msgarea(replies))		/* not valid message area */
									replies = 0;
								}
							}
						}
					}
				read_ads(buffer1,replies);
				}
			break;
		case MENU_ADSCAN:
			#ifdef MULTICHAT
				set_mc_location("Message Scanner");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 8)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				scan_ads(buffer1);
			break;

		case MENU_NEWPRIV:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				set_privilege(atoi(buffer1));
			break;
		case MENU_UPTIME:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				up_time(atoi(buffer1));
			break;
		case MENU_DOWNTIME:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				down_time(atoi(buffer1));
		  	break;
		case MENU_ADDFLAGS:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 60)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				add_flags(buffer1);
			break;
		case MENU_DELFLAGS:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && *cptr > ' ' && (cptr1 - buffer1) < 60)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				del_flags(buffer1);
			break;
		case MENU_SETTIME:
			#ifdef MULTICHAT
				set_mc_location("Internal Function");
			#endif
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				absolute_time(atoi(buffer1));
		  	break;
		case MENU_LOGENTRY:
			log_entry(L_SYSOP_DEFINED,data);
			break;
		case MENU_SYSOPALERT:
			sound_tone(262,30);		/* C */
			sound_tone(330,30);		/* E */
			sound_tone(392,30);		/* G */
			sound_tone(523,30);		/* C' */
			sound_tone(659,30);		/* E' */
			sound_tone(784,30);		/* G' */
			sound_tone(1047,30);	/* C" */
			sound_tone(1319,30);	/* E" */
			sound_tone(1047,30);	/* C" */
			sound_tone(784,30);		/* G' */
			sound_tone(659,30);		/* E' */
			sound_tone(523,30);		/* C' */
			sound_tone(392,30);		/* G */
			sound_tone(330,30);		/* E */
			sound_tone(262,30);		/* C */
			break;

		case MENU_SETCOMB:
			#ifdef MULTICHAT
				set_mc_location("Combination Boards");
			#endif
			set_combination();
			break;
		case MENU_READCOMB:
			#ifdef MULTICHAT
				set_mc_location("Message Reader");
			#endif
			read_combination();
			break;
		case MENU_SCANCOMB:
			#ifdef MULTICHAT
				set_mc_location("Message Scanner");
			#endif
			scan_combination();
			break;
		case MENU_QSCANCOMB:
			#ifdef MULTICHAT
				set_mc_location("Message Scanner");
			#endif
			qscan_combination();
			break;
		case MENU_DLCOMB:
			#ifdef MULTICHAT
				set_mc_location("Message Reader");
			#endif
			if (download_combination())
				retval = M_QUIT;
			break;
		case MENU_CFGCOMB:
			#ifdef MULTICHAT
				set_mc_location("Combination Boards");
			#endif
			configure_combination();
			break;
		case MENU_ULCOMB:
			#ifdef MULTICHAT
				set_mc_location("Message Uploader");
			#endif
			receive_qwk_mail();
			break;

		case MENU_RUN:
			if (user_time < 120L)
				_error(E_WARNING,"Cannot run an external program/door with less than 2 minutes left.");
			else
				{
				#ifdef MULTICHAT
					set_mc_location("External Program");
				#endif
				run_program(cptr);
				}
			break;
		case MENU_VERS:
			#ifdef MULTICHAT
				set_mc_location("Version Information");
			#endif
			show_version();
			break;
		case MENU_USAGE:
			#ifdef MULTICHAT
				set_mc_location("Usage Information");
			#endif
			show_usage();
			break;
		case MENU_YELL:
			#ifdef MULTICHAT
				set_mc_location("Yell/Chat");
				yell_mc();
			#else
				yell(0);
			#endif
			break;
		case MENU_TIMELESS_YELL:
			#ifdef MULTICHAT
				set_mc_location("Yell/Chat");
				yell_mc();
			#else
				yell(1);
			#endif
			break;
		case MENU_CLOCK:
			#ifdef MULTICHAT
				set_mc_location("Time Information");
			#endif
			show_clock();
			break;
		case MENU_CHECKMAIL:
			#ifdef MULTICHAT
				set_mc_location("Mail Check");
			#endif
			check_mail();
			break;
		case MENU_USERUPGRADE:
			#ifdef MULTICHAT
				set_mc_location("User Editing Utility");
			#endif
			update_users();
			break;
		case MENU_PHONEDUP:
			cptr1 = buffer1;
			while (*cptr && isdigit(*cptr) && (cptr1 - buffer1) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer1[0])
				{
				area = atoi(buffer1);
				cptr1 = buffer;
				while (*cptr)
					{
					while (*cptr && isspace(*cptr))
						++cptr;

					if (*cptr)
						{
						while (*cptr)
							{
							tval = toupper(*cptr);
							if (tval >= 'A' && tval <= 'P')
								*cptr1++ = *cptr++;
							else
								break;
							}
						}
					}
				*cptr1 = (char)'\0';
				check_duplicates(area,buffer);
				}
			break;
		case MENU_LOGOFF:
			#ifdef MULTICHAT
				set_mc_location("Logout");
			#endif
			retval = M_QUIT;
			break;
		}
	return retval;
	}



int load_menu(char *menuname)
	{
	struct menu tmenu;
	char buffer[100];
	int count;
	FILE *fd;

	if (!stricmp(menu.m_name,menuname))
		return 0;			/* already in memory */
	
	strcpy(buffer,cfg.cfg_menupath);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,menuname);
	if (buffer[strlen(buffer) - 1] != '.')
		strcat(buffer,".");
	strcat(buffer,"MNU");

	if (fd = fopen(buffer,"rb"))
		{
		if (menu.m_curlines)
			{
			for (count = 0; count < menu.m_curlines; count++)
				free(menu.m_lines[count]);
			menu.m_curlines = 0;
			}

		if (!fread(&menu.m_prompt,1,sizeof(struct prompt),fd))
			{
			fclose(fd);
			return 1;		/* invalid file */
			}
		if (menu.m_prompt.prompt_sig != M_SIGNATURE)
			{
			fclose(fd);
			return 1;		/* invalid file */
			}
	   	strncpy(menu.m_name,menuname,8);
		while (fread(&tmenu,1,sizeof(struct menu),fd))
			{
			if (menu.m_curlines >= menu.m_maxlines)
				{
				if (!(menu.m_lines = realloc(menu.m_lines,(menu.m_maxlines += 20) * sizeof(struct menu *))))
					{
					menu.m_lines = NULL;
					menu.m_curlines = 0;
					menu.m_maxlines = 0;
					menu.m_name[0] = '\0';

					system_message("Fatal error loading menu: Out of memory!");
					return 1;
					}
				}
			if (!(menu.m_lines[menu.m_curlines] = malloc(sizeof(struct menu))))
				{
				for (count = 0; count < menu.m_curlines; count++)
					free(menu.m_lines[count]);
				free(menu.m_lines);
				menu.m_lines = NULL;
				menu.m_curlines = 0;
				menu.m_maxlines = 0;
				menu.m_name[0] = '\0';
				menu.m_name[0] = '\0';
				
				system_message("Fatal error loading menu: Out of memory!");
				return 1;
				}
			memcpy(menu.m_lines[menu.m_curlines],&tmenu,sizeof(struct menu));
			++menu.m_curlines;
			}
		fclose(fd);
		}
	else
		return 1;			/* file is not there */
	return 0;
	}



int show_menu_line(char *template,struct mac *macros,int max_macros,int color,int hicolor,int no_nl)
	{
	char buffer[256];
	char *cptr;
	DATE_T tdate;
	TIME_T ttime;
	int our_color = cur_color;
	int prev_color;
	int key;
	int temp;
	int do_nl = 1;
	int which = 0;
	int count;

	prev_color = our_color;
	our_color = color;
	buffer[0] = '\0';
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		strcat(buffer,new_color1(our_color,prev_color));
	cptr = template;
	while (*cptr)
		{
		if (*cptr != '$' && *cptr != '^')
			{
			buffer[strlen(buffer) + 1] = '\0';
			buffer[strlen(buffer)] = *cptr;
			}
		else if (*cptr == '^')
			{
			if (*(cptr + 1) == '^')
				{
				strcat(buffer,"^");
				++cptr;
				}
			else
				{
				which = which ? 0 : 1;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					{
					prev_color = our_color;
					our_color = which ? hicolor : color;
					strcat(buffer,new_color1(our_color,prev_color));
					}
				}
			}
		else 
			{
			switch (*(cptr + 1))
				{
				case '$':
					strcat(buffer,"$");
					++cptr;
					break;
				case 'd':
					tdate = get_cdate();
					temp = ((tdate >> 5) & 0xf) - 1;
					if (temp && (temp >= 12 || temp < 0))
						temp = 11;
					sprintf(buffer + strlen(buffer),"%2d %s %02d",tdate & 0x1f,months_table[temp],((tdate >> 9) + 1980) % 100);
					++cptr;
					break;
				case 't':
					ttime = get_ctime();
					sprintf(buffer + strlen(buffer),"%2d:%02d ",ttime >> 11,(ttime >> 5) & 0x3f);
					++cptr;
					break;
				case 'r':
					sprintf(buffer + strlen(buffer),"%u",(int)(user_time / 60L) + 1);
					++cptr;
					break;
				case 'b':
					if (user_baud)
						sprintf(buffer + strlen(buffer),"%u",user_baud);
					else
						strcat(buffer,"Local");
					++cptr;
					break;
				case 'f':
					strcat(buffer,user_firstname);
					++cptr;
					break;
				case 'l':
					strcat(buffer,user_lastname);
					++cptr;
					break;
				case 'u':
					sprintf(buffer + strlen(buffer),"%u",user_number);
					++cptr;
					break;
				case 'a':
					sprintf(buffer + strlen(buffer),"%s",user.user_flags & USER_ANSI ? "ON" : "OFF");
					++cptr;
					break;
				case 'c':
					if (*(cptr + 2))
						++cptr;		/* continue must be LAST on line */
					else
						{
						do_nl = 0;		/* skip NL */
						++cptr;
						}
					break;
				default:
					if (isupper(*(cptr + 1)))
						{
						for (count = 0; count < max_macros; count++)
							{
							if (*(cptr + 1) == macros[count].mac_letter)
								{
								strcpy(buffer + strlen(buffer),macros[count].mac_macro);
								break;
								}
							}
						}
					++cptr;
					break;
				}
			}
		++cptr;
		}
	if (do_nl && !no_nl)
		strcat(buffer,"\r\n");
	cur_line = 0;
	if (key = send_buffer(buffer,(int)strlen(buffer),menu_handler))
		return key;		/* return hotkey */
	return 0;
	}



int send_hotkey_file(char *filename)
	{
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int rtn;

	strcpy(buffer,cfg.cfg_screenpath);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		_makepath(buffer,drive,path,fname,"ANS");
		if (!access(buffer,0))
			{
			_makepath(buffer,"","",filename,"ANS");
			return send_file(cfg.cfg_screenpath,buffer,1,menu_handler);
			}
		}
	_makepath(buffer,"","",filename,"ASC");
	rtn = send_file(cfg.cfg_screenpath,buffer,1,menu_handler);

	if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string("\x1b[0m",NULL);
	return rtn;
	}



int show_menu(char *menuname,struct mac *macros,int max_macros)
	{
	char buffer[150];
	char data[255];
	char *cptr;
	char *cptr1;
	int cur_priv = user.user_priv;
	int our_color = cur_color;
	int prev_color;
	int count;
	int kount;
	int quit = 0;
	int key;
	int rtn;

	if (load_menu(menuname))
		return MENU_ERROR;

	cptr = hotkeys;
	for (count = 0; count < menu.m_curlines; count++)
		{
		if (menu.m_lines[count]->menu_key && ((int)menu.m_lines[count]->menu_priv <= cur_priv) && ((menu.m_lines[count]->menu_flags & user.user_uflags) == menu.m_lines[count]->menu_flags))
			{
			if (isalpha(menu.m_lines[count]->menu_key))
				{
				*cptr++ = (char)tolower(menu.m_lines[count]->menu_key);
				*cptr++ = (char)toupper(menu.m_lines[count]->menu_key);
				}
			else
				*cptr++ = menu.m_lines[count]->menu_key;
			}
		}
	*cptr = '\0';

	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n\r\n",NULL);

	for (count = 0; count < menu.m_curlines; count++)
		{
		if (((int)menu.m_lines[count]->menu_priv <= cur_priv) && ((menu.m_lines[count]->menu_flags & user.user_uflags) == menu.m_lines[count]->menu_flags))
			{
			if (!(user.user_flags & USER_EXPERT) || menu.m_lines[count]->menu_expert)
				{
				if (key = show_menu_line(menu.m_lines[count]->menu_line,macros,max_macros,(unsigned char)menu.m_lines[count]->menu_color,(unsigned char)menu.m_lines[count]->menu_hilite,0))
					{
					for (kount = 0; kount < menu.m_curlines; kount++)
						{
						if (user.user_priv >= menu.m_lines[kount]->menu_priv)
							{
							if (toupper(key) == toupper(menu.m_lines[kount]->menu_key))
								return kount;
							}
						}
					}
				}
			if (menu.m_lines[count]->menu_auto)		/* autoexecute menu item */
				{
				if (menu.m_lines[count]->menu_type == MENU_SHOWHOT || menu.m_lines[count]->menu_type == MENU_SHOWHOT_NOEXPERT)
					{
					if (menu.m_lines[count]->menu_type == MENU_SHOWHOT || (menu.m_lines[count]->menu_type == MENU_SHOWHOT_NOEXPERT && !(user.user_flags & USER_EXPERT)))
						{
						expand_data(data,menu.m_lines[count]->menu_data,menucurrent);
						cptr = data;
						cptr1 = buffer;
						while (*cptr && *cptr > ' ' && (cptr1 - buffer) < 8)
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
						if (buffer[0])
							{
							if (key = send_hotkey_file(buffer))
								{
								for (kount = 0; kount < menu.m_curlines; kount++)
									{
									if (user.user_priv >= menu.m_lines[kount]->menu_priv)
										{
										if (toupper(key) == toupper(menu.m_lines[kount]->menu_key))
											return kount;
										}
									}
								}
							}
						}
					}
				else
					{
					rtn = do_menuitem(count);
					if (rtn == M_QUIT)
						return MENU_QUIT;
					else if (rtn == M_RET)
						return MENU_SKIP;
					}
				}
			}
		}

	if (user.user_flags & USER_EXPERT)		/* expert mode reminder keys */
		{
		cur_line = 0;
		send_string("\r\n",NULL);
		buffer[0] = '\0';
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			prev_color = our_color;
			our_color = CYAN | BRIGHT;
			strcat(buffer,new_color1(our_color,prev_color));
			}
		strcat(buffer,"Expert Mode Keys: [ ");
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			prev_color = our_color;
			our_color = BROWN | BRIGHT;
			strcat(buffer,new_color1(our_color,prev_color));
			}
		for (count = 0; count < menu.m_curlines; count++)
			{
			if ((int)menu.m_lines[count]->menu_priv <= cur_priv && menu.m_lines[count]->menu_key && (menu.m_lines[count]->menu_flags & user.user_uflags) == menu.m_lines[count]->menu_flags)
				{
				buffer[strlen(buffer) + 1] = '\0';
				buffer[strlen(buffer)] = menu.m_lines[count]->menu_key;
				}
			}
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			prev_color = our_color;
			our_color = CYAN | BRIGHT;
			strcat(buffer,new_color1(our_color,prev_color));
			}
		strcat(buffer," ]\r\n");
		if (key = send_buffer(buffer,(int)strlen(buffer),menu_handler))
			{
			for (kount = 0; kount < menu.m_curlines; kount++)
				{
				if (user.user_priv >= menu.m_lines[kount]->menu_priv)
					{
					if (toupper(key) == toupper(menu.m_lines[kount]->menu_key))
						return kount;
					}
				}
			}
		}

	/* now for the prompt */
	send_string("\r\n",NULL);
	if (key = show_menu_line(menu.m_prompt.prompt_string,macros,max_macros,(unsigned char)menu.m_prompt.prompt_color,(unsigned char)menu.m_prompt.prompt_hilite,1))
		{
		for (kount = 0; kount < menu.m_curlines; kount++)
			{
			if (user.user_priv >= menu.m_lines[kount]->menu_priv)
				{
				if (toupper(key) == toupper(menu.m_lines[kount]->menu_key))
					return kount;
				}
			}
		}
	send_string(" ",NULL);

	do				/* sitting at prompt */
		{
		#ifdef MULTICHAT
			key = get_mc_char();
		#else
			key = get_char();
		#endif
		if (key == '\r' || key == '\n')
			return MENU_REDRAW;		/* return hotkey */
		for (count = 0; count < menu.m_curlines; count++)
			{
			if (user.user_priv >= menu.m_lines[count]->menu_priv && ((menu.m_lines[count]->menu_flags & user.user_uflags) == menu.m_lines[count]->menu_flags))
				{
				if (toupper(key) == toupper(menu.m_lines[count]->menu_key))
					{
					buffer[0] = (char)key;
					buffer[1] = (char)'\0';
					send_string(buffer,NULL);
					quit = 1;
					break;
					}
				}
			}
		}
	while (!quit);
	return count;
	}



void do_menus(void)
	{
	char buffer[81];
	int quit = 0;
	int ret;

	strcpy(menustack[menucurrent].ms_name,"main");
	menustack[menucurrent].ms_macros = NULL;
	menustack[menucurrent].ms_curmacros = 0;
	menustack[menucurrent].ms_maxmacros = 0;

#ifdef MULTICHAT
	set_mc_location("");
#endif
	do
		{
		if ((ret = show_menu(menustack[menucurrent].ms_name,menustack[menucurrent].ms_macros,menustack[menucurrent].ms_curmacros)) == MENU_ERROR)
			{
			if (menucurrent)
				{
				sprintf(buffer,"Menu \"%s\" not found - returning to previous menu!",menustack[menucurrent].ms_name);
				_error(E_ERROR,buffer);
				system_message(buffer);
				--menucurrent;
				}
			else
				{
				if (stricmp(menustack[menucurrent].ms_name,"main"))
					{
					sprintf(buffer,"Menu \"%s\" not found - loading main menu!",menustack[menucurrent].ms_name);
					_error(E_ERROR,buffer);
					system_message(buffer);
					}
				else
					{
					sprintf(buffer,"Unable to load main menu -- Hanging up!");
					_error(E_ERROR,buffer);
					system_message(buffer);
					hangup();
					longjmp(reset_bbs,2);
					}

				menucurrent = 0;
				strcpy(menustack[menucurrent].ms_name,"main");
				menustack[menucurrent].ms_macros = NULL;
				menustack[menucurrent].ms_curmacros = 0;
				menustack[menucurrent].ms_maxmacros = 0;
				}
			}
		else if (ret == MENU_QUIT)
			quit = 1;
		else if (ret != MENU_REDRAW && ret != MENU_QUIT && ret != MENU_SKIP)
			{
			if (do_menuitem(ret) == M_QUIT)
				quit =1;
			}
		}
	while (!quit);
	}
