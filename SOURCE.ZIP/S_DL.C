/* s_dl.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 17 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_dl.c_v  $
**                       $Date:   25 Oct 1992 14:08:40  $
**                       $Revision:   1.23  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#ifndef __ZTC__
	#include <time.h>
#endif
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#include "simplex.h"


struct fl **flist = NULL;
int max_flist = 0;
int cur_flist = 0;
char **fnames = NULL;
int max_fnames = 0;
int cur_fnames = 0;
static int _far day_table[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

char _far *protocol_list = "<1> Xmodem         <2> Xmodem-1K\r\n<3> Ymodem-Batch   <4> Ymodem-G (** MNP/v42bis ONLY **)\r\n<5> Zmodem\r\n<?> Help!          <X> Exit\r\n\r\n";

#ifdef __ZTC__
	extern long time(long *);
#endif



long getseconds(DATE_T date,TIME_T time)
	{
	int tmp1;
	int tmp2;
	long tlong;
	int leap = 0;
	int count;

	tmp1 = date >> 9;			/* year from 1980 */
	tmp1 += 1980;				
	tmp2 = (date >> 5) & 0xf;	/* month */
	if (!(tmp1 % 4))
		leap = 1;
	tlong = 0L;
	for (count = 1970; count < tmp1; count++)
		{
		if (!(count % 4))
			tlong += 366;
		else
			tlong += 365;
		}
	for (count = 1; count < tmp2; count++)
		tlong += day_table[count - 1];
	if ((tmp2 > 2) && leap)
		++tlong;
	tlong += date & 0x1f;
	tlong *= 86400;		/* number of seconds in a day */
	tlong += (long)((time >> 11) * 60L);
	tlong += (long)((time >> 5) & 0x3f);
	tlong += ((long)(time & 0x1f) << 1L);

	return tlong;
	}



int check_fname(struct file *tfile,char *fname)
	{
	struct fe tfe;
	char buffer[100];
	int ok = 0;
	FILE *fd;

	strcpy(buffer,tfile->file_pathname);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,fname);
	if (!access(buffer,0))
		{
		if (tfile->file_number != 0)			/* real file area */
			{
			if (tfile->file_descname[0])
				strcpy(buffer,tfile->file_descname);
			else 
				strcpy(buffer,tfile->file_pathname);
			if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			strcat(buffer,"filelist.bbs");

			if (fd = open_filelist_read(buffer))
				{
				while (fread(&tfe,sizeof(struct fe),1,fd))
					{
					if (!stricmp(tfe.fe_name,fname))
						{
						if (tfe.fe_priv <= user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
							ok = 1;
						break;
						}
					}
				closef(fd);
				}
			}
		else
			ok = 1;			/* special condition - fileattach or QWK packet */

		return ok;
		}
	return 0;
	}



int expand_fname(struct file *tfile,char *fname,int protocol,int crossarea)
	{
	struct file *tfile1;
	struct file *tfile2;
	struct fi tfi;
	struct fe tfe;
	char buffer[100];
	char buffer1[100];
	char *cptr;
	long newtime;
	long eta = 0L;
	long ftime;
	int wildcard = 0;
	int found = 0;
	int hicolor;
	int color;
	int lfflag;
	int valid;
	int count;
	int kount;
	int skip;
	FILE *fd;

	if (protocol != PROT_DIRECT)
		{
		for (count = 0; count < cur_flist; count++)
			eta += xmit_time(protocol,flist[count]->fl_size);
		}

	if (tfile->file_descname[0])
		strcpy(buffer,tfile->file_descname);
	else 
		strcpy(buffer,tfile->file_pathname);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,"filelist.bbs");

	if (fd = open_filelist_read(buffer))
		{
		/* check file access permissions */
		while (fread(&tfe,sizeof(struct fe),1,fd))
			{
			if (check_fnames(fname,tfe.fe_name))
				{
				if (tfe.fe_location == tfile->file_number || (tfile1 = get_filearea(tfe.fe_location)))		/* location is current area, or we can find it */
					{
					if (tfe.fe_priv <= user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
						{
						if (tfe.fe_location == tfile->file_number)
							strcpy(buffer,tfile->file_pathname);
						else 
							strcpy(buffer,tfile1->file_pathname);

						if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						strcat(buffer,tfe.fe_name);

						if (get_firstfile(&tfi,buffer))
							{
							skip = 0;
							found = 1;			/* we found a match -- skip cross-area search */
							for (count = 0; count < cur_flist; count++)
								{
								if (!stricmp(tfi.fi_name,flist[count]->fl_name))
									skip = 1;
								}

							if (!skip && protocol != PROT_DIRECT)
								{
								ftime = xmit_time(protocol,tfi.fi_size);
								newtime = eta + ftime;
								if (newtime > user_time)
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									sprintf(buffer,"Download of \"%s\" will exceed your time.  Skipping.\r\n",tfi.fi_name);
									send_string(buffer,NULL);
									skip = 1;
									}
								else
									eta = newtime;
								}
							if (!skip)
								{
								if (cur_flist >= max_flist)
									{
									if (!(flist = realloc(flist,(max_flist += 10) * sizeof(struct fl *))))
										{
										_error(E_ERROR,"Unable to allocate memory for filenames.");
										cur_flist = 0;
										max_flist = 0;
										get_closefile();
										closef(fd);
										return 1;
										}
									}
								if (!(flist[cur_flist] = malloc(sizeof(struct fl))))
									{
									_error(E_ERROR,"Unable to allocate memory for filenames.");
									cur_flist = 0;
									max_flist = 0;
									get_closefile();
									closef(fd);
									return 1;
									}
								if (!(flist[cur_flist]->fl_name = malloc(strlen(tfi.fi_name) + 1)))
									{
									_error(E_ERROR,"Unable to allocate memory for filenames.");
									cur_flist = 0;
									max_flist = 0;
									get_closefile();
									closef(fd);
									return 1;
									}
								strcpy(flist[cur_flist]->fl_name,tfi.fi_name);
								flist[cur_flist]->fl_location = tfe.fe_location;
								flist[cur_flist]->fl_size = tfi.fi_size;
								flist[cur_flist]->fl_date = tfi.fi_date;
								++cur_flist;

								sprintf(buffer,"%5u  ",cur_flist);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%-12.12s ",tfi.fi_name);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(BROWN | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%9lu ",tfi.fi_size);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(MAGENTA),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_string(buffer,NULL);

								if (protocol != PROT_DIRECT)
									{
									sprintf(buffer,"%3lu:%02lu -> %lu:%02lu",ftime / 60L,ftime % 60L,eta / 60L,eta % 60L);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(WHITE | BRIGHT),NULL);
									send_string(buffer,NULL);
									}
								send_string("\r\n",NULL);
								}
//12345>  FILENAME.EXT     SIZEBYTES  DATE   DL-TIME -> TOTALTIME
							}
						get_closefile();
						}
					}
				}
			}
		closef(fd);
		}

	if (!found && crossarea)
		{
		cptr = fname;			/* check for wildcards */
		while (*cptr)
			{
			if (*cptr == '*' || *cptr == '?')
				wildcard = 1;
			++cptr;
			}

		if (!wildcard)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nThe file \"",NULL);
			send_string(fname,NULL);
			send_string("\" was not found here.  Want me to search across\r\n",NULL);
			send_string("all file areas for it (Y/n)? ",NULL);
			if (get_yn_enter(1))
				{
				send_string("\r\n",NULL);
				for (count = get_minfilearea(); count <= get_maxfilearea(); count++)
					{
					if (count != tfile->file_number)
						{
						if (tfile1 = get_filearea(count))
							{
							if (user.user_priv >= tfile1->file_priv && (tfile1->file_flags & user.user_uflags) == tfile1->file_flags)
								{
								if (tfile1->file_descname[0])
									strcpy(buffer,tfile1->file_descname);
								else 
									strcpy(buffer,tfile1->file_pathname);
								if (buffer[0])
									{
									if (buffer[strlen(buffer) - 1] != P_CSEP)
										strcat(buffer,P_SSEP);
									}
								strcat(buffer,"filelist.bbs");

								strcpy(filepath,tfile1->file_pathname);
								if (filepath[0])
									{
									if (filepath[strlen(filepath) - 1] != P_CSEP)
										strcat(filepath,P_SSEP);
									}

								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									{
									color = count & 0x7;
									color = color ? color : 7;
									hicolor = color | 0x8;
									send_string(new_color(color),NULL);
									}

								send_string("Area: ",NULL);
								strcpy(buffer1,tfile1->file_areaname);
								for (kount = (int)strlen(buffer1); kount < 40; kount++)
									strcat(buffer1," ");
								strcat(buffer1,"\r");
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(hicolor),NULL);
					    		send_string(buffer1,NULL);
								lfflag = 0;

								if (fd = open_filelist_read(buffer))		/* now open the list file itself */
									{
									while (fread(&tfe,sizeof(struct fe),1,fd))
										{
										if (check_fnames(fname,tfe.fe_name))
											{
											if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
												{
												valid = 1;
												if (tfe.fe_location == count)
													strcpy(buffer,filepath);
												else if (tfile2 = get_filearea(tfe.fe_location))
													{
													strcpy(buffer,tfile2->file_pathname);
													if (buffer[0])
														{
														if (buffer[strlen(buffer) - 1] != P_CSEP)
															strcat(buffer,P_SSEP);
														}
													}
												else
													valid = 0;

												if (valid)
													{
													strcat(buffer,tfe.fe_name);
													if (get_firstfile(&tfi,buffer))
														{
														skip = 0;
														for (kount = 0; kount < cur_flist; kount++)
															{
															if (!stricmp(tfi.fi_name,flist[kount]->fl_name) && tfe.fe_location == flist[kount]->fl_location)
																skip = 1;
															}

														if (!skip && protocol != PROT_DIRECT)
															{
												 			if (!lfflag)
												 				{
											 					send_string("\n",NULL);
											 					lfflag = 1;
											 					}

															ftime = xmit_time(protocol,tfi.fi_size);
															newtime = eta + ftime;
															if (newtime > user_time)
																{
																if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																	send_string(new_color(RED | BRIGHT),NULL);
																sprintf(buffer,"Download of \"%s\" will exceed your time.  Skipping.\r\n",tfi.fi_name);
																send_string(buffer,NULL);
																skip = 1;
																}
															else
																eta = newtime;
															}
														if (!skip)
															{
															if (cur_flist >= max_flist)
																{
																if (!(flist = realloc(flist,(max_flist += 10) * sizeof(struct fl *))))
																	{
																	_error(E_ERROR,"Unable to allocate memory for filenames.");
																	cur_flist = 0;
																	max_flist = 0;
																	get_closefile();
																	closef(fd);
																	return 1;
																	}
																}
															if (!(flist[cur_flist] = malloc(sizeof(struct fl))))
																{
																_error(E_ERROR,"Unable to allocate memory for filenames.");
																cur_flist = 0;
																max_flist = 0;
																get_closefile();
																closef(fd);
																return 1;
																}
															if (!(flist[cur_flist]->fl_name = malloc(strlen(tfi.fi_name) + 1)))
																{
																_error(E_ERROR,"Unable to allocate memory for filenames.");
																cur_flist = 0;
																max_flist = 0;
																get_closefile();
																closef(fd);
																return 1;
																}
															strcpy(flist[cur_flist]->fl_name,tfi.fi_name);
															flist[cur_flist]->fl_location = tfe.fe_location;
															flist[cur_flist]->fl_size = tfi.fi_size;
															flist[cur_flist]->fl_date = tfi.fi_date;
															++cur_flist;

															sprintf(buffer,"%5u  ",cur_flist);
															if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																send_string(new_color(RED | BRIGHT),NULL);
															send_string(buffer,NULL);

															sprintf(buffer,"%-12.12s ",tfi.fi_name);
															if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																send_string(new_color(BROWN | BRIGHT),NULL);
															send_string(buffer,NULL);

															sprintf(buffer,"%9lu ",tfi.fi_size);
															if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																send_string(new_color(MAGENTA),NULL);
															send_string(buffer,NULL);

															sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
															if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																send_string(new_color(CYAN),NULL);
															send_string(buffer,NULL);

															if (protocol != PROT_DIRECT)
																{
																sprintf(buffer,"%3lu:%02lu -> %lu:%02lu",ftime / 60L,ftime % 60L,eta / 60L,eta % 60L);
																if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																	send_string(new_color(WHITE | BRIGHT),NULL);
																send_string(buffer,NULL);
																}
															send_string("\r\n",NULL);
															}
														}
													get_closefile();
													}
												}
											}
										}
									closef(fd);
									}
								}
							}
						}
					}
				send_string("\r",NULL);					/* wipe out search area line */
				for (count = 0; count < 50; count++)
					send_string(" ",NULL);
				}
			send_string("\r\n",NULL);
			}
		}

	return 0;
	}



int expand_safe_fname(char *path,char *fname,int protocol)		/* doesn't have to check a file's permissions */
	{
	struct fi tfi;
	char buffer[100];
	long newtime;
	long size;
	long eta = 0L;
	long ftime;
	int rtn;
	int count;
	int skip;

	strcpy(buffer,path);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,fname);

	if (protocol != PROT_DIRECT)
		{
		for (count = 0; count < cur_fnames; count++)
			{
			size = file_size(path,fnames[count]);
			eta += xmit_time(protocol,size);
			}
		}

	rtn = get_firstfile(&tfi,buffer);
	while (rtn)
		{
		skip = 0;
		for (count = 0; count < cur_fnames; count++)
			{
			if (!stricmp(tfi.fi_name,fnames[count]))
				skip = 1;
			}
		if (!skip && protocol != PROT_DIRECT)
			{
			ftime = xmit_time(protocol,tfi.fi_size);
			newtime = eta + ftime;
			if (newtime > user_time)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				sprintf(buffer,"Download of \"%s\" will exceed your time.  Skipping.\r\n",tfi.fi_name);
				send_string(buffer,NULL);
				skip = 1;
				}
			else
				eta = newtime;
			}
		if (!skip)
			{
			if (cur_fnames >= max_fnames)
				{
				if (!(fnames = realloc(fnames,(max_fnames += 10) * sizeof(char *))))
					{
					_error(E_ERROR,"Unable to allocate memory for filenames.");
					cur_fnames = 0;
					max_fnames = 0;
					get_closefile();
					return 1;
					}
				}
			if (!(fnames[cur_fnames] = calloc(strlen(tfi.fi_name) + 1,sizeof(char))))
				{
				_error(E_ERROR,"Unable to allocate memory for filenames.");
				cur_fnames = 0;
				max_fnames = 0;
				get_closefile();
				return 1;
				}
			strcpy(fnames[cur_fnames],tfi.fi_name);
			++cur_fnames;

			sprintf(buffer,"%5u  ",cur_fnames);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string(buffer,NULL);

			sprintf(buffer,"%-12.12s ",tfi.fi_name);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string(buffer,NULL);

			sprintf(buffer,"%9lu ",tfi.fi_size);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(MAGENTA),NULL);
			send_string(buffer,NULL);

			sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN),NULL);
			send_string(buffer,NULL);

			if (protocol != PROT_DIRECT)
				{
				sprintf(buffer,"%3lu:%02lu -> %lu:%02lu",ftime / 60L,ftime % 60L,eta / 60L,eta % 60L);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(WHITE | BRIGHT),NULL);
				send_string(buffer,NULL);
				}
			send_string("\r\n",NULL);
			}
		rtn = get_nextfile(&tfi);
		}
	get_closefile();
	return 0;
	}



long file_size(char *path,char *fname)
	{
	struct fi tfi;
	char buffer[100];

	strcpy(buffer,path);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,fname);

	if (!get_firstfile(&tfi,buffer))
		tfi.fi_size = 0L;
	get_closefile();

	return tfi.fi_size;
	}



int xmit_handler(int key)		/* normal pause-stop handler */
	{
	key = toupper(key);
	switch (key)
		{
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int xmit_file(int area)
	{
	char buffer[100];
	int curtime;
	int dl_flag;
	int retval = 0;
	int quit = 0;
	int key = 0;
	int ok = 0;

	cur_line = 0;
	if (!get_filearea(area))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return retval;
		}
	if (!user_baud)
		retval = xmit_files(area,PROT_DIRECT);
	else
		{
		curtime = get_ctime();

		dl_flag = 0;
		if (cfg.cfg_dlstart > cfg.cfg_dlstop)
			{
			if (curtime <= cfg.cfg_dlstop || curtime >= cfg.cfg_dlstart)
				dl_flag = 1;
			}
		else
			{
			if (curtime >= cfg.cfg_dlstart && curtime <= cfg.cfg_dlstop)
				dl_flag = 1;
			}

		if (dl_flag || user.user_priv >= (unsigned char)250)		/* can only download within download hours or as Sysop level */
			{
			do
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);
				key = send_string("\r\n\r\n--- Download Menu ---\r\n\r\n",xmit_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string(protocol_list,xmit_handler);
					else
						key = send_string("[ 12345?X ]\r\n\r\n",xmit_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Exit)? ",xmit_handler);
					}
				do
					{
					if (!key)
						key = get_char();
					else
						send_string("\r\n\r\nDownload using ",NULL);
					switch (key)
						{
						case '1':
							send_string("Xmodem\r\n",NULL);
							retval = xmit_files(area,PROT_XMODEM);
							ok = 1;
							quit = 1;
							break;
						case '2':
							send_string("Xmodem-1K\r\n",NULL);
							retval = xmit_files(area,PROT_XMODEM1K);
							ok = 1;
							quit = 1;
							break;
						case '3':
							send_string("Ymodem\r\n",NULL);
							retval = xmit_files(area,PROT_YMODEM);
							ok = 1;
							quit = 1;
							break;
						case '4':
							send_string("Ymodem-G\r\n",NULL);
							retval = xmit_files(area,PROT_YMODEMG);
							ok = 1;
							quit = 1;
							break;
						case '5':
							send_string("Zmodem\r\n",NULL);
							retval = xmit_files(area,PROT_ZMODEM);
							ok = 1;
							quit = 1;
							break;
						case '?':
							cur_line = 0;
							send_string("\r\n\r\n",NULL);
							send_ansifile(cfg.cfg_screenpath,"DLHELP",0);
							ok = 1;
							break;
						case 'X':
						case 'x':
						case '\r':
						case '\n':
							ok = 1;
							quit = 1;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!quit);
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Sorry, you cannot download outside of download hours!\r\n",NULL);
			get_enter();
			}
		}
	cur_line = 0;

	return retval;
	}



int xmit_files(int area,int protocol)
	{
	struct file *tfile;
	char buffer[100];
	char fname[20];
	char *protname;
	int farea;
	int retval = 0;
	int curtime;
	int dl_flag;
	int count;
	int kount;
	int rtn = 0;

	cur_line = 0;
	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return retval;
		}

	if (protocol != PROT_DIRECT)
		{
		curtime = get_ctime();
		dl_flag = 0;
		if (cfg.cfg_dlstart > cfg.cfg_dlstop)
			{
			if (curtime <= cfg.cfg_dlstop || curtime >= cfg.cfg_dlstart)
				dl_flag = 1;
			}
		else
			{
			if (curtime >= cfg.cfg_dlstart && curtime <= cfg.cfg_dlstop)
				dl_flag = 1;
			}

		if (!dl_flag && user.user_priv < (unsigned char)250)		/* can only download within download hours or as Sysop level */
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Sorry, you cannot download outside of download hours!\r\n",NULL);
			get_enter();
			return retval;
			}
		}

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);

	switch (protocol)
		{
		case PROT_DIRECT:
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\n\r\nLocal \"Download\" permits you to copy files TO a different directory.\r\n",NULL);
			send_string("Copy to where (ENTER=Quit)? ",NULL);
			get_fname(buffer,48,0,1);
			if (buffer[0])
				{
				if (buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);

				if (rtn = get_filelist(tfile,PROT_DIRECT,NULL))
					{
					copy_out(area,buffer,flist,cur_flist);
					for (count = 0; count < cur_flist; count++)
						{
						free(flist[count]->fl_name);
						free(flist[count]);
						}
					free(flist);
					flist = NULL;
					cur_flist = 0;
					max_flist = 0;
					}
				}
			break;

		case PROT_XMODEM:
			send_string("\r\n\r\nDownload using ",NULL);
			protname = "Xmodem";
			send_string(protname,NULL);

			if (get_xmodem_file(tfile,protocol,fname,&farea))
				{
				if (rtn = get_download_choice(1))
					{
					log_entry(L_DOWNLOAD_PROTOCOL,protname);
					x_send(farea,fname);
					}
				}
			break;

		case PROT_XMODEM1K:
			send_string("\r\n\r\nDownload using ",NULL);
			protname = "Xmodem-1K";
			send_string(protname,NULL);

			if (get_xmodem_file(tfile,protocol,fname,&farea))
				{
				if (rtn = get_download_choice(1))
					{
					log_entry(L_DOWNLOAD_PROTOCOL,protname);
					x1k_send(farea,fname);
					}
				}
			break;

		case PROT_YMODEM:
			send_string("\r\n\r\nDownload using ",NULL);
			protname = "Ymodem";
			send_string(protname,NULL);

			if (rtn = get_filelist(tfile,protocol,protname))
				{
				log_entry(L_DOWNLOAD_PROTOCOL,protname);
				y_send(area,flist,cur_flist);
				for (count = 0; count < cur_flist; count++)
					{
					free(flist[count]->fl_name);
					free(flist[count]);
					}
				free(flist);
				flist = NULL;
				cur_flist = 0;
				max_flist = 0;
				}
			break;

		case PROT_YMODEMG:
			send_string("\r\n\r\nDownload using ",NULL);
			protname = "Ymodem-G";
			send_string(protname,NULL);

			if (rtn = get_filelist(tfile,protocol,protname))
				{
				log_entry(L_DOWNLOAD_PROTOCOL,protname);
				yg_send(area,flist,cur_flist);
				for (count = 0; count < cur_flist; count++)
					{
					free(flist[count]->fl_name);
					free(flist[count]);
					}
				free(flist);
				flist = NULL;
				cur_flist = 0;
				max_flist = 0;
				}
			break;

		case PROT_ZMODEM:
			send_string("\r\n\r\nDownload using ",NULL);
			protname = "Zmodem";
			send_string(protname,NULL);

			if (rtn = get_filelist(tfile,protocol,protname))
				{
				log_entry(L_DOWNLOAD_PROTOCOL,protname);
				z_send(area,flist,cur_flist);
				for (count = 0; count < cur_flist; count++)
					{
					free(flist[count]->fl_name);
					free(flist[count]);
					}
				free(flist);
				flist = NULL;
				cur_flist = 0;
				max_flist = 0;
				}
			break;
		}

	if (rtn & 0x2)		/* hangup after d/l? */
		{
		retval = 1;
		purge_input(cfg.cfg_port);
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string("\r\n\r\n\aPreparing to hangup after download.  Press any key to abort hangup....",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		for (count = 10; retval && count > 0; count--)
			{
			if (count <= 5)
				send_string("\a",NULL);

			sprintf(buffer,"%u ",count);
			send_string(buffer,NULL);
			for (kount = 0; kount < 4; kount++)
				{
				sleep(240);		/* 1/4 sec + latency */

				if (user_baud)
					{
					if (peek_input(cfg.cfg_port) != -1)
						{
						read_input(cfg.cfg_port);
						retval = 0;
						break;
						}
					else if (get_kb())
						{
						retval = 0;
						break;
						}
					}
				else
					{
					if (get_kb())
						{
						retval = 0;
						break;
						}
					}
				}
			for (kount = 0; kount < (int)strlen(buffer); kount++)
				send_string("\b",NULL);
			}
		send_string("\r\n\r\n",NULL);
		}
	else if (rtn & 0x1)		/* a d/l was done? */
		{
		if (!(user.user_flags & USER_ANSI) || (user_baud < cfg.cfg_ansibaud && user_baud))
			write_string(new_color(WHITE));
		get_enter();
		}

	return retval;
	}



/* xmit_onefile() returns:
**
**			-1 -> not enough time or cancelled
**			 0 -> no download (non-existant)
**			 1 -> download successful
**			 2 -> download not-successful/hangup.
**			 3 -> download successful/hangup.
*/


int xmit_onefile(int area,char *fname,int hangup)
	{
	struct file *tfile;
	struct fl *flist[2];
	struct fl tfl;
	char buffer[100];
	char *cptr;
	long size;
	long eta;
	int dloads = user.user_dnload;
	int retval = 0;
	int key = 0;
	int count;
	int kount;
	int ok = 0;
	int rtn = 0;

	cur_line = 0;
	if (!user_baud)
		{
		system_message("You cannot download while in local mode!");
		return 0;
		}
	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return 0;
		}

	size = file_size(tfile->file_pathname,fname);
	cptr = parse_long(size);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(menu_color),NULL);
	sprintf(buffer,"\r\n\r\n--- Download Menu for \"%s\" (%s bytes) ---\r\n\r\n",fname,cptr);
	key = send_string(buffer,xmit_handler);
	if (!key)
		{
		if (!(user.user_flags & USER_EXPERT))
			key = send_string(protocol_list,xmit_handler);
		else
			key = send_string("[ 12345?X ]\r\n\r\n",xmit_handler);
		if (!key)
			key = send_string("What is your choice (ENTER=Exit)? ",xmit_handler);
		}
	do
		{
		if (!key)
			key = get_char();
		else
			send_string("\r\n\r\nDownload using ",NULL);
		switch (key)
			{
			case '1':
				send_string("Xmodem",NULL);
				if (check_fname(tfile,fname))
					{
					eta = xmit_time(PROT_XMODEM,size);
					if (eta > user_time)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"\r\nDownload of this file will take %lu minutes %lu seconds\r\n",eta / 60L,eta % 60L);
						send_string(buffer,NULL);
						sprintf(buffer,"You do not have enough time (%lu min %lu sec) for this download!\r\n",user_time / 60L,user_time % 60L);
						send_string(buffer,NULL);
						get_enter();
						return -1;
						}
					else
						{
						if (rtn = get_download_choice(hangup))
							x_send(area,fname);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("File \"",NULL);
					send_string(fname,NULL);
					send_string("\" does not exist...Transfer cancelled!\r\n",NULL);
					get_enter();
					}
				ok = 1;
				break;
			case '2':
				send_string("Xmodem-1K",NULL);
				if (check_fname(tfile,fname))
					{
					eta = xmit_time(PROT_XMODEM1K,size);
					if (eta > user_time)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"\r\nDownload of this file will take %lu minutes %lu seconds\r\n",eta / 60L,eta % 60L);
						send_string(buffer,NULL);
						sprintf(buffer,"You do not have enough time (%lu min %lu sec) for this download!\r\n",user_time / 60L,user_time % 60L);
						send_string(buffer,NULL);
						get_enter();
						return -1;
						}
					else
						{
						if (rtn = get_download_choice(hangup))
							x1k_send(area,fname);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("File \"",NULL);
					send_string(fname,NULL);
					send_string("\" does not exist...Transfer cancelled!\r\n",NULL);
					get_enter();
					}
				ok = 1;
				break;
			case '3':
				send_string("Ymodem",NULL);
				if (check_fname(tfile,fname))
					{
					eta = xmit_time(PROT_YMODEM,size);
					if (eta > user_time)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"\r\nDownload of this file will take %lu minutes %lu seconds\r\n",eta / 60L,eta % 60L);
						send_string(buffer,NULL);
						sprintf(buffer,"You do not have enough time (%lu min %lu sec) for this download!\r\n",user_time / 60L,user_time % 60L);
						send_string(buffer,NULL);
						get_enter();
						return -1;
						}
					else
						{
						if (rtn = get_download_choice(hangup))
							{
							tfl.fl_name = fname;
							tfl.fl_size = size;
							tfl.fl_location = area;
							flist[0] = &tfl;
							flist[1] = NULL;
							y_send(area,flist,1);
							}
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("File \"",NULL);
					send_string(fname,NULL);
					send_string("\" does not exist...Transfer cancelled!\r\n",NULL);
					get_enter();
					}
				ok = 1;
				break;
			case '4':
				send_string("Ymodem-G",NULL);
				if (check_fname(tfile,fname))
					{
					eta = xmit_time(PROT_YMODEMG,size);
					if (eta > user_time)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"\r\nDownload of this file will take %lu minutes %lu seconds\r\n",eta / 60L,eta % 60L);
						send_string(buffer,NULL);
						sprintf(buffer,"You do not have enough time (%lu min %lu sec) for this download!\r\n",user_time / 60L,user_time % 60L);
						send_string(buffer,NULL);
						get_enter();
						return -1;
						}
					else
						{
						if (rtn = get_download_choice(hangup))
							{
							tfl.fl_name = fname;
							tfl.fl_size = size;
							tfl.fl_location = area;
							flist[0] = &tfl;
							flist[1] = NULL;
							yg_send(area,flist,1);
							}
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("File \"",NULL);
					send_string(fname,NULL);
					send_string("\" does not exist...Transfer cancelled!\r\n",NULL);
					get_enter();
					}
				ok = 1;
				break;
			case '5':
				send_string("Zmodem",NULL);
				if (check_fname(tfile,fname))
					{
					eta = xmit_time(PROT_ZMODEM,size);
					if (eta > user_time)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"\r\nDownload of this file will take %lu minutes %lu seconds\r\n",eta / 60L,eta % 60L);
						send_string(buffer,NULL);
						sprintf(buffer,"You do not have enough time (%lu min %lu sec) for this download!\r\n",user_time / 60L,user_time % 60L);
						send_string(buffer,NULL);
						get_enter();
						return -1;
						}
					else
						{
						if (rtn = get_download_choice(hangup))
							{
							tfl.fl_name = fname;
							tfl.fl_size = size;
							tfl.fl_location = area;
							flist[0] = &tfl;
							flist[1] = NULL;
							z_send(area,flist,1);
							}
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("File \"",NULL);
					send_string(fname,NULL);
					send_string("\" does not exist...Transfer cancelled!\r\n",NULL);
					get_enter();
					}
				ok = 1;
				break;
			case '?':
				cur_line = 0;
				send_string("\r\n\r\n",NULL);
				send_ansifile(cfg.cfg_screenpath,"DLHELP",0);
				ok = 1;
				break;
			case 'X':
			case 'x':
			case '\r':
			case '\n':
				retval = -1;
				ok = 1;
				break;
			}
		key = 0;
		}
	while (!ok);

	if (rtn & 0x2)		/* hangup after d/l? */
		{
		if (dloads != user.user_dnload)		/* file was downloaded ok? */
			retval = 3;
		else 
			retval = 2;

		purge_input(cfg.cfg_port);
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string("\r\n\r\n\aPreparing to hangup after download.  Press any key to abort hangup....",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		for (count = 10; retval && count > 0; count--)
			{
			if (count <= 5)
				send_string("\a",NULL);

			sprintf(buffer,"%u ",count);
			send_string(buffer,NULL);
			for (kount = 0; kount < 4; kount++)
				{
				sleep(240);		/* 1/4 sec + latency */

				if (user_baud)
					{
					if (peek_input(cfg.cfg_port) != -1)
						{
						read_input(cfg.cfg_port);
						if (dloads != user.user_dnload)		/* file was downloaded ok? */
							retval = 1;
						else
							retval = 0;
						break;
						}
					else if (get_kb())
						{
						if (dloads != user.user_dnload)		/* file was downloaded ok? */
							retval = 1;
						else
							retval = 0;
						break;
						}
					}
				else
					{
					if (get_kb())
						{
						if (dloads != user.user_dnload)		/* file was downloaded ok? */
							retval = 1;
						else
							retval = 0;
						break;
						}
					}
				}
			for (kount = 0; kount < (int)strlen(buffer); kount++)
				send_string("\b",NULL);
			}
		send_string("\r\n\r\n",NULL);
		}
	else if (rtn & 0x1)		/* a d/l was done? */
		{
		if (!(user.user_flags & USER_ANSI) || (user_baud < cfg.cfg_ansibaud && user_baud))
			write_string(new_color(WHITE));
		get_enter();

		if (dloads != user.user_dnload)		/* file was downloaded ok? */
			retval = 1;
		else
			retval = 0;
		}

	return retval;
	}



long xmit_time(int protocol,long size)
	{
	unsigned long eta = 0L;

	eta = size * 10L;		/* start bit, stop bit + 8 bits/byte */
	eta *= 100L;			/* multiply by 100 for percentage calculation */
	switch (protocol)		/* calculate efficiency */
		{
		case PROT_DIRECT:
			eta /= 100L;
			break;
		case PROT_XMODEM1K:
			eta /= 73L;
			break;
		case PROT_YMODEM:
			eta /= 75L;
			break;
		case PROT_YMODEMG:
			eta /= 90L;
			break;
		case PROT_ZMODEM:
			eta /= 88L;
			break;
		case PROT_XMODEM:
		default:
			eta /= 70L;
			break;
		}
	eta /= (unsigned long)user_baud;
	if (!eta)
		eta = 1L;		/* min is 1 second */
	return (long)eta;
	}



void hold_protocol(void)
	{
	user_warning = 1;			/* kill the 2 minute warning flag */
	nolimit_flag = 1;			/* prevent logoff due to time */
	}



void unhold_protocol(void)
	{
	user_warning = 0;			/* restore the 2 minute warning flag */
	if (user_time < 120L)		/* used all their time, give them 2 minutes to leave! */
		set_logofftime(120L);
	nolimit_flag = 0;			/* restore normal timing */
	}



long xfer_time(void)				/* returns current time in secs */
	{
	return time(NULL);
	}



void show_dlstats(long size,long eta,long actual)
	{
	char buffer[20];
	char *cptr;
	long efficiency;
	long tlong;
	long cps;
	long theoretical_rate = (long)user_baud / 10L;
	int new_cursor;
	int cursor;
	int count;

	if (!actual)
		actual = 1L;		/* prevent division by zero! */
	cps = (long)((unsigned long)size / (unsigned long)actual);
	efficiency = cps * 100L / theoretical_rate;
	cptr = parse_long(size);

	log_entry(L_DLULSIZE,cptr);
	sprintf(buffer,"%lu",cps);
	log_entry(L_DLULRATE,buffer);
	sprintf(buffer,"%lu",efficiency);
	log_entry(L_DLULPERCENT,buffer);

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n   Total bytes: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(cptr,NULL);
	send_string("\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("Estimated time: ",NULL);
	sprintf(buffer,"%lu:%02lu\r\n",eta / 60L,eta % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("   Actual time: ",NULL);
	sprintf(buffer,"%lu:%02lu\r\n",actual / 60L,actual % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("      CPS rate: ",NULL);
	sprintf(buffer,"%lu\r\n",cps);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("    Efficiency: ",NULL);
	sprintf(buffer,"%lu%%\r\n",efficiency);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);

	/* update status line for UL and DL info */

	cursor = bios_getcurpos();

	new_cursor = ((bottom_line + 2) << 8) | 0x3d;
	tlong = user.user_uploadbytes;
	if (tlong >= 1024L)
		{
		tlong /= 1024L;
		if (tlong < 1024L)
			sprintf(buffer,"%luKB",tlong);
		else
			{
			tlong /= 1024L;
			sprintf(buffer,"%luMB",tlong);
			}
		}
	else
		sprintf(buffer,"%luB",tlong);
	for (count = (int)strlen(buffer); count < 7; count++)
		strcat(buffer," ");

	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x48;
	tlong = user.user_dnloadbytes;
	if (tlong >= 1024L)
		{
		tlong /= 1024L;
		if (tlong < 1024L)
			sprintf(buffer,"%luKB",tlong);
		else
			{
			tlong /= 1024L;
			sprintf(buffer,"%luMB",tlong);
			}
		}
	else
		sprintf(buffer,"%luB",tlong);
	for (count = (int)strlen(buffer); count < 7; count++)
		strcat(buffer," ");

	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}
	bios_setcurpos(cursor);
	}



int update_downloads(int area,char *fname,int date)
	{
	struct file *tfile;
	struct fe tfe;
	char buffer[100];
	FILE *fd;

	if (!(tfile = get_filearea(area)))
		return 0;

	if (tfile->file_descname[0])				/* load and show the file header */
		strcpy(buffer,tfile->file_descname);
	else 
		strcpy(buffer,tfile->file_pathname);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,"filelist.bbs");

	if (access(buffer,0))		/* doesn't exist?  we don't want to create it then! */
		return 0;

	if (fd = open_filelist_write(buffer))
		{
		while (fread(&tfe,sizeof(struct fe),1,fd))
			{
			if (!stricmp(tfe.fe_name,fname))
				{
				tfe.fe_dldate = date;
				++tfe.fe_dl;

				fseek(fd,-(long)sizeof(struct fe),SEEK_CUR);
				fwrite(&tfe,sizeof(struct fe),1,fd);

				fseek(fd,0L,SEEK_CUR);
				}
			}
		fclose(fd);
		}
	else
		return 1;
	return 0;
	}
