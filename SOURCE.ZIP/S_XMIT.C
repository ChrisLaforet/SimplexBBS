/* s_xmit.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 27 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_xmit.c_v  $
**                       $Date:   25 Oct 1992 14:09:12  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#include "simplex.h"


#define MAX_SENDBUF		41


extern jmp_buf reset_bbs;


			  
void pascal purge_output(int port)
	{
	if (user_baud)
		purge_output_buffer(port);
	}



void send_modem(char *string)
	{
	char *cptr = string;

	while (*cptr)
		{
		if (*cptr != '~' && *cptr != '|')
			{
			output_wait((int)cfg.cfg_port,*cptr);
			if (cfg.cfg_flags & CFG_SLOWMODEM)
				sleep(100);
			else
				sleep(10);
			}
		else if (*cptr == '~')
	   		sleep(500);
		else if (*cptr == '|')
			{
			output_wait((int)cfg.cfg_port,'\x0d');
			if (cfg.cfg_flags & CFG_SLOWMODEM)
				sleep(100);
			else
				sleep(10);
			}
		++cptr;
		update_clock();
		}
	}



void pascal send_char(char character)
	{
	register sent = 0;

	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (!check_output(cfg.cfg_port))		/* transmitter almost empty */
			{
			output_wait(cfg.cfg_port,character);		/* out to comm port */
			++sent;
			}
		}
	while (!sent);
	}



int ps_handler(int key)		/* normal pause-stop handler */
	{
	if (key == 'P' || key == 'p')
		pause_character();
	else if (key == 'S' || key == 's' || more_flag)
		return 'S';
	return 0;
	}



int p_handler(int key)		/* normal pause handler */
	{
	if (key == 'P' || key == 'p')
		pause_character();
	return 0;
	}



int send_string(char *string,int (*hotkey_handler)(int key))
	{
	return send_buffer(string,(int)strlen(string),hotkey_handler);
	}



int send_buffer(char *buf,int buflen,int (*hotkey_handler)(int key))
	{
	char sendbuf[MAX_SENDBUF];
	char *cptr = sendbuf;
	register int current = 0;
	register int sent;
#ifdef PROTECTED
	static int counter = 0;
#endif
	int maxchar;
	static int in_pause = 0;
	int key;

	if (user_baud)
		maxchar = user_baud / 40;		/* 1/4 a second of chars */
	else
		maxchar = 150;

	if (!in_pause)
		more_flag = 0;
	while (current < buflen)
		{
		sent = 0;
		if (user.user_flags & USER_MORE && cur_line >= (user.user_screenlen - 1))
			{
			if (cptr)		/* any residual characters to be sent before pausing */
				{
				*cptr = '\0';
				write_string(sendbuf);
				update_clock();
				cptr = sendbuf;
				}

			in_pause = 1;
			pause_screen();
			in_pause = 0;
			if (more_flag && hotkey_handler)
				{
				if (key = (*hotkey_handler)(0))
					return key;
				}
			}
		do
			{
			if (user_baud)
				{
				if (!cd)
					longjmp(reset_bbs,1);
				else if (!check_output(cfg.cfg_port))		/* transmitter almost empty */
					{
					output_wait(cfg.cfg_port,buf[current]);		/* out to comm port */
					*cptr++ = buf[current];

					if (!inansi_flag && hotkey_handler && !(sent % maxchar))		/* if in the middle of an ansi sequence, skip hotkey */
						{
						if (peek_input(cfg.cfg_port) != -1)
							{
							key = read_input(cfg.cfg_port);
							if (key = (*hotkey_handler)(key))
								return key;
							}
						if (key = get_kb())
							{
							if (key = (*hotkey_handler)(key))
								return key;
							}
						}
					++sent;

#ifdef PROTECTED
					if (!(++counter % maxchar))
						{
						DosSleep(10L);
						counter = 0;
						}
#endif

					}
#ifdef PROTECTED
				else 
					DosSleep(30L);		/* hand off a time slice! */
#endif
				}
			else if (!user_baud)				/* local only */
				{
				*cptr++ = buf[current];

				if (!inansi_flag && hotkey_handler && !(sent % 100))
					{
					if (key = get_kb())
						{
						if (key = (*hotkey_handler)(key))
							return key;
						}
					}
				++sent;
#ifdef PROTECTED
				if (!(sent % 80))
					DosSleep(1L);		/* hand off a time slice - local mode would be a foreground session! */
#endif
				}

			}
		while (!sent);

		if (cptr >= sendbuf + (MAX_SENDBUF - 1))
			{
			*cptr = '\0';
			write_string(sendbuf);
			update_clock();
			cptr = sendbuf;
			}

		if (buf[current] == '\n')		/* for counting more! */
			++cur_line;
		else if (buf[current] == '\f')		/* for counting more! */
			cur_line = 0;
		++current;
		}

	if (cptr)		/* any residual characters */
		{
		*cptr = '\0';
		write_string(sendbuf);
		update_clock();
		}

	return 0;
	}



