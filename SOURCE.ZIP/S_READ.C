/* s_read.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 8 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_read.c_v  $
**                       $Date:   25 Oct 1992 14:07:10  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <io.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"



static int in_ctrl_a = 0;
static char _far linebuf[200];



int read_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'R':
		case 'N':
		case 'I':
		case 'M':
		case 'S':
		case 'T':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int read_search_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'T':
		case 'F':
		case 'S':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int psn_handler(int key)		/* pause-stop-next handler */
	{
	if (key == 'P' || key == 'p')
		pause_character();
	else if (key == 'S' || key == 's' || more_flag)
		return 'S';
	else if (key == 'N' || key == 'n')
		return key;
	return 0;
	}



void search_message(void)
	{
	cur_line = 0;			/* defeat more */
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\rSearching....",NULL);
	}



void show_message_search(int num)
	{
	char buffer[20];
	int count;

	cur_line = 0;			/* defeat more */
	sprintf(buffer,"%d",num);
	for (count = (int)strlen(buffer); count > 0; count--)
		strcat(buffer,"\b");
	send_string(buffer,NULL);
	}



void read_messages(int area,int priv,int pflags)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	struct mark tmark;
	char buffer[51];
	char *cptr;
	int total_msgs = 0;
	int current = 0;
	int count;
	int kount;
	int pause;
	int actual;
	int key;
	int direction;
	int quit = 0;
	int done;
	int mode;
	int end;
	int found;
	int rtn;
	int ok;

	if (!(tmsg = get_msgarea(area)))
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	if (priv < (int)tmsg->msg_readpriv || (tmsg->msg_readflags & pflags) != tmsg->msg_readflags)
		{
		system_message("You have insufficient privilege to read messages here!");
		return;
		}
	for (count = 0; count < max_msgcount; count++)
		{
		if (msgcount[count].mc_area == area)
			{
			total_msgs = msgcount[count].mc_msgs;
			break;
			}
		}
	if (total_msgs)
		{
		do
			{
			cur_line = 0;			/* defeat more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Message Read Menu ---\r\n\r\n",read_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					key = send_string("<T> Read Topically <F> Read Forward   <R> Read Reverse   <I> Read Individual\r\n",read_handler);
					if (!key)
						key = send_string("<N> Read New       <M> Read Marked    <S> Read Search    <?> Help!  <X> Exit\r\n\r\n",read_handler);
					}
				else
					key = send_string("[ TFRINMS?X ]\r\n\r\n",read_handler);
				if (!key)
					key = send_string("What is your choice (ENTER=Exit)? ",read_handler);
				}
			ok = 0;
			do
				{
				if (!key)
					key = get_char();
				switch (key)
					{
					case 'F':
					case 'f':
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						send_string("Start reading forward from which message (ENTER=1)? ",NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = 1;
						direction = 1;			/* forwards! */
						send_string("\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
						if (get_yn_enter(1))
							pause = 1;
						else
							pause = 0;
						actual = 1;
						kount = 0;
						end = 0;
						fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
						while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
							{
							if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
								++kount;
							if (kount == current)
								break;
							++actual;
							}
						do
							{
							if (rtn = read_individual(area,priv,pflags,&total_msgs,actual,1,pause,1,0,direction))
								{
								if (rtn == 2)
									direction = direction ? 0 : 1;
								if (direction)
									{
									if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
										{
										++current;
										++actual;
										}
									else
										--kount;
									if (current > total_msgs)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of messages....",NULL);
										end = 1;
										}
									else
										{
										search_message();
										fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												++kount;
											if (kount == current)
												break;
											++actual;
											}
										}
									}
								else
									{
									--current;
									--actual;
									if (!current || !actual)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of messages....",NULL);
										end = 1;
										}
									else
										{
										search_message();
										fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												--kount;
											if (kount == current)
												break;
											--actual;
											fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
											}
										}
									}
								}
							else
								end = 1;
							}
						while (!end);
						ok = 1;
						break;
					case 'R':
					case 'r':
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						sprintf(buffer,"Start reading backward from which message (ENTER=%u)? ",total_msgs);
						send_string(buffer,NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = total_msgs;
						direction = 0;			/* backwards! */
						send_string("\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
						if (get_yn_enter(1))
							pause = 1;
						else
							pause = 0;
						end = 0;
						found = 0;
						
						actual = mdata.mdata_msgs;
						kount = total_msgs + 1;
						fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
						while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
							{
							if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
								--kount;
							if (kount == current)
								break;
							--actual;
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							}
						do
							{
							if (rtn = read_individual(area,priv,pflags,&total_msgs,actual,1,pause,1,0,direction))
								{
								if (rtn == 2)
									direction = direction ? 0 : 1;
								if (direction)
									{
									if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
										{
										++current;
										++actual;
										}
									else
										--kount;
									if (current > total_msgs)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of messages....",NULL);
										end = 1;
										}
									else
										{
										search_message();
										fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												++kount;
											if (kount == current)
												break;
											++actual;
											}
										}
									}
								else
									{
									--current;
									--actual;
									if (!current || !actual)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of messages....",NULL);
										end = 1;
										}
									else
										{
										search_message();
										fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												--kount;
											if (kount == current)
												break;
											--actual;
											fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
											}
										}
									}
								}
							else
								end = 1;
							}
						while (!end);
						ok = 1;
						break;
					case 'N':
					case 'n':
						cur_line = 0;
						current = 1;
						for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
							{
							if (area == lastread[count]->lr_area)
								{
								current = lastread[count]->lr_prev + 1;
								break;
								}
							}
						found = 0;
						kount = 0;
						actual = 1;
						fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
						while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
							{
							if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
								++kount;
							if (kount == current)
								{
								found = 1;
								break;
								}
							++actual;
							}
						if (found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
							if (get_yn_enter(1))
								pause = 1;
							else
								pause = 0;

							end = 0;
							direction = 1;		/* forwards first! */
							do
								{
								if (rtn = read_individual(area,priv,pflags,&total_msgs,actual,1,pause,1,0,direction))
									{
									if (rtn == 2)
										direction = direction ? 0 : 1;
									if (direction)
										{
										if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
											{
											++current;
											++actual;
											}
										else
											--kount;
										if (current > total_msgs)
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											send_string("\r\n\r\nEnd of messages....",NULL);
											end = 1;
											}
										else
											{
											search_message();
											fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												if (kount == current)
													break;
												++actual;
												}
											}
										}
									else
										{
										--current;
										--actual;
										if (!current || !actual)
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											send_string("\r\n\r\nEnd of messages....",NULL);
											end = 1;
											}
										else
											{
											search_message();
											fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
													--kount;
												if (kount == current)
													break;
												--actual;
												fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
												}
											}
										}
									}
								else
									end = 1;
								}
							while (!end);
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nNo new messages in this area!",NULL);
							}
						ok = 1;
						break;
					case 'I':
					case 'i':
						do
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nMessage Area \"",NULL);
							send_string(tmsg->msg_areaname,NULL);
							send_string("\".\r\n",NULL);
							sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
							send_string(buffer,NULL);
							send_string("Read which message (ENTER to quit)? ",NULL);
							current = get_number(0,total_msgs);

							if (current)
								{
								actual = 1;
								kount = 0;
								search_message();
								fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
								while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
									{
									if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
										++kount;
									if (kount == current)
										break;
									++actual;
									}
								read_individual(area,priv,pflags,&total_msgs,actual,0,1,0,0,-1);
								}
							}
						while (current);
						ok = 1;
						break;
					case 'M':
					case 'm':
						if (cur_marked)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
							if (get_yn_enter(1))
								pause = 1;
							else
								pause = 0;
							qsort(marked,cur_marked,sizeof(struct mark),sort_mark);
							for (count = 0; count < cur_marked; )
								{
			 					total_msgs = 0;		/* count messages in area */
								for (kount = 0; kount < max_msgcount; kount++)
									{
									if (msgcount[kount].mc_area == marked[count].mark_area)
										{
										total_msgs = msgcount[kount].mc_msgs;
										break;
										}
									}
								tmark.mark_area = marked[count].mark_area;
								tmark.mark_number = marked[count].mark_number;
								if (total_msgs && !read_individual(marked[count].mark_area,0xff,0xffff,&total_msgs,marked[count].mark_number,1,pause,0,0,-1))		/* boost priv temporarily to leave responses in sysop area */
									break;
								if (tmark.mark_area == marked[count].mark_area && tmark.mark_number == marked[count].mark_number)		/* did we not delete the message */
									++count;
								}
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nEnd of messages....\r\n",NULL);
							}
						else
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nThere are currently no messages marked....\r\n",NULL);
							}
						ok = 1;
						break;
					case 'S':
					case 's':
						end = 0;
						do
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(menu_color),NULL);
							purge_input(cfg.cfg_port);
							key = send_string("\r\n\r\n--- Read Search Menu ---\r\n\r\n",read_search_handler);
							if (!key)
								{
								if (!(user.user_flags & USER_EXPERT))
									key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",read_search_handler);
								else
									key = send_string("[ TFSX ]\r\n\r\n",read_search_handler);
								if (!key)
									key = send_string("What is your choice (ENTER=Exit)? ",read_search_handler);
								}
							done = 0;
							do
								{
								if (!key)
									key = get_char();
								switch (key)
									{
									case 'T':
									case 't':
									case 'F':
									case 'f':
									case 'S':
									case 's':
										cur_line = 0;
										if (key == 'T' || key == 't')
											mode = 0;
										else if (key == 'F' || key == 'f')
											mode = 1;
										else
											mode = 2;
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nMessage Area \"",NULL);
										send_string(tmsg->msg_areaname,NULL);
										send_string("\".\r\n",NULL);
										sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
										send_string(buffer,NULL);
										if (!mode)
											send_string("Search for what in TO (ENTER=quit)? ",NULL);
										else if (mode == 1)
											send_string("Search for what in FROM (ENTER=quit)? ",NULL);
										else 
											send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
										get_field(buffer,30,1);
										if (buffer[0])
											{
											bm_setup(buffer,1);
											send_string("\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
											if (get_yn_enter(1))
												pause = 1;
											else
												pause = 0;
											found = 0;
											actual = 1;
											search_message();
											count = 0;
											fseek(msglfd,0L,SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
													{
													fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
													fread(&tmsgh,1,sizeof(struct msgh),msghfd);
													if (!mode)
														cptr = tmsgh.msgh_to;
													else if (mode == 1)
														cptr = tmsgh.msgh_from;
													else
														cptr = tmsgh.msgh_subject;
													if (bm_search(cptr) != -1)
														{
														found = 1;
														if (read_individual(area,priv,pflags,&total_msgs,actual,1,pause,0,0,-1))
															search_message();
														else
															break;
														fseek(msglfd,(long)actual * (long)sizeof(struct mlink),SEEK_SET);
														}
													++count;
													if (count == 1 || !(count % 10))
														show_message_search(count);
													}
												++actual;
												}
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											if (found)
												send_string("\r\n\r\nEnd of messages....",NULL);
											else
												send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
											}
										done = 1;
										break;
									case 'X':
									case 'x':
									case '\r':
									case '\n':
										done = 1;
										end = 1;
										break;
									}
								key = 0;
								}
							while (!done);
							}
						while (!end);
						ok = 1;
						break;
					case 'T':
					case 't':
						read_topics(area,priv,pflags,&total_msgs);
						ok = 1;
						break;
					case '?':
						cur_line = 0;
						send_string("\r\n\r\n",NULL);
						cur_line = 0;
						send_ansifile(cfg.cfg_screenpath,"READHELP",0);
						ok = 1;
						break;
					case 'X':
					case 'x':
					case '\r':
					case '\n':
						ok = 1;
						quit = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (!quit && total_msgs);
		}
	else
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nNo messages are currently in this area!\r\n",NULL);
		send_string("Why do you not leave one?\r\n",NULL);
		get_enter();
		}
	}



/* display_message_line returns:
**
** -1 if Stop was hit
** 0 if no change
** 1 if Next was hit
*/


int pascal display_message_line(char *string,int length,int next,int kludge)
	{
	char *cptr;
	char *cptr1;
	int total = 0;
	int rtn;
	int quit;

	cptr = string;
	while (total < length)
		{
		cptr1 = linebuf;
		quit = 0;
		while (!quit && total < length)
			{
			if (*cptr == '\x1')			/* Ctrl-A */
				{
				if (kludge)
					{
					*cptr1++ = '^';
					*cptr1++ = 'a';
					}
				else 
					in_ctrl_a = 1;
				}
			else if (*cptr == '\n')
				;
			else if (!*cptr)
				quit = 1;
			else if (*cptr == '\r' || *cptr == '\x8d')
				{
				if (!in_ctrl_a || kludge)
					{
					*cptr1++ = '\r';
					*cptr1++ = '\n';
					*cptr1 = '\0';
					}
				else if (in_ctrl_a)
					in_ctrl_a = 0;
				quit = 1;
				}
			else
				{
				if (!in_ctrl_a || kludge)
					*cptr1++ = *cptr;
				}
			++cptr;
			++total;
			}
		if (cptr1 != linebuf)
			{
			*cptr1 = '\0';
			if (rtn = send_string(linebuf,psn_handler))
				{
				switch (rtn)
					{
					case 'S':
					case 's':
						return -1;
						break;
					case 'N':
					case 'n':
						if (next)
							return 1;
						break;
					}
				}
			}
		}
	return 0;
	}



char *get_fileattachinfo(char *fname)
	{
	struct fi tfi;
	static char _far buffer[100];
	char *cptr;

	strcpy(buffer,cfg.cfg_fapath);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,fname);

	if (get_firstfile(&tfi,buffer))
		{
		cptr = parse_long(tfi.fi_size);
		sprintf(buffer,"%s (%s bytes)",tfi.fi_name,cptr);
		}
	else 
		sprintf(buffer,"%s (Missing)",fname);

	get_closefile();
	return buffer;
	}



/* read_message() returns:
**
** return 0  -> exit
** return 1  -> next
** return -1 -> stop pressed
*/


int read_message(struct msgh *msgh,char *areaname,int next,int total_msgs,int new,int kludge)
	{
	char buffer[100];
	struct msgh tmsgh;
	long total = 0L;
	long diff;
	int rtn = 0;
	int len;
	int temp;

	++user.user_msgread;			/* increment the messages read in userfile */
	++userinfo.ui_msgread;			/* increment the messages read this session counter */
	mark_read(msgh->msgh_area);		/* indicates area was read from */
	in_ctrl_a = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("   Area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\"",NULL);
	send_string(areaname,NULL);
	send_string("\"  -> ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	sprintf(buffer,"Message #%u of %u\r\n",msgh->msgh_number,total_msgs);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(" Posted: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	temp = ((msgh->msgh_date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"%u %s %02u at %02u:%02u\r\n",msgh->msgh_date & 0x1f,months_table[temp],((msgh->msgh_date >> 9) + 80) % 100,
			msgh->msgh_time >> 11,(msgh->msgh_time >> 5) & 0x3f);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("     To: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);

	if (msgh->msgh_flags & MSGH_URGENT)
		send_string(user.user_name,NULL);
	else 
		send_string(msgh->msgh_to,NULL);

	if (msgh->msgh_flags & MSGH_NET)
		{
		sprintf(buffer," on %u:%u/%u",msgh->msgh_dzone,msgh->msgh_dnet,msgh->msgh_dnode);
		send_string(buffer,NULL);
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);

	if (msgh->msgh_flags & MSGH_URGENT)
		sprintf(buffer,"     (Urgent User Message) %s%s%s\r\n",msgh->msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",msgh->msgh_flags & MSGH_DELETED ? "(Del) " : "",msgh->msgh_flags & MSGH_LOCAL_FILEATTACH ? "(F/Attach)" : "");
	else
		sprintf(buffer,"     %s%s%s%s%s\r\n",new ? "(New) " : "",msgh->msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",msgh->msgh_flags & MSGH_RECEIVED ? "(Recvd) " : "",
			msgh->msgh_flags & MSGH_DELETED ? "(Del) " : "",msgh->msgh_flags & MSGH_LOCAL_FILEATTACH ? "(F/Attach)" : "");
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("   From: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);
	send_string(msgh->msgh_from,NULL);
	if (msgh->msgh_flags & MSGH_NET)
		{
		sprintf(buffer," on %u:%u/%u",msgh->msgh_szone,msgh->msgh_snet,msgh->msgh_snode);
		send_string(buffer,NULL);
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	if (msgh->msgh_flags & NET_FILEATTACH)
		send_string("\r\nFile(s): ",NULL);
	else if (msgh->msgh_flags & MSGH_LOCAL_FILEATTACH)
		send_string("\r\n Attach: ",NULL);
	else 
		send_string("\r\nSubject: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);

	if (msgh->msgh_flags & MSGH_LOCAL_FILEATTACH)
		send_string(get_fileattachinfo(msgh->msgh_subject),NULL);
	else 
		send_string(msgh->msgh_subject,NULL);
	send_string("\r\n",NULL);
	if (msgh->msgh_prev || msgh->msgh_next)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		if (msgh->msgh_prev)
			{
			fseek(msghfd,(long)(msgh->msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fread(&tmsgh,sizeof(struct msgh),1,msghfd);
			sprintf(buffer,"Prev message is #%u.  ",tmsgh.msgh_number);
			send_string(buffer,NULL);
			}
		if (msgh->msgh_next)
			{
			fseek(msghfd,(long)(msgh->msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fread(&tmsgh,sizeof(struct msgh),1,msghfd);
			sprintf(buffer,"Next message is #%u.",tmsgh.msgh_number);
			send_string(buffer,NULL);
			}
		send_string("\r\n",NULL);
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN),NULL);
	send_string("\r\n",NULL);
	fseek(msgbfd,msgh->msgh_offset,SEEK_SET);
	while (total < msgh->msgh_length)
		{
		diff = msgh->msgh_length - total;
		if (diff >= (long)sizeof(buffer))
			len = sizeof(buffer);
		else
			len = (int)diff;

		fread(buffer,len,1,msgbfd);

		if (rtn = display_message_line(buffer,len,next,kludge))
			return rtn;		/* 1 or -1 for next or stop */
		total += (long)len;
		}
	send_string("\r\n",NULL);
	return 0;
	}



int pascal export_message_line(char *string,int length,FILE *fd)
	{
	char *cptr;
	char *cptr1;
	int total = 0;

	cptr = string;
	while (total < length)
		{
		cptr1 = linebuf;
		while (*cptr && *cptr != '\r' && *cptr != '\n' && *cptr != '\x8d' && total < length)
			{
			if (*cptr != '\x1')			/* Ctrl-A */
				*cptr1++ = *cptr++;
			else
				{
				*cptr1++ = '^';
				*cptr1++ = 'a';
				++cptr;
				}
			++total;
			}
		if (total < length)
			{
			*cptr1++ = '\r';
			*cptr1++ = '\n';
			*cptr1++ = '\0';
			switch (*cptr)
				{
				case '\x8d':
				case '\r':
					++total;
					++cptr;
					if (*cptr == '\n')	/* if softCR-LF or CR-LF */
						{
						++cptr;
						++total;
						}
					break;
				default:
					++total;
					++cptr;
					break;
				}
			}
		else 
			*cptr1++ = '\0';

		if (fputs(linebuf,fd) == EOF)
			return 1;
		}
	return 0;
	}



void export_message(struct msgh *msgh,char *areaname,int total_msgs,int new)
	{
	char buffer[100];
	char fname[66];
	struct msgh tmsgh;
	long total = 0L;
	long diff;
	int temp;
	int len;
	int err = 0;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nExport this message to what file/device (ENTER=Exit)?\r\n",NULL);
	send_string("Filename: ",NULL);
	get_fname(fname,65,0,1);
	if (fname[0])
		{
		if (!(fd = fopen(fname,"r+b")))
			fd = fopen(fname,"wb");
		else 
			fseek(fd,0L,SEEK_END);

		if (fd)
			{
			cur_line = 0;
			send_string("\r\nPlease wait a few moments.  Exporting message....",NULL);

			if (fputs("\r\n",fd) == EOF)
				err = 1;

			if (!err)
				{
				if (!fprintf(fd,"   Area: \"%s\" -> Message #%u of %u\r\n",areaname,msgh->msgh_number,total_msgs))
					err = 1;
				}
			if (!err)
				{
				temp = ((msgh->msgh_date >> 5) & 0xf) - 1;
				if (temp && (temp >= 12 || temp < 0))
					temp = 11;
				if (!fprintf(fd," Posted: %u %s %02u at %02u:%02u\r\n",msgh->msgh_date & 0x1f,months_table[temp],((msgh->msgh_date >> 9) + 80) % 100,
					msgh->msgh_time >> 11,(msgh->msgh_time >> 5) & 0x3f))
					err = 1;
				}

			if (!err)
				{
				if (!fprintf(fd,"     To: %s",msgh->msgh_to))
					err = 1;
				}
			if (!err)
				{
				if (msgh->msgh_flags & MSGH_NET)
					if (!fprintf(fd," on %d:%d/%d",msgh->msgh_dzone,msgh->msgh_dnet,msgh->msgh_dnode))
						err = 1;
				}
			if (!err)
				{
				if (!fprintf(fd,"     %s%s%s%s\r\n",new ? "(New) " : "",msgh->msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",msgh->msgh_flags & MSGH_RECEIVED ? "(Recvd) " : "",msgh->msgh_flags & MSGH_DELETED ? "(Del)" : ""))
					err = 1;
				}

			if (!err)
				{
				if (!fprintf(fd,"   From: %s",msgh->msgh_from))
					err = 1;
				}
			if (!err)
				{
				if (msgh->msgh_flags & MSGH_NET)
					if (!fprintf(fd," on %d:%d/%d",msgh->msgh_szone,msgh->msgh_snet,msgh->msgh_snode))
						err = 1;
				}
			if (!err)
				{
				if (fputs("\r\n",fd) == EOF)
					err = 1;
				}

			if (!err)
				{
				if (msgh->msgh_flags & NET_FILEATTACH)
					{
					if (!fprintf(fd,"File(s): %s\r\n",msgh->msgh_subject))
						err = 1;
					}
				else if (msgh->msgh_flags & MSGH_LOCAL_FILEATTACH)
					{
					if (!fprintf(fd," Attach: %s\r\n",get_fileattachinfo(msgh->msgh_subject)))
						err = 1;
					}
				else
					{
					if (!fprintf(fd,"Subject: %s\r\n",msgh->msgh_subject))
						err = 1;
					}
				}
			if (!err && (msgh->msgh_prev || msgh->msgh_next))
				{
				if (msgh->msgh_prev)
					{
					fseek(msghfd,(long)(msgh->msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
					fread(&tmsgh,sizeof(struct msgh),1,msghfd);
					if (!fprintf(fd,"Prev message is #%u.  ",tmsgh.msgh_number))
						err = 1;
					}
				if (msgh->msgh_next)
					{
					fseek(msghfd,(long)(msgh->msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
					fread(&tmsgh,sizeof(struct msgh),1,msghfd);
					if (!fprintf(fd,"Next message is #%u.",tmsgh.msgh_number))
						err = 1;
					}
				if (!err)
					{
					if (fputs("\r\n",fd) == EOF)
						err = 1;
					}
				}
			if (!err)
				{
				if (fputs("\r\n",fd) == EOF)
					err = 1;
				}

			if (!err)
				{
				fseek(msgbfd,msgh->msgh_offset,SEEK_SET);
				while (!err && total < msgh->msgh_length)
					{
					diff = msgh->msgh_length - total;
					if (diff >= (long)sizeof(buffer))
						len = sizeof(buffer);
					else
						len = (int)diff;

					fread(buffer,len,1,msgbfd);
		
					err = export_message_line(buffer,len,fd);
					total += (long)len;
					}
				}

			if (!err)
				{
				if (fputs("\r\n\r\n",fd) == EOF)
					err = 1;
				}
			fclose(fd);

			if (!err)
				send_string("Message has been exported!\r\n",NULL);
			else
				{
//				unlink(fname);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
			   	send_string("Message could not be exported!  Disk full or device offline!\r\n",NULL);
				get_enter();
				}
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nUnable to open/create file or open device!\r\n",NULL);
			get_enter();
			}
		}
	}


