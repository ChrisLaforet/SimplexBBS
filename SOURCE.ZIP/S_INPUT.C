/* s_input.c
**
** Copyright (c) 1990, Christopher Laforet
** All Rights Reserved
**
** Started: 2 January 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_input.c_v  $
**                       $Date:   25 Oct 1992 14:07:14  $
**                       $Revision:   1.23  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "simplex.h"



static int save_color;


void mark_field(int len)
	{
	char buffer[10];
	int count;

	++len;		/* one more for the backspace/enter */
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		save_color = cur_color;
		send_string(new_color(field_color),NULL);
		for (count = 0; count < len; count++)
		 	send_string(" ",NULL);
		sprintf(buffer,"[%uD",len);
		send_string(buffer,NULL);
		}
	}



void unmark_field(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		cur_color = save_color;
		send_string(new_color(cur_color),NULL);
		}
	}



/* caps = 0 -> No capitalization
** caps = 1 -> Capitalize first letters
** caps = 2 -> Capitalize all letters
*/

void get_field(char *string,int len,int caps)
	{
	char buffer[3];
	char *cptr;
	int key;
	int quit = 0;

	mark_field(len);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			quit = 1;
			}
		else if (key >= ' ' && !(key & 0xff00))
			{
			if (cptr < (string + len))
				{
				if (caps == 1 && (cptr == string || isspace(*(cptr - 1)) || ispunct(*(cptr - 1))))
					{
					if (islower(key))
						{
						*cptr = (char)toupper(key);
						sprintf(buffer,"%c",*cptr);
						send_string(buffer,NULL);
						}
					else
						{
						*cptr = (char)key;
						sprintf(buffer,"%c",*cptr);
						send_string(buffer,NULL);
						}
					}
				else if (caps == 2)
					{
					*cptr = (char)toupper(key);
					sprintf(buffer,"%c",*cptr);
					send_string(buffer,NULL);
					}
				else
					{
					*cptr = (char)key;
					sprintf(buffer,"%c",*cptr);
					send_string(buffer,NULL);
					}
				++cptr;
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



/* If wrap is true, then automatic return is done when end of line
** is reached.  The return buffer contains the wrapped text.
*/


char *get_wrap_field(char *string,int len,int wrap)
	{
	static char buffer[80];
	char *cptr;
	char *cptr1;
	int count;
	int steps;
	int quit = 0;
	int key;

	mark_field(len);
	send_string(string,NULL);
	cptr = string + strlen(string);
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			buffer[0] = (char)'\0';
			quit = 1;
			}
		else if (key >= ' ' && !(key & 0xff00))
			{
			if (cptr < (string + len))
				{
				*cptr = (char)key;
				sprintf(buffer,"%c",*cptr);
				send_string(buffer,NULL);

				++cptr;
				}
			else if (wrap)
				{
				if (key == ' ')			/* Space?  No need to wrap! */
					{
					buffer[0] = (char)key;
					buffer[1] = (char)'\0';
					}
				else
					{
					cptr1 = cptr;
					while (cptr1 != string && !isspace(*cptr1))
						--cptr1;

					if (isspace(*cptr1))
						++cptr1;

					if ((cptr - cptr1) <= (len / 2))
						{
						*cptr = (char)'\0';
						strcpy(buffer,cptr1);
						cptr = cptr1;

						steps = strlen(buffer);
						buffer[strlen(buffer)] = (char)key;
						buffer[strlen(buffer) + 1] = (char)'\0';

						for (count = 0; count < steps; count++)
							send_string("\b",NULL);
						for (count = 0; count < steps; count++)
							send_string(" ",NULL);
						}
					else
						{
						buffer[0] = (char)key;
						buffer[1] = (char)'\0';
						}
					}

				unmark_field();
				send_string("\r\n",NULL);
				quit = 1;
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';

	return buffer;
	}



void get_numlist(char *string,int len)
	{
	char buffer[3];
	char *cptr;
	int key;
	int quit = 0;

	mark_field(len);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			quit = 1;
			}
		else if (isdigit(key) || key == ' ' || key == '+' || key == '-')
			{
			if (cptr < (string + len))
				{
				*cptr = (char)toupper(key);
				sprintf(buffer,"%c",*cptr);
				send_string(buffer,NULL);
				++cptr;
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



void get_fname(char *string,int len,int wcard,int path)
	{
	char buffer[3];
	char *cptr;
	int key;
	int quit = 0;

	mark_field(len);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			quit = 1;
			}
		else if (key >= ' ' && !(key & 0xff00))
			{
			if (cptr < (string + len))
				{
				if (key > ' ' && key < 0x7f && key != '"' && key != '/' && key != '[' && key != ']' &&
					key != '|' && key != '<' &&	key != '>' && key != '+' && key != '=' && key != ';' && key != ',')
					{
					if ((wcard && (key == '?' || key == '*')) || (path && (key == P_CSEP || key == ':')) || (key != '?' && key != '*' && key != P_CSEP && key != ':'))
						{
						*cptr = (char)key;
						sprintf(buffer,"%c",*cptr);
						send_string(buffer,NULL);
						++cptr;
						}
					}
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



void get_password(char *string,int len)
	{
	char *cptr;
	int key;
	int quit = 0;

	mark_field(len);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			quit = 1;
			}
		else if (key >= ' ' && !(key & 0xff00))
			{
			if (cptr < (string + len))
				{
				*cptr = (char)key;
				send_string("*",NULL);
				++cptr;
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



void get_phone(char *string,int force)
	{
	char buffer[3];
	char *cptr;
	int len = 14;
	int key;
	int quit = 0;

	mark_field(len);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if (cptr > string)
				{
				--cptr;
				send_string("\b \b",NULL);
				}
			}
		else if (key == '\r' || key == '\n')
			{
			if (!force || (force && (cptr != string)))
				{
				unmark_field();
				send_string("\r\n",NULL);
				quit = 1;
				}
			}
		else if (key >= ' ' && !(key & 0xff00))
			{
			if (cptr < (string + len))
				{
				*cptr = (char)toupper(key);
				sprintf(buffer,"%c",*cptr);
				send_string(buffer,NULL);
				++cptr;
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



void get_date(char *string)
	{
	char buffer[3];
	char *cptr;
	int key;
	int offset = 0;
	int quit = 0;

	mark_field(8);
	cptr = string;
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f) 
			{
			if (offset)
				{
				send_string("\b \b",NULL);
				--cptr;
				--offset;
				if (offset == 2 || offset == 5)
					{
					send_string("\b \b",NULL);
					--cptr;
					--offset;
					}
				}
			}
		else if (key == '\r' || key == '\n')
			{
			if (offset != 8)
				cptr = string;
	 		unmark_field();
	 		send_string("\r\n",NULL);
	 		quit = 1;
			}
		else if (isdigit(key) && offset < 8)
			{
			*cptr = (char)key;
			sprintf(buffer,"%c",*cptr);
			send_string(buffer,NULL);
			++offset;
			++cptr;
			if (offset == 2 || offset == 5)
				{
				*cptr++ = '-';
				++offset;
				send_string("-",NULL);
				}
			}
		}
	while (!quit);
	*cptr = (char)'\0';
	}



int get_number(int minimum,int maximum)
	{
	char buffer[10];
	char buf1[2];
	char *cptr;
	int key;
	long value;
	int quit = 0;

	sprintf(buffer,"%d",maximum);
	mark_field((int)strlen(buffer));

	cptr = buffer;
	*cptr = (char)'\0';
	do
		{
		key = get_char();
		if (key == '\b' || key == 0x7f)
			{
			if ((cptr - buffer) > 0)
				{
				--cptr;
				send_string("\b \b",NULL);
				*cptr = '\0';
				}
			}
		else if (key == '\r' || key == '\n')
			{
			unmark_field();
			send_string("\r\n",NULL);
			quit = 1;
			}
		else if (isdigit(key))
			{
			*cptr = (char)key;
			*(cptr + 1) = (char)'\0';
			value = atol(buffer);
			if (value <= (long)maximum)
				{
				++cptr;
				sprintf(buf1,"%c",key);
				send_string(buf1,NULL);
				}
			else
				*cptr = (char)'\0';
			}
		}
	while (!quit);

	value = atol(buffer);
	if ((int)value < minimum)
		value = (long)minimum;
	return (int)value;
	}



int get_yn(void)
	{
	int key;
	int rtn;

	purge_input(cfg.cfg_port);
	mark_field(3);
	while (1)
		{
		key = get_char();
		if (key == 'N' || key == 'n')
			{
			send_string("No",NULL);
			unmark_field();
			send_string("\r\n",NULL);
			rtn = 0;
			break;
			}
		else if (key == 'Y' || key == 'y')
			{
			send_string("Yes",NULL);
			unmark_field();
			send_string("\r\n",NULL);
			rtn = 1;
			break;
			}
		}
	return rtn;
	}



int get_yn_enter(int value)
	{
	int key;
	int rtn;

	purge_input(cfg.cfg_port);
	mark_field(3);
	while (1)
		{
		key = get_char();
		if (key == '\r' || key == '\n')
			{
			if (value)
				key = 'Y';
			else
				key = 'N';
			}
		if (key == 'N' || key == 'n')
			{
			send_string("No",NULL);
			unmark_field();
			send_string("\r\n",NULL);
			rtn = 0;
			break;
			}
		else if (key == 'Y' || key == 'y')
			{
			send_string("Yes",NULL);
			unmark_field();
			send_string("\r\n",NULL);
			rtn = 1;
			break;
			}
		}
	return rtn;
	}
