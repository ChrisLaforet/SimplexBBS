/* s_mark.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 9 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_mark.c_v  $
**                       $Date:   25 Oct 1992 14:07:20  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"




struct mark *marked = NULL;
int cur_marked = 0;
int max_marked = 0;



int sort_mark(struct mark *arg1,struct mark *arg2)
	{
	if ((*arg1).mark_area > (*arg2).mark_area)
		return 1;
	else if ((*arg1).mark_area < (*arg2).mark_area)
		return -1;
	else
		{
		if ((*arg1).mark_number > (*arg2).mark_number)
			return 1;
		else if ((*arg1).mark_number < (*arg2).mark_number)
			return -1;
		}
	return 0;
	}



void free_mark(void)
	{
	if (cur_marked)
		{
		free(marked);
		marked = NULL;
 		cur_marked = 0;
	 	max_marked = 0;
		}
	}



int mark(int area,int system_number)
	{
	int count;
	int found = 0;

	for (count = 0; count < cur_marked; count++)
		{
		if (marked[count].mark_area == area && marked[count].mark_number == system_number)
			{
			found = 1;
			break;
			}
		}
	if (!found)
		{
		if (cur_marked >= max_marked)
			{
			if (!(marked = realloc(marked,(max_marked += 100) * sizeof(struct mark))))
				{
				system_message("Unable to allocate memory for marked message list...list dumped!");
				cur_marked = 0;
				max_marked = 0;
				return 1;
				}
			}
		marked[cur_marked].mark_area = area;
		marked[cur_marked].mark_number = system_number;
		++cur_marked;
		}
	return 0;
	}



int unmark(int area,int system_number)
	{
	int count;
	int found = 0;

	for (count = 0; count < cur_marked; count++)
		{
		if (marked[count].mark_area == area && marked[count].mark_number == system_number)
			{
			found = 1;
			break;
			}
		}
	if (found)
		{
		if (count < (cur_marked - 1))
			memmove(marked + count,marked + (count + 1),(cur_marked - count + 1) * sizeof(struct mark));
		--cur_marked;
		}
	return 0;
	}

