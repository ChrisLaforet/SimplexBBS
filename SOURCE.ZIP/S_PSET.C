/* s_pset.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 17 March 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_pset.c_v  $
**                       $Date:   25 Oct 1992 14:07:36  $
**                       $Revision:   1.6  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include "simplex.h"



void set_privilege(int priv)
	{
	int ttime;
	int otime;

	if ((unsigned int)priv > 0 && (unsigned int)priv <= 0xff && (unsigned int)priv != (unsigned int)user.user_priv)
		{
		update_priv_flag = 1;

		otime = (int)((projected_time(0L) - login_time) / 60L);
		if (otime < 0)
			otime = 0;

		if (!time_flag)
			{
			ttime = logon_times[(int)user.user_priv] - otime;
			ttime -= user.user_timeused;
			}
		else
			{
			ttime = time_flag;
			if (ttime > (logon_times[(int)user.user_priv] + otime))
				ttime = logon_times[(int)user.user_priv] - otime;
			ttime -= user.user_timeused;
			}
		if (ttime < 2)
			ttime = 2;

		set_logofftime((long)ttime * 60L);
		user_time = remaining_time();

		user.user_priv = (unsigned char)priv;
		user_warning = 0;			/* set 2 minute warning flag off! */

		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);

		show_user();
		update_priv_flag = 0;
		}
	}



void absolute_time(int mins)
	{
	char buffer[10];
	char *cptr;
	int new_cursor;
	int cursor;
	long tlong;

	tlong = (long)mins * 60L;
	if (user_time >= tlong)			/* only change user's time if it will DROP their time! */
		{
		set_logofftime(tlong);
		user_time = remaining_time();
		user_warning = 0;		/* reset the user's 2 minute warning flag */
		cursor = bios_getcurpos();
		sprintf(buffer,"%lu",user_time / 60L);
		new_cursor = ((bottom_line + 2) << 8) | 0x34;
		cptr = buffer;
		while (*cptr)
			{
			bios_setcurpos(new_cursor++);
			bios_outchar(*cptr++,status_color[2],1);
			}
		bios_setcurpos(cursor++);
		}
	}



void up_time(int mins)
	{
	char buffer[10];
	char *cptr;
	int new_cursor;
	int cursor;

	bump_logofftime(mins);
	user_time = remaining_time();
	user_warning = 0;		/* reset the user's 2 minute warning flag */
	cursor = bios_getcurpos();
	sprintf(buffer,"%lu",user_time / 60L);
	new_cursor = ((bottom_line + 2) << 8) | 0x34;
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}
	bios_setcurpos(cursor++);
	}



void down_time(int mins)
	{
	char buffer[10];
	char *cptr;
	int new_cursor;
	int cursor;

	bump_logofftime(-mins);
	user_time = remaining_time();
	user_warning = 0;		/* reset the user's 2 minute warning flag */
	cursor = bios_getcurpos();
	sprintf(buffer,"%lu",user_time / 60L);
	new_cursor = ((bottom_line + 2) << 8) | 0x34;
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}
	bios_setcurpos(cursor++);
	}



int get_flags(char *flaglist)
	{
	char *cptr;
	unsigned int template = 0;

	cptr = flaglist;
	while (*cptr)
		{
		switch (*cptr)
			{
			case 'A':
			case 'a':
				template |= UF_A;
				break;
			case 'B':
			case 'b':
				template |= UF_B;
				break;
			case 'C':
			case 'c':
				template |= UF_C;
				break;
			case 'D':
			case 'd':
				template |= UF_D;
				break;
			case 'E':
			case 'e':
				template |= UF_E;
				break;
			case 'F':
			case 'f':
				template |= UF_F;
				break;
			case 'G':
			case 'g':
				template |= UF_G;
				break;
			case 'H':
			case 'h':
				template |= UF_H;
				break;
			case 'I':
			case 'i':
				template |= UF_I;
				break;
			case 'J':
			case 'j':
				template |= UF_J;
				break;
			case 'K':
			case 'k':
				template |= UF_K;
				break;
			case 'L':
			case 'l':
				template |= UF_L;
				break;
			case 'M':
			case 'm':
				template |= UF_M;
				break;
			case 'N':
			case 'n':
				template |= UF_N;
				break;
			case 'O':
			case 'o':
				template |= UF_O;
				break;
			case 'P':
			case 'p':
				template |= UF_P;
				break;
			}
		++cptr;
		}
	return (int)template;
	}



void add_flags(char *flaglist)
	{
	int template;
	int tflags;

	template = get_flags(flaglist);
	tflags = user.user_uflags | template;
	if (tflags != user.user_uflags)
		{
		user.user_uflags = tflags;
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void del_flags(char *flaglist)
	{
	int template;
	int tflags;

	template = (int)~get_flags(flaglist);
	tflags = user.user_uflags & template;
	if (tflags != user.user_uflags)
		{
		user.user_uflags = tflags;
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}




