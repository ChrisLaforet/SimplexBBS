/* s_utime.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 1 November 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_utime.c_v  $
**                       $Date:   25 Oct 1992 14:08:02  $
**                       $Revision:   1.3  $
**
*/


#include <stdio.h>
#include <time.h>
#include "simplex.h"




long logoff_time;
volatile long inactive_time;
static long holdtime;




long projected_time(long secs)		/* calcuates a projected time based on now */
	{
	time_t curtime;

	time(&curtime);
	return (long)curtime + secs;		/* actual time since 00:00:00 1/1/70 GMT when to logoff */
	}



void set_logofftime(long actualtime)
	{
	logoff_time = projected_time(actualtime);		/* actual time since 00:00:00 1/1/70 GMT when to logoff */
	}



void set_inactivetime(void)
	{
	long actualtime;

	if (cfg.cfg_inactive)
		actualtime = (long)cfg.cfg_inactive * 60L;
	else
		actualtime = 300L;
	inactive_time = projected_time(actualtime);		/* actual time since 00:00:00 1/1/70 GMT when to logoff */
	}



void bump_logofftime(int minutes)
	{
	long ptime;

	ptime = projected_time(0);
	if (logoff_time < ptime)
		logoff_time = ptime;
	logoff_time += ((long)minutes * 60L);
	}



long remaining_time(void)
	{
	time_t curtime;
	long actualtime;

	time(&curtime);
	actualtime = logoff_time - (long)curtime;
	if (actualtime < 0L)
		return 0L;
	return actualtime;
	}



void start_holdtime(void)
	{
	holdtime = (long)time(NULL);
	}



void stop_holdtime(void)
	{
	time_t curtime;
	long actualtime;

	time(&curtime);
	actualtime = (long)curtime - holdtime;
	if (actualtime < 0)
		actualtime = 0;
	logoff_time += actualtime;
	}
