/* s_user.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 28 October 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_user.c_v  $
**                       $Date:   25 Oct 1992 14:07:40  $
**                       $Revision:   1.17  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <io.h>
#include "simplex.h"





void draw_user_screen(void)
	{
	char buffer[60];
	int count;

	send_string(new_color(CYAN),NULL);
	send_string("[2J",NULL);
	send_string("����������������������������������������������������������������������������͸\r\n",NULL);
	for (count = 2; count < 7; count++)
		{
		sprintf(buffer,"�[%u;78H�\r\n",count);
		send_string(buffer,NULL);
		}
	send_string("����������������������������������������������������������������������������Ĵ\r\n",NULL);
	for (count = 8; count < 10; count++)
		{
		sprintf(buffer,"�[%u;39H�[%u;78H�\r\n",count,count);
		send_string(buffer,NULL);
		}
	send_string("����������������������������������������������������������������������������Ĵ\r\n",NULL);
	send_string("�[11;13H�[11;26H�[11;39H�[11;52H�[11;65H�[11;78H�\r\n",NULL);
	send_string("����������������������������������������������������������������������������͵\r\n",NULL);
	send_string("�[13;78H�\r\n",NULL);
	send_string("����������������������������������������������������������������������������͵\r\n",NULL);
	for (count = 15; count < 17; count++)
		{
		sprintf(buffer,"�[%u;39H�[%u;78H�\r\n",count,count);
		send_string(buffer,NULL);
		}
	send_string("����������������������������������������������������������������������������͵\r\n",NULL);
	send_string("� + Next  - Prev  < First  > Last  F Find  A Again  ^ Del  N Name  P Passwd  �\r\n",NULL);
	send_string("� @ Addr-1  & Addr-2  C City  S State  Z Zip  H Home#  D Data#  L Priv-Level �\r\n",NULL);
	send_string("� $ Credit  0 Guest  1 ScrnLen  2 Clear  3 More  4 Ansi  5 Editor  6 Expert  �\r\n",NULL);
	send_string("�     7 F/Attch  8 Flags  U Add User  * Hide Pwds  R Redraw  Q or X Exit     �\r\n",NULL);
#ifdef PROTECTED
	send_string("����������������[22;64H�������������;",NULL);
#else
	send_string("�����������������[22;63H��������������;",NULL);
#endif

	send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("[2;3HUser Number:",NULL);
	send_string("[2;30HUser Type:",NULL);
	send_string("[2;60HStatus:",NULL);
	send_string("[3;10HName:",NULL);
	send_string("[4;7HAddress:",NULL);
	send_string("[4;48HPassword:",NULL);
	send_string("[5;51HState:",NULL);
	send_string("[6;10HCity:",NULL);
	send_string("[6;53HZip:",NULL);

	send_string("[8;4HHome Phone:",NULL);
	send_string("[8;41HLevel:",NULL);
	send_string("[8;54HFlags:",NULL);
	send_string("[9;4HData Phone:",NULL);
	send_string("[9;41HCredit:",NULL);
	send_string("[9;56HLen:",NULL);

	send_string("[11;3HCls:",NULL);
	send_string("[11;15HMore:",NULL);
	send_string("[11;28HAnsi:",NULL);
	send_string("[11;41HEdit:",NULL);
	send_string("[11;54HXpert:",NULL);
	send_string("[11;67HF/Att:",NULL);

	send_string("[15;4HFirst Call:",NULL);
	send_string("[15;27HCalls:",NULL);
	send_string("[15;44HUploads:",NULL);
	send_string("[16;5HLast Call:",NULL);
	send_string("[16;42HDownloads:",NULL);

	send_string(new_color(GREEN | BRIGHT),NULL);
#ifdef PROTECTED
	sprintf(buffer,"[22;16H Simplex/2 (v %u.%02u.%02u) Sysop's User Update System ",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION);
#else
	sprintf(buffer,"[22;17H Simplex (v %u.%02u.%02u) Sysop's User Update System ",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION);
#endif
	send_string(buffer,NULL);
	}



void pascal show_line(int row,int col,char *string,int maxlen)
	{
	char buffer[50];
	int count;

	sprintf(buffer,"[%d;%dH",row,col);
	send_string(buffer,NULL);
	strcpy(buffer,string);
	for (count = (int)strlen(buffer); count < maxlen; count++)
		buffer[count] = ' ';
	buffer[count] = '\0';
	send_string(buffer,NULL);
	}



void fill_user_screen(struct user *tuser,int current,int total,int hidden)
	{
	char buffer[20];
	int count;
	int temp;
	int val = 1;

	send_string(new_color(BROWN | BRIGHT),NULL);
	sprintf(buffer,"%u of %u",current + 1,total);
	show_line(2,16,buffer,13);
	show_line(2,41,tuser->user_flags & USER_GUEST ? "Guest User" : "Regular User",12);
	show_line(2,68,tuser->user_flags & USER_DELETED ? "Deleted" : "Active",7);
	show_line(3,16,tuser->user_name,40);
	show_line(4,16,tuser->user_address1,30);
	if (hidden || (unsigned int)user.user_priv < (unsigned int)tuser->user_priv)
		{
		for (count = 0; count < (int)strlen(tuser->user_password); count++)
			buffer[count] = '*';
		buffer[count] = '\0';
		show_line(4,58,buffer,15);
		}
	else 
		show_line(4,58,tuser->user_password,15);
	show_line(5,16,tuser->user_address2,30);
	show_line(5,58,tuser->user_state,15);
	show_line(6,16,tuser->user_city,30);
	show_line(6,58,tuser->user_zip,15);

	show_line(8,16,tuser->user_home,15);
	show_line(9,16,tuser->user_data,15);

	sprintf(buffer,"%u",(int)(unsigned char)tuser->user_priv);
	show_line(8,49,buffer,3);

	for (count = 0; count < 16; count++)
		{
		if (tuser->user_uflags & val)
			buffer[count] = (char)('A' + count);
		else
			buffer[count] = (char)('a' + count);
		val <<= 1;
		}
	buffer[16] = '\0';
	show_line(8,61,buffer,16);

	sprintf(buffer,"%u",tuser->user_credit);
	show_line(9,49,buffer,5);
	sprintf(buffer,"%u",tuser->user_screenlen);
	show_line(9,61,buffer,2);

	show_line(11,8,tuser->user_flags & USER_CLS ? "Yes" : "No",3);
	show_line(11,21,tuser->user_flags & USER_MORE ? "Yes" : "No",3);
	show_line(11,34,tuser->user_flags & USER_ANSI ? "Yes" : "No",3);
	show_line(11,47,tuser->user_flags & USER_EDITOR ? "Full" : "Line",4);
	show_line(11,61,tuser->user_flags & USER_EXPERT ? "Yes" : "No",3);
	show_line(11,74,tuser->user_flags & USER_FILEATTACH ? "Yes" : "No",3);

	if (tuser->user_firstdate)
		{
		temp = ((tuser->user_firstdate >> 5) & 0xf) - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(buffer,"%02u %s %02u",tuser->user_firstdate & 0x1f,months_table[temp],((tuser->user_firstdate >> 9) + 80) % 100);
		show_line(15,16,buffer,9);
		}
	else
		show_line(15,16,"Never",9);
	sprintf(buffer,"%u",tuser->user_calls);
	show_line(15,34,buffer,5);
	if (tuser->user_lastdate)
		{
		temp = ((tuser->user_lastdate >> 5) & 0xf) - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(buffer,"%02u %s %02u at %02u:%02u",tuser->user_lastdate & 0x1f,months_table[temp],((tuser->user_lastdate >> 9) + 80) % 100,
			tuser->user_lasttime >> 11,(tuser->user_lasttime >> 5) & 0x3f);
		show_line(16,16,buffer,15);
		}
	else 
		show_line(16,16,"Never",15);

	sprintf(buffer,"%luKB (%u)",tuser->user_uploadbytes / 1024L,tuser->user_upload);
	show_line(15,53,buffer,15);
	sprintf(buffer,"%luKB (%u)",tuser->user_dnloadbytes / 1024L,tuser->user_dnload);
	show_line(16,53,buffer,15);
	}



/* caps = 0 -> No capitalization
** caps = 1 -> Capitalize first letters
** caps = 2 -> Capitalize all letters
*/

int edit_user_field(char *prompt,char *oldstring,char *newstring,int len,int caps)
	{
	int count;

	send_string(new_color(RED | BRIGHT),NULL);
	send_string("[13;2H",NULL);
	send_string(prompt,NULL);
	send_string(" ",NULL);
	get_field(newstring,len,caps);
	send_string("[13;2H",NULL);
	for (count = 0; count < 62; count++)
		send_string(" ",NULL);
	if (!newstring[0])
		return 0;
	return strcmp(oldstring,newstring);
	}



int edit_user_number(char *prompt,int min,int max)
	{
	int rtn = 0;
	int count;

	send_string(new_color(RED | BRIGHT),NULL);
	send_string("[13;2H",NULL);
	send_string(prompt,NULL);
	send_string(" ",NULL);
	rtn = get_number(min,max);
	send_string("[13;2H",NULL);
	for (count = 0; count < 50; count++)
		send_string(" ",NULL);
	return rtn;
	}



int edit_user_flags(int *flags)
	{
	char buffer[20];
	int rtn = 0;
	int count;
	int key;
	unsigned int tflags = *flags;
	int change = 1;
	int val = 1;

	send_string(new_color(RED | BRIGHT),NULL);
	send_string("[13;2H",NULL);
	send_string("Set which flags (Uppercase is ON): ",NULL);
	send_string(" ",NULL);
	for (count = 0; count < 16; count++)
		{
		if (tflags & val)
			buffer[count] = (char)('A' + count);
		else
			buffer[count] = (char)('a' + count);
		val <<= 1;
		}
	buffer[16] = '\0';
	send_string(new_color(field_color),NULL);

	do
		{
		if (change)
			{
			send_string("[13;37H",NULL);
			send_string(buffer,NULL);
			change = 0;
			}
		key = get_char();
		if (isalpha(key))
			key = toupper(key);
		switch (key)
			{
			case 'A':
				if (tflags & UF_A)
					{
					tflags &= ~UF_A;
					buffer[0] = 'a';
					}
				else
					{
					tflags |= UF_A;
					buffer[0] = 'A';
					}
				change = 1;
				break;
			case 'B':
				if (tflags & UF_B)
					{
					tflags &= ~UF_B;
					buffer[1] = 'b';
					}
				else
					{
					tflags |= UF_B;
					buffer[1] = 'B';
					}
				change = 1;
				break;
			case 'C':
				if (tflags & UF_C)
					{
					tflags &= ~UF_C;
					buffer[2] = 'c';
					}
				else
					{
					tflags |= UF_C;
					buffer[2] = 'C';
					}
				change = 1;
				break;
			case 'D':
				if (tflags & UF_D)
					{
					tflags &= ~UF_D;
					buffer[3] = 'd';
					}
				else
					{
					tflags |= UF_D;
					buffer[3] = 'D';
					}
				change = 1;
				break;
			case 'E':
				if (tflags & UF_E)
					{
					tflags &= ~UF_E;
					buffer[4] = 'e';
					}
				else
					{
					tflags |= UF_E;
					buffer[4] = 'E';
					}
				change = 1;
				break;
			case 'F':
				if (tflags & UF_F)
					{
					tflags &= ~UF_F;
					buffer[5] = 'f';
					}
				else
					{
					tflags |= UF_F;
					buffer[5] = 'F';
					}
				change = 1;
				break;
			case 'G':
				if (tflags & UF_G)
					{
					tflags &= ~UF_G;
					buffer[6] = 'g';
					}
				else
					{
					tflags |= UF_G;
					buffer[6] = 'G';
					}
				change = 1;
				break;
			case 'H':
				if (tflags & UF_H)
					{
					tflags &= ~UF_H;
					buffer[7] = 'h';
					}
				else
					{
					tflags |= UF_H;
					buffer[7] = 'H';
					}
				change = 1;
				break;
			case 'I':
				if (tflags & UF_I)
					{
					tflags &= ~UF_I;
					buffer[8] = 'i';
					}
				else
					{
					tflags |= UF_I;
					buffer[8] = 'I';
					}
				change = 1;
				break;
			case 'J':
				if (tflags & UF_J)
					{
					tflags &= ~UF_J;
					buffer[9] = 'j';
					}
				else
					{
					tflags |= UF_J;
					buffer[9] = 'J';
					}
				change = 1;
				break;
			case 'K':
				if (tflags & UF_K)
					{
					tflags &= ~UF_K;
					buffer[10] = 'k';
					}
				else
					{
					tflags |= UF_K;
					buffer[10] = 'K';
					}
				change = 1;
				break;
			case 'L':
				if (tflags & UF_L)
					{
					tflags &= ~UF_L;
					buffer[11] = 'l';
					}
				else
					{
					tflags |= UF_L;
					buffer[11] = 'L';
					}
				change = 1;
				break;
			case 'M':
				if (tflags & UF_M)
					{
					tflags &= ~UF_M;
					buffer[12] = 'm';
					}
				else
					{
					tflags |= UF_M;
					buffer[12] = 'M';
					}
				change = 1;
				break;
			case 'N':
				if (tflags & UF_N)
					{
					tflags &= ~UF_N;
					buffer[13] = 'n';
					}
				else
					{
					tflags |= UF_N;
					buffer[13] = 'N';
					}
				change = 1;
				break;
			case 'O':
				if (tflags & UF_O)
					{
					tflags &= ~UF_O;
					buffer[14] = 'o';
					}
				else
					{
					tflags |= UF_O;
					buffer[14] = 'O';
					}
				change = 1;
				break;
			case 'P':
				if (tflags & UF_P)
					{
					tflags &= ~UF_P;
					buffer[15] = 'p';
					}
				else
					{
					tflags |= UF_P;
					buffer[15] = 'P';
					}
				change = 1;
				break;
			}
		}
	while (key != '\r' && key != '\n');

	if ((int)tflags != *flags)
		{
		*flags = (int)tflags;
		send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("[8;61H",NULL);
		send_string(buffer,NULL);
		rtn = 1;
		}

	send_string(new_color(RED | BRIGHT),NULL);
	send_string("[13;2H",NULL);
	for (count = 0; count < 55; count++)
		send_string(" ",NULL);
	return rtn;
	}



void show_user_message(char *message)
	{
	int count;
	int key;

	send_string(new_color(MAGENTA | BRIGHT),NULL);
	send_string("[13;2H ",NULL);
	send_string(message,NULL);
	send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("  [Enter]",NULL);
	while (1)
		{
		key = get_char();
		if (key == '\r' || key == '\n')
			break;
		}
	send_string("[13;2H",NULL);
	for (count = 0; count < 74; count++)
		send_string(" ",NULL);
	}



void update_users(void)
    {
	struct user tuser;
	struct user suser;
	char buffer[50];
	char search[21];
	char *cptr;
	char *cptr1;
	char first[41];
	char last[41];
	int pause = 0;
	int hidden = 1;
	int current = 0;
	int found;
	int count;
	int total;
	int temp;
	int quit = 0;
	int change = 0;
	int key;
	int ok;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		if (user.user_flags & USER_MORE)
			{
			pause = 1;
			user.user_flags &= ~USER_MORE;
			}
		draw_user_screen();
		total = (int)(filelength(fileno(userfd)) / (long)sizeof(struct user));
		if (current == user_number)
			{
			memcpy(&tuser,&user,sizeof(struct user));
			if (pause)
				tuser.user_flags |= USER_MORE;
			}
		else
			{
			fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
			fread(&tuser,sizeof(struct user),1,userfd);
			}
		fill_user_screen(&tuser,current,total,hidden);
		search[0] = '\0';
		do
			{
			send_string(new_color(RED | BRIGHT),NULL);
			send_string("[13;2HWhat is your command? ",NULL);
			do
				{
				ok = 1;
				key = get_char();
				if (change && (key == '+' || key == '-' || key == '<' || key == '>' || key == 'U' || key == 'u' || key == 'F' || key == 'f' || key == 'A' || key == 'a' || key == 'Q' || key == 'q' || key == 'X' || key == 'x'))
					{
					send_string(new_color(MAGENTA | BRIGHT),NULL);
					send_string("[13;2H",NULL);
					send_string("Record has changed!  Save changes (Y/n)? ",NULL);
					if (get_yn_enter(1))
						{
						fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
						fwrite(&tuser,sizeof(struct user),1,userfd);
						if (current == user_number)
							{
							if (pause)
								tuser.user_flags &= ~USER_MORE;
							memcpy(&user,&tuser,sizeof(struct user));
							show_user();
							cptr = tuser.user_name;
							while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
								++cptr;

							cptr1 = user_firstname;
							while (*cptr && is_namechar(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';

							while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
								++cptr;

							cptr1 = user_lastname;
							while (*cptr && is_namechar(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';
							}
						if (current == total)			/* we added one */
							++total;
						sprintf(buffer,"%d (%s)",current,tuser.user_name);
						log_entry(L_USERCHANGE,buffer);
						}
					send_string("[13;2H",NULL);
					for (count = 0; count < 55; count++)
						send_string(" ",NULL);

					change = 0;
					}
				switch (key)
					{
					case '+':			/* next */
						if (current < (total - 1))
							{
							++current;
							if (current == user_number)
								{
								memcpy(&tuser,&user,sizeof(struct user));
								if (pause)
									tuser.user_flags |= USER_MORE;
								}
							else
								{
								fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
								fread(&tuser,sizeof(struct user),1,userfd);
								}
							fill_user_screen(&tuser,current,total,hidden);
							}
						change = 0;
						break;
					case '-':			/* previous */
						if (current)
							{
							--current;
							if (current == user_number)
								{
								memcpy(&tuser,&user,sizeof(struct user));
								if (pause)
									tuser.user_flags |= USER_MORE;
								}
							else
								{
								fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
								fread(&tuser,sizeof(struct user),1,userfd);
								}
							fill_user_screen(&tuser,current,total,hidden);
							}
						change = 0;
						break;
					case '<':			/* first record */
						if (current)
							{
							current = 0;
							if (current == user_number)
								{
								memcpy(&tuser,&user,sizeof(struct user));
								if (pause)
									tuser.user_flags |= USER_MORE;
								}
							else
								{
								fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
								fread(&tuser,sizeof(struct user),1,userfd);
								}
							fill_user_screen(&tuser,current,total,hidden);
							}
						change = 0;
						break;
					case '>':			/* last record */
						if (current != (total - 1))
							{
							current = total - 1;
							if (current == user_number)
								{
								memcpy(&tuser,&user,sizeof(struct user));
								if (pause)
									tuser.user_flags |= USER_MORE;
								}
							else
								{
								fseek(userfd,(long)current * (long)sizeof(struct user),SEEK_SET);
								fread(&tuser,sizeof(struct user),1,userfd);
								}
							fill_user_screen(&tuser,current,total,hidden);
							}
						change = 0;
						break;
					case 'N': 			/* name edit */
					case 'n':
						if ((unsigned char)user.user_priv >= (unsigned char)tuser.user_priv)
							{
							if (edit_user_field("What is user's name?",tuser.user_name,buffer,40,1))
								{
								cptr = buffer;
								while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
									++cptr;

								cptr1 = first;
								while (*cptr && is_namechar(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';

								while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
									++cptr;

								cptr1 = last;
								while (*cptr && is_namechar(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								if (first[0] && last[0])
									{
									sprintf(tuser.user_name,"%s %s",first,last);
									send_string(new_color(BROWN | BRIGHT),NULL);
									show_line(3,16,tuser.user_name,40);
									change = 1;
									}
								else
									show_user_message("You cannot change a name unless you enter a first AND last name!");
								}
							}
						else 
							show_user_message("You cannot change a name with a priv level higher than yours!");
						break;
					case 'P': 			/* password edit */
					case 'p':
						if ((unsigned char)user.user_priv >= (unsigned char)tuser.user_priv)
							{
							if (edit_user_field("What is user's password?",tuser.user_password,buffer,15,2))
								{
								strcpy(tuser.user_password,buffer);
								send_string(new_color(BROWN | BRIGHT),NULL);
								if (hidden)
									{
									for (count = 0; count < (int)strlen(tuser.user_password); count++)
										buffer[count] = '*';
									buffer[count] = '\0';
									show_line(4,58,buffer,15);
									}
								else 
									show_line(4,58,tuser.user_password,15);
								change = 1;
								}
							}
						else
							show_user_message("You cannot change a password with a higher priv than yours!");
						break;
					case '@':
						if (edit_user_field("What is user's address 1?",tuser.user_address1,buffer,30,1))
							{
							strcpy(tuser.user_address1,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(4,16,tuser.user_address1,30);
							change = 1;
							}
						break;
					case '&':
						if (edit_user_field("What is user's address 2?",tuser.user_address2,buffer,30,1))
							{
							strcpy(tuser.user_address2,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(5,16,tuser.user_address2,30);
							change = 1;
							}
						break;
					case 'C':			/* city edit */
					case 'c':
						if (edit_user_field("What is user's city?",tuser.user_city,buffer,30,1))
							{
							strcpy(tuser.user_city,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(6,16,tuser.user_city,30);
							change = 1;
							}
						break;
					case 'S':
					case 's':
						if (edit_user_field("What is user's state?",tuser.user_state,buffer,15,1))
							{
							strcpy(tuser.user_state,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(5,58,tuser.user_state,15);
							change = 1;
							}
						break;
					case 'Z':
					case 'z':
						if (edit_user_field("What is user's zip?",tuser.user_zip,buffer,15,1))
							{
							strcpy(tuser.user_zip,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(6,58,tuser.user_zip,15);
							change = 1;
							}
						break;
					case 'H':			/* home phone edit */
					case 'h':
						send_string(new_color(RED | BRIGHT),NULL);
						send_string("[13;2H",NULL);
						send_string("User's Home Phone (ENTER=Same)? ",NULL);
						get_phone(buffer,0);
						send_string("[13;2H",NULL);
						for (count = 0; count < 50; count++)
							send_string(" ",NULL);
						if (buffer[1] && stricmp(buffer,tuser.user_home))
							{
							strcpy(tuser.user_home,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(8,16,tuser.user_home,15);
							change = 1;
							}
						break;
					case 'D':			/* data phone edit */
					case 'd':
						send_string(new_color(RED | BRIGHT),NULL);
						send_string("[13;2H",NULL);
						send_string("User's Data/Work Phone (ENTER=Same)? ",NULL);
						get_phone(buffer,0);
						send_string("[13;2H",NULL);
						for (count = 0; count < 60; count++)
							send_string(" ",NULL);
						if (buffer[1] && stricmp(buffer,tuser.user_data))
							{
							strcpy(tuser.user_data,buffer);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(9,16,tuser.user_data,15);
							change = 1;
							}
						break;
					case 'L':			/* priv change */
					case 'l':
						if ((unsigned char)user.user_priv >= (unsigned char)tuser.user_priv)
							{
							temp = edit_user_number("User's new priv level [1-255] (ENTER=Same)?",0,255);
							if (temp && temp != (int)(unsigned char)tuser.user_priv)
								{
								if (temp <= (int)(unsigned char)user.user_priv)
									{
									tuser.user_priv = (unsigned char)temp;
									sprintf(buffer,"%u",temp);
									send_string(new_color(BROWN | BRIGHT),NULL);
									show_line(8,49,buffer,3);
									change = 1;
									}
								else
									show_user_message("You cannot set a priv level higher than yours!");
								}
							}
						else
							show_user_message("You cannot change a priv level higher than yours!");
						break;
					case '$':			/* credit change */
						temp = edit_user_number("User's new credit [0-30000]?",0,30000);
						if (temp != tuser.user_credit)
							{
							tuser.user_credit = temp;
							sprintf(buffer,"%u",temp);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(9,49,buffer,5);
							change = 1;
							}
						break;
					case '0':			/* guest user toggle */
						if (tuser.user_flags & USER_GUEST)
							tuser.user_flags &= ~USER_GUEST;
						else
							tuser.user_flags |= USER_GUEST;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(2,41,tuser.user_flags & USER_GUEST ? "Guest User" : "Regular User",12);
						change = 1;
						break;
					case '1':			/* screen len change */
						temp = edit_user_number("How many lines on screen [10-66] (ENTER=24)?",9,66);
						if (temp == 9)
							temp = 24;
						if (temp != tuser.user_screenlen)
							{
							tuser.user_screenlen = (char)temp;
							sprintf(buffer,"%u",temp);
							send_string(new_color(BROWN | BRIGHT),NULL);
							show_line(9,61,buffer,2);
							change = 1;
							}
						break;
					case '2':			/* screen clear toggle */
						if (tuser.user_flags & USER_CLS)
							tuser.user_flags &= ~USER_CLS;
						else
							tuser.user_flags |= USER_CLS;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,8,tuser.user_flags & USER_CLS ? "Yes" : "No",3);
						change = 1;
						break;
					case '3':			/* more toggle */
						if (tuser.user_flags & USER_MORE)
							tuser.user_flags &= ~USER_MORE;
						else
							tuser.user_flags |= USER_MORE;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,21,tuser.user_flags & USER_MORE ? "Yes" : "No",3);
						change = 1;
						break;
					case '4':			/* ansi toggle */
						if (tuser.user_flags & USER_ANSI)
							tuser.user_flags &= ~USER_ANSI;
						else
							tuser.user_flags |= USER_ANSI;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,34,tuser.user_flags & USER_ANSI ? "Yes" : "No",3);
						change = 1;
						break;
					case '5':			/* editor toggle */
						if (tuser.user_flags & USER_EDITOR)
							tuser.user_flags &= ~USER_EDITOR;
						else
							tuser.user_flags |= USER_EDITOR;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,47,tuser.user_flags & USER_EDITOR ? "Full" : "Line",4);
						change = 1;
						break;
					case '6':			/* expert toggle */
						if (tuser.user_flags & USER_EXPERT)
							tuser.user_flags &= ~USER_EXPERT;
						else
							tuser.user_flags |= USER_EXPERT;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,61,tuser.user_flags & USER_EXPERT ? "Yes" : "No",3);
						change = 1;
						break;
					case '7':			/* file attach toggle */
						if (tuser.user_flags & USER_FILEATTACH)
							tuser.user_flags &= ~USER_FILEATTACH;
						else
							tuser.user_flags |= USER_FILEATTACH;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(11,74,tuser.user_flags & USER_FILEATTACH ? "Yes" : "No",3);
						change = 1;
						break;
					case '8':
						if (edit_user_flags(&tuser.user_uflags))
							change = 1;
						break;
					case '^':			/* delete toggle */
						if (tuser.user_flags & USER_DELETED)
							tuser.user_flags &= ~USER_DELETED;
						else
							tuser.user_flags |= (int)USER_DELETED;
						send_string(new_color(BROWN | BRIGHT),NULL);
						show_line(2,68,tuser.user_flags & USER_DELETED ? "Deleted" : "Active",7);
						change = 1;
						break;
					case 'U':			/* add a new user */
					case 'u':
						change = 1;
						current = total;
						memset(&tuser,0,sizeof(struct user));
						tuser.user_flags |= USER_CLS | USER_MORE | USER_ANSI;
						tuser.user_priv = cfg.cfg_newpriv;
						tuser.user_uflags = cfg.cfg_newflags;
						tuser.user_credit = cfg.cfg_newcredit;
						tuser.user_screenlen = 25;
						tuser.user_firstdate = get_cdate();
						tuser.user_lasttime = get_ctime();
						tuser.user_lastdate = tuser.user_firstdate;
						fill_user_screen(&tuser,current,total,hidden);
						break;
					case '*':			/* hide passwords */
						hidden = hidden ? 0 : 1;
						send_string(new_color(BROWN | BRIGHT),NULL);
						if (hidden || (unsigned char)user.user_priv < (unsigned char)tuser.user_priv)
							{
							for (count = 0; count < (int)strlen(tuser.user_password); count++)
								buffer[count] = '*';
							buffer[count] = '\0';
							show_line(4,58,buffer,15);
							}
						else 
							show_line(4,58,tuser.user_password,15);
						break;
					case 'F':			/* search */
					case 'f':
						if (edit_user_field("Search for what name?","",search,20,2))
							{
							bm_setup(search,1);
							count = 0;
							found = 0;
							fseek(userfd,0L,SEEK_SET);
							while (fread(&suser,sizeof(struct user),1,userfd))
								{
								if (bm_search(suser.user_name) != -1)
									{
									if (count != current)
										{
										current = count;
										if (current == user_number)
											{
											memcpy(&tuser,&user,sizeof(struct user));
											if (pause)
												tuser.user_flags |= USER_MORE;
											}
										else
											memcpy(&tuser,&suser,sizeof(struct user));
										fill_user_screen(&tuser,current,total,hidden);
										}
									found = 1;
									break;
									}
								++count;
								}
							if (!found)
								{
								sprintf(buffer,"Nothing was found matching \"%s\"!",search);
								show_user_message(buffer);
								}
							change = 0;
							}
						break;
					case 'A':			/* find next */
					case 'a':
						if (search[0])
							{
							if (current < (total - 1))
								{
								bm_setup(search,1);
								count = current + 1;
								found = 0;
								fseek(userfd,(long)count * (long)sizeof(struct user),SEEK_SET);
								while (fread(&suser,sizeof(struct user),1,userfd))
									{
									strcpy(buffer,suser.user_name);
									strupr(buffer);
									if (strstr(buffer,search))
										{
										current = count;
										if (current == user_number)
											{
											memcpy(&tuser,&user,sizeof(struct user));
											if (pause)
												tuser.user_flags |= USER_MORE;
											}
										else
											memcpy(&tuser,&suser,sizeof(struct user));
										fill_user_screen(&tuser,current,total,hidden);
										found = 1;
										break;
										}
									++count;
									}
								if (!found)
									{
									sprintf(buffer,"Nothing was found matching \"%s\"!",search);
									show_user_message(buffer);
									}
								}
							else
								show_user_message("Already at the end of the file!");
							}
						else
							show_user_message("Nothing has been specified in search string!");
						change = 0;
						break;
					case 'R':			/* redraw screen */
					case 'r':
						draw_user_screen();
						fill_user_screen(&tuser,current,total,hidden);
						break;
					case 'Q':			/* quit/exit */
					case 'q':
					case 'X': 
					case 'x':
						quit = 1;
						break;
					default:
						ok = 0;
						break;
					}
				}
			while (!ok);
			}
		while (!quit);
		cur_line = 0;
		if (pause)
			user.user_flags |= USER_MORE;
		}
	else
		{
		send_string("\r\n\r\n\aSorry.  You must be using ANSI to run the Sysop's User Upgrade System!\r\n",NULL);
		get_enter();
		}
    }



