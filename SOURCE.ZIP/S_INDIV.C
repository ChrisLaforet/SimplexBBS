/* s_indiv.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 8 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_indiv.c_v  $
**                       $Date:   25 Oct 1992 14:08:32  $
**                       $Revision:   1.25  $
**
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include "simplex.h"




#define MAX_READ_OPTIONS			20

struct rt
	{
	char rt_option[41];
	char rt_key;
	};

static struct rt _far read_options[MAX_READ_OPTIONS];
int cur_read_option = 0;
struct msgh _far read_msg;				/* used by read_topics() */
int thread_forward = 0;
int thread_backward = 0;
unsigned char areas_read[MSG_AREAS];	/* bitmapped message areas read */



void mark_read(int areanum)			/* marks area as having being read */
	{
	int byte;
	int bit;

	byte = areanum / 8;
	bit = areanum % 8;
	if (byte < MSG_AREAS)
		areas_read[byte] |= (1 << bit);
	}



int read_option_handler(int key)
	{
	int count;
	int found = 0;

	key = toupper(key);
	for (count = 0; count < cur_read_option; count++)
		{
		if (key == toupper(read_options[count].rt_key))
			{
			found = 1;
			break;
			}
		}
	if (!found)
		{
		if (key == '\r' || key == '\n')
			found = 1;
		else if (key == '+' && thread_forward)
			found = 1;
		else if (key == '-' && thread_backward)
			found = 1;
		}
	if (found)
		return key;
	return 0;
	}



void register_read_option(char *option,char key)
	{
	if ((cur_read_option + 1) >= MAX_READ_OPTIONS)
		return;
	strcpy(read_options[cur_read_option].rt_option,option);
	read_options[cur_read_option].rt_key = key;
	++cur_read_option;
	}



int show_read_options(char *title,int thread_fore,int thread_back)
	{
	char buffer[41];
	int count;
	int kount;
	int key = 0;
	int found = 0;
	int len = (int)strlen(title);
	int offset = 0;

	cur_line = 0;
	send_string("\r\n",NULL);
	purge_input(cfg.cfg_port);
	thread_forward = thread_fore;
	thread_backward = thread_back;
	if (!(user.user_flags & USER_EXPERT))
		{
		if (thread_fore || thread_back)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				key = send_string(new_color(GREEN | BRIGHT),NULL);
			if (!key)
				{
				strcpy(buffer,"Threads: ");
				for (kount = (int)strlen(buffer); kount < len; kount++)
					strcat(buffer," ");
				key = send_string(buffer,read_option_handler);
				if (!key)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						key = send_string(new_color(RED | BRIGHT),read_option_handler);
					if (!key)
						{
						if (thread_back)
							key = send_string("<-> Read Thread Backwards  ",read_option_handler);
						if (!key)
							{
							if (thread_fore)
								key = send_string("<+> Read Thread Forwards",read_option_handler);
							if (!key)
								key = send_string("\r\n",read_option_handler);
							}
						}
					}
				}
			}
		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				key = send_string(new_color(GREEN | BRIGHT),read_option_handler);
			if (!key)
				{
				key = send_string(title,read_option_handler);
				offset = len;
				if (!key)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),read_option_handler);
					for (count = 0; count < cur_read_option; count++)
						{
						sprintf(buffer,"<%c> %s ",read_options[count].rt_key,read_options[count].rt_option);
						if ((offset + strlen(buffer)) > 78)
							{
							cur_line = 0;
							if (key = send_string("\r\n",read_option_handler))
								break;
							for (kount = 0; kount < len; kount++)
								{
								if (key = send_string(" ",read_option_handler))
									break;
								}
							offset = len;
							}
						if (!key)
							{
							if (key = send_string(buffer,read_option_handler))
								break;
							offset += (int)strlen(buffer);
							}
						}
					}
				}
			}
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			key = send_string(new_color(CYAN | BRIGHT),read_option_handler);
		if (!key)
			{
			key = send_string(title,read_option_handler);
			if (!key)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					key = send_string(new_color(BROWN | BRIGHT),read_option_handler);
				if (!key)
					{
					strcpy(buffer,"Choice [");
					if (thread_back)
						strcat(buffer,"-");
					if (thread_fore)
						strcat(buffer,"+");
					for (count = 0; count < cur_read_option; count++)
						{
						buffer[strlen(buffer) + 1] = '\0';
						buffer[strlen(buffer)] = (char)toupper(read_options[count].rt_key);
						}
					strcat(buffer,"]? ");
					key = send_string(buffer,read_option_handler);
					}
				}
			}
		}
	if (!key)
		{
		do
			{
			key = get_char();
			key = toupper(key);
			for (count = 0; count < cur_read_option; count++)
				{
				if (key == toupper(read_options[count].rt_key))
					{
					found = 1;
					break;
					}
				}
			if (!found)
				{
				if (key == '\r' || key == '\n')
					found = 1;
				else if (key == '+' && thread_fore)
					found = 1;
				else if (key == '-' && thread_back)
					found = 1;
				}
			}
		while (!found);
		}
	cur_read_option = 0;
	return key;
	}



int check_fileattach(int area,char *fname)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	int total = 0;
	int current = 0;

	fseek(msglfd,0L,SEEK_SET);
	while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
		{
		if (tmlink.mlink_area == area)
			{
			fseek(msghfd,(long)current * (long)sizeof(struct msgh),SEEK_SET);
			fread(&tmsgh,sizeof(struct msgh),1,msghfd);
			if (tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH)
				{
				if (!stricmp(tmsgh.msgh_subject,fname))
					++total;
				}

			}
		++current;
		}
	return total;
	}



int check_name(char *name)
	{
	int rtn = 0;

	if (!stricmp(name,user.user_name))
		rtn = 1;
	else if (user.user_alias[0][0] && !stricmp(name,user.user_alias[0]))
		rtn = 1;
	else if (user.user_alias[1][0] && !stricmp(name,user.user_alias[1]))
		rtn = 1;
	else if (user.user_alias[2][0] && !stricmp(name,user.user_alias[2]))
		rtn = 1;
	else if (user.user_alias[3][0] && !stricmp(name,user.user_alias[3]))
		rtn = 1;
	return rtn;
	}



/* read_individual() returns:
**
** return 0  -> exit
** return 1  -> next
** return 2  -> change direction
** return 3  -> message was deleted
** return 4  -> combined board skip area
** return -1 -> access not granted
*/


int read_individual(int area,int priv,int pflags,int *total_msgs,int current,int next,int pause,int change,int comb,int direction)
	{
	struct fl *tflist[1];
	struct fl tfl;
	struct msgh tmsgh;
	struct msgh pmsgh;
	struct msgh nmsgh;
	struct msg *tmsg;
	struct msg *tmsg1;
	struct mlink tmlink;
	struct nl tnl;
	struct nlix tnlix;
	char buffer[100];
	char buffer1[70];
	char from[41];
	char to[41];
	char path[51];
	char *from_name[5];
	char *tonames[2];
	long offset;
	int netmail_area = 0;
	int user_flags;
	int net_flags;
	int total;
	int private;
	int count;
	int kount;
	int kurrent;
	int renum;
	int kludge = 0;
	int again;
	int end;
	int rtn = 0;
	int ret;
	int key;
	int tzone;
	int zone;
	int net;
	int node;
	int sent;
	int tval;
	int cost;
	int valid;
	int new;
	int ok;

	tmsg = get_msgarea(area);		/* assuming calling function takes care of verifying this */
	fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
	fread(&tmsgh,1,sizeof(struct msgh),msghfd);

	do
		{
		new = 0;
		for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
			{
			if (area == lastread[count]->lr_area)
				{
				new = lastread[count]->lr_prev + 1;
				break;
				}
			}
		again = 0;
		strcpy(to,get_addressee(tmsgh.msgh_to));
		strcpy(from,get_addressee(tmsgh.msgh_from));
		if (!(tmsgh.msgh_flags & MSGH_PRIVATE) || ((tmsgh.msgh_flags & MSGH_PRIVATE) &&
			(user.user_priv >= tmsg->msg_sysoppriv || check_name(to) || check_name(from) || (tmsgh.msgh_flags & MSGH_URGENT))))
			{
			if ((user.user_flags & USER_CLS) && pause)
				send_string("\f",NULL);
			else
				send_string("\r\n\r\n",NULL);
			if (!pause)
				{
				user_flags = user.user_flags;
				user.user_flags &= ~USER_MORE;
				}
			ret = read_message(&tmsgh,tmsg->msg_areaname,next,*total_msgs,new <= tmsgh.msgh_number ? 1 : 0,kludge);
			kludge = 0;			/* show ctrl-A junk? */
			cur_line = 0;
			if (!pause)
				user.user_flags = user_flags;
			for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
				{
				if (area == lastread[count]->lr_area)
					{
					lastread[count]->lr_new = tmsgh.msgh_number;
					break;
					}
				}
			if (!(tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH) && check_name(to) && !(tmsgh.msgh_flags & MSGH_RECEIVED))
				{
				tmsgh.msgh_flags |= MSGH_RECEIVED;
				fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
				fflush(msghfd);

				fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fread(&tmlink,sizeof(struct mlink),1,msglfd);
				tmlink.mlink_flags |= MSGH_RECEIVED;
				fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
				fflush(msglfd);							  
				}
			if (ret)
				{
				if (ret == 1 && next)
					{
					memcpy(&read_msg,&tmsgh,sizeof(struct msgh));		/* in case it is needed by read_topics() */
					return 1;
					}
				else if (ret == 2 && change)
					{
					memcpy(&read_msg,&tmsgh,sizeof(struct msgh));		/* in case it is needed by read_topics() */
					return 2;
					}
				else if (ret == -1 && !pause)
					{
					memcpy(&read_msg,&tmsgh,sizeof(struct msgh));		/* in case it is needed by read_topics() */
					return 0;
					}
				}
			end = 0;
			if (pause)
				{
				do
					{
					if (next)
						register_read_option("Next",'N');
					if ((tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH) && cfg.cfg_fapath[0] && (user.user_priv >= tmsg->msg_sysoppriv || check_name(to)))
						register_read_option("Get File",'G');
					if (change)
						register_read_option("Chng Direction",'C');
					if (comb)
						register_read_option("Skip Area",'#');

					register_read_option("Again",'A');

					if (((!(tmsg->msg_flags & MSG_ECHO) && priv >= (int)(unsigned int)tmsg->msg_writepriv) || ((tmsg->msg_flags & MSG_ECHO) && user.user_priv >= tmsg->msg_writepriv)) && (tmsg->msg_writeflags & pflags) == tmsg->msg_writeflags)		/* if an echo, no way can they reply to the message w/o TRUE priv */
						register_read_option("Reply",'R');
					if (tmsg->msg_flags & MSG_ECHO)
						{
						tval = tmsg->msg_source;
						if (tval < 0 || tval > 5)
							tval = 0;
						if (tval)
							{
							if (cfg.cfg_akanet[tval - 1])
								{
								zone = cfg.cfg_akazone[tval - 1];
								net = cfg.cfg_akanet[tval - 1];
								node = cfg.cfg_akanode[tval - 1];
								}
							else
								tval = 0;
							}
						if (!tval)
							{
							zone = cfg.cfg_zone;
							net = cfg.cfg_net;
							node = cfg.cfg_node;
							}
						if (netmail_area = get_netmail_area(zone,net,node))
							{
							tmsg1 = get_msgarea(netmail_area);
							if (user.user_priv >= tmsg1->msg_writepriv && (tmsg1->msg_writeflags & user.user_uflags) == tmsg1->msg_writeflags)
								register_read_option("Netmail Reply",'$');
							}
						}
					else if (tmsg->msg_flags & MSG_NET)
						netmail_area = area;

					if (netmail_area && (tmsg->msg_flags & MSG_ECHO || tmsg->msg_flags & MSG_NET))
						register_read_option("Search Nodelist",'@');

					if (user.user_priv >= tmsg->msg_sysoppriv || check_name(to) || check_name(tmsgh.msgh_from))
						register_read_option("Delete",'D');
					if (user.user_priv >= tmsg->msg_sysoppriv || check_name(to))
						register_read_option("Forward Msg",'F');
					if (user.user_priv >= tmsg->msg_sysoppriv)
						{
						if (!(tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH))
							register_read_option("Move",'M');
						register_read_option("Export",'E');
						if (tmsg->msg_flags & MSG_ECHO || tmsg->msg_flags & MSG_NET)
							register_read_option("Kludge",'K');
						}
					if ((user.user_priv >= tmsg->msg_sysoppriv && stricmp(to,"all")) || check_name(to))
						register_read_option("Keep Unreceived",'U');

					if (tmsg->msg_flags & MSG_PRIVATE && tmsg->msg_flags & MSG_PUBLIC)
						{
						if ((user.user_priv >= tmsg->msg_sysoppriv && stricmp(to,"all")) || check_name(to) || check_name(tmsgh.msgh_from))
							{
							if (tmsgh.msgh_flags & MSGH_PRIVATE)
								register_read_option("Mark Public",'*');
							else 
								register_read_option("Mark Restricted",'*');
							}
						}
					register_read_option("Exit",'X');

					sprintf(buffer,"%s",direction == -1 ? "Message: " : direction ? "Forward: " : "Backward: ");
					key = show_read_options(buffer,tmsgh.msgh_next,tmsgh.msgh_prev);
					switch (key)
						{
						case '+':
							read_thread(area,priv,pflags,total_msgs,current,1);
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nFinished reading FORWARDS through thread.\r\n",NULL);
							send_string("Returning to original message....\r\n",NULL);
							get_enter();

							/* in case we deleted messages */
							fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fread(&tmsgh,1,sizeof(struct msgh),msghfd);
							end = 1;
							again = 1;
							break;
						case '-':
							read_thread(area,priv,pflags,total_msgs,current,0);
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nFinished reading BACKWARDS through thread.\r\n",NULL);
							send_string("Returning to original message....\r\n",NULL);
							get_enter();

							/* in case we deleted messages */
							fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fread(&tmsgh,1,sizeof(struct msgh),msghfd);
							end = 1;
							again = 1;
							break;
						case 'A':
						case 'a':
							again = 1;
							end = 1;
							break;
						case 'U':
						case 'u':
							tmsgh.msgh_flags &= ~MSGH_RECEIVED;
							fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
							fflush(msghfd);

							fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
							fread(&tmlink,sizeof(struct mlink),1,msglfd);
							tmlink.mlink_flags &=~ MSGH_RECEIVED;
							fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
							fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
							fflush(msglfd);

							if (next)
								rtn = 1;
							else
								rtn = 0;
							end = 1;
							break;
						case '*':
							if (tmsgh.msgh_flags & MSGH_PRIVATE)
								tmsgh.msgh_flags &= ~MSGH_PRIVATE;
							else 
								tmsgh.msgh_flags |= MSGH_PRIVATE;
							fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
							fflush(msghfd);

							fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
							fread(&tmlink,sizeof(struct mlink),1,msglfd);
							if (tmlink.mlink_flags & MSGH_PRIVATE)
								tmlink.mlink_flags &= ~MSGH_PRIVATE;
							else 
								tmlink.mlink_flags |= MSGH_PRIVATE;
							fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
							fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
							fflush(msglfd);
							again = 1;
							end = 1;
							break;
						case 'R':
						case 'r':
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\n\r\nAre you sure that you want to reply to this message (ENTER=Yes)? ",NULL);
							if (get_yn_enter(1))
								{
								/* we must find the true end of the chain -- walk the reply chain */
								offset = (long)(current - 1) * sizeof(struct msgh);
								memcpy(&nmsgh,&tmsgh,sizeof(struct msgh));
								while (nmsgh.msgh_next)
									{
									/**** This is a safety net to catch references beyond EOF or before BOF *****/
									if (nmsgh.msgh_next < 0 || nmsgh.msgh_next > mdata.mdata_msgs)
										{
										sprintf(buffer,"Correcting invalid next message %d while walking reply chain.",nmsgh.msgh_next);
										log_entry(L_ERROR,buffer);
										nmsgh.msgh_next = 0;
										fseek(msghfd,offset,SEEK_SET);
										fwrite(&nmsgh,1,sizeof(struct msgh),msghfd);
										fflush(msghfd);
										break;
										}

									offset = (long)(nmsgh.msgh_next - 1) * (long)sizeof(struct msgh);
									fseek(msghfd,offset,SEEK_SET);
									fread(&nmsgh,1,sizeof(struct msgh),msghfd);
									}

								from[0] = '\0';
								if (tmsg->msg_flags & MSG_ALIAS)
									{
									if (user.user_alias[0][0] || user.user_alias[1][0] || user.user_alias[2][0] || user.user_alias[3][0])
										{
										from_name[0] = user.user_name;
										total = 1;

										for (count = 0; count < 4; count++)
											{
											if (user.user_alias[count][0])
												{
												from_name[total] = user.user_alias[count];
												++total;
												}
											}

										/* now for a menu of name choices */
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\nAliases are allowed in this message area.  Choose which of the following\r\n",NULL);
										send_string("   names you wish to use in this message:\r\n\r\n",NULL);

										for (count = 0; count < total; count++)
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(BROWN | BRIGHT),NULL);
											sprintf(buffer,"      %d) ",count + 1);
											send_string(buffer,NULL);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(CYAN | BRIGHT),NULL);
											send_string("\"",NULL);
											send_string(from_name[count],NULL);
											send_string("\"\r\n",NULL);
											}
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(WHITE | BRIGHT),NULL);
										sprintf(buffer,"\r\nWhat is your choice [1-%d] (ENTER=1)? ",total);
										send_string(buffer,NULL);

										ok = 0;
										do
											{
											key = get_char();
											switch (key)
												{
												case '1':
												case '\r':
												case '\n':
													strcpy(from,from_name[0]);
													ok = 1;
													break;

												case '2':
													if (total > 1)
														{
														strcpy(from,from_name[1]);
														ok = 1;
														}
													break;

												case '3':
													if (total > 2)
														{
														strcpy(from,from_name[2]);
														ok = 1;
														}
													break;

												case '4':
													if (total > 3)
														{
														strcpy(from,from_name[3]);
														ok = 1;
														}
													break;

												case '5':
													if (total > 4)
														{
														strcpy(from,from_name[4]);
														ok = 1;
														}
													break;
												}
											}
										while (!ok);
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n   From: ",NULL);
										mark_field(40);
										send_string(from,NULL);
										unmark_field();
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\n",NULL);
										}
									}

								if (!from[0])
									strcpy(from,user.user_name);

								/* prepare subject */
								if (strnicmp(tmsgh.msgh_subject,"RE:",3))
									strcpy(buffer1,"Re: ");
								else
									buffer1[0] = '\0';
								strcat(buffer1,tmsgh.msgh_subject);
								buffer1[60] = '\0';			/* cut it down to size in case */

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nYou may change the subject line for the reply, otherwise press ENTER to\r\n",NULL);
								send_string("    keep the current subject.\r\n\r\n",NULL);
								send_string("    Subject: ",NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(field_color),NULL);
								send_string(buffer1,NULL);
								for (count = (int)strlen(buffer1); count < 61; count++)
									send_string(" ",NULL);

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nNew Subject: ",NULL);
								get_field(buffer,60,0);
								if (buffer[0])
									strcpy(buffer1,buffer);

								if (tmsg->msg_flags & MSG_NET)
									{
									zone = tmsgh.msgh_szone;
									net = tmsgh.msgh_snet;
									node = tmsgh.msgh_snode;
									net_flags = 0;
									cost = 0;

									tzone = 0;
									count = 1;
									valid = 0;
									fseek(nidxfd,(long)sizeof(struct nlix),SEEK_SET);
									while (fread(&tnlix,sizeof(struct nlix),1,nidxfd))
										{
										/* Version 6 nodelist encodes zones as node == -2  and regions as -1 */
										if (tnlix.nlix_node == NLIX_ZONE && tnlix.nlix_net != tzone)
   											tzone = tnlix.nlix_net;
										if (tnlix.nlix_node == NLIX_ZONE || tnlix.nlix_node == NLIX_REGION)		/* so we can match network zone and regional hubs! */
											tnlix.nlix_node = 0;
										if (node == tnlix.nlix_node && net == tnlix.nlix_net && ((zone && zone == tzone) || !zone))
											{
											valid = 1;
											break;
											}
										++count;
										}
									if (valid)
										{
										fseek(nlstfd,(long)count * (long)sizeof(struct nl),SEEK_SET);
										fread(&tnl,sizeof(struct nl),1,nlstfd);
										cost = tnl.nl_cost;

										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(MAGENTA | BRIGHT),NULL);

										cur_line = 0;
										send_string("\r\n",NULL);
										send_string("Replying to: ",NULL);
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(BROWN | BRIGHT),NULL);
										send_string(tnl.nl_bbsname,NULL);
										sprintf(buffer," at %d:%d/%d",tzone,tnl.nl_net,tnl.nl_node);
										send_string(buffer,NULL);
										send_string("\r\n",NULL);
										send_string("             ",NULL);
										send_string(tnl.nl_city,NULL);
										send_string("\r\n",NULL);

										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(CYAN | BRIGHT),NULL);
										send_string("             ",NULL);
										send_string("Phone: ",NULL);
										send_string(tnl.nl_phone,NULL);
										if (!(tnl.nl_flags & NL_CM))
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											send_string(" (Not Crash-Mail)",NULL);
											}
										send_string("\r\n",NULL);

										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(RED | BRIGHT),NULL);
										send_string("              ",NULL);
										send_string("Baud: ",NULL);
										sprintf(buffer,"%u %s",(unsigned int)tnl.nl_baud * 300,(char *)(tnl.nl_modemtype & 0x1 ? "(HST)" : (tnl.nl_modemtype & 0x2 ? "(PEP)" : "")));
										send_string(buffer,NULL);
										send_string("\r\n",NULL);

										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(WHITE | BRIGHT),NULL);
										send_string("              ",NULL);
										send_string("Cost: ",NULL);
										sprintf(buffer,"%u credit%s from your total of %u credit%s",tnl.nl_cost,tnl.nl_cost != 1 ? "s" : "",user.user_credit,user.user_credit != 1 ? "s" : "");
										send_string(buffer,NULL);
										send_string("\r\n\r\n",NULL);
										}
									else 
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(RED | BRIGHT),NULL);
										if (user.user_priv >= tmsg->msg_sysoppriv)
											{
											send_string("\r\nNetwork address is not in the nodelist.  Replying anyway!\r\n",NULL);
											valid = 1;
											}
										else
											send_string("\r\nNetwork address is not in the nodelist.  Reply cancelled!\r\n",NULL);
										get_enter();
										}

									if (valid)
										{
										net_flags |= get_net_route(user.user_credit,cost);
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("Kill message after sending (Y/n)? ",NULL);
										if (get_yn_enter(1))
											net_flags |= NET_KILLSENT;
										}
									}
								else
									{
									zone = 0;
									net = 0;
									node = 0;
									cost = 0;
									net_flags = 0;
									valid = 1;
									}

				 				if (valid)
			 						{
									tonames[0] = tmsgh.msgh_from;
									tonames[1] = NULL;
								 	if (rtn = do_message(from,tonames,buffer1,area,priv,user.user_uflags,current,tmsgh.msgh_flags & MSGH_PRIVATE ? MESSAGE_PRIVATE : 0,zone,net,node,cost,net_flags))
										{
										/* now we make sure that we write the updated chain member */
										nmsgh.msgh_next = rtn;
										fseek(msghfd,offset,SEEK_SET);
										fwrite(&nmsgh,1,sizeof(struct msgh),msghfd);
										fflush(msghfd);

										/* if the link to next is in our current message... */
										if (nmsgh.msgh_number == tmsgh.msgh_number)
											memcpy(&tmsgh,&nmsgh,sizeof(struct msgh));

										*total_msgs += 1;
										}
									}
			 					else if (valid && tmsg->msg_flags & MSG_NET)
			 						{
			 						send_string("Sorry, you do not have enough netmail credit to send message.\r\n",NULL);
			 						get_enter();
			 						}
								end = 1;
								again = 1;
								}
							else
								{
								again = 1;
								end = 1;
								}
							break;
						case '@':
							if (netmail_area && ((tmsg->msg_flags & MSG_ECHO) || (tmsg->msg_flags & MSG_NET)))
								{
								check_net_address(1);
								again = 1;
								end = 1;
								}
							break;
						case '$':
							if ((tmsg->msg_flags & MSG_ECHO) && netmail_area)
								{
								tmsg1 = get_msgarea(netmail_area);
								if (user.user_priv >= tmsg1->msg_writepriv && (tmsg1->msg_writeflags & user.user_uflags) == tmsg1->msg_writeflags)
									{
			 						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			 							send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\nAre you sure that you want to reply to this using Netmail (ENTER=Yes)? ",NULL);
									if (get_yn_enter(1))
		 								{
										tmsg1 = get_msgarea(netmail_area);

										if (get_net_address("Send Netmail reply to what Net Address (ENTER=Quit)?","Sending Netmail reply to:",&zone,&net,&node,&cost,-1,-1))
											{
											net_flags = get_net_route(user.user_credit,cost);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											send_string("Kill message after sending (Y/n)? ",NULL);
											if (get_yn_enter(1))
												net_flags |= NET_KILLSENT;
											send_string("Make this message restricted (Y/n)? ",NULL);
												private = get_yn_enter(1);

											tonames[0] = tmsgh.msgh_from;
											tonames[1] = NULL;

											from[0] = '\0';
											if (tmsg1->msg_flags & MSG_ALIAS)
												{
												if (user.user_alias[0][0] || user.user_alias[1][0] || user.user_alias[2][0] || user.user_alias[3][0])
													{
													from_name[0] = user.user_name;
													total = 1;

													for (count = 0; count < 4; count++)
														{
														if (user.user_alias[count][0])
															{
															from_name[total] = user.user_alias[count];
															++total;
															}
														}

													/* now for a menu of name choices */
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(GREEN | BRIGHT),NULL);
													send_string("\r\nAliases are allowed in this message area.  Choose which of the following\r\n",NULL);
													send_string("   names you wish to use in this message:\r\n\r\n",NULL);

													for (count = 0; count < total; count++)
														{
														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(BROWN | BRIGHT),NULL);
														sprintf(buffer,"      %d) ",count + 1);
														send_string(buffer,NULL);

														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(CYAN | BRIGHT),NULL);
														send_string("\"",NULL);
														send_string(from_name[count],NULL);
														send_string("\"\r\n",NULL);
														}
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(WHITE | BRIGHT),NULL);
													sprintf(buffer,"\r\nWhat is your choice [1-%d] (ENTER=1)? ",total);
													send_string(buffer,NULL);

													ok = 0;
													do
														{
														key = get_char();
														switch (key)
															{
															case '1':
															case '\r':
															case '\n':
																strcpy(from,from_name[0]);
																ok = 1;
																break;

															case '2':
																if (total > 1)
																	{
																	strcpy(from,from_name[1]);
																	ok = 1;
																	}
																break;

															case '3':
																if (total > 2)
																	{
																	strcpy(from,from_name[2]);
																	ok = 1;
																	}
																break;

															case '4':
																if (total > 3)
																	{
																	strcpy(from,from_name[3]);
																	ok = 1;
																	}
																break;

															case '5':
																if (total > 4)
																	{
																	strcpy(from,from_name[4]);
																	ok = 1;
																	}
																break;
															}
														}
													while (!ok);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(GREEN | BRIGHT),NULL);
													send_string("\r\n   From: ",NULL);
													mark_field(40);
													send_string(from,NULL);
													unmark_field();
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(GREEN | BRIGHT),NULL);
													send_string("\r\n\r\n",NULL);
													}
												}

											if (!from[0])
												strcpy(from,user.user_name);

											/* prepare subject */
			 								if (strnicmp(tmsgh.msgh_subject,"RE:",3))
			 									strcpy(buffer,"Re: ");
		 									else
												buffer[0] = '\0';
											strcat(buffer,tmsgh.msgh_subject);
											buffer[70] = '\0';			/* cut it down to size in case */

											do_message(from,tonames,buffer,netmail_area,priv,user.user_uflags,current,private ? MESSAGE_PRIVATE : 0,zone,net,node,cost,net_flags);
											}
										}
									}
								end = 1;
								again = 1;
								}
							break;
						case 'D':
						case 'd':
							if (!(tmsgh.msgh_flags & MSGH_DELETED))
								{
								if ((tmsg->msg_flags & MSG_ECHO) && user.user_priv < tmsg->msg_sysoppriv)
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\r\n\r\n\aSorry.  You cannot delete this message to you since it is\r\n",NULL);
									send_string("a part of an echomail area.  If it is offensive or you have an\r\n",NULL);
									send_string("important reason for it to be deleted, please drop a note to the\r\n",NULL);
									send_string("Sysop providing reasons for its deletion.\r\n\r\n",NULL);

									get_enter();
									again = 1;
									end = 1;
									}
								else
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\nAre you sure that you want to delete this message (ENTER=No)? ",NULL);
									if (get_yn_enter(0))
										{
										send_string("\r\nPlease wait a few moments.  Deleting message....",NULL);

										if (tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH)
											{
											if (check_fileattach(area,tmsgh.msgh_subject) < 2)
												{
												strcpy(buffer,cfg.cfg_fapath);
												if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
													strcat(buffer,P_SSEP);
												strcat(buffer,tmsgh.msgh_subject);
												unlink(buffer);				/* delete file */
												}
											}

										/* forge message links first */
										if (tmsgh.msgh_prev)
											{
											/**** Check that our message number is existant ****/
											if (tmsgh.msgh_prev <= 0 || tmsgh.msgh_prev > mdata.mdata_msgs)
												{
												sprintf(buffer,"Invalid prev message %d while linking reply chain during delete.",tmsgh.msgh_prev);
												log_entry(L_ERROR,buffer);
												}
											else
												{
												fseek(msghfd,(long)(tmsgh.msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
												fread(&pmsgh,1,sizeof(struct msgh),msghfd);
												pmsgh.msgh_next = tmsgh.msgh_next;		/* may be valid or 0 */
												fseek(msghfd,(long)(tmsgh.msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
												fwrite(&pmsgh,1,sizeof(struct msgh),msghfd);
												}
											}
										if (tmsgh.msgh_next)
											{
											/**** Check that our message number is existant ****/
											if (tmsgh.msgh_next <= 0 || tmsgh.msgh_next > mdata.mdata_msgs)
												{
												sprintf(buffer,"Invalid next message %d while linking reply chain during delete.",tmsgh.msgh_next);
												log_entry(L_ERROR,buffer);
												}
											else
												{
												fseek(msghfd,(long)(tmsgh.msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
												fread(&nmsgh,1,sizeof(struct msgh),msghfd);
												nmsgh.msgh_prev = tmsgh.msgh_prev;		/* may be valid of 0 */
												fseek(msghfd,(long)(tmsgh.msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
												fwrite(&nmsgh,1,sizeof(struct msgh),msghfd);
												}
											}

										/* now mark the message as deleted */
										renum = tmsgh.msgh_number;		/* save for later use */
										tmsgh.msgh_number = 0;
										tmsgh.msgh_flags |= MSGH_DELETED;
										if (tmsgh.msgh_flags & MSGH_ECHO_UNSENT)
											tmsgh.msgh_flags &= ~MSGH_ECHO_UNSENT;
										if (tmsgh.msgh_flags & MSGH_NET_UNSENT)
											tmsgh.msgh_flags &= ~MSGH_NET_UNSENT;
										fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
										fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
										fflush(msghfd);

										/* log the entry */
										sprintf(buffer,"#%u on board %u",renum,area);
										log_entry(L_MSGDELETED,buffer);

										/* now update data file */
										++mdata.mdata_del;
										fseek(msgdfd,0L,SEEK_SET);
										fwrite(&mdata,1,sizeof(struct mdata),msgdfd);
										for (count = 0; count < cur_msgcount; count++)
											{
											if (msgcount[count].mc_area == area)
												{
												if (msgcount[count].mc_msgs)
													{
													--msgcount[count].mc_msgs;
													fseek(msgdfd,(long)sizeof(struct mdata) + (long)count * (long)sizeof(struct mc),SEEK_SET);	/* seek to position */
													fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
													}
												break;
												}
											}
										fflush(msgdfd);			/* flush it to disk! */

										/* now to update the record link file */
										fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
										fread(&tmlink,sizeof(struct mlink),1,msglfd);
										tmlink.mlink_flags |= MSGH_DELETED;		/* mark message as deleted */
										fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
										fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
										fflush(msglfd);

										/* now to renumber all consecutive messages */
										count = current + 1;
										fseek(msglfd,(long)(count - 1) * (long)sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												{
												fseek(msghfd,(long)(count - 1) * (long)sizeof(struct msgh),SEEK_SET);
												fread(&nmsgh,sizeof(struct msgh),1,msghfd);
												fseek(msghfd,(long)(count - 1) * (long)sizeof(struct msgh),SEEK_SET);
												nmsgh.msgh_number = renum;
												fwrite(&nmsgh,sizeof(struct msgh),1,msghfd);

												fseek(msglfd,(long)(count - 1) * (long)sizeof(struct mlink),SEEK_SET);
												tmlink.mlink_number = renum;
												fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
												fseek(msglfd,0L,SEEK_CUR);		/* seek between write and read -- required */
												++renum;
												}
											++count;
											}
										fflush(msghfd);

										unmark(area,current);		/* in case it is marked */
										send_string("Message has been deleted!\r\n",NULL);
										end = 1;
										rtn = 3;
										*total_msgs -= 1;
										}
									else
										{
										again = 1;
										end = 1;
										}
									}
								}
							else
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nMessage has already been deleted!\r\n",NULL);
								again = 1;
								end = 1;
								}
							break;
						case 'N':
						case 'n':
							rtn = 1;
							end = 1;
							break;
						case 'C':
						case 'c':
							rtn = 2;
							end = 1;
							break;
						case '#':
							if (comb)
								{
								rtn = 4;
								end = 1;
								}
							break;
						case 'F':
						case 'f':
							if (forward_message(tmsg,&tmsgh,(long)(current - 1) * (long)sizeof(struct msgh)))
								*total_msgs += 1;
							end = 1;
							again = 1;
							break;
						case 'M':
						case 'm':
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							if (!(tmsgh.msgh_flags & MSGH_DELETED))
								{
								send_string("\r\n\r\nMove this message to which of these areas?\r\n\r\n",NULL);

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);

								kurrent = 0;
								for (count = get_minmsgarea(); count <= get_maxmsgarea(); count++)
									{
									if ((count != area) && (tmsg1 = get_msgarea(count)))
										{
										cur_line = 0;
										if (kurrent && !(kurrent % 3))
											send_string("\r\n",NULL);
										sprintf(buffer,"%4d: %.17s",count,tmsg1->msg_areaname);
										send_string(buffer,NULL);
										for (kount = (int)strlen(buffer); kount < 25; kount++)
											send_string(" ",NULL);
										++kurrent;
										}
									}
								do
									{
									cur_line = 0;
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\nMove message into what area (ENTER=Exit)? ",NULL);
									if (kurrent = get_number(0,9999))
										{
										if (!(tmsg1 = get_msgarea(kurrent)))
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(RED | BRIGHT),NULL);
											send_string("\r\nInvalid message area number provided....please reenter!",NULL);
											}
										}
									}
								while (kurrent && !tmsg1);
								if (kurrent && tmsg1)
									{
									cur_line = 0;
									send_string("\r\nAre you sure that you want to move this message (ENTER=No)? ",NULL);

									if (get_yn_enter(0))
										{
										move_message(tmsg,&tmsgh,current,kurrent);
										unmark(area,current);
										rtn = 3;		/* tell read function that message was "deleted" */
										*total_msgs -= 1;
										}
									else
										again = 1;
									}
								else 
									again = 1;
								}
							else
								{
								send_string("\r\n\r\nMessage has been deleted!\r\n",NULL);
								again = 1;
								}
							end = 1;
							break;
						case 'E':
						case 'e':
							export_message(&tmsgh,tmsg->msg_areaname,*total_msgs,new <= tmsgh.msgh_number ? 1 : 0);
							again = 1;
							end = 1;
							break;
						case 'K':
						case 'k':
							kludge = 1;
							again = 1;
							end = 1;
							break;
						case 'G':
						case 'g':
							sent = 0;
							if (!user_baud)
								{
								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nCopy to where (ENTER=Quit)? ",NULL);
								get_fname(path,48,0,1);
								if (path[0])
									{
									if (path[strlen(path) - 1] != P_CSEP)
										strcat(path,P_SSEP);
									tfl.fl_name = tmsgh.msgh_subject;
									tfl.fl_location = 0;
									tfl.fl_update = 0;
									tflist[0] = &tfl;
									copy_out(0,buffer,tflist,1);
									sent = 1;
									}
								}
							else
								{
								if ((xmit_onefile(AREA_FATTACH,tmsgh.msgh_subject,0) == 1) && !(tmsgh.msgh_flags & MSGH_URGENT))
									sent = 1;
								}
							if (sent)
								{
								if (check_name(to))
									{
									if (check_fileattach(area,tmsgh.msgh_subject) < 2)
										{
										strcpy(buffer,cfg.cfg_fapath);
										if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
											strcat(buffer,P_SSEP);
										strcat(buffer,tmsgh.msgh_subject);
										unlink(buffer);				/* delete file */
										}
									tmsgh.msgh_flags &= ~MSGH_LOCAL_FILEATTACH;

									tmsgh.msgh_flags |= MSGH_RECEIVED;
									fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
									fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
									fflush(msghfd);

									fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
									fread(&tmlink,sizeof(struct mlink),1,msglfd);
									tmlink.mlink_flags |= MSGH_RECEIVED;
									fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
									fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
									fflush(msglfd);							  
									}
								}
							again = 1;
							end = 1;
							break;
						case 'X':
						case 'x':
							rtn = 0;
							end = 1;
							break;
						case '\r':
						case '\n':
							if (next)
								rtn = 1;		/* act as Next otherwise act as X */
							else
								rtn = 0;
							end = 1;
							break;
						}

					if (!*total_msgs)
						{
						end = 1;
						memcpy(&read_msg,&tmsgh,sizeof(struct msgh));		/* in case it is needed by read_topics() */
						return rtn;
						}
					}
				while (!end);
				send_string("\r\n\r\n",NULL);
				}
			else		/* no pausing */
				{
				rtn = 1;
				again = 0;
				}
			}
		else
			rtn = -1;				/* message is private */
		}
	while (again);
	memcpy(&read_msg,&tmsgh,sizeof(struct msgh));		/* in case it is needed by read_topics() */
	return rtn;
	}
