/* s_node.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 19 May 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_node.c_v  $
**                       $Date:   25 Oct 1992 14:07:32  $
**                       $Revision:   1.21  $
**
*/


#include <stdio.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "simplex.h"


#define PERM_DIRECT			0x1
#define PERM_ROUTE			0x2
#define PERM_HOLD			0x4




int nodelist_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'N':
		case 'B':
		case 'C':
		case 'A':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



void search_nodelist(void)
	{
	struct nl tnl;
	char buffer[81];
	char name[21];
	char *cptr;
	int zone;
	int count;
	int found;
	int tval;
	int end;
	int key;
	int quit = 0;
	int ok;

	if (check_netmail_area())
		{
		do
			{
			cur_line = 0;			/* defeat more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Search the Nodelist ---\r\n\r\n",nodelist_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					key = send_string("<N> Search by Net  <B> Search by BBS  <C> Search by City  <A> Search Address\r\n",nodelist_handler);
					if (!key)
						key = send_string("<?> Help!          <X> Exit\r\n\r\n",nodelist_handler);
					}
				else
					key = send_string("[ NBCA?X ]\r\n\r\n",nodelist_handler);
				if (!key)
					key = send_string("What is your choice (ENTER=Exit)? ",nodelist_handler);
				}
			do
				{
				ok = 0;
				if (!key)
					key = get_char();
				found = 0;
				switch (key)
					{
					case 'N':
					case 'n':
						cur_line = 0;			/* defeat more */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nList what nodes for which net#? ",NULL);
						tval = (int)get_number(0,0x7fff);
						if (tval)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(BROWN | BRIGHT),NULL);
							send_string("\r\nNet/Node      BBS Name                        City, State                Crash\r\n",NULL);
							send_string("------------  ------------------------------  -------------------------  -----\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN),NULL);
							fseek(nlstfd,0L,SEEK_SET);
							end = 0;
							zone = 0;
							while (!end && fread(&tnl,sizeof(struct nl),1,nlstfd))
								{
								if (tnl.nl_net != -1)
									{
									if (tnl.nl_net != zone && tnl.nl_flags & NL_ZONE)
										zone = tnl.nl_net;
									if (tval == tnl.nl_net)
										{
										sprintf(buffer,"%u:%u/%u",zone,tnl.nl_net,tnl.nl_node);
										for (count = (int)strlen(buffer); count < 14; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-30.30s",tnl.nl_bbsname);
										for (count = (int)strlen(buffer); count < 46; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-25.25s",tnl.nl_city);
										for (count = (int)strlen(buffer); count < 73; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%s\r\n",tnl.nl_flags & NL_CM ? "Yes" : "No");
										send_string(buffer,NULL);
										++found;
										}
									}
								key = 0;
								if (user_baud)
									{
									if (peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else 
										key = get_kb();
									}
								else
									key = get_kb();

								switch (key)
									{
									case 'S':
									case 's':
										end = 1;
										break;
									case 'P':
									case 'p':
										pause_character();
										break;
									}
								}
							if (found)
								{
								cptr = parse_long((long)found);
								sprintf(buffer,"\r\nEnd of list.  %s node%s found\r\n",cptr,found == 1 ? "" : "s");
								}
							else 
								sprintf(buffer,"\r\nSorry, no nodes found for net %d\r\n",tval);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string(buffer,NULL);
							get_enter();
							}
						ok = 1;
						break;
					case 'B':
					case 'b':
						cur_line = 0;			/* defeat more */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nFind Net nodes with partial BBS name? ",NULL);
						get_field(name,20,2);
						if (name[0])
							{
							bm_setup(name,1);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(BROWN | BRIGHT),NULL);
							send_string("\r\nNet/Node      BBS Name                        City, State                Crash\r\n",NULL);
							send_string("------------  ------------------------------  -------------------------  -----\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN),NULL);
							fseek(nlstfd,0L,SEEK_SET);
							zone = 0;
							end = 0;
							while (!end && fread(&tnl,sizeof(struct nl),1,nlstfd))
								{
								if (tnl.nl_net != -1)
									{
									if (tnl.nl_net != zone && tnl.nl_flags & NL_ZONE)
										zone = tnl.nl_net;
									if (bm_search(tnl.nl_bbsname) != -1)
										{
										sprintf(buffer,"%u:%u/%u",zone,tnl.nl_net,tnl.nl_node);
										for (count = (int)strlen(buffer); count < 14; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-30.30s",tnl.nl_bbsname);
										for (count = (int)strlen(buffer); count < 46; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-25.25s",tnl.nl_city);
										for (count = (int)strlen(buffer); count < 73; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%s\r\n",tnl.nl_flags & NL_CM ? "Yes" : "No");
										send_string(buffer,NULL);
										++found;
										}
									}
								key = 0;
								if (user_baud)
									{
									if (peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else 
										key = get_kb();
									}
								else
									key = get_kb();

								switch (key)
									{
									case 'S':
									case 's':
										end = 1;
										break;
									case 'P':
									case 'p':
										pause_character();
										break;
									}
								}
							if (found)
								{
								cptr = parse_long((long)found);
								sprintf(buffer,"\r\nEnd of list.  %s node%s found\r\n",cptr,found == 1 ? "" : "s");
								}
							else 
								sprintf(buffer,"\r\nSorry, no nodes found for bbs name %s\r\n",name);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string(buffer,NULL);
							get_enter();
							}
						ok = 1;
						break;
					case 'C':
					case 'c':
						cur_line = 0;			/* defeat more */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nFind Net nodes with partial CITY/STATE name? ",NULL);
						get_field(name,20,2);
						if (name[0])
							{
							bm_setup(name,1);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(BROWN | BRIGHT),NULL);
							send_string("\r\nNet/Node      BBS Name                        City, State                Crash\r\n",NULL);
							send_string("------------  ------------------------------  -------------------------  -----\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN),NULL);
							fseek(nlstfd,0L,SEEK_SET);
							zone = 0;
							end = 0;
							while (!end && fread(&tnl,sizeof(struct nl),1,nlstfd))
								{
								if (tnl.nl_net != -1)
									{
									if (tnl.nl_net != zone && tnl.nl_flags & NL_ZONE)
										zone = tnl.nl_net;
									if (bm_search(tnl.nl_city) != -1)
										{
										sprintf(buffer,"%u:%u/%u",zone,tnl.nl_net,tnl.nl_node);
										for (count = (int)strlen(buffer); count < 14; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-30.30s",tnl.nl_bbsname);
										for (count = (int)strlen(buffer); count < 46; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%-25.25s",tnl.nl_city);
										for (count = (int)strlen(buffer); count < 73; count++)
											strcat(buffer," ");
										sprintf(buffer + strlen(buffer),"%s\r\n",tnl.nl_flags & NL_CM ? "Yes" : "No");
										send_string(buffer,NULL);
										++found;
										}
									}
								key = 0;
								if (user_baud)
									{
									if (peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else 
										key = get_kb();
									}
								else
									key = get_kb();

								switch (key)
									{
									case 'S':
									case 's':
										end = 1;
										break;
									case 'P':
									case 'p':
										pause_character();
										break;
									}
								}
							if (found)
								{
								cptr = parse_long((long)found);
								sprintf(buffer,"\r\nEnd of list.  %s node%s found\r\n",cptr,found == 1 ? "" : "s");
								}
							else 
								sprintf(buffer,"\r\nSorry, no nodes found for city name %s\r\n",name);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string(buffer,NULL);
							get_enter();
							}
						ok = 1;
						break;
					case 'A':
					case 'a':
						cur_line = 0;			/* defeat more */
						check_net_address(0);
						ok = 1;
						break;
					case '?':
						cur_line = 0;
						send_string("\r\n\r\n",NULL);
						cur_line = 0;
						send_ansifile(cfg.cfg_screenpath,"NODEHELP",0);
						ok = 1;
						break;
					case 'X':
					case 'x':
					case '\r':
					case '\n':
						quit = 1;
						ok = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (!quit);
		}
	}



int get_net_address(char *prompt,char *confirm,int *zone,int *net,int *node,int *cost,int defzone,int defnet)
	{
	struct nlix tnlix;
	struct nl tnl;
	char buffer[80];
	char buffer1[40];
	char *cptr;
	char *cptr1;
	int cur_zone;
	int tzone;
	int tnet;
	int tnode;
	int tcost;
	int tval;
	int ournode;
	int quit = 0;
	int count;
	int kount;
	int found;
	int valid;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	do
		{
		found = 0;
		valid = 0;
		ournode = 0;

		cur_line = 0;
		send_string("\r\n\r\n",NULL);
		send_string(prompt,NULL);
		send_string(" ",NULL);
		cur_line = 0;

		get_field(buffer,15,1);
		if (!buffer[0])
			quit = 1;
		else
			{
			if (defzone != -1 && defnet != -1)
				{
				tzone = defzone;
				tnet = defnet;
				}
			else
				{
				tzone = cfg.cfg_zone;	/* default to our zone if only net/node entered */
				tnet = cfg.cfg_net;		/* default to our net if only node entered */
				}
			tnode = 0;

			cptr = buffer;
			if (isdigit(*cptr))
				{
				cptr1 = buffer1;
				while (isdigit(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';	
				tval = atoi(buffer1);	
				if (*cptr == ':')			/* was ZONE provided? Parse NET/NODE next */
					{
					tzone = tval;

					while (*cptr && !isdigit(*cptr))
						++cptr;
					cptr1 = buffer1;
					while (isdigit(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					tval = atoi(buffer1);
					if (*cptr == '/')
						{
						tnet = tval;

						while (*cptr && !isdigit(*cptr))
							++cptr;
						if (*cptr)
							{
							cptr1 = buffer1;
							while (isdigit(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';

							tnode = atoi(buffer1);
							found = 1;
							}
						}
					}
				else if (*cptr == '/')		/* was NET provided?  Parse NODE next */
					{
					tnet = tval;
					while (*cptr && !isdigit(*cptr))
						++cptr;
					if (*cptr)
						{
						cptr1 = buffer1;
						while (isdigit(*cptr))
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
						tnode = atoi(buffer1);
						found = 1;
						}
					}
				else						/* was NODE provided alone? */
					{
					tnode = tval;
					found = 1;
					}
				}
			if (found)
				{
				count = 0;
				valid = 0;
				cur_zone = 0;
				fseek(nidxfd,0L,SEEK_SET);
				while (fread(&tnlix,sizeof(struct nlix),1,nidxfd))
					{
					if (tnlix.nlix_net != -1)
						{
						/* Version 6 nodelist encodes zones and regions as node == -2 */
						if (tnlix.nlix_node == NLIX_ZONE && tnlix.nlix_net != cur_zone)
							cur_zone = tnlix.nlix_net;
						if (tnlix.nlix_node == NLIX_ZONE || tnlix.nlix_node == NLIX_REGION)		/* so we can match network zone and regional hubs! */
							tnlix.nlix_node = 0;

						if (tnode == tnlix.nlix_node && tnet == tnlix.nlix_net && ((tzone && tzone == cur_zone) || !tzone))
							{
					   		valid = 1;
							if (tnode == cfg.cfg_node && tnet == cfg.cfg_net && ((tzone && tzone == cfg.cfg_zone) || !tzone))		/* our node? */
								{
								valid = 0;
								ournode = 1;
								}
							for (kount = 0; kount < 5; kount++)
								{
								if (tnode == cfg.cfg_akanode[kount] && tnet == cfg.cfg_akanet[kount] && ((tzone && tzone == cfg.cfg_akazone[kount]) || !tzone))		/* our aka node? */
									{
									valid = 0;
									ournode = 1;
									break;
									}
								}
							break;
							}
						}
					++count;
					}
				if (valid)
					{
					fseek(nlstfd,(long)count * (long)sizeof(struct nl),SEEK_SET);
					fread(&tnl,sizeof(struct nl),1,nlstfd);

					tcost = tnl.nl_cost;

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(MAGENTA | BRIGHT),NULL);

					cur_line = 0;
					send_string("\r\n",NULL);
					send_string(confirm,NULL);
					send_string(" ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					send_string(tnl.nl_bbsname,NULL);
					sprintf(buffer," at %d:%d/%d",tzone,tnet,tnode);
					send_string(buffer,NULL);
					send_string("\r\n",NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(tnl.nl_city,NULL);
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string("Phone: ",NULL);
					send_string(tnl.nl_phone,NULL);
					if (!(tnl.nl_flags & NL_CM))
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string(" (Not Crash-Mail)",NULL);
						}
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(" Baud: ",NULL);

					buffer1[0] = (char)'\0';
					if (tnl.nl_modemtype & 0x1)
						strcat(buffer1,"HST");
					if (tnl.nl_modemtype & 0x2)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"PEP");
						}
					if (tnl.nl_modemtype & 0x8)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"v32bis");
						}
					else if (tnl.nl_modemtype & 0x4)		/* v32b might have both flags set */
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"v32");
						}
					if (tnl.nl_modemtype & 0x10)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"MNP or v42bis");
						}

					sprintf(buffer,"%u %s",(unsigned int)tnl.nl_baud * 300,buffer1);
					send_string(buffer,NULL);
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(" Cost: ",NULL);
					sprintf(buffer,"%u credit%s from your total of %u credit%s",tnl.nl_cost,tnl.nl_cost != 1 ? "s" : "",user.user_credit,user.user_credit != 1 ? "s" : "");
					send_string(buffer,NULL);

					send_string("\r\n\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("Is this address correct (Y/n)? ",NULL);
					if (get_yn_enter(1))
						quit = 1;
					}
				}
			}
		if (!quit && !valid)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			if (ournode)
				send_string("\r\nYou can't send netmail to your own node!!\r\n",NULL);
			else
				{
				sprintf(buffer,"\r\nError: Invalid netmail address (%u:%u/%u) entered!\r\n",tzone,tnet,tnode);
				send_string(buffer,NULL);
				}
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			}
		}
	while (!quit);
	if (valid)
		{
		*zone = tzone;
		*net = tnet;
		*node = tnode;
		*cost = tcost;
		return 1;
		}
	return 0;
	}



int get_net_route(int credit,int cost)
	{
	char buffer[80];
	char *enterstring = "Routed";
	int enter = NET_ROUTE;
	int perms = 0;
	int ok = 0;
	int key;
	int rtn;

	if (credit >= cost)
		perms = PERM_DIRECT | PERM_ROUTE | PERM_HOLD;
	else 
		perms = PERM_ROUTE | PERM_HOLD;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\nSend message by which of the following network channels?\r\n\r\n",NULL);
	if (perms & PERM_DIRECT)
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("    <D>  ",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		sprintf(buffer,"Direct (Crash) Netmail (uses %d credit%s).\r\n",cost,cost == 1 ? "" : "s");
		send_string(buffer,NULL);
		enter = NET_DIRECT;
		enterstring = "Direct";
		}
	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("    <R>  ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);
	send_string("Routed Netmail (uses 0 credits but takes a while).\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("    <H>  ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string("Hold for pickup (requires agreement with other sysop to call).\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	sprintf(buffer,"    What is your choice [ENTER=%s]? ",enterstring);
	send_string(buffer,NULL);
	do
		{
		key = get_char();
		switch (key)
			{
			case 'D':
			case 'd':
				if (perms & PERM_DIRECT)
					{
					send_string("Direct\r\n",NULL);
					rtn = NET_DIRECT;
					ok = 1;
					}
				break;
			case 'R':
			case 'r':
				if (perms & PERM_ROUTE)
					{
					send_string("Routed\r\n",NULL);
					rtn = NET_ROUTE;
					ok = 1;
					}
				break;
			case 'H':
			case 'h':
				if (perms & PERM_HOLD)
					{
					send_string("Hold\r\n",NULL);
					rtn = NET_HOLD;
					ok = 1;
					}
				break;
			case '\r':
			case '\n':
				send_string(enterstring,NULL);
				send_string("\r\n",NULL);
				rtn = enter;
				ok = 1;
				break;
			}
		}
	while (!ok);
	send_string("\r\n",NULL);
	return rtn;
	}



void make_freq(void)
	{
	char **files = NULL;
	int cur_files = 0;
	int max_files = 0;
	int new_files = 0;
	char buffer[100];
	char buffer1[20];
	char filename[21];
	char password[9];
	char *tonames[2];
	char *cptr;
	char *cptr1;
	int ok;
	int zone;
	int net;
	int node;
	int cost;
	int count;
	int found;
	int valid = 0;
	FILE *fd;

	if (cfg.cfg_outboundpath[0])
		{
		if (cfg.cfg_zone > 0 && cfg.cfg_zone < 100)
			valid = get_net_address("Generate a File Request from what Net Address (ENTER=Quit)?","Generating Freq from:",&zone,&net,&node,&cost,-1,-1);
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nError: We cannot send Netmail.  System is not configured with a valid address.\r\n",NULL);
			send_string("       Address MUST have Zone:Net/Node in the configuration.\r\n",NULL);
			send_string("       Please inform Sysop.\r\n",NULL);
			get_enter();
			}
		if (valid)
			{
			sprintf(buffer1,"%04x%04x.REQ",net,node);
			sprintf(buffer,"%s%s",get_outbound(zone),buffer1);
			if (fd = fopen(buffer,"r+b"))
				{
				while (fgets(buffer,sizeof(buffer),fd))
					{
					cptr = buffer;
					while (*cptr && *cptr <= ' ')
						++cptr;
					cptr1 = cptr;
					while (*cptr1 && *cptr1 > ' ')
						++cptr1;
					*cptr1 = '\0';
					if (*cptr)
						{
						if (cur_files >= max_files)
							{
							if (!(files = realloc(files,(max_files += 10) * sizeof(char *))))
								{
								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\nFatal Error: Out of memory while allocating for filelist!\r\n",NULL);
								get_enter();
								fclose(fd);
								fd = NULL;		/* bypasses the function and drops out */
								}
							}
						if (!(files[cur_files] = malloc((strlen(cptr) + 1) * sizeof(char))))
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("\r\nFatal Error: Out of memory while allocating for filelist!\r\n",NULL);
							for (count = 0; count < cur_files; count++)
								free(files[count]);
							free(files);
							get_enter();
							fclose(fd);
							fd = NULL;		/* bypasses the function and drops out */
							}
						strcpy(files[cur_files],cptr);
						++cur_files;
						}
					}
				}
			else
				fd = fopen(buffer,"wb");

			if (fd)
				{
				new_files = cur_files;

				send_string("\r\n",NULL);
				if (cur_files)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					sprintf(buffer,"Notice: There are already %d files in the request!\r\n\r\n",cur_files);
					send_string(buffer,NULL);
					}
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				do
					{
					cur_line = 0;
					send_string("FREQ what filename (ENTER=Quit)? ",NULL);
					get_field(filename,20,2);
					if (filename[0])
						{
						found = 0;
						for (count = 0; count < cur_files; count++)
							{
							strcpy(buffer,files[count]);
							cptr = buffer;
							while (*cptr && *cptr != ' ')
								++cptr;
							*cptr = (char)'\0';
							if (!stricmp(buffer,filename))
								found = 1;
							}

						if (found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("This file is already in the list.  Skipping.\r\n\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							}
						else
							{
							send_string(" Password for file (ENTER=None)? ",NULL);
							get_field(password,8,2);
							send_string("\r\n",NULL);

							sprintf(buffer,"%s%s%s",filename,(char *)(password[0] ? " !" : ""),password);

							if (cur_files >= max_files)
								{
								if (!(files = realloc(files,(max_files += 10) * sizeof(char *))))
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string("\r\nFatal Error: Out of memory while allocating for filelist!\r\n",NULL);
									get_enter();
									cur_files = 0;		/* bypasses the function and drops out */
									filename[0] = '\0';
									}
								}
							if (!(files[cur_files] = malloc((strlen(buffer) + 1) * sizeof(char))))
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\nFatal Error: Out of memory while allocating for filelist!\r\n",NULL);
								for (count = 0; count < cur_files; count++)
									free(files[count]);
								free(files);
								get_enter();
								cur_files = 0;		/* bypasses the function and drops out */
								filename[0] = '\0';
								}
							strcpy(files[cur_files],buffer);
							++cur_files;
							}
						}
					}
				while (filename[0]);

				if (cur_files)
					{
					cur_line = 0;
					send_string("\r\n\r\nPlease wait a moment, writing FREQ file....",NULL);
					fseek(fd,0L,SEEK_SET);
					chsize(fileno(fd),0L);
					for (count = 0; count < cur_files; count++)
						fprintf(fd,"%s\r\n",files[count]);
					fflush(fd);

					if (new_files != cur_files)
						{
						/* send netmail message indicating which board is doing the requesting
						** the name of the person doing the requesting and the files requested */

						ok = 1;
						if (!load_msg_line("Thank you for permitting file requests.  I have requested\r"))
							ok = 0;
						if (ok)
							{
							if (!load_msg_line("the following files from your system:\r\r"))
								ok = 0;
							}
						if (ok)
							{
							for (count = new_files; ok && count < cur_files; count++)
								{
								strcpy(buffer,files[count]);
								cptr = buffer;
								while (*cptr && *cptr != ' ')
									++cptr;
								*cptr = (char)'\0';
								strcat(buffer,"\r");

								if (!load_msg_line(buffer))
									ok = 0;
								}
							}

						if (ok)
							{
							tonames[0] = "Sysop";
							tonames[1] = NULL;
							do_message(user.user_name,tonames,"File request",get_netmail_area(zone,net,node),0xff,0xffff,0,MESSAGE_LOADED | MESSAGE_PRIVATE,zone,net,node,0,MSGH_NET | NET_KILLSENT | NET_DIRECT);

							if (max_mlines)
								{
								free(mlines);
								mlines = NULL;
								max_mlines = 0;
								}
							}
						}

					for (count = 0; count < cur_files; count++)
						free(files[count]);
					free(files);

					send_string("Finished!\r\n\r\n",NULL);
					}
				fclose(fd);

				if (!cur_files)		/* no filenames in req file! */
					{
					sprintf(buffer1,"%04x%04x.REQ",net,node);
					strcpy(buffer,cfg.cfg_outboundpath);
					if (buffer[0])
						{
						if (buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						}
					strcat(buffer,buffer1);
					unlink(buffer);
					}
				}
			else
				{
				send_string("\r\nError: Unable to open \r\n",NULL);
				send_string(buffer1,NULL);
				send_string("for Freq file!\r\n",NULL);
				get_enter();
				}
			}
		}
	else
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("\r\nError: No outbound path specified in CONFIG.BBS.  Pleas inform Sysop!\r\n",NULL);
		get_enter();
		}
	}



char *get_outbound(int zone)
	{
	static char _far outpath[100];
	char buffer[5];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	strcpy(outpath,cfg.cfg_outboundpath);
	if (outpath[0])
		{
		if (outpath[strlen(outpath) - 1] == P_CSEP)
			outpath[strlen(outpath) - 1] = '\0';
		}
	if (zone && zone != cfg.cfg_zone)
		{
		_splitpath(outpath,drive,path,fname,ext);
		sprintf(buffer,"%03x",zone);
		_makepath(outpath,drive,path,fname,buffer);
		}
	if (outpath[0])
		{
		if (outpath[strlen(outpath) - 1] != P_CSEP)
			strcat(outpath,P_SSEP);
		}
	return outpath;
	}



void check_net_address(int again)
	{
	struct nlix tnlix;
	struct nl tnl;
	char buffer[81];
	char buffer1[41];
	char *cptr;
	char *cptr1;
	char *prompt = "Search for which node?";
	char *confirm = "Here is a matching node:";
	int cur_zone;
	int tzone;
	int tnet;
	int tnode;
	int tval;
	int quit = 0;
	int count;
	int found;
	int valid;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	do
		{
		found = 0;
		valid = 0;

		cur_line = 0;
		send_string("\r\n\r\n",NULL);
		send_string(prompt,NULL);
		send_string(" ",NULL);
		cur_line = 0;

		get_field(buffer,15,1);
		if (!buffer[0])
			quit = 1;
		else
			{
			tzone = cfg.cfg_zone;	/* default to our zone if only net/node entered */
			tnet = cfg.cfg_net;		/* default to our net if only node entered */
			tnode = 0;

			cptr = buffer;
			if (isdigit(*cptr))
				{
				cptr1 = buffer1;
				while (isdigit(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';	
				tval = atoi(buffer1);	
				if (*cptr == ':')			/* was ZONE provided? Parse NET/NODE next */
					{
					tzone = tval;

					while (*cptr && !isdigit(*cptr))
						++cptr;
					cptr1 = buffer1;
					while (isdigit(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					tval = atoi(buffer1);
					if (*cptr == '/')
						{
						tnet = tval;

						while (*cptr && !isdigit(*cptr))
							++cptr;
						if (*cptr)
							{
							cptr1 = buffer1;
							while (isdigit(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';

							tnode = atoi(buffer1);
							found = 1;
							}
						}
					}
				else if (*cptr == '/')		/* was NET provided?  Parse NODE next */
					{
					tnet = tval;
					while (*cptr && !isdigit(*cptr))
						++cptr;
					if (*cptr)
						{
						cptr1 = buffer1;
						while (isdigit(*cptr))
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
						tnode = atoi(buffer1);
						found = 1;
						}
					}
				else						/* was NODE provided alone? */
					{
					tnode = tval;
					found = 1;
					}
				}
			if (found)
				{
				count = 0;
				valid = 0;
				cur_zone = 0;
				fseek(nidxfd,0L,SEEK_SET);
				while (fread(&tnlix,sizeof(struct nlix),1,nidxfd))
					{
					if (tnlix.nlix_net != -1)
						{
						/* Version 6 nodelist encodes zones as node == -2  and regions as -1 */
						if (tnlix.nlix_node == NLIX_ZONE && tnlix.nlix_net != cur_zone)
							cur_zone = tnlix.nlix_net;
						if (tnlix.nlix_node == NLIX_ZONE || tnlix.nlix_node == NLIX_REGION)		/* so we can match network zone and regional hubs! */
							tnlix.nlix_node = 0;

						if (tnode == tnlix.nlix_node && tnet == tnlix.nlix_net && ((tzone && tzone == cur_zone) || !tzone))
							{
					   		valid = 1;
							break;
							}
						}
					++count;
					}
				if (valid)
					{
					fseek(nlstfd,(long)count * (long)sizeof(struct nl),SEEK_SET);
					fread(&tnl,sizeof(struct nl),1,nlstfd);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(MAGENTA | BRIGHT),NULL);

					cur_line = 0;
					send_string("\r\n",NULL);
					send_string(confirm,NULL);
					send_string(" ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					send_string(tnl.nl_bbsname,NULL);
					sprintf(buffer," at %d:%d/%d",tzone,tnet,tnode);
					send_string(buffer,NULL);
					send_string("\r\n",NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(tnl.nl_city,NULL);
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string("Phone: ",NULL);
					send_string(tnl.nl_phone,NULL);
					if (!(tnl.nl_flags & NL_CM))
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string(" (Not Crash-Mail)",NULL);
						}
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(" Baud: ",NULL);

					buffer1[0] = (char)'\0';
					if (tnl.nl_modemtype & 0x1)
						strcat(buffer1,"HST");
					if (tnl.nl_modemtype & 0x2)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"PEP");
						}
					if (tnl.nl_modemtype & 0x8)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"v32bis");
						}
					else if (tnl.nl_modemtype & 0x4)		/* v32b might have both flags set */
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"v32");
						}
					if (tnl.nl_modemtype & 0x10)
						{
						if (buffer1[0])
							strcat(buffer1,"/");
						strcat(buffer1,"MNP or v42bis");
						}

					sprintf(buffer,"%u %s",(unsigned int)tnl.nl_baud * 300,buffer1);
					send_string(buffer,NULL);
					send_string("\r\n",NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE | BRIGHT),NULL);
					for (count = 0; count <= (int)strlen(confirm); count++)
						send_string(" ",NULL);
					send_string(" Cost: ",NULL);
					sprintf(buffer,"%u credit%s from your total of %u credit%s",tnl.nl_cost,tnl.nl_cost != 1 ? "s" : "",user.user_credit,user.user_credit != 1 ? "s" : "");
					send_string(buffer,NULL);
					send_string("\r\n\r\n",NULL);

					if (again)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("Do you want to search for another address (y/N)? ",NULL);
						if (!get_yn_enter(0))
							quit = 1;
						}
					}
				}
			}
		if (!quit && !valid)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nError: Invalid netmail address entered!\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			}
		}
	while (again && !quit);
	}

