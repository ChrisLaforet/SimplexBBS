/* s_msgul.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 21 October 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_msgul.c_v  $
**                       $Date:   25 Oct 1992 14:07:28  $
**                       $Revision:   1.3  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include "simplex.h"



#define LINEWRAP			76



int upload_message(void)
	{
	char *fname = "message.ul";
	char buffer[100];
	char buffer1[100];
	char *cptr;
	char *cptr1;
	int curchar;
	int prevchar;
	int success = 0;
	int count;
	int nl = 0;
	int ok;
	FILE *listfd;
	FILE *fd;

	if (!user_baud)
		{
		do
			{
			ok = 1;
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPath to message (ENTER=Quit)? ",NULL);
			get_fname(buffer,48,0,1);
			if (buffer[0])
				{
				if (fd = fopen(buffer,"rb"))
					success = 1;
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\n\r\nError: Unable to find/open message file!\r\n",NULL);
					ok = 0;
					}
				}
			}
		while (!ok);
		}
	else
		{
		strcpy(buffer,bbspath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		sprintf(buffer1,"upload#%u.bbs",cfg.cfg_port);
		strcat(buffer,buffer1);

		if (!(listfd = fopen(buffer,"w+b")))
			{
			sprintf(buffer,"Unable to open %s in mail upload area!",buffer1);
			_error(E_ERROR,buffer);
			system_message(buffer);
			return 0;
			}

		x1k_recv(AREA_UPLOADMAIL,fname,listfd);

		fseek(listfd,0L,SEEK_SET);
		while (fgets(buffer,sizeof(buffer),listfd))
			{
			if (!strnicmp(buffer,"OK ",3))
				{
				cptr = buffer + 4;
				cptr1 = fname;

				while (*cptr > ' ')
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
					++cptr;

				sprintf(buffer,"\"%s\" in message upload area.",fname);
				log_entry(L_UPLOAD,buffer);

				strcpy(buffer,bbspath);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				strcat(buffer,fname);

				if (fd = fopen(buffer,"rb"))
					success = 1;
				}
			else	   		/* delete any bad file fragments we might have left! */
				{
				cptr = buffer + 4;
				cptr1 = buffer1;

				while (*cptr > ' ')
					*cptr1++ = *cptr++;
				*cptr1 = '\0';

				strcpy(buffer,bbspath);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				strcat(buffer,buffer1);

				unlink(buffer);
				}
			}
		fclose(listfd);
		}

	if (success)
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nPlease wait while loading and formatting message...\r\n",NULL);

		cptr = buffer1;
		*cptr = '\0';
		prevchar = 0;
		while ((curchar = fgetc(fd)) != EOF)
			{
			if (curchar == '\r')
				{
				if (prevchar == '\r')
					nl = 2;
				}
			else if (curchar == '\n')
				nl = 2;
			else if (curchar == 0x1b)		/* strip ESC codes */
				;
			else if (curchar == '\t')
				*cptr++ = ' ';
			else if (curchar >= ' ')
				{
				if (prevchar == '\r')
					nl = 2;
				*cptr++ = (char)(unsigned char)curchar;
				}
			prevchar = curchar;

			if (!nl && ((cptr - buffer1) >= LINEWRAP))
				nl = 1;

			if (nl)
				{
				if (nl == 2)
					{
					if ((cptr - buffer1) > 0)		/* trim trailing spaces */
						{
						--cptr;		
						while (((cptr - buffer1) > 0) && isspace(*cptr))
							--cptr;
						++cptr;
						}
					*cptr++ = '\r';
					*cptr = '\0';
					if (!load_msg_line(buffer1))
						{
						system_message("Fatal error in editor: Out of memory.  Message aborted!");
						fclose(fd);
						return 0;
						}

					cptr = buffer1;
					*cptr = '\0';
					}
				else
					{
					*cptr = '\0';
					--cptr;
					if (isspace(*cptr))
						buffer[0] = '\0';
					else
						{
						while (((cptr - buffer1) >= 0) && !isspace(*cptr))
							--cptr;
						++cptr;
						if (strlen(cptr) <= LINEWRAP / 2)		/* LINEWRAP/2 key wrap limit */
							{
							strcpy(buffer,cptr);			/* move the data to the new line */
							*cptr = '\0';					/* cut off the end of the string which is now on another line */
							}
						else
							buffer[0] = '\0';
						}

					*cptr++ = (char)(unsigned char)'\x8d';		/* soft-CR */
					*cptr = (char)'\0';

					if (!load_msg_line(buffer1))
						{
						system_message("Fatal error in editor: Out of memory.  Message aborted!");
						fclose(fd);
						return 0;
						}

					strcpy(buffer1,buffer);
					cptr = buffer1 + strlen(buffer1);
					}
				nl = 0;
				}
			}
		if ((cptr - buffer1) > 0)
			{
			if ((cptr - buffer1) > 0)		/* trim trailing spaces */
				{
				--cptr;		
				while (((cptr - buffer1) > 0) && isspace(*cptr))
					--cptr;
				++cptr;
				}
			*cptr++ = '\r';
			*cptr = '\0';

			if (!load_msg_line(buffer1))
				{
				system_message("Fatal error in editor: Out of memory.  Message aborted!");
				fclose(fd);
				return 0;
				}
			}
		fclose(fd);

		if (user_baud)
			{
			strcpy(buffer,bbspath);
			if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			strcat(buffer,fname);
			unlink(buffer);			/* delete uploaded file */
			}
		return 1;
		}
	return 0;
	}
