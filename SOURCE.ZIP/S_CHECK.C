/* s_check.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 8 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_check.c_v  $
**                       $Date:   25 Oct 1992 14:06:50  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "simplex.h"




/* flags for checksum check */

#define CKSUM_NAME					1
#define CKSUM_ALIAS1				2
#define CKSUM_ALIAS2				4
#define CKSUM_ALIAS3				8
#define CKSUM_ALIAS4				16



struct mark *urgent = NULL;
int cur_urgent = 0;
int max_urgent = 0;



int mark_urgent(int area,int system_number)
	{
	int count;
	int found = 0;

	for (count = 0; count < cur_urgent; count++)
		{
		if (urgent[count].mark_area == area && urgent[count].mark_number == system_number)
			{
			found = 1;
			break;
			}
		}
	if (!found)
		{
		if (cur_urgent >= max_urgent)
			{
			if (!(urgent = realloc(urgent,(max_urgent += 10) * sizeof(struct mark))))
				{
				system_message("Unable to allocate memory for urgent message list...list dumped!");
				cur_urgent = 0;
				max_urgent = 0;
				return 1;
				}
			}
		urgent[cur_urgent].mark_area = area;
		urgent[cur_urgent].mark_number = system_number;
		++cur_urgent;
		}
	return 0;
	}



void free_urgent(void)
	{
	if (max_urgent)
		{
		free(urgent);
		urgent = NULL;
 		cur_urgent = 0;
	 	max_urgent = 0;
		}
	}



char *get_addressee(char *to)
	{
	static char buffer[50];
	char *cptr;

	strcpy(buffer,to);
	cptr = buffer;
	while (*cptr)
		{
		if (!strnicmp(cptr," on ",4) || !strnicmp(cptr," at ",4))
			{
			while (*cptr && cptr != buffer)
				{
				if (!isspace(*cptr))
					{
					++cptr;
					break;
					}
				--cptr;
				}
			*cptr = (char)'\0';
			break;
			}
		++cptr;
		}
	return buffer;
	}



void check_mail(void)
	{
	struct msg *tmsg;
	struct msgh tmsgh;
	struct mlink tmlink;
	struct mark tmark;
	char buffer[100];
	char *cptr;
	unsigned short cksum[5];
	int cksum_flags = 0;
	int total_msgs;
	int count;
	int kount;
	int counter;
	int found;
	int mark_flag;
	int got_header;
	int maximum;
	int match;
	int len;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\nPlease wait a few moments. Checking for un-received personal mail....\r\n",NULL);

	cptr = user.user_name;
	cksum[0] = 0;
	while (*cptr)
		{
		cksum[0] += toupper(*cptr);
		++cptr;
		}
	cksum_flags |= CKSUM_NAME;
	for (count = 0; count < 4; count++)
		{
		cksum[count + 1] = 0;
		if (user.user_alias[count][0])
			{
			cptr = user.user_alias[count];
			while (*cptr)
				{
				cksum[count + 1] += toupper(*cptr);
				++cptr;
				}
			if (!count)
				cksum_flags |= CKSUM_ALIAS1;
			else if (count == 1)
				cksum_flags |= CKSUM_ALIAS2;
			else if (count == 2)
				cksum_flags |= CKSUM_ALIAS3;
			else if (count == 3)
				cksum_flags |= CKSUM_ALIAS4;
			}
		}

	count = 0;
	fseek(msglfd,0L,SEEK_SET);
	while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
		{
		got_header = 0;
		if (!(tmlink.mlink_flags & MSGH_DELETED) && !(tmlink.mlink_flags & MSGH_RECEIVED))
			{
			if (cksum[0] == tmlink.mlink_cksum)
				match = 1;
			else if ((cksum_flags & CKSUM_ALIAS1) && cksum[1] == tmlink.mlink_cksum)
				match = 1;
			else if ((cksum_flags & CKSUM_ALIAS2) && cksum[2] == tmlink.mlink_cksum)
				match = 1;
			else if ((cksum_flags & CKSUM_ALIAS3) && cksum[3] == tmlink.mlink_cksum)
				match = 1;
			else if ((cksum_flags & CKSUM_ALIAS4) && cksum[4] == tmlink.mlink_cksum)
				match = 1;
			else
				match = 0;

			if (match)
				{
				mark_flag = 0;

				fseek(msghfd,(long)count * sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh,sizeof(struct msgh),1,msghfd);

				if (!stricmp(user.user_name,tmsgh.msgh_to))
					mark_flag = 1;
				if (!mark_flag && strlen(user.user_name) < strlen(tmsgh.msgh_to))
					{
					cptr = get_addressee(tmsgh.msgh_to);
					if (!stricmp(user.user_name,cptr))
						mark_flag = 1;
					}

				for (kount = 0; !mark_flag && kount < 4; kount++)
					{
					if (user.user_alias[kount][0])
						{
						if (!stricmp(user.user_alias[kount],tmsgh.msgh_to))
							mark_flag = 1;
						if (!mark_flag && strlen(user.user_alias[kount]) < strlen(tmsgh.msgh_to))
							{
							cptr = get_addressee(tmsgh.msgh_to);
							if (!stricmp(user.user_alias[kount],cptr))
								mark_flag = 1;
							}
						}
					}

				if (mark_flag)
					mark(tmsgh.msgh_area,count + 1);
				got_header = 1;
				}
			}

		if (!(tmlink.mlink_flags & MSGH_DELETED) && (tmlink.mlink_flags & MSGH_URGENT))
			{
			if (!got_header)
				{
				fseek(msghfd,(long)count * sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh,sizeof(struct msgh),1,msghfd);
				}
			if ((tmsgh.msgh_date > user_lastdate) || ((tmsgh.msgh_date == user_lastdate) && (tmsgh.msgh_time > user_lasttime)))
				mark_urgent(tmsgh.msgh_area,count + 1);
			}

		if (!(count % 100))
			{
			sprintf(buffer,"%d\r",count);
			send_string(buffer,NULL);
			}
		++count;
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	if (cur_marked)
		{
		qsort(marked,cur_marked,sizeof(struct mark),sort_mark);
		cur_line = 0;
		sprintf(buffer,"\rYou have the following %d message%s waiting.\r\n",cur_marked,cur_marked != 1 ? "s" : "");
		send_string(buffer,NULL);
		sprintf(buffer,"%s been marked for reading later:\r\n\r\n",cur_marked != 1 ? "They have" : "It has");
		send_string(buffer,NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Message Area                   Message Number(s)\r\n",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(MAGENTA | BRIGHT),NULL);
		send_string("------------------------------ -----------------------------------------------",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		for (count = 0, maximum = 0; count < cur_marked; count++)
			{
			if (marked[count].mark_area > maximum)
				{
				maximum = marked[count].mark_area;
				if (tmsg = get_msgarea(maximum))
					{
					found = 0;
					len = 0;
					for (kount = 0; kount < cur_marked; kount++)
						{
						if (marked[kount].mark_area == maximum)
							{
							if (!found)
								{
								send_string("\r\n",NULL);
								sprintf(buffer,"%-30.30s ",tmsg->msg_areaname);
								send_string(buffer,NULL);
								found = 1;
								}

							fseek(msghfd,(long)(marked[kount].mark_number - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fread(&tmsgh,sizeof(struct msgh),1,msghfd);
							sprintf(buffer,"%d ",tmsgh.msgh_number);
							if (len >= 45)
								{
								len = 0;
								send_string("\r\n",NULL);
								for (counter = 0; counter < 31; counter++)
									send_string(" ",NULL);
								}
							send_string(buffer,NULL);
							len += (int)strlen(buffer);
							}
						}
					}
				}
			}
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		sprintf(buffer,"\r\n\r\n\r\nDo you want to read %s message%s now (ENTER=Yes)? ",cur_marked == 1 ? "this" : "these",cur_marked == 1 ? "" : "s");
		send_string(buffer,NULL);
		if (get_yn_enter(1))
			{
			for (count = 0; count < cur_marked; )
				{
			 	total_msgs = 1;		/* recount messages due to replies/deletes */
				for (kount = 0; kount < max_msgcount; kount++)
					{
					if (msgcount[kount].mc_area == marked[count].mark_area)
						{
						total_msgs = msgcount[kount].mc_msgs;
						break;
						}
					}
				tmark.mark_area = marked[count].mark_area;
				tmark.mark_number = marked[count].mark_number;
				if (!read_individual(marked[count].mark_area,0xff,0xffff,&total_msgs,marked[count].mark_number,1,1,0,0,-1))		/* boost priv temporarily to leave responses in sysop area */
					break;			/* exit if they press X */
				if (tmark.mark_area == marked[count].mark_area && tmark.mark_number == marked[count].mark_number)		/* did we not delete the message */
					++count;
				}
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\n\r\nEnd of messages.   Press any key to continue or wait 5 seconds....",NULL);
			wait_key(5);
			send_string("\r\n\r\n",NULL);
			cur_line = 0;
			}
		}
	else
		{
		cur_line = 0;
	 	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 		send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\rSorry, no unread mail is waiting for you.\r\n\r\n",NULL);
	 	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 		send_string(new_color(RED | BRIGHT),NULL);

		send_string("Press any key to continue or wait 5 seconds....",NULL);
		wait_key(5);
		send_string("\r\n\r\n",NULL);
		cur_line = 0;
		}
	}



void read_urgent(void)
	{
	char buffer[100];
	struct msg *tmsg;
	struct msgh tmsgh;
	struct mark tmark;
	int total_msgs;
	int count;
	int kount;
	int counter;
	int found;
	int len;
	int maximum;

	if (cur_urgent)
		{
		qsort(urgent,cur_urgent,sizeof(struct mark),sort_mark);

		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		sprintf(buffer,"\r\nYou have the following %d Urgent user message%s waiting.\r\n\r\n",cur_urgent,cur_urgent != 1 ? "s" : "");
		send_string(buffer,NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Message Area                   Message Number(s)\r\n",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(MAGENTA | BRIGHT),NULL);
		send_string("------------------------------ -----------------------------------------------",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		for (count = 0, maximum = 0; count < cur_urgent; count++)
			{
			if (urgent[count].mark_area > maximum)
				{
				maximum = urgent[count].mark_area;
				if (tmsg = get_msgarea(maximum))
					{
					found = 0;
					len = 0;
					for (kount = 0; kount < cur_urgent; kount++)
						{
						if (urgent[kount].mark_area == maximum)
							{
							if (!found)
								{
								send_string("\r\n",NULL);
								sprintf(buffer,"%-30.30s ",tmsg->msg_areaname);
								send_string(buffer,NULL);
								found = 1;
								}

							fseek(msghfd,(long)(urgent[kount].mark_number - 1) * (long)sizeof(struct msgh),SEEK_SET);
							fread(&tmsgh,sizeof(struct msgh),1,msghfd);
							sprintf(buffer,"%d ",tmsgh.msgh_number);
							if (len >= 45)
								{
								len = 0;
								send_string("\r\n",NULL);
								for (counter = 0; counter < 31; counter++)
									send_string(" ",NULL);
								}
							send_string(buffer,NULL);
							len += (int)strlen(buffer);
							}
						}
					}
				}
			}
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		sprintf(buffer,"\r\n\r\n\r\nPress any key to read %s message%s now....",cur_urgent == 1 ? "this" : "these",cur_urgent == 1 ? "" : "s");
		send_string(buffer,NULL);

		get_char();
		for (count = 0; count < cur_urgent; )
			{
			total_msgs = 1;		/* recount messages due to replies/deletes */
			for (kount = 0; kount < max_msgcount; kount++)
				{
				if (msgcount[kount].mc_area == urgent[count].mark_area)
					{
					total_msgs = msgcount[kount].mc_msgs;
					break;
					}
				}
			tmark.mark_area = urgent[count].mark_area;
			tmark.mark_number = urgent[count].mark_number;
			read_individual(urgent[count].mark_area,0xff,0xffff,&total_msgs,urgent[count].mark_number,1,1,0,0,-1);		/* boost priv temporarily to leave responses in sysop area */
			if (tmark.mark_area == urgent[count].mark_area && tmark.mark_number == urgent[count].mark_number)		/* did we not delete the message */
				++count;
			}
		free_urgent();
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nEnd of messages.   Press any key to continue or wait 5 seconds....",NULL);
		wait_key(5);
		send_string("\r\n\r\n",NULL);
		cur_line = 0;
		}
	}
