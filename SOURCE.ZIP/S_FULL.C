/* s_full.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 2 June 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_full.c_v  $
**                       $Date:   25 Oct 1992 14:09:14  $
**                       $Revision:   1.20  $
**
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef PROTECTED
	#define INCL_DOS
	#include <os2.h>
#else
	#include <dos.h>
	#ifdef __ZTC__
		#include <int.h>
	#endif
#endif
#include "simplex.h"



#define MAXLINES		20
#define WRAP			76
#define ALLOCLEN		82


static int _far lines_inuse[MAXLINES];
static volatile int mins = -1;
static char **quote = NULL;
static int max_quote = 0;
static int cur_quote = 0;


typedef enum
	{
		_NOTHING,

		_ABORT_EXIT,
		_SAVE_EXIT,

		_ENTER,
		_BACKSPACE,
		_TAB,
		_DELETE,

		_KEY_UP,
		_KEY_DOWN,
		_KEY_LEFT,
		_KEY_RIGHT,
		_KEY_HOME,
		_KEY_END,
		_KEY_PGUP,
		_KEY_PGDN,
		_WORD_KEY_LEFT,
		_WORD_KEY_RIGHT,
		_TOP_PAGE,
		_BOTTOM_PAGE,
		_TOP_FILE,
		_BOTTOM_FILE,
		_TOP_LINE,
		_BOTTOM_LINE,

		_INSERT_LINE,
		_DELETE_LINE,
		_CENTER,
		_FLUSH_KEY_RIGHT,
		_FLUSH_KEY_LEFT,

		_REDRAW,
		_QUOTE,
		_HELP,

		_CHARACTER,
		} ACTION;



int add_quote(char *line)
	{
	int count;

	if (cur_quote >= max_quote)
		{
		if (!(quote = realloc(quote,(max_quote += 50) * sizeof(char *))))
			{
			send_string("Error: Out of memory for quotes...loading line editor\r\n",NULL);
			max_quote = 0;
			cur_quote = 0;
			return 1;
			}
		}
	if (!(quote[cur_quote] = calloc(strlen(line) + 1,sizeof(char))))
		{
		send_string("Error: Out of memory for quotes...loading line editor\r\n",NULL);
		for (count = 0; count < cur_quote; count++)
			free(quote[count]);
		free(quote);
		quote = NULL;
		max_quote = 0;
		cur_quote = 0;
		return 1;
		}
	strcpy(quote[cur_quote],line);
	++cur_quote;
	return 0;
	}



void free_quotes(void)
	{
	int count;

	if (max_quote)
		{
		for (count = 0; count < cur_quote; count++)
			free(quote[count]);
		free(quote);
		quote = NULL;
		max_quote = 0;
		cur_quote = 0;
		}
	}



void pascal draw_quote(int topquote)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;
	int count;

	sprintf(buffer1,"[%d;1H",MAXLINES - 6 + 3);	/* 1 less since ANSI counts from line 1 NOT line 0 */
	send_string(buffer1,NULL);
	for (count = 0; count < 79; count++)
		{
		if (count == 33)
			{
			send_string(" Quote Window ",NULL);
			count += 13;
			}
		else 
			send_string("-",NULL);
		}
	lines_inuse[MAXLINES - 6] = 1;
	for (count = 0; count < 5; count++)
		{
		cur_line = 0;			/* disable more */
		if ((topquote + count) < cur_quote)
			{
			cptr = quote[topquote + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
				sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
				send_string(buffer1,NULL);
				send_string(buffer,NULL);
				send_string("[K",NULL);
				lines_inuse[count + MAXLINES - 5] = 1;
				}
			else if (lines_inuse[MAXLINES - 5 + count])
				{
				sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
				send_string(buffer1,NULL);
				send_string("[K",NULL);
				lines_inuse[MAXLINES - 5 + count] = 1;
				}
			}
		else if (lines_inuse[MAXLINES - 5 + count])
			{
			sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
			send_string(buffer1,NULL);
			send_string("[K",NULL);
			lines_inuse[MAXLINES - 5 + count] = 1;
			}
		}
	}



void pascal redraw_quote(int topquote)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;
	int count;

	for (count = 0; count < 5; count++)
		{
		cur_line = 0;			/* disable more */
		if ((topquote + count) < cur_quote)
			{
			cptr = quote[topquote + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
			 	sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
			 	send_string(buffer1,NULL);
				send_string(buffer,NULL);
				send_string("[K",NULL);
				lines_inuse[count + MAXLINES - 5] = 1;
				}
			else if (lines_inuse[MAXLINES - 5 + count])
				{
				sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
				send_string(buffer1,NULL);
				send_string("[K",NULL);
				lines_inuse[MAXLINES - 5 + count] = 0;
				}
			}
		else if (lines_inuse[MAXLINES - 5 + count])
			{
			sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
			send_string(buffer1,NULL);
			send_string("[K",NULL);
			lines_inuse[MAXLINES - 5 + count] = 0;
			}
		}
	}



void pascal draw_screen(int top,int line,int col,int inquote,int topquote,int linequote)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;
	int count;
	int maximum = MAXLINES;

	send_string(new_color(WHITE),NULL);
	send_string("[2J",NULL);
	send_string(new_color(BROWN | BRIGHT | ON_RED),NULL);
	for (count = 0; count < 80; count++)
		send_string(" ",NULL);
	send_string("[2;1H",NULL);
	for (count = 0; count < 80; count++)
		send_string(" ",NULL);
	send_string("[1;1H",NULL);
#ifdef PROTECTED
	sprintf(buffer,"Simplex/2 (v %d.%02d.%02u%s) ANSI Editor.  Press <Ctl-K><?> for Help",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA ? "Beta" : ""));
#else
	sprintf(buffer,"Simplex (v %d.%02d.%02u%s) ANSI Editor.  Press <Ctl-K><?> for Help",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA ? "Beta" : ""));
#endif
	send_string(buffer,NULL);
	send_string("[3;1H",NULL);
	send_string(new_color(WHITE),NULL);

	for (count = 0; count < MAXLINES; count++)
		lines_inuse[count] = 0;

	if (inquote)
		maximum = MAXLINES - 6;
	for (count = 0; count < maximum; count++)
		{
		cur_line = 0;			/* disable more */
		if ((count + top) < cur_mlines)
			{
			cptr = mlines[top + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r' && *cptr != '\x8d')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
				sprintf(buffer1,"[%d;1H",count + 3);
				send_string(buffer1,NULL);
				send_string(buffer,NULL);
				lines_inuse[count] = 1;
				}
			}
		}
	if (inquote)
		draw_quote(topquote);
#if 0
		{
		sprintf(buffer1,"[%d;1H",MAXLINES - 6 + 3);	/* 1 less since ANSI counts from line 1 NOT line 0 */
		send_string(buffer1,NULL);
		lines_inuse[MAXLINES - 6] = 1;
		for (count = 0; count < 79; count++)
			{
			if (count == 33)
				{
				send_string(" Quote Window ",NULL);
				count += 13;
				}
			else 
				send_string("-",NULL);
			}
		if ((topquote + 6) >= cur_quote)
			maximum = cur_quote - topquote;
		else
			maximum = 6;
		for (count = 0; count < maximum; count++)
			{
			cur_line = 0;			/* disable more */
			cptr = quote[topquote + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
				sprintf(buffer1,"[%d;1H",count + MAXLINES - 5 + 3);
				send_string(buffer1,NULL);
				send_string(buffer,NULL);
				lines_inuse[count + MAXLINES - 5] = 1;
				}
			}
		}
#endif
	if (!inquote)
		sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
	else
		sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
	send_string(buffer1,NULL);
	}



void pascal draw_partial_screen(int top,int line,int col,int inquote)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;
	int count;
	int maximum = MAXLINES;

	if (inquote)
		maximum = MAXLINES - 6;
	for (count = 0; count < maximum; count++)
		{
		cur_line = 0;			/* disable more */
		if ((top + count) < cur_mlines)
			{
			cptr = mlines[top + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r' && *cptr != '\x8d')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
				sprintf(buffer1,"[%d;1H",count + 3);
				send_string(buffer1,NULL);
				send_string(buffer,NULL);
				send_string("[K",NULL);
				lines_inuse[count] = 1;
				}
			else if (lines_inuse[count])
				{
				sprintf(buffer1,"[%d;1H",count + 3);
				send_string(buffer1,NULL);
				send_string("[K",NULL);
				lines_inuse[count] = 0;
				}
			}
		else if (lines_inuse[count])
			{
			sprintf(buffer1,"[%d;1H",count + 3);
			send_string(buffer1,NULL);
			send_string("[K",NULL);
			lines_inuse[count] = 0;
			}
		}
	sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
	send_string(buffer1,NULL);
	}



void pascal draw_screen_from_line(int top,int line,int col,int inquote)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;
	int count;
	int maximum = MAXLINES;

	if (inquote && maximum >= (MAXLINES - 6))
		maximum = MAXLINES - 6;
	for (count = (line - top); count < maximum; count++)
		{
		cur_line = 0;			/* disable more */
		if ((top + count) < cur_mlines)
			{
			cptr = mlines[top + count];
			cptr1 = buffer;
			while (*cptr && *cptr != '\r' && *cptr != '\x8d')
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (buffer[0])
				{
				sprintf(buffer1,"[%d;1H",count + 3);
				send_string(buffer1,NULL);
				send_string(buffer,NULL);
				send_string("[K",NULL);
				lines_inuse[count] = 1;
				}
			else if (lines_inuse[count])
				{
				sprintf(buffer1,"[%d;1H",count + 3);
				send_string(buffer1,NULL);
				send_string("[K",NULL);
				lines_inuse[count] = 0;
				}
			}
		else if (lines_inuse[count])
			{
			sprintf(buffer1,"[%d;1H",count + 3);
			send_string(buffer1,NULL);
			send_string("[K",NULL);
			lines_inuse[count] = 0;
			}
		}
	}



void pascal draw_partial_line(int top,int line,int col)
	{
	char buffer[100];
	char buffer1[10];
	char *cptr;
	char *cptr1;

	cur_line = 0;			/* disable more */
	cptr = mlines[line];
	cptr1 = buffer;
	while (*cptr && *cptr != '\r' && *cptr != '\x8d')
		*cptr1++ = *cptr++;
	*cptr1 = '\0';
	sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
	send_string(buffer1,NULL);
	if (col < (int)strlen(buffer))
		send_string(buffer + col,NULL);
	if (strlen(buffer))
		lines_inuse[line - top] = 1;
	else 
		lines_inuse[line - top] = 0;
	send_string("[K",NULL);
	}



int reformat_paragraph(int top,int line,int col)
	{
	char buffer[40];
	char buffer1[120];
	char *cptr;
	int count;
	int len;
	int tline;
	int soft;
	int rtn = 0;		/* wrap occurred */

//printf("In reformat_paragraph\r\n");
	cptr = mlines[line];
	while (*cptr && *cptr != '\r' && *cptr != '\x8d')
		++cptr;
	if (*cptr == '\x8d')
		soft = 1;
	else
		soft = 0;
	cptr = mlines[line] + (strlen(mlines[line]) - 1);
	while (cptr > mlines[line])
		{
		if (*cptr == ' ' && (cptr - mlines[line]) < WRAP)
			break;
		--cptr;
		}
	++cptr;
	if ((len = (int)strlen(cptr)) <= 35)		/* 35 character wrap limit */
		{
		sprintf(buffer,"[%d;%dH",(line - top) + 3,strlen(mlines[line]) + 1);
		send_string(buffer,NULL);
		for (count = 0; count < len; count++)
			send_string("\b",NULL);
		send_string("[K",NULL);		/* erase to EOL */
		strcpy(buffer,cptr);
		}
	else
		{
		cptr = mlines[line] + (strlen(mlines[line]) - 1);
		buffer[0] = (char)'\0';
		rtn = 1;
		}
	*cptr++ = (char)'\x8d';		/* establish a soft-CR */
	*cptr = (char)'\0';

	while (1)
		{
		tline = line + 1;

#if 0
		if (tline >= cur_mlines)
			{
			for (count = cur_mlines; count <= tline; count++ )
				{
				if (cur_mlines >= max_mlines)
					{
					if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
						{
						system_message("Fatal error in editor: Out of memory.  Loading line editor...");
						max_mlines = 0;
						cur_mlines = 0;
						return -1;
						}
					}
				if (!(mlines[count] = calloc(ALLOCLEN,sizeof(char))))
					{
					system_message("Fatal error in editor: Out of memory.  Loading line editor...");
					for (count = 0; count < cur_mlines; count++)
						free(mlines[count]);
					free(mlines);
					mlines = NULL;
					max_mlines = 0;
					cur_mlines = 0;
					return -1;
					}
				mlines[count][0] = (char)'\r';
				++cur_mlines;
				}
			}
#endif

		if (!soft)
			{
//printf("tline = %u\nBEFORE: ",tline);
//for (count = 0; count < cur_mlines; count++)
//	printf("%u=%04x  ",count,(unsigned short)mlines[count]);
//printf("\nAFTER: ");

			memmove(mlines + (tline + 1),mlines + tline,(cur_mlines - tline) * sizeof(char *));
			++cur_mlines;
			if (cur_mlines >= max_mlines)
				{
				if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
					{
					system_message("Fatal error in editor: Out of memory.  Loading line editor...");
					max_mlines = 0;
					cur_mlines = 0;
					return -1;
					}
				}
			if (!(mlines[tline] = calloc(ALLOCLEN,sizeof(char))))
				{
				system_message("Fatal error in editor: Out of memory.  Loading line editor...");
				for (count = 0; count < cur_mlines; count++)
					free(mlines[count]);
				free(mlines);
				mlines = NULL;
				max_mlines = 0;
				cur_mlines = 0;
				return -1;
				}
			mlines[tline][0] = (char)'\r';


//for (count = 0; count < cur_mlines; count++)
//	printf("%u=%04x  ",count,(unsigned short)mlines[count]);
//printf("\n");

			strcpy(mlines[tline],buffer);
			break;
			}
		else
			{
			strcpy(buffer1,buffer);
			cptr = buffer1;
			while (*cptr && *cptr != '\r' && *cptr != '\x8d')
				++cptr;
			strcpy(cptr,mlines[tline]);

			while (*cptr && *cptr != '\r' && *cptr != '\x8d')
				++cptr;
			if (*cptr == '\x8d')
				soft = 1;
			else
				soft = 0;
			if (strlen(buffer1) >= WRAP)
				{
				cptr = buffer1 + (strlen(buffer1) - 1);
				while ((cptr - buffer1) > 0)
					{
					if (*cptr == ' ' && (cptr - buffer1) < WRAP)
						break;
					--cptr;
					}
				++cptr;
				if ((cptr - buffer1) > 40)		/* 35 character wrap limit */
					strcpy(buffer,cptr);
				else
					{
					cptr = buffer1 + (WRAP - 2);
					strcpy(buffer,cptr);
					*cptr++ = (char)' ';
					}
				*cptr++ = (char)'\x8d';		/* establish a soft-CR */
				*cptr = (char)'\0';
				strcpy(mlines[tline],buffer1);
				}
			else
				{
				buffer[0] = (char)'\0';
				strcpy(mlines[tline],buffer1);
				break;
				}
			}
		++line;
		}
//printf("Out----------------\r\n\r\n",rtn);
//fflush(stdout);
	return rtn;
	}



void set_timer(int val)
	{
#ifdef PROTECTED
	DosEnterCritSec();
	mins = val;
	DosExitCritSec();
#else
	#ifdef __ZTC__
		int_off();
	#else
		_disable();
	#endif
	mins = val;
	#ifdef __ZTC__
		int_on();
	#else
		_enable();
	#endif
#endif
	}



void show_timer(void)
	{
	char buffer[20];
	int mins_left;
	int save_color;

	if (!chat_flag)
		{
		mins_left = (int)(user_time / 60L) + 1;
		if (mins != mins_left)
			{
			save_color = cur_color;
			set_timer(mins_left);
			send_string("[s",NULL);		/* save cursor */
			if (mins <= 2)
				{
				send_string(new_color(CYAN | BRIGHT | ON_RED | BLINK),NULL);
				send_string("\a",NULL);
				}
			else
				send_string(new_color(CYAN | BRIGHT | ON_RED),NULL);
			send_string("[1;66H",NULL);
			sprintf(buffer,"%4d min%s left ",mins,(char *)(mins == 1 ? "" : "s"));
			send_string(buffer,NULL);
			send_string(new_color(save_color),NULL);
			send_string("[u",NULL);		/* restore cursor */
			}
		}
	}




ACTION get_editkey(int *keystroke)
	{
	ACTION type = _NOTHING;
	int key;

	do
		{
		key = get_char();
		switch (key)
			{
			case '\x1b':	/* ESC */
				key = get_char();
				switch (key)
					{
					case '\x1b':		/* ESC */
						type = _ABORT_EXIT;
						break;
					case '[':
						key = get_char();
						switch (key)
							{
							case 'A':		/* VT-100  CUU */
								type = _KEY_UP;
								break;
							case 'B':	   	/* VT-100  CUD */
								type = _KEY_DOWN;
								break;
							case 'C':		/* VT-100  CUR */
								type = _KEY_RIGHT;
								break;
							case 'D':		/* VT-100  CUL */
								type = _KEY_LEFT;
								break;
							case 'H':		/* VT-100  Home */
								type = _KEY_HOME;
								break;
							case 'K':		/* VT-100  End */
								type = _KEY_END;
								break;
							}
						break;
					default:
						if (key >= ' ' && !(key & 0xff00) && key != (unsigned char)'\x8d')
							{
							type = _CHARACTER;
							*keystroke = key;
							}
						break;
					}
				break;

			case '\x0b':	/* Ctrl-K  Wordstar sequence */
				key = get_char();
				switch (key)
					{
					case 'A': 			
					case 'a': 			
					case '\x1': 		/* Ctrl-A */
						type = _ABORT_EXIT;
						break;
					case 'C':
					case 'c':
					case '\x3':			/* Ctrl-C - Center Line */
						type = _CENTER;
						break;
					case 'F':
					case 'f':
					case '\x6':			/* Ctrl-F - Flush line to Right */
						type = _FLUSH_KEY_RIGHT;
						break;
					case 'R': 			
					case 'r': 			
					case '\x12': 		/* Ctrl-R */
						type = _REDRAW;
						break;
					case 'S':
					case 's':
					case '\x13':		/* Ctrl-S */
					case 'D':
					case 'd':
					case '\x4':			/* Ctrl-D */
						type = _SAVE_EXIT;
						break;
					case 'Q':
					case 'q':
					case '\x11':		/* Ctrl-Q */
						type = _QUOTE;
						break;
					case '?':			/* Help */
						type = _HELP;
						break;
					default:
						if (key >= ' ' && !(key & 0xff00) && key != (unsigned char)'\x8d')
							{
							type = _CHARACTER;
							*keystroke = key;
							}
						break;
					}
				break;

			case '\x11':	/* Ctrl-Q  Wordstar sequence */
				key = get_char();
				switch (key)
					{
					case 'S':
					case 's':
					case '\x13':		/* Ctrl-S */
						type = _KEY_HOME;
						break;
					case 'D':
					case 'd':
					case '\x4':			/* Ctrl-D */
						type = _KEY_END;
						break;
					case 'E':
					case 'e':
					case '\x05':		/* Ctrl-E - Wordstar top of page */
						break;
					case 'X':
					case 'x':
					case '\x18':		/* Ctrl-X - Wordstar bottom of page */
						break;
					case 'R': 			
					case 'r': 			
					case '\x12': 		/* Ctrl-R  - Wordstar top of message */
						break;
					case 'C':
					case 'c':
					case '\x03':		/* Ctrl-C  - Wordstar bottom of message */
						break;
					case 'Q':
					case 'q':
					case '\x11':		/* Ctrl-Q */
						type = _QUOTE;
						break;
					case '?':			/* Help */
						type = _HELP;
						break;
					default:
						if (key >= ' ' && !(key & 0xff00) && key != (unsigned char)'\x8d')
							{
							type = _CHARACTER;
							*keystroke = key;
							}
						break;
					}
				break;

			case '\r':
				type = _ENTER;
				break;
			case '\b':
				type = _BACKSPACE;
				break;
			case '\t':
				type = _TAB;
				break;
			case '\x7f':	/* Del */
			case '\x7':		/* Ctrl-G  Wordstar Delete Current Char */
			case 0x153:		/* local Del */
				type = _DELETE;
				break;
			case '\x5':		/* Ctrl-E  Wordstar Up */
			case 0x148:		/* local up arrow */
				type = _KEY_UP;
				break;
			case '\x18':	/* Ctrl-X  Wordstar Down */
			case 0x150:		/* local down arrow */
				type = _KEY_DOWN;
				break;
			case '\x4':		/* Ctrl-D  Wordstar Right */
			case 0x14d:		/* local right arrow */
				type = _KEY_RIGHT;
				break;
			case '\x13':	/* Ctrl-S  Wordstar Left */
			case 0x14b:		/* local left arrow */
				type = _KEY_LEFT;
				break;
			case 0x147:		/* Home key */
				type = _KEY_HOME;
				break;
			case 0x14f:		/* End key */
				type = _KEY_END;
				break;
			case '\x1':		/* Ctrl-A  Wordstar word left */
			case 0x173:		/* local Ctrl-Left */
				type = _WORD_KEY_LEFT;
				break;
			case '\x6':		/* Ctrl-F  Wordstar word right */
			case 0x174:		/* local Ctrl-Right */
				type = _WORD_KEY_RIGHT;
				break;
			case '\x12':	/* Ctrl-R  Wordstar PgUp */
			case 0x149:		/* Local PgUp */
				type = _KEY_PGUP;
				break;
			case '\x3':		/* Ctrl-C  Wordstar PgDn */
			case 0x151:		/* Local PgDn */
				type = _KEY_PGDN;
				break;
			case '\x0e':	/* Ctrl-N  Wordstar Insert Line */
				break;
			case '\x19':	/* Ctrl-Y  Wordstar Delete Line */
				type = _DELETE_LINE;
				break;
			case '\x1a':	/* Ctrl-Z  VT-100 Save */
				type = _SAVE_EXIT;
				break;
			default:
				if (key >= ' ' && !(key & 0xff00) && key != (unsigned char)'\x8d')
					{
					type = _CHARACTER;
					*keystroke = key;
					}
				break;
			}
		}
	while (type == _NOTHING);
	return type;
	}



int fullscreen_edit_message(int prev,int kludge)
	{
	struct msgh tmsgh;
	char buffer[120];
	char buffer1[100];
	char initials[3];
	long total = 0L;
	ACTION taction;
	char *cptr;
	char *cptr1;
	int character;
	int count;
	int top = 0;
	int topquote = 0;
	int line = 0;
	int offset;
	int len;
	int tcol;
	int tline;
	int linequote = 0;
	int col = 0;
	int quit = 0;
	int inquote = 0;
	int key;
	int rtn = 0;
	int temp;
	int cr;
	int kill_line;
	int ctrl_a = 0;

	/* first to set up the quotes */
	if (prev)
		{
		fseek(msghfd,(long)(prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
		fread(&tmsgh,sizeof(struct msgh),1,msghfd);

		cptr = tmsgh.msgh_from;
		cptr1 = initials;
		while (*cptr && isspace(*cptr))
			++cptr;
		if (*cptr)
			{
			*cptr1++ = (char)toupper(*cptr);
			while (*cptr && !isspace(*cptr))
				++cptr;
			while (*cptr && isspace(*cptr))
				++cptr;
			if (*cptr)
				*cptr1++ = (char)toupper(*cptr);
			}
		*cptr1 = '\0';
		temp = (((unsigned int)tmsgh.msgh_date >> 5) & 0xf) - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;

		/* prepare quote line */
		sprintf(buffer,"In a message dated <%d %s %02d at %d:%02d>, %-.30s wrote to %s:\r",tmsgh.msgh_date & 0x1f,months_table[temp],(((unsigned int)tmsgh.msgh_date >> 9) + 1980) % 100,
				(unsigned int)tmsgh.msgh_time >> 11,((unsigned int)tmsgh.msgh_time >> 5) & 0x3f,tmsgh.msgh_from,tmsgh.msgh_to);
		cptr = buffer + strlen(buffer);
		buffer1[0] = '\0';
		if ((cptr - buffer) >= WRAP)
			{
			cptr1 = buffer + (WRAP - 1);
			while (*cptr1 && ((cptr1 - buffer) != 0) && !isspace(*cptr1))
				--cptr1;
			++cptr1;
			strcpy(buffer1,cptr1);
			cptr = cptr1;
			*cptr++ = '\r';
			*cptr++ = '\0';
			}
		if (add_quote(buffer))
			return -1;
		if (buffer1[0])
			{
			if (add_quote(buffer1))
				return -1;
			}
		if (add_quote("\r"))
			return -1;

		buffer1[0] = '\0';
		fseek(msgbfd,tmsgh.msgh_offset,SEEK_SET);
		while (total < tmsgh.msgh_length)
			{
			sprintf(buffer,"%s> %s",initials,buffer1);
			cptr = buffer + strlen(buffer);
			buffer1[0] = '\0';
			while ((character = fgetc(msgbfd)) != EOF && character != '\n' && character != '\r' && total < tmsgh.msgh_length)
				{
				if (character == '\x01')		/* ctrl-a? */
					{
					if (!kludge)
						ctrl_a = 1;
					else
						{
						*cptr++ = '^';
						character = 'a';
						ctrl_a = 0;
						}
					}
				if (!ctrl_a)
					{
					if (character != (unsigned char)'\x8d')
						*cptr++ = (char)character;
					else
						*cptr++ = ' ';
					++total;
					if ((cptr - buffer) >= (WRAP - 2))
						{
						cptr1 = cptr - 1;
						while (*cptr1 && (cptr1 - buffer) != 0 && !isspace(*cptr1))
							--cptr1;
						++cptr1;
						if ((cptr - cptr1) <= (WRAP / 2))		/* wrap no greater than 35 characters */
							{
							*cptr = '\0';
							strcpy(buffer1,cptr1);
							cptr = cptr1;
							}
						break;
						}
					}
				}
			if (character == EOF || character == '\r' || character == '\n')
				{
				ctrl_a = 0;
				++total;
				}
			*cptr++ = '\r';
			*cptr = '\0';
			if (add_quote(buffer))
				return -1;
			}
		}

	/* we have to stop the 2 minute time alarm and handle it ourselves! */
	draw_screen(top,line,col,inquote,topquote,linequote);
	user_warning = 1;
	set_timer(0);
	timer_function = show_timer;

	if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
		{
		system_message("Fatal error in editor: Out of memory.  Loading line editor...");
		max_mlines = 0;
		cur_mlines = 0;
		timer_function = NULL;
		user_warning = 0;
		free_quotes();
		return 0;
		}
	if (!(cptr = calloc(ALLOCLEN,sizeof(char))))
		{
		system_message("Fatal error in editor: Out of memory.  Loading line editor...");
		for (count = 0; count < cur_mlines; count++)
				free(mlines[count]);
		free(mlines);
		mlines = NULL;
		max_mlines = 0;
		cur_mlines = 0;
		timer_function = NULL;
		user_warning = 0;
		free_quotes();
		return -1;
		}
	mlines[cur_mlines] = cptr;
	*cptr = '\r';
	++cur_mlines;

	do
		{
		cur_line = 0;			/* disable more */
		taction = get_editkey(&key);
		switch (taction)
			{
			case _ABORT_EXIT:
				send_string("[2;1H",NULL);
				send_string(new_color(BROWN | BRIGHT | ON_RED),NULL);
				send_string("Do you want to abort this message (y/N)? ",NULL);
				if (get_yn_enter(0))
					quit = 1;
				else
					{
					send_string("[2;1H",NULL);
					send_string(new_color(WHITE | ON_RED),NULL);
					for (count = 0; count < 45; count++)
						send_string(" ",NULL);
					send_string(new_color(WHITE),NULL);
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _CENTER:
				strcpy(buffer,mlines[line]);
				cptr = buffer;
				while (*cptr && *cptr <= ' ')		/* strip leading spaces */
					++cptr;
				if (*cptr)
					{
					len = 0;
					cptr1 = cptr;
					while (*cptr)			/* count length of string */
						{
						++len;
						++cptr;
						}
					--cptr;
					while ((cptr - buffer) > 0 && *cptr <= ' ')		/* strip trailing spaces */
						{
						--len;
						--cptr;
						}
					temp = (unsigned int)(WRAP - len) >> 1;		/* center line */
					cptr = mlines[line];
					for (count = 0; count < temp; count++)
						*cptr++ = ' ';
					for (count = 0; count < len; count++)
						*cptr++ = *cptr1++;
					*cptr++ = '\r';		/* add hard-CR to preserve formatting */
					*cptr = '\0';
					col = 0;
					draw_partial_line(top,line,col);
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _FLUSH_KEY_RIGHT:
				strcpy(buffer,mlines[line]);
				cptr = buffer;
				while (*cptr && *cptr <= ' ')		/* strip leading spaces */
					++cptr;
				if (*cptr)
					{
					len = 0;
					cptr1 = cptr;
					while (*cptr)			/* count length of string */
						{
						++len;
						++cptr;
						}
					--cptr;
					while ((cptr - buffer) > 0 && *cptr <= ' ')		/* strip trailing spaces */
						{
						--len;
						--cptr;
						}
					temp = WRAP - len;		/* right-justify line */
					cptr = mlines[line];
					for (count = 0; count < temp; count++)
						*cptr++ = ' ';
					for (count = 0; count < len; count++)
						*cptr++ = *cptr1++;
					*cptr++ = '\r';		/* add hard-CR to preserve formatting */
					*cptr = '\0';
					col = 0;
					draw_partial_line(top,line,col);
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _REDRAW:
				draw_screen(top,line,col,inquote,topquote,linequote);
				set_timer(0);
				break;
			case _HELP:
				timer_function = NULL;
				send_string("[0m[2J",NULL);
				send_ansifile(cfg.cfg_screenpath,"ANSIHELP",0);
				get_enter();
				draw_screen(top,line,col,inquote,topquote,linequote);
				set_timer(0);
				timer_function = show_timer;
				break;
			case _QUOTE:
				if (cur_quote)
					{
					inquote = inquote ? 0 : 1;
					if (inquote)
						{
						if ((line - top) >= (MAXLINES - 7))
							{
							top += 10;
							draw_partial_screen(top,line,col,inquote);
							}
						sprintf(buffer1,"[%d;1H",(line - top) + 3);
						send_string(buffer1,NULL);
						send_string(new_color(WHITE | BLINK),NULL);
						send_string("_",NULL);
						send_string(new_color(WHITE),NULL);
						draw_quote(topquote);
						sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
						}
					else
						{
						sprintf(buffer1,"[%d;1H",(line - top) + 3);
						send_string(buffer1,NULL);
						send_string(new_color(WHITE),NULL);
						if (!mlines[line][0] || mlines[line][0] == '\r' || mlines[line][0] == '\x8d')
							send_string(" ",NULL);
						else
							{
							sprintf(buffer1,"%c",mlines[line][0]);
							send_string(buffer1,NULL);
							}
						draw_screen_from_line(top,top + MAXLINES - 7,col,inquote);
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						}
					send_string(buffer1,NULL);
					}
				break;
			case _ENTER:
				if (!inquote)
					{
					cptr = mlines[line] + col;
					len = (int)strlen(cptr);

					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					send_string("[K",NULL);		/* erase to EOL */

					strcpy(buffer1,cptr);			/* move the data to the new line */
					*cptr++ = '\r';
					*cptr = '\0';

					++line;
					col = 0;
					if (cur_mlines >= max_mlines)
						{
						if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
							{
							system_message("Fatal error in editor: Out of memory.  Loading line editor...");
							max_mlines = 0;
							cur_mlines = 0;
							timer_function = NULL;
							user_warning = 0;
							free_quotes();
							return -1;
							}
						}
					if (!(cptr = calloc(ALLOCLEN,sizeof(char))))
						{
						system_message("Fatal error in editor: Out of memory.  Loading line editor...");
						for (count = 0; count < cur_mlines; count++)
							free(mlines[count]);
						free(mlines);
						mlines = NULL;
						max_mlines = 0;
						cur_mlines = 0;
						timer_function = NULL;
						user_warning = 0;
						free_quotes();
						return -1;
						}
					strcpy(cptr,buffer1);

					++cur_mlines;

					if (line < (cur_mlines - 1))
						memmove(mlines + (line + 1),mlines + line,(cur_mlines - line) * sizeof(char *));
					mlines[line] = cptr;
					if (!inquote && (line - top) >= MAXLINES)
						{
						top += 10;
						draw_partial_screen(top,line,col,inquote);
						}
					else
						{
						draw_screen_from_line(top,line,col,inquote);
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						}
					}
				else
					{
					if (line)
						{
						cptr = mlines[line - 1];
						while (*cptr && *cptr != '\r' && *cptr != '\x8d')
							++cptr;
						if (!*cptr)
							{
							*cptr++ = '\r';
							*cptr = '\0';
							}
						else if (*cptr == '\x8d')
							*cptr = '\r';
						}

					if (cur_mlines >= max_mlines)
						{
						if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
							{
							system_message("Fatal error in editor: Out of memory.  Loading line editor...");
							max_mlines = 0;
							cur_mlines = 0;
							timer_function = NULL;
							user_warning = 0;
							free_quotes();
							return -1;
							}
						}
					if (!(cptr = calloc(ALLOCLEN,sizeof(char))))
						{
						system_message("Fatal error in editor: Out of memory.  Loading line editor...");
						for (count = 0; count < cur_mlines; count++)
							free(mlines[count]);
						free(mlines);
						mlines = NULL;
						max_mlines = 0;
						cur_mlines = 0;
						timer_function = NULL;
						user_warning = 0;
						free_quotes();
						return -1;
						}
					strcpy(cptr,quote[linequote]);

					memmove(mlines + (line + 1),mlines + line,(cur_mlines - line) * sizeof(char *));

					++cur_mlines;
					mlines[line] = cptr;

					sprintf(buffer1,"[%d;1H",(line - top) + 3);
					send_string(buffer1,NULL);
					send_string(" ",NULL);

					++line;
					if ((line - top) >= (MAXLINES - 7))
						{
						top += 10;
						draw_partial_screen(top,line,col,inquote);
						}
					else
						draw_screen_from_line(top,line - 1,col,inquote);
					sprintf(buffer1,"[%d;1H",(line - top) + 3);
					send_string(buffer1,NULL);
					send_string(new_color(WHITE | BLINK),NULL);
					send_string("_",NULL);
					send_string(new_color(WHITE),NULL);

					if (linequote < (cur_quote - 1))
						{
						++linequote;
						if (linequote >= (topquote + 5))
							{
							topquote += 5;
							redraw_quote(topquote);
							}
						}
					sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
					send_string(buffer1,NULL);
					}
				break;
			case _BACKSPACE:
				if (!inquote)
					{
					if (col)
						{
						offset = (int)strlen(mlines[line]);
						if (offset)
							{
							if (mlines[line][offset - 1] == '\r' || mlines[line][offset - 1] == '\x8d')
								--offset;
							}
						--col;
						if (col <= offset)
							{
							memmove(mlines[line] + col,mlines[line] + (col + 1),(strlen(mlines[line] + (col + 1)) + 1) * sizeof(char));
							draw_partial_line(top,line,col);
							}
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						}
					else if (line)
						{
						offset = (int)strlen(mlines[line - 1]);
						if (offset)
							{
							if (mlines[line - 1][offset - 1] == '\r' || mlines[line - 1][offset - 1] == '\x8d')
								--offset;
							}
						len = WRAP - offset;
						count = 0;
						cptr = mlines[line];
						cptr1 = buffer;
						while (*cptr && count < len)
							{
							*cptr1++ = *cptr++;
							++count;
							}
						cr = 0;
						kill_line = 0;
						if ((cptr1 - buffer) != 0)
							{
							while ((cptr1 - buffer) != 0 && *(cptr1 - 1) != ' ')
								{
								--cptr1;
								if (*cptr1 == '\r' || *cptr1 == '\x8d')
									{
									if (*cptr1 == '\r')
										cr = 1;
									kill_line = 1;
									break;
									}
								}
							if (!cr)
								*cptr1++ = '\x8d';
							else 
								*cptr1++ = '\r';
							}
						*cptr1 = '\0';
						if (buffer[0])
							{
							strcpy(mlines[line - 1] + offset,buffer);
							memmove(mlines[line],mlines[line] + (strlen(buffer) - 1),((strlen(mlines[line]) + 1) - (strlen(buffer) - 1)) * sizeof(char));
							--line;
							col = offset;
							if (line >= top)
								{
								draw_partial_line(top,line,col);
								if (kill_line)
									{
									free(mlines[line + 1]);
									memmove(mlines + (line + 1),mlines + (line + 2),(cur_mlines - line + 2) * sizeof(char *));
									--cur_mlines;
									draw_screen_from_line(top,line + 1,0,inquote);
									}
								else 
									draw_partial_line(top,line + 1,0);
								}
							else
								{
								if (top >= 10)
									top -= 10;
								else
									top = 0;
								draw_partial_screen(top,line,col,inquote);
								}
							}
						else
							{
							--line;
							col = offset;
							}
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						}
					}
				break;
			case _TAB:
				if (!inquote)
					{
					temp = ((col / 4) + 1) * 4;
					offset = (int)strlen(mlines[line]);
					if (offset)
						{
						if (mlines[line][offset - 1] == '\r' || mlines[line][offset - 1] == '\x8d')
							--offset;
						}
					if (col > offset)			/* we need to pad with spaces */
						{
						len = col - offset;
						for (count = 0; count < len; count++)
							{
							memmove(mlines[line] + (offset + 1),mlines[line] + offset,(col - offset) * sizeof(char));
							mlines[line][offset] = ' ';
							++offset;
							}
						}

					len = temp - col;
					for (count = 0; count < len; count++)
						{
						memmove(mlines[line] + (col + count + 1),mlines[line] + (col + count),((strlen(mlines[line]) + 1) - (col + count)) * sizeof(char));
						mlines[line][col + count] = ' ';
						++offset;
						}

					if (offset >= WRAP)
						{
						col = temp;
						if (reformat_paragraph(top,line,col) == -1)
							{
							timer_function = NULL;
							user_warning = 0;
							free_quotes();
							return -1;
							}
						if (col >= (int)(strlen(mlines[line]) - 1))		/* was our column beyond the wrap? */
							{
							col -= ((int)strlen(mlines[line]) - 1);
							++line;
							}

						if (!inquote && (line - top) >= MAXLINES)
							{
							top += 10;
							draw_partial_screen(top,line,col,inquote);
							}
						else
							{
							draw_screen_from_line(top,line,col,inquote);
							sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
							send_string(buffer1,NULL);
							}
						}
					else
						{
						draw_partial_line(top,line,col);
						col = temp;
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						lines_inuse[line - top] = 1;
						}
					}
				break;
			case _DELETE:
				if (!inquote)
					{
					memmove(mlines[line] + col,mlines[line] + (col + 1),(strlen(mlines[line] + (col + 1)) + 1) * sizeof(char));
					draw_partial_line(top,line,col);
					sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer1,NULL);
					}
				break;
			case _KEY_UP:
				if (!inquote)
					{
					if (line)
						{
						--line;
						if (line < top)
							{
							if (top >= 10)
								top -= 10;
							else
								top = 0;
							draw_partial_screen(top,line,col,inquote);
							}
						else
							send_string("[A",NULL);	/* CUU */
						}
					}
				else
					{
					if (linequote)
						{
						--linequote;
						if (linequote < topquote)
							{
							if (topquote > 5)
								topquote -= 5;
							else
								topquote = 0;
							redraw_quote(topquote);
							}
						sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
						send_string(buffer1,NULL);
						}
					}
				break;
			case _KEY_DOWN:
				if (!inquote)
					{
					++line;
					if (line >= cur_mlines)
						{
						if (cur_mlines >= max_mlines)
							{
							if (!(mlines = realloc(mlines,(max_mlines += 50) * sizeof(char *))))
								{
								system_message("Fatal error in editor: Out of memory.  Loading line editor...");
								max_mlines = 0;
								cur_mlines = 0;
								timer_function = NULL;
								user_warning = 0;
								free_quotes();
								return -1;
								}
							}
						if (!(cptr = calloc(ALLOCLEN,sizeof(char))))
							{
							system_message("Fatal error in editor: Out of memory.  Loading line editor...");
							for (count = 0; count < cur_mlines; count++)
								free(mlines[count]);
							free(mlines);
							mlines = NULL;
							max_mlines = 0;
							cur_mlines = 0;
							timer_function = NULL;
							user_warning = 0;
							free_quotes();
							return -1;
							}
						*cptr = '\r';		/* add hard CR */
						mlines[line] = cptr;
						++cur_mlines;
						}
					if (!inquote && (line - top) >= MAXLINES)
						{
						top += 10;
						draw_partial_screen(top,line,col,inquote);
						}
					else
						send_string("[B",NULL);	/* CUD */
					}
				else
					{
					if (linequote < (cur_quote - 1))
						{
						++linequote;
						if (linequote >= (topquote + 5))
							{
							topquote += 5;
							redraw_quote(topquote);
							}
						sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
						send_string(buffer1,NULL);
						}
					}
				break;
			case _KEY_RIGHT:
				if (!inquote)
					{
					if (col < WRAP)
						{
						++col;
						send_string("[C",NULL);	/* CUR */
						}
					}
				break;
			case _KEY_LEFT:
				if (!inquote)
					{
					if (col)
						{
						--col;
						send_string("[D",NULL);	/* CUL */
						}
					}
				break;
			case _KEY_HOME:
				if (!inquote)
					{
					if (col)
						{
						col = 0;
						sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer,NULL);
						}
					}
				break;
			case _KEY_END:
				if (!inquote)
					{
					col = (int)strlen(mlines[line]);
					if (col && (mlines[line][col - 1] == '\r' || mlines[line][col - 1] == '\x8d'))
						--col;
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _WORD_KEY_LEFT:
				if (!inquote)
					{
					tcol = col;
					tline = line;
					while (!isspace(mlines[tline][tcol]))
						{
						if (!tcol)
							{
							if (!tline)
								break;
							else
								{
								--tline;
								tcol = (int)strlen(mlines[tline]);
								if (tcol)
									{
									--tcol;
									cptr = mlines[tline] + tcol;
									while (tcol && (!*cptr || *cptr == '\r' || *cptr == '\n' || *cptr == '\x8d'))
										{
										--cptr;
										--tcol;
										}
									}
								break;
								}
							}
						else
							--tcol;
						}
					while (1)
						{
						if (tcol && !isspace(mlines[tline][tcol]))
							break;
						if (!tcol)
							{
							if (!tline)
								break;
							else
								{
								--tline;
								tcol = (int)strlen(mlines[tline]);
								if (tcol)
									{
									--tcol;
									cptr = mlines[tline] + tcol;
									while (tcol && (!*cptr || *cptr == '\r' || *cptr == '\n' || *cptr == '\x8d'))
										{
										--cptr;
										--tcol;
										}
									}
								}
							}
						else
							--tcol;
						}
					while (1)
						{
						if (isspace(mlines[tline][tcol]))
							{
							++tcol;
							break;
							}
						if (!tcol)
							break;
						else
							--tcol;
						}
					line = tline;
					col = tcol;
					if (line < top)
						{
						if (line > 10)
							top = line - 10;
						else
							top = 0;
						draw_partial_screen(top,line,col,inquote);
						}
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _WORD_KEY_RIGHT:
				if (!inquote)
					{
					tcol = col;
					tline = line;
					while (!isspace(mlines[tline][tcol]))
						{
						if (!mlines[tline][tcol] || mlines[tline][tcol] == '\r' || mlines[tline][tcol] == '\n' || mlines[tline][tcol] == '\x8d')
							{
							if ((tline + 1) >= cur_mlines)
								break;
							else
								{
								++tline;
								tcol = 0;
								}
							}
						else
							++tcol;
						}
					while (isspace(mlines[tline][tcol]))
						{
						if (!mlines[tline][tcol] || mlines[tline][tcol] == '\r' || mlines[tline][tcol] == '\n' || mlines[tline][tcol] == '\x8d')
							{
							if ((tline + 1) >= cur_mlines)
								break;
							else
								{
								++tline;
								tcol = 0;
								}
							}
						else
							++tcol;
						}
					line = tline;
					col = tcol;
					if ((line - top) >= MAXLINES)
						{
						if (line > 10)
							top = line - 10;
						else
							top = 0;
						draw_partial_screen(top,line,col,inquote);
						}
					sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
					send_string(buffer,NULL);
					}
				break;
			case _KEY_PGUP:
				if (inquote)
					{
					if (topquote)
						{
						if (topquote >= 5)
							{
							topquote -= 5;
							linequote -= 5;
							}
						else
							{
							topquote = 0;
							linequote = 0;
							}
						redraw_quote(topquote);
						sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
						send_string(buffer1,NULL);
						}
					}
				else
					{
					if (top)
						{
						if (top < MAXLINES)
							{
							top = 0;
							line = 0;
							col = 0;
							}
						else
							{
							top -= MAXLINES;
							line -= MAXLINES;
							col = 0;
							}
						draw_partial_screen(top,line,col,inquote);
						}
					}
				break;
			case _KEY_PGDN:
				if (inquote)
					{
					if (topquote + 5 <= (cur_quote - 1))
						{
						topquote += 5;
						linequote += 5;
						if (linequote >= (cur_quote - 1))
							linequote = cur_quote - 1;
						redraw_quote(topquote);
						sprintf(buffer1,"[%d;1H",(linequote - topquote) + MAXLINES - 5 + 3);
						send_string(buffer1,NULL);
						}
					}
				else
					{
					if ((top + MAXLINES) <= (cur_mlines - 1))
						{
						top += MAXLINES;
						if ((line + MAXLINES) <= (cur_mlines - 1))
							{
							line += MAXLINES;
							col = 0;
							}
						else
							{
							line = cur_mlines - 1;
							col = 0;
							}
						draw_partial_screen(top,line,col,inquote);
						}
					}
				break;
			case _DELETE_LINE:
				if (!inquote)
					{
					if (line == cur_mlines - 1)
						{
						strcpy(mlines[line],"\r");
						col = 0;
						sprintf(buffer,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer,NULL);
						send_string("[K",NULL);
						}
					else
						{
						free(mlines[line]);
						memmove(mlines + line,mlines + (line + 1),(cur_mlines - line + 1) * sizeof(char *));
						--cur_mlines;
						draw_screen_from_line(top,line,col,inquote);
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						}
					}
				break;
			case _SAVE_EXIT:
				rtn = 1;
				quit = 1;
				break;
			case _CHARACTER:
				if (!inquote)
					{
					offset = (int)strlen(mlines[line]);
					if (offset)
						{
						if (mlines[line][offset - 1] == '\r' || mlines[line][offset - 1] == '\x8d')
							--offset;
						}
					if (col > offset)			/* we need to pad with spaces */
						{
						len = col - offset;
						for (count = 0; count < len; count++)
							{
//							memmove(mlines[line] + (offset + 1),mlines[line] + offset,(col - offset) * sizeof(char));
							mlines[line][offset] = ' ';
							++offset;
							}
						mlines[line][offset] = '\0';
						}
					if (offset >= WRAP)
						{
						temp = reformat_paragraph(top,line,col);
						if (temp == -1)
							{
							timer_function = NULL;
							user_warning = 0;
							free_quotes();
							return -1;
							}

						if (col >= (int)(strlen(mlines[line]) - 1))		/* was our column beyond the wrap? */
							{
							if (temp)
								col = 0;
							else
								col -= ((int)strlen(mlines[line]) - 1);

							++line;
							}
						memmove(mlines[line] + (col + 1),mlines[line] + col,(strlen(mlines[line] + col) + 1) * sizeof(char));
						mlines[line][col] = (char)key;
						++col;
						if (!inquote && (line - top) >= MAXLINES)
							{
							top += 10;
							draw_partial_screen(top,line,col,inquote);
							}
						else
							{
							draw_screen_from_line(top,line,col,inquote);
							sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
							send_string(buffer1,NULL);
							}
						}
					else
						{
						memmove(mlines[line] + (col + 1),mlines[line] + col,(strlen(mlines[line] + col) + 1) * sizeof(char));
						mlines[line][col] = (char)key;
						draw_partial_line(top,line,col);
						++col;
						sprintf(buffer1,"[%d;%dH",(line - top) + 3,col + 1);
						send_string(buffer1,NULL);
						lines_inuse[line - top] = 1;
						}
					}
				break;
			}
		}
	while (!quit);

	free_quotes();
	if (!rtn)
		{
		if (max_mlines)
			{
			for (count = 0; count < cur_mlines; count++)
				free(mlines[count]);
			free(mlines);
			mlines = NULL;
			cur_mlines = 0;
			max_mlines = 0;
			}
		}
	timer_function = NULL;
	send_string("[0m[2J",NULL);
	user_warning = 1;			/* restore the user 2 minute warning flag */
	return rtn;
	}
