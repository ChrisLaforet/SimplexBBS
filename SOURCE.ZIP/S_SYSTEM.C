`/* s_system.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 3 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_system.c_v  $
**                       $Date:   25 Oct 1992 14:09:02  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>
#ifdef PROTECTED
	#define INCL_DOS
	#include <os2.h>
#else
	#ifdef __ZTC__
		#include <int.h>
	#endif
	#include <dos.h>
#endif
#include "simplex.h"



extern jmp_buf reset_bbs;



void system_message(char *message)
	{
	char buffer[81];
	char *cptr;
	char *cptr1;
	int save_color;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		save_color = cur_color;
		send_string(new_color(BROWN | BRIGHT),NULL);
		}
	send_string("\r\n\r\n\aSystem Message: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);

	cptr = message;
	while (*cptr)
		{
		cptr1 = buffer;
		while (*cptr && (cptr1 - buffer) < 60)
			*cptr1++ = *cptr++;
		while (!isspace(*cptr1) && (cptr1 - buffer) > 45)
			{
			--cptr1;
			--cptr;
			}
		*cptr1 = (char)'\0';
		send_string(buffer,NULL);
		send_string("\r\n",NULL);
		if (*cptr)
			send_string("               ",NULL);

		}
	send_string("\r",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(save_color),NULL);
	get_enter();
	}



void show_version(void)
	{
	char buffer[100];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
#ifdef PROTECTED
	#ifdef MULTICHAT
		send_string("SIMPLEX/2-M: A Bulletin Board System for OS/2 with MultiChat.\r\n",NULL);
	#else
		send_string("SIMPLEX/2: A Bulletin Board System for OS/2.\r\n",NULL);
	#endif
	sprintf(buffer,"Version %u.%02u.%02u%s for OS/2 compiled on %s\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""),__DATE__);
	send_string(buffer,NULL);
#elif defined(__ZTC__)
	send_string("SIMPLEX/S: A Bulletin Board System for DOS.\r\n",NULL);
	sprintf(buffer,"Swapping version %u.%02u.%02u%s for MS-DOS compiled on %s\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""),__DATE__);
	send_string(buffer,NULL);
#else
	send_string("SIMPLEX: A Bulletin Board System for DOS.\r\n",NULL);
	sprintf(buffer,"Version %u.%02u.%02u%s for MS-DOS compiled on %s\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""),__DATE__);
	send_string(buffer,NULL);
#endif
	send_string("Copyright (c) 1989-93, Christopher Laforet and Chris Laforet Software.\r\n",NULL);
	send_string("All rights reserved.\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
#ifdef PROTECTED
	sprintf(buffer,"Running under OS/2 version %d.%02d\r\n",_osmajor / 10,_osminor);
	send_string(buffer,NULL);
#else
	sprintf(buffer,"Running under DOS version %d.%02d\r\n",_osmajor,_osminor);
	send_string(buffer,NULL);
#endif

#if defined(__ZTC__)
	send_string("Compiled using Zortech C++ version 3.00\r\n\r\n",NULL);
#elif defined(__WATCOMC__)
	send_string("Compiled using Watcom C version 9.0\r\n\r\n",NULL);
#else
	send_string("Compiled using Microsoft C version 6.00a\r\n\r\n",NULL);
#endif
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("For more information contact Chris Laforet at:\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("\tProgrammer's Oasis BBS, USA .... 919/226-6984\r\n",NULL);
	send_string("\tProgrammer's Oasis 2 BBS, USA .. 919/226-7136\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\tFidonet Email .................. Chris Laforet @ 1:3644/1 or 1:3644/2\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\tCompuserve Email ............... User ID: 76120,110\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\tBIX Email....................... User ID: Laforet\r\n\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string("Dedicated to my wife Sherry and to my daughter Rebekah -- Chris.\r\n",NULL);
	get_enter();
	}



void change_citystate(void)
	{
	char buffer[31];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhere are you calling from (City, State): ",NULL);
	get_field(buffer,30,1);
	if (buffer[0])
		{
		strcpy(user.user_city,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_address1(void)
	{
	char buffer[31];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your Address Line 1: ",NULL);
	get_field(buffer,30,1);
	if (buffer[0])
		{
		strcpy(user.user_address1,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_address2(void)
	{
	char buffer[31];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your Address Line 2: ",NULL);
	get_field(buffer,30,1);
	if (buffer[0])
		{
		strcpy(user.user_address2,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_city(void)
	{
	char buffer[31];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your City: ",NULL);
	get_field(buffer,30,1);
	if (buffer[0])
		{
		strcpy(user.user_city,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_state(void)
	{
	char buffer[16];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your State/Country: ",NULL);
	get_field(buffer,15,1);
	if (buffer[0])
		{
		strcpy(user.user_state,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_zip(void)
	{
	char buffer[16];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your Zip: ",NULL);
	get_field(buffer,15,1);
	if (buffer[0])
		{
		strcpy(user.user_zip,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		}
	}



void change_password(void)
	{
	char buffer[16];
	char buffer1[16];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nPlease enter your current password: ",NULL);
	get_password(buffer,15);
	if (!stricmp(buffer,user.user_password))
		{
		send_ansifile(cfg.cfg_screenpath,"PASSWORD",1);
		cur_line = 0;		/* defeats more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN),NULL);
		send_string("\r\nPlease enter your new password: ",NULL);
		get_password(buffer,15);
		if (strlen(buffer) >= 4)
			{
			send_string("\r\nPlease re-enter your password: ",NULL);
			get_password(buffer1,15);
			if (!stricmp(buffer,buffer1))
				{
				strcpy(user.user_password,buffer);
				fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
				fwrite(&user,1,sizeof(struct user),userfd);
				fflush(userfd);
				send_string("\r\n\aPassword has been changed!\r\n",NULL);
				}
			else
				send_string("\r\n\aYou mis-typed your password...Password was NOT changed!\r\n",NULL);
			}
		else
			send_string("\r\n\aA password must be 4-15 characters long...Password was NOT changed!\r\n",NULL);
		}
	else
		send_string("\r\n\aInvalid password provided!\r\n",NULL);
	get_enter();
	}



void change_cls(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nDo you want screen clearing codes sent (y/n)? ",NULL);
	if (get_yn())
		user.user_flags |= USER_CLS;
	else
		user.user_flags &= ~USER_CLS;
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,1,sizeof(struct user),userfd);
	fflush(userfd);
	}



void change_more(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nDo you want to pause after each screen (y/n)? ",NULL);
	if (get_yn())
		user.user_flags |= USER_MORE;
	else
		user.user_flags &= ~USER_MORE;
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,1,sizeof(struct user),userfd);
	fflush(userfd);
	}



void change_ansi(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nDo you want ANSI screen codes sent (y/n)? ",NULL);
	if (get_yn())
		user.user_flags |= USER_ANSI;
	else
		{
		user.user_flags &= ~USER_ANSI;
		write_string(new_color(WHITE));		/* make sure that our color is gray */
		}
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,1,sizeof(struct user),userfd);
	fflush(userfd);
	}



void change_editor(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nDo you want to use the ANSI full-screen editor (y/n)? ",NULL);
	if (get_yn())
		user.user_flags |= USER_EDITOR;
	else
		user.user_flags &= ~USER_EDITOR;
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,1,sizeof(struct user),userfd);
	fflush(userfd);
	}



void change_expert(void)
	{
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nDo you want use expert mode menus (y/n)? ",NULL);
	if (get_yn())
		user.user_flags |= USER_EXPERT;
	else
		user.user_flags &= ~USER_EXPERT;
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,1,sizeof(struct user),userfd);
	fflush(userfd);
	}



void change_screenlen(void)
	{
	char buffer[81];
	int len;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	sprintf(buffer,"\r\n\r\nHow many lines fit on your screen [10-66] (ENTER=%d)? ",user.user_screenlen);
	send_string(buffer,NULL);
	len = get_number(9,66);
	if (len > 9)
		{
		user.user_screenlen = (char)len;
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		}
	}



void change_dataphone(void)
	{
	char buffer[15];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your DATA (or WORK) number (ENTER=No Change)? ",NULL);
	get_phone(buffer,0);
	if (buffer[0])
		{
		strcpy(user.user_data,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		send_string("\r\nYour Data/Work number has been changed.\r\n",NULL);
		get_enter();
		}
	}



void change_homephone(void)
	{
	char buffer[15];

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n\r\nWhat is your HOME number (ENTER=No Change)? ",NULL);
	get_phone(buffer,0);
	if (buffer[0])
		{
		strcpy(user.user_home,buffer);
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		show_user();
		send_string("\r\nYour Home number has been changed.\r\n",NULL);
		get_enter();
		}
	}



void change_aliases(void)
	{
	struct user tuser;
	char buffer[80];
	char buffer1[80];
	int count;
	int kount;
	int legal;
	int change = 0;
	int quit = 0;
	int key;
	int ok;

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nThe following aliases are registered to you:\r\n\r\n",NULL);
		for (count = 0; count < 4; count++)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			sprintf(buffer,"      %d) ",count + 1);
			send_string(buffer,NULL);

			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN | BRIGHT),NULL);
			send_string("\"",NULL);
			send_string(user.user_alias[count],NULL);
			send_string("\"\r\n",NULL);
			}

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nEdit which alias [1-4 or X] (ENTER=Exit)? ",NULL);

		ok = 0;
		do
			{
			key = get_char();
			switch (key)
				{
				case '1':
				case '2':
				case '3':
				case '4':
					if (key == '1')
						count = 0;
					else if (key == '2')
						count = 1;
					else if (key == '3')
						count = 2;
					else
						count = 3;

					sprintf(buffer,"\r\n     Current alias #%d: ",count + 1);
					send_string(buffer,NULL);
					mark_field(40);
					send_string(user.user_alias[count],NULL);
					unmark_field();
					send_string("\r\nEdit or ENTER to quit: ",NULL);
					get_field(buffer,40,1);
					if (buffer[0])
						{
						send_string("Please wait....checking validity of alias....",NULL);
						legal = 1;
						if (!stricmp(buffer,"Sysop") || !stricmp(buffer,"Users") || !stricmp(buffer,"All"))
							legal = 0;
						if (legal)		/* check badalias.bbs entries */
							{
							strcpy(buffer1,buffer);
							strupr(buffer1);		/* uppercase for strstr() - badaliases already are */
							for (kount = 0; kount < cur_badalias; kount++)
								{
								if (strstr(buffer1,badalias[kount]))
									{
									legal = 0;
									break;
									}
								}
							}

						if (legal)		/* check that alias is not a user's name or alias */
							{
							kount = 0;
							fseek(userfd,0L,SEEK_SET);
							while (fread(&tuser,sizeof(struct user),1,userfd))
								{
								if (kount != user_number)
									{
									if (!stricmp(tuser.user_name,buffer))
										legal = 0;
									else if (!stricmp(tuser.user_alias[0],buffer))
										legal = 0;
									else if (!stricmp(tuser.user_alias[1],buffer))
										legal = 0;
									else if (!stricmp(tuser.user_alias[2],buffer))
										legal = 0;
									else if (!stricmp(tuser.user_alias[3],buffer))
										legal = 0;

									if (!legal)
										break;
									}
								++kount;
								}
							}

						send_string("\r\n",NULL);

						if (legal)
							{
							if (user.user_alias[count][0])
								log_entry(L_CHANGEALIAS,user.user_alias[count]);
							log_entry(L_NEWALIAS,buffer);
							strcpy(user.user_alias[count],buffer);
							change = 1;
							send_string("\r\nAlias has been changed.\r\n",NULL);
							}
						else
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("\r\nThe requested alias is not permitted on this system.  Try another.\r\n",NULL);
							log_entry(L_INVALIDALIAS,buffer);
							}
						}
					else if (user.user_alias[count][0])
						{
						send_string("\r\nDo you want to DELETE this alias (y/N)? ",NULL);
						if (get_yn_enter(0))
							{
							log_entry(L_CHANGEALIAS,user.user_alias[count]);
							log_entry(L_DELETEALIAS,NULL);
							user.user_alias[count][0] = (char)'\0';
							change = 1;
							}
						}
					ok = 1;
					break;

				case 'X':
				case 'x':
				case '\r':
				case '\n':
					quit = 1;
					ok = 1;
					break;
				}
			}
		while (!ok);
		}
	while (!quit);

	if (change)
		{
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		}
	}



void wait_key(int secs)
	{
	int total = secs * 20;		/* number of 50 msec intervals */
	int count;

	purge_input(cfg.cfg_port);
	while (get_kb())
		;
	count = 0;
	while (count < total)
		{
		if (user_baud)
			{
			if (recv_char(0) != -1)
				break;
			if (!cd)
				longjmp(reset_bbs,1);
			}
		if (get_kb())
			break;
		sleep(45);		/* 45 instead of 50 makes up for slight latency in sleep() */
		++count;
		}
	}



void show_usage(void)
	{
	char buffer[21];
	char *cptr;
	int temp;
	long cur_time = projected_time(0L);

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	send_string("Your Usage Statistics:\r\n",NULL);
	send_string("---------------------\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("First call to this system ......... ",NULL);
	temp = ((user.user_firstdate >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"%2u %s %02u",user.user_firstdate & 0x1f,months_table[temp],((user.user_firstdate >> 9) + 80) % 100);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\nLast call to this system .......... ",NULL);
	temp = ((user_lastdate >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"%2u %s %02u at %02u:%02u",user_lastdate & 0x1f,months_table[temp],((user_lastdate >> 9) + 80) % 100,
		user_lasttime >> 11,(user_lasttime >> 5) & 0x3f);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\n\r\nTotal time available today ........ ",NULL);
	sprintf(buffer,"%4u min 00 sec",logon_times[(int)user.user_priv]);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nTime used prior to this call ...... ",NULL);
	sprintf(buffer,"%4u min 00 sec",user.user_timeused);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nTime used during this call ........ ",NULL);
	sprintf(buffer,"%4lu min %02lu sec",(cur_time - login_time) / 60L,(cur_time - login_time) % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nTime remaining for this call ...... ",NULL);
	sprintf(buffer,"%4lu min %02lu sec",user_time / 60L,user_time % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(buffer,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n\r\nTotal number of files uploaded .... ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	cptr = parse_long((long)user.user_upload);
	send_string(cptr,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\nTotal number of bytes uploaded .... ",NULL); 
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	cptr = parse_long(user.user_uploadbytes);
	send_string(cptr,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\nTotal number of files downloaded .. ",NULL); 
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	cptr = parse_long((long)user.user_dnload);
	send_string(cptr,NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\nTotal number of bytes downloaded .. ",NULL); 
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	cptr = parse_long(user.user_dnloadbytes);
	send_string(cptr,NULL);
	send_string("\r\n\r\n",NULL);

	get_enter();
	}



void search_userlist(void)
	{
	char buffer[41];
	char buffer1[85];
	char *cptr;
	struct user tuser;
	int key;
	int found = 0;
	int temp;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\n",NULL);
	send_string("Search for User (ENTER=All)? ",NULL);
	get_field(buffer,40,2);
	if (buffer[0])
		bm_setup(buffer,1);
	cur_line = 0;
	more_flag = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nUser's Name                              Calling From         Last On   Calls\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("---------------------------------------- -------------------- --------- -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN),NULL);
	fseek(userfd,0L,SEEK_SET);
	while (fread(&tuser,1,sizeof(struct user),userfd))
		{
		if (!(tuser.user_flags & USER_DELETED))
			{
			if (!buffer[0] || bm_search(tuser.user_name) != -1)
				{
				++found;
				if (stricmp(tuser.user_name,user.user_name))
					{
					temp = ((tuser.user_lastdate >> 5) & 0xf) - 1;
					if (temp && (temp >= 12 || temp < 0))
						temp = 11;
					sprintf(buffer1,"%-40.40s %-20.20s %2u %s %02u %5d\r\n",tuser.user_name,tuser.user_city,tuser.user_lastdate & 0x1f,months_table[temp],((tuser.user_lastdate >> 9) + 80) % 100,tuser.user_calls);
					}
				else
					{
					temp = ((user_lastdate >> 5) & 0xf) - 1;
					if (temp && (temp >= 12 || temp < 0))
						temp = 11;
					sprintf(buffer1,"%-40.40s %-20.20s %2u %s %02u %5d\r\n",tuser.user_name,tuser.user_city,user_lastdate & 0x1f,months_table[temp],((user_lastdate >> 9) + 80) % 100,tuser.user_calls);
					}
				send_string(buffer1,NULL);

				if (more_flag)
					return;

				key = 0;
				if (user_baud)
					{
					if (peek_input(cfg.cfg_port) != -1)
						key = read_input(cfg.cfg_port);
					else 
						key = get_kb();
					}
				else
					key = get_kb();

				switch (key)
					{
					case 'S':
					case 's':
						return;
						break;
					case 'P':
					case 'p':
						if (dopause())
							return;
						break;
					}
				}
			}
		}
	if (found)
		{
		cptr = parse_long((long)found);
		sprintf(buffer1,"\r\nEnd of list:  %s user%s found\r\n",cptr,found == 1 ? "" : "s");
		}
	else
		sprintf(buffer1,"\r\nNo users found\r\n");
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string(buffer1,NULL);
	get_enter();
	}



void show_clock(void)
	{
	char buffer[35];
	int temp;
#ifdef PROTECTED
	DATETIME dt;
#elif defined(__ZTC__)				/* Zortech version of date functions */
	struct dos_time_t time;
	struct dos_date_t date;
#else
	struct dostime_t time;
	struct dosdate_t date;
#endif
	int key;
	int sent_warning = 0;
	int save_color;
	long tlong;
	
	cur_line = 0;
	set_inactivetime();

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	send_string("The Current Time on this BBS:\r\n",NULL);
	send_string("----------------------------\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("Press ENTER when you are finished....\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);

	while (1)
		{
#ifdef PROTECTED
		DosGetDateTime(&dt);
		temp = dt.month - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(buffer,"\rIt is now %2d %s %02d  %2d:%02d:%02d",dt.day,months_table[temp],dt.year % 100,dt.hours,dt.minutes,dt.seconds);
#else
#ifdef __ZTC__
		dos_getdate(&date);
		dos_gettime(&time);
#else
		_dos_getdate(&date);
		_dos_gettime(&time);
#endif
		temp = date.month - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(buffer,"\rIt is now %2d %s %02d  %2d:%02d:%02d",date.day,months_table[temp],date.year % 100,time.hour,time.minute,time.second);
#endif
		send_string(buffer,NULL);

		tlong = projected_time(0L);
		key = 0;
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (key = get_kb())
			set_inactivetime();
		else if (user_baud && peek_input(cfg.cfg_port) != -1)
			{
			key = read_input(cfg.cfg_port);
			set_inactivetime();
			}
		else if (tlong >= inactive_time)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE | BRIGHT | BLINK),NULL);
			send_string("\r\n\r\n\aSorry! Hanging up due to keyboard inactivity timeout!\r\n",NULL);
			hangup();
	 		longjmp(reset_bbs,2);
			}
		else if (!key && !sent_warning && (inactive_time - tlong) < 30L)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				save_color = cur_color;
				send_string(new_color(RED | BRIGHT | BLINK),NULL);
				}
			sent_warning = 1;
			send_string("\r\n\a\aPress a key or you will be disconnected within 30 seconds!!\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(save_color),NULL);
			}
		sleep(100);
		if (key == '\r' || key == '\n')
			break;
		update_clock();
		}
	send_string("\r\n\r\n",NULL);
	}




void duplicate_header(void)
	{
	char buffer[81];

	sprintf(buffer,"The user \"%s\" (#%u) has provided the following\r",user.user_name,user_number + 1);
	if (!load_msg_line(buffer))
		return;
	sprintf(buffer,"phone numbers:\r\r");
	if (!load_msg_line(buffer))
		return;
	sprintf(buffer,"         Home: %s\r",(char *)(user.user_home[0] ? user.user_home : "Unlisted"));
	if (!load_msg_line(buffer))
		return;
	sprintf(buffer,"    Work/Data: %s\r",(char *)(user.user_data[0] ? user.user_data : "Unlisted"));
	if (!load_msg_line(buffer))
		return;
	sprintf(buffer,"     Password: \"%s\"\r\r",user.user_password);
	if (!load_msg_line(buffer))
		return;
	if (!load_msg_line("The following user(s) had matches:\r\r"))
		return;
	}



void check_duplicates(int area,char *flaglist)
	{
	struct user tuser;
	struct msg *tmsg;
	char *tonames[2];
	char buffer[81];
	char buffer1[21];
	char password[16];
	char home[15];
	char data[15];
	char *cptr;
	char *cptr1;
	int current = 0;
	int new = 1;

	if ((tmsg = get_msgarea(area)) && (tmsg->msg_flags & MSG_LOCAL))
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nPlease wait a moment.  Checking for duplicate phone numbers....\r\n",NULL);

		cptr = user.user_home;
		cptr1 = home;
		while (*cptr)
			{
			if (isdigit(*cptr))
				*cptr1++ = *cptr;
			++cptr;
			}
		*cptr1 = (char)'\0';

		cptr = user.user_data;
		cptr1 = data;
		while (*cptr)
			{
			if (isdigit(*cptr))
				*cptr1++ = *cptr;
			++cptr;
			}
		*cptr1 = (char)'\0';

		strcpy(password,user.user_password);

		fseek(userfd,0L,SEEK_SET);
		while (fread(&tuser,sizeof(struct user),1,userfd))
			{
			if (user_number != current)
				{
				cptr = tuser.user_home;
				cptr1 = buffer1;
				while (*cptr)
					{
					if (isdigit(*cptr))
						*cptr1++ = *cptr;
					++cptr;
					}
				*cptr1 = (char)'\0';

				if (home[0] && !stricmp(home,buffer1))
					{
					if (new)
						{
						duplicate_header();
						new = 0;
						}

					sprintf(buffer,"  %4u)  %s%s's HOME number matched user's home\r",current + 1,(char *)(tuser.user_flags & USER_DELETED ? "Deleted User " : ""),tuser.user_name);
					if (!load_msg_line(buffer))
						return;
					}

				if (data[0] && !stricmp(data,buffer1))
					{
					if (new)
						{
						duplicate_header();
						new = 0;
						}

					sprintf(buffer,"  %4u)  %s%s's HOME number matched user's work/data\r",current + 1,(char *)(tuser.user_flags & USER_DELETED ? "Deleted User " : ""),tuser.user_name);
					if (!load_msg_line(buffer))
						return;
					}

				cptr = tuser.user_data;
				cptr1 = buffer1;
				while (*cptr)
					{
					if (isdigit(*cptr))
						*cptr1++ = *cptr;
					++cptr;
					}
				*cptr1 = (char)'\0';

				if (home[0] && !stricmp(home,buffer1))
					{
					if (new)
						{
						duplicate_header();
						new = 0;
						}

					sprintf(buffer,"  %4u)  %s%s's DATA number matched user's home\r",current + 1,(char *)(tuser.user_flags & USER_DELETED ? "Deleted User " : ""),tuser.user_name);
					if (!load_msg_line(buffer))
						return;
					}

				if (data[0] && !stricmp(data,buffer1))
					{
					if (new)
						{
						duplicate_header();
						new = 0;
						}

					sprintf(buffer,"  %4u)  %s%s's DATA number matched user's work/data\r",current + 1,(char *)(tuser.user_flags & USER_DELETED ? "Deleted User " : ""),tuser.user_name);
					if (!load_msg_line(buffer))
						return;
					}

				if (password[0] && !stricmp(password,tuser.user_password))
					{
					if (new)
						{
						duplicate_header();
						new = 0;
						}

					sprintf(buffer,"  %4u)  %s%s's PASSWORD matched user's password\r",current + 1,(char *)(tuser.user_flags & USER_DELETED ? "Deleted User " : ""),tuser.user_name,password,tuser.user_password);
					if (!load_msg_line(buffer))
						return;
					}
				}

			if (!(current % 25))
				{
				sprintf(buffer,"%u\r",current);
				send_string(buffer,NULL);
				}
			++current;
			}

		send_string("Finished!\r\n",NULL);

		if (!new)
			{
			tonames[0] = cfg.cfg_sysopname;
			tonames[1] = NULL;
			do_message("Simplex Duplicate Checker",tonames,"Duplicate report",area,0xff,0xffff,0,MESSAGE_PRIVATE | MESSAGE_LOADED,0,0,0,0,0);

			cptr = flaglist;		/* get uppercase flags to add */
			cptr1 = buffer;
			while (*cptr)
				{
				if (isupper(*cptr))
					*cptr1++ = *cptr;
				++cptr;
				}
			*cptr1 = (char)'\0';
			if (buffer[0])
				add_flags(buffer);

			cptr = flaglist;		/* get lowercase flags to kill */
			cptr1 = buffer;
			while (*cptr)
				{
				if (islower(*cptr))
					*cptr1++ = *cptr;
				++cptr;
				}
			*cptr1 = (char)'\0';
			if (buffer[0])
				del_flags(buffer);
			}
		}
	else
		{
		sprintf(buffer,"Message area %u is not a valid message area or is not local only!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		}
	}
