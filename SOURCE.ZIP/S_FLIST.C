/* s_flist.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 16 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_flist.c_v  $
**                       $Date:   25 Oct 1992 14:08:04  $
**                       $Revision:   1.24  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <ctype.h>
#include <io.h>
#include "simplex.h"



#define MISSING					-1L
#define INVALID					-2L
#define MARGIN					33
#define MAXLINE					78

#define MAX_RETRIES				15

#define BUFSIZE					120


struct f
	{
	char *f_name;
	int f_date;
	int f_time;
	long f_size;
	};


static struct f **filenames = NULL;
static int cur_filenames = 0;
static int max_filenames = 0;
static int stop_flag = 0;

char filepath[100];


extern jmp_buf reset_bbs;



FILE *open_filelist_read(char *path)
	{
	int count;
	FILE *fd = NULL;

	if (!access(path,0))
		{
		for (count = 0; count < MAX_RETRIES; count++)
			{
			if (fd = fopen(path,"rb"))
				break;

			sleep(50);			/* take a nap */
			}
		}
	return fd;
	}



FILE *open_filelist_write(char *path)
	{
	int count;
	FILE *fd = NULL;

	if (!access(path,0))
		{
		for (count = 0; count < MAX_RETRIES; count++)
			{
			if (fd = fopen(path,"r+b"))
				break;

			sleep(50);			/* take a nap */
			}
		}
	else
		fd = fopen(path,"w+b");

	return fd;
	}



int check_fnames(char *pattern,char *string)
	{
	int rtn = 1;
	int match = 0;
	char *cptr;
	char *cptr1;

	cptr = pattern;
	cptr1 = string;
	while (*cptr && *cptr1)
		{
		if (*cptr == '*')
			{
			while (*(cptr + 1) == '*')	/* in case someone puts more than one together! */
				++cptr;

			if (!*(cptr + 1))		/* we match from here on, so it is successful! */
				break;
			else
				{
				++cptr;
				do
					{
					while (*cptr1 && toupper(*cptr) != toupper(*cptr1))
						++cptr1;
					if (*cptr1)
						match = check_fnames(++cptr,++cptr1);
					}
				while (*cptr1 && !match);
				}
			}
		else if (*cptr == '?')
			{
			++cptr;
			++cptr1;
			}
		else if (toupper(*cptr) != toupper(*cptr1))
			{
			rtn = 0;
			break;
			}
		else
			{
			++cptr;
			++cptr1;
			}
		}
	if (!match && ((!*cptr && *cptr1) || (*cptr && !*cptr1)))
		rtn = 0;
	return rtn;
	}



void show_fileline(struct fe *tfe,long size,int date,int show_uploader)
	{
	char buffer[100];
	char *cptr;
	char *cptr1;
	int count;
	int first = 1;
	int line = 0;
	int new = 0;
	int len;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		send_string(new_color(BROWN | BRIGHT),NULL);
		if (more_flag)
			stop_flag = 1;
		}

	strupr(tfe->fe_name);
	sprintf(buffer,"%-12.12s ",tfe->fe_name);
	send_string(buffer,NULL);
	if (more_flag)
		stop_flag = 1;

	if (tfe->fe_uldate >= (unsigned int)user_lastdate)
		new |= 1;
	if ((unsigned int)date >= (unsigned int)user_lastdate)
		new |= 2;

	if (size == MISSING)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(RED | BRIGHT),NULL);
			if (more_flag)
				stop_flag = 1;
			}
		send_string("-Offline-           ",NULL);
		if (more_flag)
			stop_flag = 1;
		}
	else if (size == INVALID)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(RED | BRIGHT),NULL);
			if (more_flag)
				stop_flag = 1;
			}
		send_string("-Invalid Area-      ",NULL);
		if (more_flag)
			stop_flag = 1;
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			if (new)
				send_string(new_color(MAGENTA | BRIGHT),NULL);
			else 
				send_string(new_color(MAGENTA),NULL);
			if (more_flag)
				stop_flag = 1;
			}
		sprintf(buffer,"%9lu ",size);
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			if (new)
				send_string(new_color(GREEN | BRIGHT),NULL);
			else 
				send_string(new_color(GREEN),NULL);
			if (more_flag)
				stop_flag = 1;
			}
		sprintf(buffer,"%02u-%02u-%02u%s ",((unsigned int)date >> 5) & 0xf,date & 0x1f,((((unsigned int)date >> 9) & 0x7f) + 80) % 100,(char *)((new & 2) ? "*" : " "));
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;
		}

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		if (new)
			send_string(new_color(CYAN | BRIGHT),NULL);
		else
			send_string(new_color(CYAN),NULL);
		if (more_flag)
			stop_flag = 1;
		}

	if (tfe->fe_descrip[0])
		{
		cptr = tfe->fe_descrip;

		if (!*cptr)
			{
			send_string("\r\n",NULL);
			if (more_flag)
				stop_flag = 1;
			}
		else
			{
			while (*cptr && !stop_flag)
				{
				if (first)		/* first line of description */
					{
					sprintf(buffer,"[%u] ",tfe->fe_dl);
					cptr1 = buffer + strlen(buffer);;
					len = strlen(buffer);
					first = 0;
					}
				else
					{
					cptr1 = buffer;
					len = 0;
					}

				while (*cptr && len < MAXLINE - MARGIN)
					{
					*cptr1++ = *cptr++;
					++len;
					}

				if (len >= MAXLINE - MARGIN)
					{
					while (len && *cptr != ' ')
						{
						--cptr;
						--len;
						}

					if (len >= ((MAXLINE - MARGIN) / 2))
						cptr1 = buffer + len;
					else
						cptr += len;
					}

				*cptr1 = '\0';

				if ((cptr1 - buffer) != 0)
					{
					if (line)
						{
						for (count = 0; count < MARGIN; count++)
							{
							send_string(" ",NULL);
							if (more_flag)
								stop_flag = 1;
							}
						}
					++line;
					send_string(buffer,NULL);
					if (more_flag)
						stop_flag = 1;
					send_string("\r\n",NULL);
					if (more_flag)
						stop_flag = 1;
					}

				if (!line)
					{
					send_string("\r\n",NULL);
					if (more_flag)
						stop_flag = 1;
					}

				while (*cptr && *cptr == ' ')
					++cptr;
				}
			}
		}
	else
		{
		sprintf(buffer,"[%u] Description was NOT provided.\r\n",tfe->fe_dl);
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;
		}

	/* finally show the uploader information */
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		if (new)
			send_string(new_color(RED | BRIGHT),NULL);
		else 
			send_string(new_color(RED),NULL);
		if (more_flag)
			stop_flag = 1;
		}
	if (show_uploader)
		{
		sprintf(buffer,"U/L: %02u-%02u-%02u%s By: %s\r\n",(tfe->fe_uldate >> 5) & 0xf,tfe->fe_uldate & 0x1f,(((tfe->fe_uldate >> 9) & 0x7f) + 80) % 100,
			(char *)((new & 1) ? "*" : " "),(char *)(tfe->fe_uploader[0] ? tfe->fe_uploader : "Unknown"));
		for (count = 0; count < (MARGIN - 15); count++)
			{
			send_string(" ",NULL);
			if (more_flag)
				stop_flag = 1;
			}

		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;
		}
	}



void list_filearea(int area,int order,int show_uploader)
	{
	struct file *tfile;
	struct file *tfile1;
	struct fe tfe;
	struct fi tfi;
	char buffer[BUFSIZE];
	int total;
	int current;
	int valid;
	int quit = 0;
	int end = 0;
	int key;
	FILE *fd;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}


	if (tfile->file_descname[0])				/* load and show the file header */
		strcpy(buffer,tfile->file_descname);
	else 
		strcpy(buffer,tfile->file_pathname);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,"filehead.bbs");

	purge_input(cfg.cfg_port);

	cur_line = 0;
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	cur_line = 0;

	if (fd = openf(buffer,"rb"))
		{
	  	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	  		send_string(new_color(WHITE | BRIGHT),NULL);

		while (fgets(buffer,sizeof(buffer),fd))
			send_string(buffer,NULL);
		send_string("\r\n",NULL);

		closef(fd);
		}

	strcpy(filepath,tfile->file_pathname);
	if (filepath[0])
		{
		if (filepath[strlen(filepath) - 1] != P_CSEP)
			strcat(filepath,P_SSEP);
		}

	if (tfile->file_descname[0])
		strcpy(buffer,tfile->file_descname);
	else 
		strcpy(buffer,tfile->file_pathname);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,"filelist.bbs");

	cur_line = 0;
	if (fd = open_filelist_read(buffer))		/* now open the list file itself */
		{
		total = (int)(filelength(fileno(fd)) / (long)sizeof(struct fe));
		if (order)		/* reverse order */
			current = total - 1;
		else
			current = 0;

		fseek(fd,(long)current * (long)sizeof(struct fe),SEEK_SET);
		if (!fread(&tfe,sizeof(struct fe),1,fd))
			end = 1;

		stop_flag = 0;
		while (!quit && !end)
			{
			if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
				{
#if 0
				/* check if group changed */
	  			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	  				send_string(new_color(WHITE | BRIGHT),NULL);
#endif

				valid = 1;
				if (tfe.fe_location == area)
					strcpy(buffer,filepath);
				else if (tfile1 = get_filearea(tfe.fe_location))
					{
					strcpy(buffer,tfile1->file_pathname);
					if (buffer[0])
						{
						if (buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						}
					}
				else
					valid = 0;

				if (valid)
					{
					strcat(buffer,tfe.fe_name);

					if (get_firstfile(&tfi,buffer))
						show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
					else 
						show_fileline(&tfe,MISSING,0,show_uploader);
					}
				else 
					show_fileline(&tfe,INVALID,0,show_uploader);
				get_closefile();
				}

			if (stop_flag)
				quit = 1;
			else
				{
				update_clock();
				key = '\0';
				if (user_baud && !cd)
					longjmp(reset_bbs,1);
				if (user_baud && peek_input(cfg.cfg_port) != -1)
					key = read_input(cfg.cfg_port);
				else
					key = get_kb();
				switch (key)
					{
					case 'S':
					case 's':
						quit = 1;
						break;
					case 'P':
					case 'p':
						if (dopause())
							quit = 1;
						break;
					}
				}

			if (order)
				{
				--current;
				if (current < 0)
					end = 1;
				}
			else
				{
				++current;
				if (current >= total)
					end = 1;
				}
			if (!end)
				{
				fseek(fd,(long)current * (long)sizeof(struct fe),SEEK_SET);
				if (!fread(&tfe,sizeof(struct fe),1,fd))
					end = 1;
				}
			}

		closef(fd);

		if (!quit)
			get_enter();
		}
	else
		{
		sprintf(buffer,"Error: Unable to open filelist.bbs in area %u!  Drive may be invalid or temporarily offline.",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		}
	}



int fname_comp(struct f **arg1,struct f **arg2)
	{
	return(strcmp((*arg1)->f_name,(*arg2)->f_name));
	}



void raw_filearea(int area)
	{
	struct file *tfile;
	struct fi tfi;
	char buffer[100];
	char filespec[13];
	int key;
	int rtn;
	int quit = 0;
	int count;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nRaw directory of what filespec [* and ? ok] (ENTER=None)? ",NULL);
	get_fname(filespec,12,1,0);
	if (filespec[0])
		{
		strcpy(buffer,tfile->file_pathname);
		if (buffer[0])
			{
			if (buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			}
		strcat(buffer,filespec);

		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(WHITE | BRIGHT),NULL);
		send_string("Scanning...",NULL);

		rtn = get_firstfile(&tfi,buffer);
		while (rtn)
			{
			if (tfi.fi_name[0] != '.')
				{
				if (cur_filenames >= max_filenames)
					{
					if (!(filenames = realloc(filenames,(max_filenames += 50) * sizeof(struct f *))))
						{
				 		system_message("Out of memory to allocate filename structures!");
						filenames = NULL;
						cur_filenames = 0;
						max_filenames = 0;
						get_closefile();
						return;
						}
					}
				if (!(filenames[cur_filenames] = calloc(1,sizeof(struct f))))
					{
					system_message("Out of memory to allocate filename structures!");
					filenames = NULL;
					cur_filenames = 0;
					max_filenames = 0;
					get_closefile();
					return;
					}
				if (!(filenames[cur_filenames]->f_name = calloc(strlen(tfi.fi_name) + 1,sizeof(char))))
					{
					system_message("Out of memory to allocate filename structures!");
					filenames = NULL;
					cur_filenames = 0;
					max_filenames = 0;
					get_closefile();
					return;
					}
				strcpy(filenames[cur_filenames]->f_name,tfi.fi_name);

				filenames[cur_filenames]->f_size = tfi.fi_size;
				filenames[cur_filenames]->f_date = tfi.fi_date;
				filenames[cur_filenames]->f_time = tfi.fi_time;
				++cur_filenames;
				}
			rtn = get_nextfile(&tfi);
			}
		get_closefile();

		send_string("\r            \r\n",NULL);		/* removes the "Scanning..." message */
		cur_line = 0;
		if (cur_filenames)
			{
			qsort(filenames,cur_filenames,sizeof(struct f *),fname_comp);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Raw directory of \"",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN | BRIGHT),NULL);
			send_string(tfile->file_areaname,NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\"\r\n\r\n",NULL);
			stop_flag = 0;
			for (count = 0; count < cur_filenames && !quit; count += 2)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					{
					send_string(new_color(BROWN | BRIGHT),NULL);
					if (more_flag)
						stop_flag = 1;
					}
				sprintf(buffer,"%-12.12s ",filenames[count]->f_name);
				send_string(buffer,NULL);
				if (more_flag)
					stop_flag = 1;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(MAGENTA),NULL);
				sprintf(buffer,"%8lu ",filenames[count]->f_size);
				send_string(buffer,NULL);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN),NULL);
				sprintf(buffer,"%2u-%02u-%02u  ",((unsigned int)filenames[count]->f_date >> 5) & 0xf,filenames[count]->f_date & 0x1f,((((unsigned int)filenames[count]->f_date >> 9) & 0x7f) + 80) % 100);
				send_string(buffer,NULL);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(CYAN),NULL);
				sprintf(buffer,"%2u:%02u  ",(unsigned int)filenames[count]->f_time >> 11,((unsigned int)filenames[count]->f_time >> 5) & 0x3f);
				send_string(buffer,NULL);
				if ((count + 1) < cur_filenames)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(WHITE),NULL);
					send_string("� ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					sprintf(buffer,"%-12.12s ",filenames[count + 1]->f_name);
					send_string(buffer,NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(MAGENTA),NULL);
					sprintf(buffer,"%9lu ",filenames[count + 1]->f_size);
					send_string(buffer,NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN),NULL);
					sprintf(buffer,"%2u-%02u-%02u  ",((unsigned int)filenames[count + 1]->f_date >> 5) & 0xf,filenames[count + 1]->f_date & 0x1f,((((unsigned int)filenames[count + 1]->f_date >> 9) & 0x7f) + 80) % 100);
					send_string(buffer,NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN),NULL);
					sprintf(buffer,"%2u:%02u",(unsigned int)filenames[count + 1]->f_time >> 11,((unsigned int)filenames[count + 1]->f_time >> 5) & 0x3f);
					send_string(buffer,NULL);
					}
				send_string("\r\n",NULL);
				if (more_flag)
					stop_flag = 1;

				if (stop_flag)
					quit = 1;
				else
					{
					update_clock();
					key = '\0';
					if (user_baud && !cd)
						longjmp(reset_bbs,1);
					if (user_baud && peek_input(cfg.cfg_port) != -1)
						key = read_input(cfg.cfg_port);
					else
						key = get_kb();
					switch (key)
						{
						case 'S':
						case 's':
							quit = 1;
							break;
						case 'P':
						case 'p':
							if (dopause())
								quit = 1;
							break;
						}
					}
				}
			for (count = 0; count < cur_filenames; count++)
				{
				free(filenames[count]->f_name);
				free(filenames[count]);
				}
			free(filenames);
			filenames = NULL;
			cur_filenames = 0;
			max_filenames = 0;
			if (!quit)
				get_enter();
			}
		else
			system_message("Sorry: No files matching your pattern found in this area!");
		}
	}



void list_newfiles(int area,int show_uploader)
	{
	struct file *tfile;
	struct file *tfile1;
	struct fe tfe;
	struct fi tfi;
	char buffer[BUFSIZE];
	char buffer1[81];
	int date = 0;
	int key;
	int count;
	int kount;
	int lfflag;
	int color;
	int hicolor;
	int valid;
	int ok = 0;
	int quit = 0;
	int skip;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nDo you want to see new files since you last logged on (ENTER=Yes)? ",NULL);
	if (get_yn_enter(1))
		{
		ok = 1;
		date = user_lastdate;
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nSearch for files since what date [MM-DD-YY] (ENTER=Quit)? ",NULL);
		get_date(buffer);
		if (ok = check_date(buffer))
			date = convert_date(buffer);
		}
	if (ok)
		{
		if (area)
			{
			send_string("Do you want to search across all file areas (Y/n)? ",NULL);
			if (get_yn_enter(1))
				area = 0;
			}

		if (!area)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file areas: Press S to stop, N for next area, or P for pause.\r\n",NULL);

			stop_flag = 0;
			for (count = get_minfilearea(); count <= get_maxfilearea() && !quit; count++)
				{
				if (tfile = get_filearea(count))
					{
					if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
						{
						if (tfile->file_descname[0])
							strcpy(buffer,tfile->file_descname);
						else 
							strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,"filelist.bbs");

						strcpy(filepath,tfile->file_pathname);
						if (filepath[0])
							{
							if (filepath[strlen(filepath) - 1] != P_CSEP)
								strcat(filepath,P_SSEP);
							}

						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							{
							color = count & 0x7;
							color = color ? color : 7;
							hicolor = color | 0x8;
							send_string(new_color(color),NULL);
							if (more_flag)
								stop_flag = 1;
							}

						send_string("Area: ",NULL);
						if (more_flag)
							stop_flag = 1;
						strcpy(buffer1,tfile->file_areaname);
						for (kount = (int)strlen(buffer1); kount < 40; kount++)
							strcat(buffer1," ");
						strcat(buffer1,"\r");
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(hicolor),NULL);
					    send_string(buffer1,NULL);
						lfflag = 0;

						if (fd = open_filelist_read(buffer))		/* now open the list file itself */
							{
							purge_input(cfg.cfg_port);

							skip = 0;
							while (!quit && !skip && fread(&tfe,sizeof(struct fe),1,fd))
								{
								if ((unsigned int)tfe.fe_uldate >= (unsigned int)date)
									{
									if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
										{
										valid = 1;
										if (tfe.fe_location == count)
											strcpy(buffer,filepath);
										else if (tfile1 = get_filearea(tfe.fe_location))
											{
											strcpy(buffer,tfile1->file_pathname);
											if (buffer[0])
												{
												if (buffer[strlen(buffer) - 1] != P_CSEP)
													strcat(buffer,P_SSEP);
												}
											}
										else
											valid = 0;

										if (valid)
											{
											strcat(buffer,tfe.fe_name);
											if (get_firstfile(&tfi,buffer))
												{
												if (!lfflag)
													{
													send_string("\n",NULL);
													if (more_flag)
														stop_flag = 1;
													lfflag = 1;
													}
												show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
												}
											}
										get_closefile();
										}
									}

								if (stop_flag)
									quit = 1;
								else
									{
									update_clock();
									key = '\0';
									if (user_baud && !cd)
										longjmp(reset_bbs,1);
									if (user_baud && peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else
										key = get_kb();
									switch (key)
										{
										case 'S':
										case 's':
											quit = 1;
											break;
										case 'N':
										case 'n':
											skip = 1;
											break;
										case 'P':
										case 'p':
											if (dopause())
												quit = 1;
											break;
										}
									}
								}
							if (lfflag)
								send_string("\n",NULL);
							closef(fd);
							}
						}
					}
				}
			}
		else
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file area: Press S to stop, N for next area, or P for pause.\r\n",NULL);

			if (tfile = get_filearea(area))
				{
				if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
					{
					if (tfile->file_descname[0])
						strcpy(buffer,tfile->file_descname);
					else 
						strcpy(buffer,tfile->file_pathname);
					if (buffer[0])
						{
						if (buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						}
					strcat(buffer,"filelist.bbs");

					strcpy(filepath,tfile->file_pathname);
					if (filepath[0])
						{
						if (filepath[strlen(filepath) - 1] != P_CSEP)
							strcat(filepath,P_SSEP);
						}

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("Area: ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string(tfile->file_areaname,NULL);
					send_string("\r\n",NULL);

					if (fd = open_filelist_read(buffer))		/* now open the list file itself */
						{
						purge_input(cfg.cfg_port);

						while (!quit && fread(&tfe,sizeof(struct fe),1,fd))
							{
							if ((unsigned int)tfe.fe_uldate >= (unsigned int)date)
								{
								if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
									{
									valid = 1;
									if (tfe.fe_location == area)
										strcpy(buffer,filepath);
									else if (tfile1 = get_filearea(tfe.fe_location))
										{
										strcpy(buffer,tfile1->file_pathname);
										if (buffer[0])
											{
											if (buffer[strlen(buffer) - 1] != P_CSEP)
												strcat(buffer,P_SSEP);
											}
										}
									else
										valid = 0;
									if (valid)
										{
										strcat(buffer,tfe.fe_name);

										if (get_firstfile(&tfi,buffer))
											show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
										get_closefile();
										}
									}
								}
							if (stop_flag)
								quit = 1;
							else
								{
								update_clock();
								key = '\0';
								if (user_baud && !cd)
									longjmp(reset_bbs,1);
								if (user_baud && peek_input(cfg.cfg_port) != -1)
									key = read_input(cfg.cfg_port);
								else
									key = get_kb();
								switch (key)
									{
									case 'S':
									case 's':
										quit = 1;
										break;
									case 'P':
									case 'p':
										if (dopause())
											quit = 1;
										break;
									}
								}
							}
						closef(fd);
						}
					}
				}
			}
		if (lfflag)
			send_string("\n",NULL);
		else if (!area)
			{
			buffer1[0] = '\0';
			for (kount = 0; kount < 46; kount++)
				strcat(buffer1," ");
			strcat(buffer1,"\r");
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE),NULL);
			send_string(buffer1,NULL);
			}
		if (!quit)
			get_enter();
		}
	else if (buffer[0])
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("An invalid date was entered!\r\n",NULL);
		get_enter();
		}
	}



void search_filename(int area,int show_uploader)
	{
	struct file *tfile;
	struct file *tfile1;
	struct fe tfe;
	struct fi tfi;
	char buffer[BUFSIZE];
	char buffer1[81];
	char fname[13];
	int count;
	int kount;
	int lfflag;
	int color;
	int hicolor;
	int valid;
	int quit = 0;
	int skip;
	int key;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nSearch for what filename [* and ? are ok] (ENTER=Quit)? ",NULL);
	get_fname(fname,12,1,0);
	if (fname[0])
		{
		if (area)
			{
			send_string("Do you want to search across all file areas (Y/n)? ",NULL);
			if (get_yn_enter(1))
				area = 0;
			}

		if (!area)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file areas: Press S to stop, N for next area, or P for pause.\r\n",NULL);

			stop_flag = 0;
			for (count = get_minfilearea(); count <= get_maxfilearea() && !quit; count++)
				{
				if (tfile = get_filearea(count))
					{
					if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
						{
						if (tfile->file_descname[0])
							strcpy(buffer,tfile->file_descname);
						else 
							strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,"filelist.bbs");

						strcpy(filepath,tfile->file_pathname);
						if (filepath[0])
							{
							if (filepath[strlen(filepath) - 1] != P_CSEP)
								strcat(filepath,P_SSEP);
							}

						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							{
							color = count & 0x7;
							color = color ? color : 7;
							hicolor = color | 0x8;
							send_string(new_color(color),NULL);
							if (more_flag)
								stop_flag = 1;
							}
						send_string("Area: ",NULL);
						if (more_flag)
							stop_flag = 1;
						strcpy(buffer1,tfile->file_areaname);
						for (kount = (int)strlen(buffer1); kount < 40; kount++)
							strcat(buffer1," ");
						strcat(buffer1,"\r");
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(hicolor),NULL);
					    send_string(buffer1,NULL);
						lfflag = 0;

						if (fd = open_filelist_read(buffer))		/* now open the list file itself */
							{
							purge_input(cfg.cfg_port);

							skip = 0;
							while (!quit && !skip && fread(&tfe,sizeof(struct fe),1,fd))
								{
								if (check_fnames(fname,tfe.fe_name))
									{
									if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
										{
									 	if (!lfflag)
									 		{
									 		send_string("\n",NULL);
									 		if (more_flag)
									 			stop_flag = 1;
									 		lfflag = 1;
									 		}

										valid = 1;
										if (tfe.fe_location == count)
											strcpy(buffer,filepath);
										else if (tfile1 = get_filearea(tfe.fe_location))
											{
											strcpy(buffer,tfile1->file_pathname);
											if (buffer[0])
												{
												if (buffer[strlen(buffer) - 1] != P_CSEP)
													strcat(buffer,P_SSEP);
												}
											}
										else
											valid = 0;

										if (valid)
											{
											strcat(buffer,tfe.fe_name);
											if (get_firstfile(&tfi,buffer))
												show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
											else 
												show_fileline(&tfe,MISSING,0,show_uploader);

											get_closefile();
											}
										}
									}

								if (stop_flag)
									quit = 1;
								else 
									{
									update_clock();
									if (user_baud && !cd)
										longjmp(reset_bbs,1);
									key = '\0';
									if (user_baud && peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else
										key = get_kb();
									switch (key)
										{
										case 'S':
										case 's':
											quit = 1;
											break;
										case 'N':
										case 'n':
											skip = 1;
											break;
										case 'P':
										case 'p':
											if (dopause())
												quit = 1;
											break;
										}
									}
								}
							if (lfflag)
								send_string("\n",NULL);
							closef(fd);
							}
						}
					}
				}
			}
		else
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file area: Press S to stop, N for next area, or P for pause.\r\n",NULL);

			if (tfile = get_filearea(area))
				{
				if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
					{
					if (tfile->file_descname[0])
						strcpy(buffer,tfile->file_descname);
					else 
						strcpy(buffer,tfile->file_pathname);
					if (buffer[0])
						{
						if (buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						}
					strcat(buffer,"filelist.bbs");

					strcpy(filepath,tfile->file_pathname);
					if (filepath[0])
						{
						if (filepath[strlen(filepath) - 1] != P_CSEP)
							strcat(filepath,P_SSEP);
						}

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("Area: ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string(tfile->file_areaname,NULL);
					send_string("\r\n",NULL);

					if (fd = open_filelist_read(buffer))		/* now open the list file itself */
						{
						purge_input(cfg.cfg_port);

						while (!quit && fread(&tfe,sizeof(struct fe),1,fd))
							{
							if (check_fnames(fname,tfe.fe_name))
								{
								if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
									{
									valid = 1;
									if (tfe.fe_location == area)
										strcpy(buffer,filepath);
									else if (tfile1 = get_filearea(tfe.fe_location))
										{
										strcpy(buffer,tfile1->file_pathname);
										if (buffer[0])
											{
											if (buffer[strlen(buffer) - 1] != P_CSEP)
												strcat(buffer,P_SSEP);
											}
										}
									else
										valid = 0;

									if (valid)
										{
										strcat(buffer,tfe.fe_name);
										if (get_firstfile(&tfi,buffer))
											show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
										else 
											show_fileline(&tfe,MISSING,0,show_uploader);
										}

									get_closefile();
									}
								}

							if (stop_flag)
								quit = 1;
							else
								{
								update_clock();
								key = '\0';
								if (user_baud && !cd)
									longjmp(reset_bbs,1);
								if (user_baud && peek_input(cfg.cfg_port) != -1)
									key = read_input(cfg.cfg_port);
								else
									key = get_kb();
								switch (key)
									{
									case 'S':
									case 's':
										quit = 1;
										break;
									case 'P':
									case 'p':
										if (dopause())
											quit = 1;
										break;
									}
								}
							}
						closef(fd);
						}
					}
				}
			}
		if (lfflag)
			send_string("\n",NULL);
		else if (!area)
			{
			buffer1[0] = '\0';
			for (kount = 0; kount < 46; kount++)
				strcat(buffer1," ");
			strcat(buffer1,"\r");
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE),NULL);
			send_string(buffer1,NULL);
			}
		if (!quit)
			get_enter();
		}
	}



void search_keyword(int area,int show_uploader)
	{
	struct file *tfile;
	struct file *tfile1;
	struct fe tfe;
	struct fi tfi;
	char buffer[BUFSIZE];
	char buffer1[81];
	char search[21];
	char *cptr;
	int count;
	int kount;
	int lfflag;
	int color;
	int valid;
	int hicolor;
	int quit = 0;
	int skip;
	int key;
	int rtn;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nSearch for what string (ENTER=Quit)? ",NULL);
	get_field(search,20,2);
	if (search[0])
		{
		bm_setup(search,1);
		if (area)
			{
			send_string("Do you want to search across all file areas (Y/n)? ",NULL);
			if (get_yn_enter(1))
				area = 0;
			}

		if (!area)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file areas: Press S to stop, N for next area, or P for pause.\r\n",NULL);

			stop_flag = 0;
			for (count = get_minfilearea(); count <= get_maxfilearea() && !quit; count++)
				{
				if (tfile = get_filearea(count))
					{
					if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
						{
						if (tfile->file_descname[0])
							strcpy(buffer,tfile->file_descname);
						else 
							strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,"filelist.bbs");

						strcpy(filepath,tfile->file_pathname);
						if (filepath[0])
							{
							if (filepath[strlen(filepath) - 1] != P_CSEP)
								strcat(filepath,P_SSEP);
							}

						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							{
							color = count & 0x7;
							color = color ? color : 7;
							hicolor = color | 0x8;
							send_string(new_color(color),NULL);
							if (more_flag)
								stop_flag = 1;
							}
						send_string("Area: ",NULL);
						if (more_flag)
							stop_flag = 1;
						strcpy(buffer1,tfile->file_areaname);
						for (kount = (int)strlen(buffer1); kount < 40; kount++)
							strcat(buffer1," ");
						strcat(buffer1,"\r");
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(hicolor),NULL);
					    send_string(buffer1,NULL);
						lfflag = 0;

						if (fd = open_filelist_read(buffer))		/* now open the list file itself */
							{
							purge_input(cfg.cfg_port);

							skip = 0;
							while (!quit && !skip && fread(&tfe,sizeof(struct fe),1,fd))
								{
								if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
									{
									rtn = bm_search(tfe.fe_descrip);
									if (rtn != -1)
										{
										cptr = tfe.fe_descrip + rtn;
										for (kount = 0; kount < (int)strlen(search); kount++)
											{
											*cptr = (char)toupper(*cptr);
											++cptr;
											}

									 	if (!lfflag)
									 		{
									 		send_string("\n",NULL);
									 		if (more_flag)
									 			stop_flag = 1;
									 		lfflag = 1;
									 		}

										valid = 1;
										if (tfe.fe_location == count)
											strcpy(buffer,filepath);
										else if (tfile1 = get_filearea(tfe.fe_location))
											{
											strcpy(buffer,tfile1->file_pathname);
											if (buffer[0])
												{
												if (buffer[strlen(buffer) - 1] != P_CSEP)
													strcat(buffer,P_SSEP);
												}
											}
										else
											valid = 0;

										if (valid)
											{
											strcat(buffer,tfe.fe_name);
											if (get_firstfile(&tfi,buffer))
												show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
											else 
												show_fileline(&tfe,MISSING,0,show_uploader);

											get_closefile();
											}
										}
									}

								if (stop_flag)
									quit = 1;
								else
									{
									update_clock();
									key = '\0';
									if (user_baud && !cd)
										longjmp(reset_bbs,1);
									if (user_baud && peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else
										key = get_kb();
									switch (key)
										{
										case 'S':
										case 's':
											quit = 1;
											break;
										case 'N':
										case 'n':
											skip = 1;
											break;
										case 'P':
										case 'p':
											if (dopause())
												quit = 1;
											break;
										}
									}
								}
							if (lfflag)
								send_string("\n",NULL);
							closef(fd);
							}
						}
					}
				}
			}
		else
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nScanning file area: Press S to stop, N for next area, or P for pause.\r\n",NULL);
			if (tfile = get_filearea(area))
				{
				if (user.user_priv >= tfile->file_priv && (tfile->file_flags & user.user_uflags) == tfile->file_flags)
					{
					if (tfile->file_descname[0])
						strcpy(buffer,tfile->file_descname);
					else 
						strcpy(buffer,tfile->file_pathname);
					if (buffer[0])
						{
						if (buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						}
					strcat(buffer,"filelist.bbs");

					strcpy(filepath,tfile->file_pathname);
					if (filepath[0])
						{
						if (filepath[strlen(filepath) - 1] != P_CSEP)
							strcat(filepath,P_SSEP);
						}

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("Area: ",NULL);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string(tfile->file_areaname,NULL);
					send_string("\r\n",NULL);

					if (fd = open_filelist_read(buffer))		/* now open the list file itself */
						{
						purge_input(cfg.cfg_port);

						while (!quit && fread(&tfe,sizeof(struct fe),1,fd))
							{
							if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
								{
								rtn = bm_search(tfe.fe_descrip);
								if (rtn != -1)
									{
									cptr = tfe.fe_descrip + rtn;
									for (kount = 0; kount < (int)strlen(search); kount++)
										{
										*cptr = (char)toupper(*cptr);
										++cptr;
										}

									valid = 1;
									if (tfe.fe_location == area)
										strcpy(buffer,filepath);
									else if (tfile1 = get_filearea(tfe.fe_location))
										{
										strcpy(buffer,tfile1->file_pathname);
										if (buffer[0])
											{
											if (buffer[strlen(buffer) - 1] != P_CSEP)
												strcat(buffer,P_SSEP);
											}
										}
									else
										valid = 0;

									if (valid)
										{
										strcat(buffer,tfe.fe_name);
										if (get_firstfile(&tfi,buffer))
											show_fileline(&tfe,tfi.fi_size,tfi.fi_date,show_uploader);
										else 
											show_fileline(&tfe,MISSING,0,show_uploader);

										get_closefile();
										}
									}
								}

							if (stop_flag)
								quit = 1;
							else
								{
								update_clock();
								key = '\0';
								if (user_baud && !cd)
									longjmp(reset_bbs,1);
								if (user_baud && peek_input(cfg.cfg_port) != -1)
									key = read_input(cfg.cfg_port);
								else
									key = get_kb();
								switch (key)
									{
									case 'S':
									case 's':
										quit = 1;
										break;
									case 'P':
									case 'p':
										if (dopause())
											quit = 1;
										break;
									}
								}
							}
						closef(fd);
						}
					}
				}
			}
		if (lfflag)
			send_string("\n",NULL);
		else if (!area)
			{
			buffer1[0] = '\0';
			for (kount = 0; kount < 46; kount++)
				strcat(buffer1," ");
			strcat(buffer1,"\r");
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE),NULL);
			send_string(buffer1,NULL);
			}
		if (!quit)
			get_enter();
		}
	}

								 
