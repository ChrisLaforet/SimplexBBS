/* s_chat.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 5 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_chat.c_v  $
**                       $Date:   25 Oct 1992 14:08:30  $
**                       $Revision:   1.26  $
**
*/


#include <stdio.h>
#include <io.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#define INCL_DOSINFOSEG
	#include <os2.h>
#else
	#include <conio.h>
#endif
#include "simplex.h"



extern jmp_buf reset_bbs;
int yells = 0;
int chat_flag = 0;


void sound_tone(int freq,int duration)
	{
#ifdef PROTECTED
	DosBeep(freq,duration);
#else
	int tval;
	int start;
	int save;

	outp(0x43,0xb6);
	tval = (int)(0x144f38L / (long)freq);
	outp(0x42,tval % 0x100);
	outp(0x42,tval / 0x100);
	start = inp(0x61);
	save = (start &= 0xff);
	start |= 0x3;
	outp(0x61,start);
	sleep(duration);
	outp(0x61,save);
#endif
	}



void chat(void)
	{
	char pathname[270];
	char buffer[100];
	char buf1[2];
	char *cptr;
	DATE_T date;
	TIME_T time;
	int who = 0;
	int quit = 0;
	int save_color;
	int count;
	int len;
	int user_flags = user.user_flags;
	int log = 0;
	int filterbit8 = 0;
	int	local;
	int remote;
	int tchar;
#ifdef PROTECTED
	SEL gsel;
	SEL lsel;
	LINFOSEG *linfoptr;
#endif
	FILE *fd;

#ifdef PROTECTED
	DosGetInfoSeg(&gsel,&lsel);
	linfoptr = MAKEP(lsel,0);
#endif

	nolimit_flag = 1;
	chat_flag = 1;
	start_holdtime();

	if (yells)
		{
		yells = 0;
		show_user();			/* clear CHAT legend */
		}
	log_entry(L_CHAT,NULL);
	user.user_flags &= ~USER_MORE;			/* unset more */
	if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
		save_color = cur_color;
	write_string(new_color(GREEN | BRIGHT));
#ifdef PROTECTED
	write_string("\r\n*** Chat Mode Active: Press [Esc] to exit...Hotkeys and Chime are active! ***\r\n");
#else
	write_string("\r\n*** Chat Mode Active: Press [Esc] to exit...Hotkeys are active! ***\r\n");
#endif
	write_string("*** Press [Ctrl-L] to toggle capture log on/off. ***\r\n");
	write_string("*** Press [Ctrl-F] to toggle 8th-bit filter on/off. ***\r\n");
	if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
		send_string(new_color(WHITE | BRIGHT),NULL);
	else
		write_string(new_color(WHITE | BRIGHT));
	send_string("\r\nWelcome to Chat Mode. Your online time countdown has been suspended.\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
		send_string(new_color(BROWN | BRIGHT),NULL);
	else
		write_string(new_color(BROWN | BRIGHT));
	sprintf(buffer,"\r\nHello there %s!\r\n",user_firstname);
	send_string(buffer,NULL);
	sprintf(buffer,"Your friendly Sysop (%s) is online.  ",cfg.cfg_sysopname[0] ? cfg.cfg_sysopname : "?");
	send_string(buffer,NULL);

	cptr = buffer + strlen(buffer);
	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);

		if (strlen(buffer) >= 77)			/* word wrap */
			{
			--cptr;
			if (isspace(*cptr))
				{
				if (log)
					fprintf(fd,"%s\r\n",buffer);
				send_string("\r\n",NULL);
				cptr = buffer;
				*cptr = '\0';
				}
			else
				{
				while (((cptr - buffer) > 0) && !isspace(*cptr))
					--cptr;
				++cptr;
				if ((len = (int)strlen(cptr)) <= 35)		/* 35 character wrap limit */
					{
					for (count = 0; count < len; count++)
						send_string("\b",NULL);
					for (count = 0; count < len; count++)
						send_string(" ",NULL);
					if (log)
						fprintf(fd,"%.*s\r\n",strlen(buffer) - len,buffer);
					send_string("\r\n",NULL);
					send_string(cptr,NULL);
					memmove(buffer,cptr,len);		/* move the data to the new line */
					cptr = buffer + len;
					*cptr = '\0';
					}
				else
					{
					if (log)
						fprintf(fd,"%s\r\n",buffer);
					send_string("\r\n",NULL);
					cptr = buffer;
					*cptr = '\0';
					}
				}
			}

		if (local = get_kb())
			{
			if (who)
				{
				if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
					send_string(new_color(BROWN | BRIGHT),NULL);
				else
					write_string(new_color(BROWN | BRIGHT));
				who = 0;
				}
			if (local == 0x1b)		/* Esc - highway to the exit zone */
				quit = 1;
			else if (local == '\a')		/* BEL - wake up the other end */
				send_string("\a",NULL);
			else if (local == '\r' || local == '\n')
				{
				if (log)
					fprintf(fd,"%s\r\n",buffer);
				send_string("\r\n",NULL);
				cptr = buffer;
				*cptr = '\0';
				}
			else if (local == '\b' || local == 0x7f)
				{
				send_string("\b \b",NULL);
				if ((cptr - buffer) > 0)
					--cptr;
				*cptr = '\0';
				}
			else if (local == '\x06')		/* Ctrl-F - toggle 8th bit filter on/off*/
				{
				sound_tone(659,200);	/* E-1 */
				filterbit8 = (filterbit8 ? 0 : 1);
				}
			else if (local == '\x0c')		/* Ctrl-L - toggle chat log on/off */
				{
				if (log)
					{
					if (log)
						fprintf(fd,"%s\r\n",buffer);
					fclose(fd);
					sound_tone(659,200);	/* E-1 */
					log = 0;
					}
				else
					{
					sprintf(pathname,"%schat.log",bbspath);
					if (!(fd = fopen(pathname,"r+b")))
						fd = fopen(pathname,"w+b");

					if (fd)
						{
						log = 1;
						sound_tone(1319,200);	/* E */
						sound_tone(659,200);	/* E-1 */
						if (filelength(fileno(fd)))
							{
							fseek(fd,-1L,SEEK_END);
							tchar = fgetc(fd);
							fseek(fd,0L,SEEK_END);
							if (tchar != '\r' && tchar != '\n')
								fprintf(fd,"\r\n");
							}
						date = get_cdate();
						time = get_ctime();

						fprintf(fd,"[-------------------- Chat Log as of %u/%02u/%02u at %u:%02u --------------------]\r\n",date & 0x1f,(date >> 5) & 0xf,((date >> 9) + 80) % 100,
							time >> 11,(time >> 5) & 0x3f);
						fprintf(fd,"Chatting with: %s\r\n\r\n",user.user_name);
						}
					}
				}
			else
				{
				if (local == '\t' || (local >= ' ' && local != 0xff))
					{
					if (local == '\t')
						local = ' ';
					*cptr = (char)local;
					buf1[0] = *cptr;
					buf1[1] = '\0';
					send_string(buf1,NULL);
					++cptr;
					*cptr = '\0';
					}
				}
			}
		else if (peek_input(cfg.cfg_port) != -1)
			{
			remote = read_input(cfg.cfg_port);

			if (filterbit8)
				remote &= 0x7f;

#ifdef PROTECTED
			if (linfoptr->fForeground == 0 && linfoptr->typeProcess == PT_FULLSCREEN)		/* not in foreground AND fullscreen session, then chime varying tones with each character */
				DosBeep(2000 + (remote << 2),5);
#endif

			if (!who)
				{
				if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
					send_string(new_color(CYAN),NULL);
				else
					write_string(new_color(CYAN));
				who = 1;
				}
			if (remote == '\r' || remote == '\n')
				{
				if (log)
					fprintf(fd,"%s\r\n",buffer);
				send_string("\r\n",NULL);
				cptr = buffer;
				*cptr = '\0';
				}
			else if (remote == '\b' || remote == 0x7f)
				{
				send_string("\b \b",NULL);
				if ((cptr - buffer) > 0)
					--cptr;
				*cptr = '\0';
				}
			else if (remote == '\t' || (remote >= ' ' && remote != 0xff))
				{
				if (remote == '\t')
					remote = ' ';
				*cptr = (char)remote;
				buf1[0] = *cptr;
				buf1[1] = '\0';
				send_string(buf1,NULL);
				++cptr;
				*cptr = '\0';
				}
			}
		else
			sleep(50);
		update_clock();
		}
	while (!quit);

	if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
		send_string(new_color(GREEN | BRIGHT),NULL);
	else 
		write_string(new_color(GREEN | BRIGHT));

	if (log)
		{
		if (log)
			fprintf(fd,"%s\r\n",buffer);
		fclose(fd);
		sound_tone(659,200);	/* E-1 */
		write_string("\r\nChat log has been closed.");
		}

	set_inactivetime();
	stop_holdtime();
	chat_flag = 0;
	nolimit_flag = 0;

	send_string("\r\nChat Mode is now finished.  You might need to press ENTER to continue!\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
		{
		cur_color = save_color;
		send_string(new_color(cur_color),NULL);
		}
	else 
		write_string(new_color(WHITE));
	user.user_flags = user_flags;			/* reset more! */
	cur_line = 0;
	}



void yell(int type)			/* if type, ignore time boundaries */
	{
	char reason[51];
	long endtime;
	TIME_T curtime = get_ctime();
	int answer = 0;
	int quit = 0;
	int yell_flag;
	int key;
	int times = 0;

	cur_line = 0;
	if (user_baud)
		{
		if (!type)
			{
			yell_flag = 0;
			if (cfg.cfg_yellstart > cfg.cfg_yellstop)
				{
				if (curtime <= cfg.cfg_yellstop || curtime >= cfg.cfg_yellstart)
					yell_flag = 1;
				}
			else
				{
				if (curtime >= cfg.cfg_yellstart && curtime <= cfg.cfg_yellstop)
					yell_flag = 1;
				}
			}

		if (type || yell_flag)
			{
			if (yells < 0)			/* if previous yells were outside of chat hours */
				yells = 0;

			if (yells >= cfg.cfg_yells)
				{
				send_string("\r\n",NULL);
				send_ansifile(cfg.cfg_screenpath,"toomany",1);
		 		get_enter();
				}
			else
				{
				log_entry(L_YELL,NULL);
				if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\n\r\nWhy do you want to Chat? ",NULL);
				get_field(reason,50,0);
				if (reason[0])
					{
					log_entry(L_YELLREASON,reason);

					write_string(new_color(BROWN | BRIGHT));
					write_string("\r\nUser is Yelling.  Press [C] for chat mode or [Esc] to abort!");
					write_string(new_color(WHITE));
					if ((user.user_flags & USER_ANSI) && user_baud >= cfg.cfg_ansibaud)
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("\r\nYelling for chat with Sysop: ",NULL);

					endtime = projected_time((long)cfg.cfg_yelltime);
					do
						{
						if (user_baud && !cd)
							longjmp(reset_bbs,1);
						send_string(".",NULL);

						if (!type)
							{
							/* Star Trek: The New Generation theme - Copyright Paramount */
							switch (times % 5)
								{
								case 0:
									sound_tone(659,400);	/* E-1 */
									sound_tone(880,100);	/* A */
									sound_tone(1109,100);	/* C# */
									sound_tone(988,400);	/* B */
									break;
								case 1:
									sound_tone(784,100);	/* G-1 */
									sound_tone(1480,100);	/* F# */
									sound_tone(1319,600);	/* E */
									sleep(200);
									break;
								case 2:
									sound_tone(1175,100);	/* D */
									sound_tone(1319,100);	/* E */
									sound_tone(1480,100);	/* F# */
									sound_tone(1175,100);	/* D */
									sound_tone(1319,300);	/* E */
									break;
								case 3:
									sound_tone(1175,300);	/* D */
									sound_tone(1109,300);	/* C# */
									break;
								case 4:
									sleep(50);
									sound_tone(1109,100);	/* C# */
									sound_tone(880,100);	/* A */
									sound_tone(1109,100);	/* C# */
									sound_tone(988,400);	/* B */
									sleep(200);
									break;
								}
							}
						else
							{
							/* Star Wars theme - Copyright Lucasfilms et al */
							switch (times % 6)
								{
								case 0:
									sound_tone(587,600);	/* D-1 */
									sound_tone(880,500);	/* A */
									sleep(100);
									break;
								case 1:
								case 3:
									sound_tone(784,100);	/* G-1 */
									sound_tone(740,100);	/* F#-1 */
									sound_tone(659,200);	/* E-1 */
									break;
								case 2:
								case 4:
									sound_tone(1175,400);	/* D */
									sound_tone(880,500);	/* A */
									sleep(100);
									break;
								case 5:
									sound_tone(784,100);	/* G-1 */
									sound_tone(740,100);	/* F#-1 */
									sound_tone(784,100);	/* G-1 */
									sound_tone(659,500);	/* E-1 */
									sleep(50);
									break;
								}
							}
						if (user_baud && peek_input(cfg.cfg_port) != -1)
							{
							read_input(cfg.cfg_port);		/* eat character */
							quit = 1;
							}
						if (peek_kb() != -1)
							{
							key = read_kb();
							if (key == 'C' || key == 'c')
								{
								answer = 1;
								chat();
								}
							else if (key == 0x1b)			/* esc aborts yell */
								quit = 1;
							}
#ifdef PROTECTED
						else
							DosSleep(0L);
#endif

						++times;
						update_clock();
						}
					while (!answer && !quit && (projected_time(0L) < endtime));
					++yells;
					if (!answer)
						{
						send_string("\r\n",NULL);
						send_ansifile(cfg.cfg_screenpath,"noanswer",1);
						get_enter();
						}
					else
						yells = 0;			/* reset yell flag */
					}
				show_user();		/* show if they want chat or clear it if they got it */
				}
			}
		else
			{
			send_string("\r\n\r\n",NULL);
			send_ansifile(cfg.cfg_screenpath,"noyell",1);
			get_enter();

			yells = -1;
			show_user();		/* show that they want chat outside of hours */
			}
		}
	else
		system_message("You must be confused!  You can't yell from the local console!!\r\n");
	}
