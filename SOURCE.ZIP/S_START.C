/* s_start.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 27 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_start.c_v  $
**                       $Date:   25 Oct 1992 14:06:38  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#else
	#ifdef __ZTC__
		#include <int.h>
	#endif
	#include <dos.h>
#endif
#include "simplex.h"



#define RINGBACK_TIME			40			/* 40 seconds before stepping down */
#define REINIT_TIME				300			/* 300 * 1 sec == 5 minutes */
#define SAVER_TIME				120			/* 120 * 1 sec == 2 minutes */



jmp_buf reset_bbs;
int saver_mode = 0;
int saver_timer;



void go_offhook(void)
	{
	char buffer[100];
	int retry = 0;
	int ok = 0;

	purge_output(cfg.cfg_port);
	purge_input(cfg.cfg_port);
	do
		{
		_error(E_NOTICE,"Attempting to put modem offhook!");
		lower_dtr(cfg.cfg_port);
		sleep(1000);
		raise_dtr(cfg.cfg_port);
		if (check_cd(cfg.cfg_port))
			{
			send_modem(cfg.cfg_hangup);
			purge_output(cfg.cfg_port);
			purge_input(cfg.cfg_port);
			if (check_cd(cfg.cfg_port))
				_error(E_ERROR,"Unable to force modem hangup!");
			}
		send_modem(cfg.cfg_busy);
		do
			{
			receive_modem(buffer);
			if (buffer[0])
				{
				strupr(buffer);
				if (strstr(buffer,cfg.cfg_resp))
					ok = 1;
				}
			}
		while (buffer[0] && !ok);	/* as long as the modem is talking, we are listening! */
		if (!ok)
			{
			sleep(500);
			++retry;
			}
		}
	while (!ok && retry < 5);
	if (!ok)
		_error(E_WARNING,"Unable to put modem offhook!");
	}



void start_bbs(void)
	{
	char buffer[100];
	int retry;
	int count;
	int first = 1;
	int quit = 0;
	int ok;
	int rtn;

	init_color();
	if (!local_flag)
		{
#ifndef PROTECTED
		if (!init_fossil(cfg.cfg_port))
			_error(E_FATAL,"Unable to initialize fossil driver or invalid fossil version!");
#else
		if (port == -1)
			{
			if (!init_fossil(cfg.cfg_port))
				_error(E_FATAL,"Unable to open communications port or invalid port number!");
			}
		else
			{
			if (!setup_fossil(cfg.cfg_port,port))
				_error(E_FATAL,"Invalid communications port number!");
			}
		if (!start_kbthread())
			_error(E_FATAL,"Unable to start keyboard monitoring thread...Aborting!");
		if (!start_ringthread())
			_error(E_FATAL,"Unable to start com port protocol output thread...Aborting!");
#endif
		}
#ifdef PROTECTED
	else
		{
		if (!start_kbthread())
			_error(E_FATAL,"Unable to start keyboard monitoring thread...Aborting!");
		}
#endif

	initf();		/* set up file-closing system */

	if (rtn = setjmp(reset_bbs))
		{
		if (user_online)			/* did we just hangup?  Update user's time online */
			logout();
		user_online = 0;
		user_baud = 0;

		if (rtn == 3)		/* fatal logging error */
			{
			exit_flag = 0;		/* make sure that errorlevel doesn't change */
			errorlevel = 1;
			return;
			}

		init_color();
		if (rtn == 1)
			{
			_error(E_NOTICE,"Carrier was dropped/lost caller!");
			log_entry(L_NOCARRIER,NULL);
			}

		closeallf();			/* close any outstanding files if carrier lost */
		if (!exit_flag)
			{
			init_flag = 1;
			time_flag = 0;
			}
		if (exit_flag)
			return;

		if (cur_flist)			/* carrier dropped while downloading and not exiting, reset download queue */
			{
			for (count = 0; count < cur_flist; count++)
				{
				free(flist[count]->fl_name);
				free(flist[count]);
				}
			free(flist);
			flist = NULL;
			cur_flist = 0;
			max_flist = 0;
			}

		if (cur_deps)			/* carrier dropped while killing files and not exiting */
			free(deps);
		deps = NULL;
		cur_deps = 0;
		max_deps = 0;
		}

	saver_mode = 0;

	do
		{
		init_color();
		if (!saver_mode)
			clear_user();
		saver_timer = 0;
		nolimit_flag = 0;				/* restore normal online timing */
		ok = 0;
		retry = 0;

		if (!local_flag)
			reinit_fossil(cfg.cfg_port);			/* give fossil a gentle bump! */

		if (init_flag)
			{
			if (!locked_flag && cfg.cfg_flags & CFG_LOCKBAUD)		/* initialize locked baud */
				{
				locked_flag = 1;
				locked_baud = cfg.cfg_baud;
				}

			raise_dtr(cfg.cfg_port);
			enable_flowctrl(cfg.cfg_port,1,0,0);		/* cts-rts and NO xon-xoff */
			if (!set_baud(cfg.cfg_port,locked_flag ? locked_baud : cfg.cfg_baud))
				{
				if (!saver_mode)
					{
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* clear status lines */
					clear_user();
					update_clock();
					}
				saver_timer = 0;

				_error(E_FATAL,"Unable to set baud rate!");
				return;
				}
			do
				{
				if (!saver_mode)
					{
					sprintf(buffer,"Initializing modem (attempt %u of 10)...",retry + 1);
					_error(E_NOTICE,buffer);
					}

				purge_output(cfg.cfg_port);
				purge_input(cfg.cfg_port);
				if (check_cd(cfg.cfg_port))
					{
					lower_dtr(cfg.cfg_port);
					sleep(1000);
					raise_dtr(cfg.cfg_port);
					if (check_cd(cfg.cfg_port))
						{
						send_modem(cfg.cfg_hangup);
						purge_output(cfg.cfg_port);
						purge_input(cfg.cfg_port);
						if (check_cd(cfg.cfg_port))
							{
							if (!saver_mode)
								{
								bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* clear status lines */
								clear_user();
								update_clock();
								}
							saver_timer = 0;

							_error(E_ERROR,"Unable to force modem hangup!");
							}
						}
					}
				send_modem(cfg.cfg_init);
				do
					{
					receive_modem(buffer);
					if (buffer[0])
						{
						strupr(buffer);
						if (strstr(buffer,cfg.cfg_resp))
							ok = 1;
						}
					}
				while (buffer[0] && !ok);	/* as long as the modem is talking, we are listening! */
				if (!ok)
					{
					sleep(1000);
					++retry;
					}
				}
			while (!ok && retry < 10);
			if (ok)
				{
				if (!saver_mode)
					{
					sprintf(buffer,"\"%s\" is waiting for call!",cfg.cfg_bbsname);
					_error(E_NOTICE,buffer);
					}

				if (first)
					{
					log_entry(L_ONLINE,buffer);
					first = 0;
					}
				purge_input(cfg.cfg_port);

				get_next_event();		/* set up for events */
				rtn = call_wait();
				switch (rtn)
					{
					case CW_RESET_MODEM:
						break;
					case CW_KB_EXIT:
						quit = 1;
						break;
					case CW_END_OF_SESSION:
						break;
					case CW_EVENT_EXIT:
						event_exit = 1;
						quit = 1;
						break;
					}
				}
			else
				_error(E_FATAL,"Unable to initialize modem!");
			}
		else		/* direct log in */
			{
			if (!user_baud)
				{
				_error(E_NOTICE,"Local console login!");
				login();
				if (!exit_flag)
					init_flag = 1;
				else 
					rtn = CW_END_OF_SESSION;
				}
			else
				{
#ifdef PROTECTED			
				DosSemRequest(&update_sem,SEM_INDEFINITE_WAIT);
#endif
				cd = 1;
#ifdef PROTECTED			
				DosSemClear(&update_sem);
#endif
				cd = 1;
				if (locked_flag)
					sprintf(buffer,"Already online at baud %u and locked baud %u!",(unsigned int)user_baud,(unsigned int)locked_baud);
				else 
					sprintf(buffer,"Already online at baud %u!",user_baud);
				_error(E_NOTICE,buffer);
				raise_dtr(cfg.cfg_port);
				enable_flowctrl(cfg.cfg_port,1,0,0);		/* cts-rts and NO xon-xoff */
				if ((unsigned int)user_baud >= (unsigned int)cfg.cfg_minbaud)
					login();
				else
					{
					send_file(cfg.cfg_screenpath,"tooslow.asc",1,NULL);
					if (user_baud)
						sleep(4000);   	/* make sure screen is sent before toggling hangup! */
					hangup();
					}
				if (!exit_flag)
					{
					init_flag = 1;
					time_flag = 0;
					}
				else
					rtn = CW_END_OF_SESSION;
				}
			}
		if (exit_flag && rtn == CW_END_OF_SESSION)
			quit = 1;
		}
	while (!quit);
	/* deinitializing of fossil is in exit_list */
	}



int call_wait(void)
	{
	char buffer[100];
	unsigned int baud;
	DATE_T curdate;
	TIME_T curtime;
	int ringback_armed = 0;
	int ringback_time = 0;
	int quit = 0;
	int kbchar;
	int ring;
	int gotbaud;
	int retry;
	int reinit = 0;
	int rtn = CW_RESET_MODEM;

	do
		{
		ring = 0;
		if (ringback_armed)
			{
			++ringback_time;
			if (ringback_time >= RINGBACK_TIME)		/* 40-50 seconds */
				{
				if (!saver_mode)
					_error(E_WARNING,"Time elapsed, disarming ringback feature!");
				ringback_armed = 0;
				}
			}
		if (peek_kb() != -1)
			{
			if (saver_mode)
				{
				saver_mode = 0;
				bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* clear status lines */
				clear_user();
				update_clock();
				}
			saver_timer = 0;

			kbchar = read_kb();
			switch (kbchar)
				{
				case 0x2d00:		/* alt-x - exit program */
					_error(E_NOTICE,"Keyboard request to exit BBS!");
					exit_flag = 0;		/* toggle off exit flag because we don't want errorlevel exit! */
					rtn = CW_KB_EXIT;
					quit = 1;
					break;
				case 0x2400:	   	/* alt-j - shell to DOS */
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */
					shell();
					bios_clrblk(0x0,(bottom_line << 8) | 0x4f,WHITE);
					bios_setcurpos(0x0);
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* prepare status lines */
					rtn = CW_RESET_MODEM;		/* reinitialize modem */
					quit = 1;
					break;
				case 0x2600:		/* alt-l - local login */
					_error(E_NOTICE,"Local console login!");
					if (cfg.cfg_busy[0])
						go_offhook();
					user_baud = 0;
					login();
					rtn = CW_END_OF_SESSION;
					quit = 1;
					break;
				case 0x2300:			/* alt-h - key help */
					if (help_flag)
						clear_user();
					else
						show_help();
					break;
				}
			}
		else 
			{
			if (ringback_flag && !ringback_armed) 		/* ringback feature */
				{
				receive_modem(buffer);
				retry = 0;
				do
					{
					if (buffer[0])
						{
						strupr(buffer);
						if (strstr(buffer,cfg.cfg_ring))
							{
							_error(E_NOTICE,"Counting Ring for Ringback!");
							retry = 0;
							++ring;
							}
						}
					else
						{
						++retry;
						sleep(800);
						}
					receive_modem(buffer);
					}
				while (buffer[0] || retry < 3);		/* as long as the modem is talking or 3 seconds */

				if (ring < ringback_rings || ring > ringback_rings)
					ring = 0;
				else 
					{
					_error(E_WARNING,"Ringback feature armed!");
					ringback_armed = 1;
					ring = 0;
					ringback_time = 0;
					reinit = 0;
					purge_input(cfg.cfg_port);
					}
				}
			else if (!answer_flag)		/* otherwise if not immediate answer */
				{
				do
					{
					receive_modem(buffer);
					if (buffer[0])
						{
						strupr(buffer);
						if (strstr(buffer,cfg.cfg_ring))
							ring = 1;
						}
					}
				while (buffer[0] && !ring);		/* as long as the modem is talking, we are listening! */
				}
			if (ring || answer_flag)
				{
				if (saver_mode)
					{
					saver_mode = 0;
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,ON_RED);		/* clear status lines */
					clear_user();
					update_clock();
					}
				saver_timer = 0;

				if (!answer_flag)
					_error(E_NOTICE,"Ringing!");
				else 
					_error(E_NOTICE,"Immediate answer requested!");
				purge_input(cfg.cfg_port);
				purge_output(cfg.cfg_port);
				send_modem(cfg.cfg_answer);
				if (ringback_armed)
					ringback_armed = 0;		/* disarm the ringback */
				retry = 0;
				do
					{
					if (!cd)
						{
						++retry;
						sleep(1000);
						}
					update_clock();
					}
				while (!cd && retry < 60);		/* wait 60 seconds for connect */

				if (!cd)
					{
					if (!answer_flag)
						rtn = CW_RESET_MODEM;		/* reinitialize modem */
					else 
						rtn = CW_END_OF_SESSION;	/* no carrier, exit anyway */
					quit = 1;
					}
				else
					{
					gotbaud = 0;
					do
						{
						receive_modem(buffer);
						strupr(buffer);
						if (cfg.cfg_resp384_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp384_1))
								{
								baud = (int)(unsigned int)38400;
								gotbaud = 1;
								}
							}
						if (cfg.cfg_resp384_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp384_2))
								{
								baud = (int)(unsigned int)38400;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp192_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp192_1))
								{
								baud = 19200;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp192_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp192_2))
								{
								baud = 19200;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp96_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp96_1))
								{
								baud = 9600;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp96_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp96_2))
								{
								baud = 9600;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp48_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp48_1))
								{
								baud = 4800;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp48_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp48_2))
								{
								baud = 4800;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp24_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp24_1))
								{
								baud = 2400;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp24_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp24_2))
								{
								baud = 2400;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp12_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp12_1))
								{
								baud = 1200;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp12_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp12_2))
								{
								baud = 1200;
								gotbaud = 1;
								}
							}

						if (!gotbaud && cfg.cfg_resp3_1[0])
							{
							if (strstr(buffer,cfg.cfg_resp3_1))
								{
								baud = 300;
								gotbaud = 1;
								}
							}
						if (!gotbaud && cfg.cfg_resp3_2[0])
							{
							if (strstr(buffer,cfg.cfg_resp3_2))
								{
								baud = 300;
								gotbaud = 1;
								}
							}
						}
					while (buffer[0] && !gotbaud);	/* as long as the modem is talking, we are listening! */
					if (!gotbaud)
						_error(E_ERROR,"Unable to detect baud rate of connect!");
					else
						{
						if (!locked_flag)
							sprintf(buffer,"Connected and setting baud to %u!",(unsigned int)baud);
						else 
							sprintf(buffer,"Connected at %u and locking baud to %u!",(unsigned int)baud,(unsigned int)locked_baud);
						_error(E_NOTICE,buffer);
						sprintf(buffer,"%u",baud);
						log_entry(L_CONNECT,buffer);
						if (!set_baud(cfg.cfg_port,locked_flag ? locked_baud : baud))
							_error(E_ERROR,"Unable to set baud rate!");
						else
							{
							retry = 0;
							do
								{
								purge_input(cfg.cfg_port);
								if (peek_input(cfg.cfg_port) != -1)
									{
									if (read_input(cfg.cfg_port) == 0x1b)
										retry = 10;
									}
								if (retry < 30)
									{
									++retry;
									sleep(100);	 	/* wait for connection to stabilize for 3 seconds */
									}
								}
							while (retry < 30);
							if (cd)
								{
								user_baud = baud;
								if (baud >= (unsigned int)cfg.cfg_minbaud)
									login();
								else
									{
									send_file(cfg.cfg_screenpath,"tooslow.asc",1,NULL);
									if (user_baud)
   										sleep(4000);   	/* make sure screen is sent before toggling hangup! */
									hangup();
									}
								}
							}
						}
					rtn = CW_END_OF_SESSION;
					quit = 1;
					}
				}
			}

		if (cur_events)
			{
			curdate = get_cdate();
			curtime = get_ctime() & 0xffe0;		/* take seconds out of the picture */

			if ((curdate > next_edate || (curdate == next_edate && curtime >= next_etime)) && next_eforced)
				{
				errorlevel = next_eerrorlevel;
				rtn = CW_EVENT_EXIT;
				quit = 1;
				}
			else if (curdate == next_edate && curtime == next_etime && !next_eforced)
				{
				errorlevel = next_eerrorlevel;
				rtn = CW_EVENT_EXIT;
				quit = 1;
				}
			else
				get_next_event();
			}


		if (!quit)
			{
			++reinit;		/* counting towards reinitializing modem */
			if (reinit >= REINIT_TIME)
				{
				rtn = CW_RESET_MODEM;
				quit = 1;
				}

			if (!saver_mode)
				{
				++saver_timer;		/* counting towards screen-saver */
				if (saver_timer >= SAVER_TIME)
					{
					saver_mode = 1;
					bios_clrblk(0x0,((bottom_line + 3) << 8) + 0x4f,BLACK);
					bios_setcurpos(0x0);
					cur_color = WHITE;
					cur_line = 0;
					}
				}
			}
		}
	while (!quit);
	return rtn;
	}



