/* s_recv.c
**
** Copyright (c) 1990, Christopher Laforet
** All Rights Reserved
**
** Started: 2 January 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_recv.c_v  $
**                       $Date:   25 Oct 1992 14:09:18  $
**                       $Revision:   1.23  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <ctype.h>
#include "simplex.h"


#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#define INCL_DOSSEMAPHORES
	#include <os2.h>
#else
	#ifdef __ZTC__
		#include <int.h>
	#endif
	#include <dos.h>
#endif




extern jmp_buf reset_bbs;
extern void login_user(void);
int volatile more_flag = 0;




void pascal purge_input(int port)
	{
	if (user_baud)
		{
		while (peek_protocol_input(port) != -1)
			{
			if (!cd)
				longjmp(reset_bbs,1);
			read_input(port);
			}
		purge_input_buffer(port);
		}
	}



void receive_modem(char *buffer)
	{
	char *cptr = buffer;
	char inchar;
	int retry = 0;

	do
		{
		if (peek_protocol_input(cfg.cfg_port) != -1)
			{
			*cptr++ = inchar = (char)read_input((int)cfg.cfg_port);
			retry = 0;
			}
		else
			{
#ifdef PROTECTED
			sleep(40);		/* should be around 50 msec due to latency */
#else
			sleep(50);
#endif
			++retry;
			}
		update_clock();
		}
	while (inchar != '\x0d' && retry < 30);		/* no CR and retry < 1.5 sec */
	*cptr = '\0';
	}



int get_kb(void)
	{
	char buffer[60];
	char *cptr;
	long tlong;
	unsigned int key;
	int new_cursor;
	int cursor;

	if (peek_kb() != -1)
		{
		key = (unsigned int)read_kb();
		if (!(key & 0xff))
			{
			switch (key)
				{
				case 0x2300:			/* alt-h - key help */
					if (!update_priv_flag)
						{
						if (help_flag)
							{
							if (which_status == 3)
								show_user();
							else if (which_status == 2)
								show_username();
							else if (which_status == 1)
								login_user();
							else
								clear_user();
							}
						else
							show_help();
						}
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					if (user_online)
						{
						logoff_notify = logoff_notify ? 0 : 1;

						cursor = bios_getcurpos();
						tlong = user_time / 60L;
						if (tlong < 0L)
							tlong = 0L;
						sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : ""));
						new_cursor = ((bottom_line + 2) << 8) | 0x34;
						cptr = buffer;
						while (*cptr)
							{
							bios_setcurpos(new_cursor++);
							bios_outchar(*cptr++,status_color[2],1);
							}
						bios_setcurpos(new_cursor);
						bios_outchar(' ',status_color[2],1);
						bios_setcurpos(cursor++);
						}
					break;
				case 0x2500:			/* alt-k - disable/enable keyboard */
					if (user_baud)
						{
						if (cfg.cfg_flags & CFG_DISABLEKB)
							cfg.cfg_flags &= ~CFG_DISABLEKB;
						else 
							cfg.cfg_flags |= CFG_DISABLEKB;
						}
					break;
				case 0x1400:			/* alt-t - terminate connection/unconditional hangup */
					hangup();
					longjmp(reset_bbs,2);
					break;
				case 0x2400:			/* alt-j - shell to DOS */
#ifdef PROTECTED
					send_string("\r\nSysop shelling to OS/2:  Please wait a few moments....\r\n",NULL);
#else
					send_string("\r\nSysop shelling to DOS:  Please wait a few moments....\r\n",NULL);
#endif
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */
					shell();
					bios_clrblk(0x0,(bottom_line << 8) | 0x4f,WHITE);
					bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* clear status lines */
					bios_setcurpos(0x0);

					set_inactivetime();
					if (user_online)
						show_user();		/* user's logged in already */
					else
						login_user();		/* waiting for user login! */
					send_string("Sysop has returned:  All yours again!\r\n",NULL);
					break;
				case 0x1900:			/* alt-p - change priv level */
					if (user_online)
						{
						if (help_flag)
							show_user();
						send_string("\r\nSysop updating your privilege level.  Please wait....\r\n",NULL);
						update_priv();
						send_string("Sysop has finished.  Please carry on using the BBS...\r\n",NULL);
						}
					break;
				case 0x8400:			/* Ctrl-PgUp - increase user's time */
					bump_logofftime(1);
					user_time = remaining_time();
					user_warning = 0;		/* reset the user's 2 minute warning flag */
					cursor = bios_getcurpos();
					tlong = user_time / 60L;
					if (tlong < 0L)
						tlong = 0L;
					sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : " "));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(cursor++);
					break;
				case 0x7600:			/* Ctrl-PgDn - decrease user's time */
					if (user_time > 60L)
						bump_logofftime(-1);
					else
						user_time = 0L;
					user_warning = 0;		/* reset the user's 2 minute warning flag */
					user_time = remaining_time();
					cursor = bios_getcurpos();
					tlong = user_time / 60L;
					if (tlong < 0L)
						tlong = 0L;
					sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : " "));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				case 0x2100:			/* alt-f - edit user's flags */
					if (user_online)
						{
						if (help_flag)
							show_user();
						send_string("\r\nSysop updating your user flags.  Please wait....\r\n",NULL);
						update_flags();
						send_string("Sysop has finished.  Please carry on using the BBS...\r\n",NULL);
						}
					break;
				case 0x2e00:			/* alt-c - enter chat mode */
					if (user_baud && !chat_flag)
						chat();
					else if (!user_baud)
						system_message("You want to talk to yourself!!  Methinks you need some help!!\r\n");
					break;
				case 0x4d00:			/* right arrow */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x14d;
					break;
				case 0x4b00:			/* left arrow */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x14b;
					break;
				case 0x4800:			/* up arrow */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x148;
					break;
				case 0x5000:			/* down arrow */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x150;
					break;
				case 0x4700:			/* home key */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x147;
					break;
				case 0x5300:			/* delete key */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x153;
					break;
				case 0x4f00:			/* end key */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x14f;
					break;
				case 0x4900:			/* pgup key */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x149;
					break;
				case 0x5100:			/* pgdn key */
					if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB))
						return 0x151;
				}
			}
		else if (!user_baud || !(cfg.cfg_flags & CFG_DISABLEKB) || !update_priv_flag)
			return (int)key;
		}
	return 0;
	}

	

int pascal recv_char_fast(void)
	{
	int inbyte = -1;
	int count;

	if (user_baud && !cd)
		longjmp(reset_bbs,1);
	for (count = 0; count < 120; count += 30)
		{
		if (peek_protocol_input(cfg.cfg_port) != -1)
			{
			inbyte = read_protocol_input(cfg.cfg_port);
			break;
			}
		else 
#ifdef PROTECTED
			DosSleep(30L); 	/* if nothing try again */
#else
			sleep(30);	   	/* if nothing try again */
#endif
		}
	return inbyte;
	}



int pascal recv_char(int timeout)
	{
	register int max_timeout = 0;
	int quit = 0;
	int rtn = -1;

	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (peek_input(cfg.cfg_port) != -1)
			{
			rtn = read_input(cfg.cfg_port);
			++quit;
			}
		else if (timeout)
			{
#ifdef PROTECTED
			DosSleep(30L);
#else
			sleep(40);			/* edge DOS a bit */
#endif
			max_timeout += 30;
			if (max_timeout >= timeout)
				++quit;
			}
		else
			break;
		}
	while (!quit);

	return rtn;
	}



#ifdef PROTECTED

int pascal recv_protocol_char(int timeout)
	{
	register int max_timeout = 0;
	int quit = 0;
	int rtn = -1;

	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (peek_protocol_input(cfg.cfg_port) != -1)
			{
			rtn = read_protocol_input(cfg.cfg_port);
			++quit;
			}
		else if (timeout)
			{
			DosSleep(30L);		/* close to a clocktick */
			max_timeout += 30;
			if (max_timeout >= timeout)
				++quit;
			}
		else
			break;
		}
	while (!quit);
	return rtn;
	}

#endif



int get_char(void)
	{
	long tlong;
	int sent_warning = 0;
	int save_color;
	int quit = 0;
	int key;
	int rtn;
	
	set_inactivetime();
	do
		{
		tlong = projected_time(0L);
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (key = get_kb())
			{
			rtn = key;
			quit = 1;
			set_inactivetime();
			}
		else if (user_baud && peek_input(cfg.cfg_port) != -1)
			{
			rtn = read_input(cfg.cfg_port);
			quit = 1;
			set_inactivetime();
			}
		else if (tlong >= inactive_time)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE | BRIGHT | BLINK),NULL);
			send_string("\r\n\r\n\aSorry! Hanging up due to keyboard inactivity timeout!\r\n",NULL);
			hangup();
	 		longjmp(reset_bbs,2);
			}
		else if (!sent_warning && ((inactive_time - tlong) < 30L))
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				save_color = cur_color;
				send_string(new_color(RED | BRIGHT | BLINK),NULL);
				}
			sent_warning = 1;
			send_string("\r\n\a\aPress a key or you will be disconnected within 30 seconds!!\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(save_color),NULL);
			}
		if (!quit)
			{
			sleep(30);
			update_clock();
			}
		}
	while (!quit);
	return rtn;
	}



void hangup(void)
	{
	if (user_baud)					/* be hard to hangup on local console! */
		{
		lower_dtr(cfg.cfg_port);	/* force hangup */
		sleep(1000);
	 	raise_dtr(cfg.cfg_port);
		sleep(1000);
		if (check_cd(cfg.cfg_port))
			{
			lower_dtr(cfg.cfg_port);   
			sleep(1000);
			raise_dtr(cfg.cfg_port);
			sleep(1000);
			if (check_cd(cfg.cfg_port))
				{
				lower_dtr(cfg.cfg_port);   
				sleep(1000);
				raise_dtr(cfg.cfg_port);
				sleep(1000);
				if (check_cd(cfg.cfg_port))
					{
					purge_output(cfg.cfg_port);
					purge_input(cfg.cfg_port);
					send_modem(cfg.cfg_hangup);
					sleep(1000);
					if (check_cd(cfg.cfg_port))
						_error(E_ERROR,"Unable to force modem hangup!");
					}
				}
			}
		}
	}



void pause_character(void)
	{
	purge_input(cfg.cfg_port);
	get_char();
	}



static char *temp_color(char *ansi,int color)		/* this is only for pause function - temporary */
	{
	strcpy(ansi,"[");
	if (!(color & BRIGHT))
		strcat(ansi,"0;");
	switch (color & 7)
		{
		case BLACK:
			strcat(ansi,"30");
			break;
		case RED:
			strcat(ansi,"31");
			break;
		case GREEN:
			strcat(ansi,"32");
			break;
		case BROWN:
			strcat(ansi,"33");
			break;
		case BLUE:
			strcat(ansi,"34");
			break;
		case MAGENTA:
			strcat(ansi,"35");
			break;
		case CYAN:
			strcat(ansi,"36");
			break;
		case WHITE:
			strcat(ansi,"37");
			break;
		}
	switch (color & 0x70)
		{
		case ON_BLACK:
			strcat(ansi,";40");
			break;
		case ON_RED:
			strcat(ansi,";41");
			break;
		case ON_GREEN:
			strcat(ansi,";42");
			break;
		case ON_BROWN:
			strcat(ansi,";43");
			break;
		case ON_BLUE:
			strcat(ansi,";44");
			break;
		case ON_MAGENTA:
			strcat(ansi,";45");
			break;
		case ON_CYAN:
			strcat(ansi,";46");
			break;
		case ON_WHITE:
			strcat(ansi,";47");
			break;
		}
	if (color & BRIGHT)
		strcat(ansi,";1");
	if (color & BLINK)
		strcat(ansi,";5");
	strcat(ansi,"m");
	return ansi;
	}



void get_enter(void)
	{
	int save_color;
	int key;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		save_color = cur_color;
		send_string(new_color(WHITE | BRIGHT),NULL);
		}
	send_string("\r\nPress ENTER to continue...",NULL);
	purge_input(cfg.cfg_port);
	while (get_kb())
		;
	while (1)
		{
		key = get_char();
		if (key == '\r' || key == '\n')
			break;
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		send_string(new_color(save_color),NULL);
		send_string("\r[K",NULL);		/* erase to EOL in ANSI! */
		}
	else 
		send_string("\r                          \r",NULL);
	cur_line = 0;
	}



void pause_screen(void)
	{
	char ansi[30];
	int save_color;
	int key;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		save_color = cur_color;
		temp_color(ansi,BROWN | BRIGHT);
		send_string(ansi,NULL);
		send_string("\rPause: ",NULL);
		temp_color(ansi,CYAN | BRIGHT);
		send_string(ansi,NULL);
		send_string("Show more (Y/n)? ",NULL);
		}
	else 
		send_string("\rPause: Show more (Y/n)? ",NULL);
	purge_input(cfg.cfg_port);

	do
		{
		key = get_char();
		key = toupper(key);
		}
	while (key != 'Y' && key != 'N' && key != '\r' && key != '\n');
	if (key == 'N')
		more_flag = 1;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		send_string("\r[K",NULL);		/* erase to EOL in ANSI! */
		temp_color(ansi,save_color);
		send_string(ansi,NULL);
		}
	else 
		send_string("\r                       \r",NULL);
	}



int dopause(void)
	{
	char ansi[30];
	int save_color;
	int key;
	int save_line = cur_line;
	int rtn = 0;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		save_color = cur_color;
		temp_color(ansi,BROWN | BRIGHT);
		send_string(ansi,NULL);
		send_string("\rPaused: ",NULL);
		temp_color(ansi,CYAN | BRIGHT);
		send_string(ansi,NULL);
		send_string("Show more (Y/n)? ",NULL);
		}
	else 
		send_string("\rPaused: Show more (Y/n)? ",NULL);
	purge_input(cfg.cfg_port);

	do
		{
		key = get_char();
		key = toupper(key);
		}
	while (key != 'Y' && key != 'N' && key != '\r' && key != '\n');
	if (key == 'N')
		rtn = 1;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		{
		send_string("\r[K",NULL);		/* erase to EOL in ANSI! */
		temp_color(ansi,save_color);
		send_string(ansi,NULL);
		}
	else 
		send_string("\r                          \r",NULL);
	cur_line = save_line;
	return rtn;
	}
