/* s_quote.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 7 May 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_quote.c_v  $
**                       $Date:   25 Oct 1992 14:07:38  $
**                       $Revision:   1.6  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "simplex.h"



void do_quote(char *filename,int pause)
	{
	struct qh tqh;
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int inchar;
	long random;
	int len;
	int tlen;
	FILE *fd;

	strcpy(buffer,cfg.cfg_screenpath);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	_makepath(buffer,drive,path,fname,"cq");		/* questionnaire file */
	if (fd = fopen(buffer,"rb"))
		{
		if (fread(&tqh,sizeof(struct qh),1,fd))
			{
			if (!strcmp(tqh.qh_sig,"Simplex Quote"))
				{
				/* generate soething somewhat "random"! */

				random = login_time * user_time;
				random *= (long)user.user_lasttime * (long)user.user_lastdate;
				random *= (long)user.user_firstdate;
				random *= (long)get_cdate();
				random += (long)get_ctime();		/* notice the PLUS sign here! */

				if (login_time & 0x1L && !(random & 0x1L))
					++random;

				random = (unsigned long)((unsigned int)random % (unsigned int)tqh.qh_lines);

				fseek(fd,(random * (long)sizeof(long)) + (long)sizeof(struct qh),SEEK_SET);
				if (fread(&random,sizeof(long),1,fd))
					{
					if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					send_string("\r\n\r\nQuote of the Moment:\r\n\r\n",NULL);
					if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);

					fseek(fd,random,SEEK_SET);
					len = 0;
					while ((inchar = fgetc(fd)) != EOF && inchar)
						{
						buffer[len++] = (char)inchar;
						if (len >= 76)
							{
							buffer[len] = (char)'\0';
							tlen = len - 1;
							while (isspace(buffer[tlen]))
								--tlen;
							while (tlen >= (len - 35) && !isspace(buffer[tlen]))		/* 35 character wrap limit */
								--tlen;
							if (tlen >= (len - 35))
								{
								buffer[tlen] = (char)'\0';
								++tlen;
								send_string(buffer,NULL);
								strcpy(buffer,buffer + tlen);
								len = (int)strlen(buffer);
								}
							else
								{
								send_string(buffer,NULL);
								len = 0;
								}
							send_string("\r\n",NULL);
							}
						}
					if (len)
						{
						buffer[len] = (char)'\0';
						send_string(buffer,NULL);
						send_string("\r\n",NULL);
						}
					send_string("\r\n",NULL);
					if (pause)
						get_enter();
					else
						{
						cur_line = 0;
					 	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					 		send_string(new_color(RED | BRIGHT),NULL);
						send_string("Press any key to continue or wait 5 seconds....",NULL);
						wait_key(5);
						send_string("\r\n\r\n",NULL);
						cur_line = 0;
						}
					}
				}
			}
		fclose(fd);
		}
	}
