/* s_xmodem.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 23 October 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_xmodem.c_v  $
**                       $Date:   25 Oct 1992 14:08:08  $
**                       $Revision:   1.18  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include "simplex.h"



/*********************** Send Functions **************************/


void x_send(int area,char *file)
	{
	struct file *tfile;
	STATE state;
	char buffer[128];
	char buffer1[31];
	char *cptr;
	char *cptr1;
	char cksum;
	char crc_flag = 0;
	long total_size;
	long blocks;
	long actual_time;
	long eta;
	int new_cursor;
	int cursor;
	int quit;
	int crc;
	int inchar;
	int rtn;
	int count;
	int kount;
	int retry = 0;
	FILE *fd;

	tfile = get_filearea(area);
	strcpy(buffer,tfile->file_pathname);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	total_size = file_size(tfile->file_pathname,file);
	eta = xmit_time(PROT_XMODEM,total_size);
	strcat(buffer,file);
	if (!(fd = openf(buffer,"rb")))
		{
		_error(E_ERROR,"Unable to open file for Xmodem send!");
		return;
		}

	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("    File area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(tfile->file_areaname,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("  Xmodem send: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(file,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Transfer size: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);

	cptr = parse_long(total_size);
	strcpy(buffer1,cptr);
	cptr = parse_long((total_size / 128L) + (total_size % 128L ? 1L : 0L));
	sprintf(buffer,"%s bytes (%s blocks)",buffer1,cptr);
	send_string(buffer,NULL);
	send_string("\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Transfer time: ",NULL);

	sprintf(buffer,"%lu min %02lu sec",eta / 60L,eta % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string(buffer,NULL);
	send_string(" (estimated)\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Start receiving now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);
	
	hold_protocol();
	actual_time = xfer_time();
	write_string(new_color(BROWN | BRIGHT));
	write_string("\r\nXmodem send: ");
	write_string(new_color(WHITE | BRIGHT));
	write_string(file);
	write_string(new_color(GREEN | BRIGHT));
	sprintf(buffer," (%s bytes)",buffer1);
	write_string(buffer);
	write_string("\r\n");
	write_string(new_color(WHITE));
	write_string("Waiting for Xmodem Startup....");
	retry = 0;
	state = _START;
	quit = 0;
	purge_input(cfg.cfg_port);

	do
		{
		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{
			case _START:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_STARTRETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == 'C')
						{
						crc_flag = 1;
						write_string(new_color(CYAN | BRIGHT));
						write_string("CRC Send\r\n");
						write_string(new_color(WHITE));
						blocks = 1L;
						retry = 0;
						state = _GOTACK;
						}
					else if (inchar == NAK)
						{
						crc_flag = 0;
						write_string(new_color(CYAN | BRIGHT));
						write_string("Checksum Send\r\n");
						write_string(new_color(WHITE));
						blocks = 1L;
						retry = 0;
						state = _GOTACK;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;
					else
						{
						++retry;
						if (retry == MAX_STARTRETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
            case _GOTACK:
				if (rtn = (int)fread(buffer,sizeof(char),128,fd))
					{
					cptr = buffer;
					cptr1 = send;
					memset(send,'\x1a',sizeof(send));					/* pad with Ctrl-Z */
					*cptr1++ = SOH;
					*cptr1++ = (char)(unsigned char)((unsigned char)blocks % 256);
					*cptr1++ = (char)(unsigned char)(0xff - *(cptr1 - 1));
					while ((cptr - buffer) < rtn)
						*cptr1++ = *cptr++;
					cptr1 = (send + 3);
					if (!crc_flag)
						{
						cksum = 0;
						for (count = 0; count < 128; count++)
							cksum += *cptr1++;
						*cptr1 = cksum;
						}
					else
						{
						crc = (int)calc_crc16(128,cptr1);
						cptr1 += 128;
						*cptr1++ = (char)(unsigned char)((unsigned int)crc >> 8);
						*cptr1 = (char)(unsigned char)(crc & 0xff);
						}

					write_string("\rSending Block: ");
					sprintf(buffer,"%lu  Bytes Sent: %lu ",blocks,blocks * 128L);
					write_string(buffer);

					for (count = 0; count < (crc_flag ? 133 : 132); count++)
						send_char_fast(send[count]);
					state = _GETRESPONSE;
					}
				else
					{
					retry = 0;
					state = _END;
					}
				break;
			case _GETRESPONSE:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_RETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == ACK)
						{
						retry = 0;
						state = _GOTACK;
						++blocks;
						}
					else if (inchar == NAK || (inchar == 'C' && blocks == 1L))
						{
						retry = 0;
						state = _GOTNAK;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;							
					else
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
			case _GOTNAK:
				write_string(new_color(RED | BRIGHT));
				write_string("-> NAK\r\n");
				write_string(new_color(WHITE));
				fseek(fd,(long)(blocks - 1) * 128L,SEEK_SET);
				state = _GOTACK;
				break;
			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Timeout.  Aborting\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Other side aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}

				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				quit = 1;
				break;
            case _END:
				write_string(new_color(CYAN | BRIGHT));
				write_string("-> Completed\r\n");
				write_string(new_color(WHITE));
				retry = 0;
				do
					{
					send_char_fast(EOT);
					inchar = recv_protocol_char(MAX_TIMEOUT);
					if (inchar == -1)
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					else
						{
						if (inchar == ACK)
							state = _GOTACK;
						else if (inchar == CAN)
							state = _OTHER_ABORT;							
						}
					}
				while (state != _TIMEOUT && state != _GOTACK && state != _OTHER_ABORT && state != _ABORT);

				actual_time = xfer_time() - actual_time;
				sleep(2000);
				
				show_dlstats(total_size,eta,actual_time);
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);

				sprintf(buffer,"\"%s\" in area %u.",file,area);
				log_entry(L_DOWNLOAD,buffer);

				++userinfo.ui_dnload;
				userinfo.ui_dnloadbytes += total_size;
				++user.user_dnload;
				user.user_dnloadbytes += total_size;
				fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
				fwrite(&user,1,sizeof(struct user),userfd);
				fflush(userfd);

				update_downloads(area,file,get_cdate());

				quit = 1;
				break;
			}
		update_clock();
		}
	while (!quit);
	closef(fd);
	unhold_protocol();
	}



void x1k_send(int area,char *file)
	{
	struct file *tfile;
	STATE state;
	char buffer[1024];
	char buffer1[31];
	char *cptr;
	char *cptr1;
	char cksum;
	char crc_flag = 0;
	long total_size;
	long cur_chars = 0L;
	long blocks = 0L;
	long eta = 0L;
	long actual_time;
	int new_cursor;
	int cursor;
	int inchar;
	int count;
	int kount;
	int retry;
	int maxlen;
	long remain;
	int tval;
	int crc;
	int len;
	int rtn;
	int quit;
	FILE *fd;

	tfile = get_filearea(area);
	strcpy(buffer,tfile->file_pathname);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,file);
	total_size = file_size(tfile->file_pathname,file);
	eta = xmit_time(PROT_XMODEM1K,total_size);
	if (!(fd = openf(buffer,"rb")))
		{
		_error(E_ERROR,"Unable to open file for Xmodem-1K send!");
		return;
		}

	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("     File area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(tfile->file_areaname,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Xmodem-1K send: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(file,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string(" Transfer size: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);

	tval = (int)(total_size / 1024L);
	remain = total_size % 1024L;
	tval += (int)(remain / 128L);
	tval += (remain % 128L ? 1 : 0);

	cptr = parse_long(total_size);
	strcpy(buffer1,cptr);
	cptr = parse_long(tval);
	sprintf(buffer,"%s bytes (%s blocks)",buffer1,cptr);

	send_string(buffer,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string(" Transfer time: ",NULL);

	sprintf(buffer,"%lu min %02lu sec",eta / 60L,eta % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string(buffer,NULL);
	send_string(" (estimated)\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Start receiving now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);

	hold_protocol();
	actual_time = xfer_time();
	write_string(new_color(BROWN | BRIGHT));
	write_string("\r\nXmodem-1K send: ");
	write_string(new_color(WHITE | BRIGHT));
	write_string(file);
	write_string(new_color(GREEN | BRIGHT));
	sprintf(buffer," (%s bytes)",buffer1);
	write_string(buffer);
	write_string("\r\n");
	write_string(new_color(WHITE));
	write_string("Waiting for Xmodem-1K Startup....");
	retry = 0;
	state = _START;
	quit = 0;
	purge_input(cfg.cfg_port);

	do
		{
		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{
			case _START:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_STARTRETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == 'C')
						{
						crc_flag = 1;
						write_string(new_color(CYAN | BRIGHT));
						write_string("CRC Send\r\n");
						write_string(new_color(WHITE));
						blocks = 1L;
						retry = 0;
						state = _GOTACK;
						}
					else if (inchar == NAK)
						{
						crc_flag = 0;
						write_string(new_color(CYAN | BRIGHT));
						write_string("Checksum Send\r\n");
						write_string(new_color(WHITE));
						blocks = 1L;
						retry = 0;
						state = _GOTACK;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;
					else
						{
						++retry;
						if (retry == MAX_STARTRETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
            case _GOTACK:
				if (total_size > cur_chars)
					{
					maxlen = ((total_size - cur_chars) >= 1024L) ? 1024 : 128;
					if (rtn = (int)fread(buffer,sizeof(char),maxlen,fd))
						{
						cptr = buffer;
						cptr1 = send;
						memset(send,'\x1a',sizeof(send));		/* pad with Ctrl-Z */
						if (maxlen == 128)
							*cptr1++ = SOH;
						else
							*cptr1++ = STX;
                    
						*cptr1++ = (char)(unsigned char)((unsigned char)blocks % 256);
						*cptr1++ = (char)(unsigned char)(0xff - *(cptr1 - 1));
						while ((cptr - buffer) < maxlen)
							*cptr1++ = *cptr++;
						cptr1 = (send + 3);
						if (!crc_flag)
							{
							cksum = 0;
							for (count = 0; count < maxlen; count++)
								cksum += *cptr1++;
							*cptr1 = cksum;
							}
						else
							{
							crc = (int)calc_crc16(maxlen,cptr1);
							cptr1 += maxlen;
							*cptr1++ = (char)(unsigned char)((unsigned int)crc >> 8);
							*cptr1 = (char)(unsigned char)(crc & 0xff);
							}
						len = maxlen + 4;
						if (crc_flag)
							++len;
						write_string("\rSending Block: ");
						sprintf(buffer,"%lu  Bytes Sent: %lu ",blocks,cur_chars + (long)rtn);
						write_string(buffer);
						for (count = 0; count < len; count++)
							send_char_fast(send[count]);
						state = _GETRESPONSE;
						}
					else
						{
						retry = 0;
						state = _END;
						}
					}
				else
					{
					retry = 0;
					state = _END;
					}
				break;
			case _GETRESPONSE:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_RETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == ACK)
						{
						retry = 0;
						state = _GOTACK;
						++blocks;
						cur_chars += (long)maxlen;
						}
					else if (inchar == NAK || (inchar == 'C' && blocks == 1L))
						{
						retry = 0;
						state = _GOTNAK;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;							
					else
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
			case _GOTNAK:
				write_string(new_color(RED | BRIGHT));
				write_string("-> NAK\r\n");
				write_string(new_color(WHITE));
				fseek(fd,ftell(fd) - (long)maxlen,SEEK_SET);
				state = _GOTACK;
				break;
			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Timeout.  Aborting\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Other side aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
			case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}
			
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				quit = 1;
				break;
            case _END:
				write_string(new_color(CYAN | BRIGHT));
				write_string("-> Completed\r\n");
				write_string(new_color(WHITE));

				retry = 0;
				do
					{
					send_char_fast(EOT);
					inchar = recv_protocol_char(MAX_TIMEOUT);
					if (inchar == -1)
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					else
						{
						if (inchar == ACK)
							state = _GOTACK;
						else if (inchar == CAN)
							state = _OTHER_ABORT;							
						}
					}
				while (state != _TIMEOUT && state != _GOTACK && state != _OTHER_ABORT && state != _ABORT);

				actual_time = xfer_time() - actual_time;
				sleep(2000);

				show_dlstats(total_size,eta,actual_time);
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);

				sprintf(buffer,"\"%s\" in area %u.",file,area);
				log_entry(L_DOWNLOAD,buffer);

				++userinfo.ui_dnload;
				userinfo.ui_dnloadbytes += total_size;
				++user.user_dnload;
				user.user_dnloadbytes += total_size;
				fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
				fwrite(&user,1,sizeof(struct user),userfd);
				fflush(userfd);

				update_downloads(area,file,get_cdate());

				quit = 1;
				break;
			}
		update_clock();
		}
	while (!quit);
	closef(fd);
	}



/*********************** Receive Functions **************************/


void x_recv(int area,char *filename,FILE *listfd)
	{
	struct file *tfile;
	STATE state;
	char buffer[80];
	char buffer1[10];
	char *cptr;
	char cksum;
	long blocks;
	long filelen;
	long actual_time;
	int new_cursor;
	int cursor;
	int inchar;
	int crc;
	int crc_flag = 1;
	int retry;
	int count;
	int kount;
	int quit = 0;
	FILE *fd = NULL;

	tfile = get_filearea(area);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("     File area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(tfile->file_areaname,NULL);
	send_string("\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("    Disk space: ",NULL);
	cptr = parse_long(disk_size(tfile->file_pathname));
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(cptr,NULL);
	send_string(" bytes free\r\n",NULL);
	
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Xmodem receive: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(filename,NULL);
	send_string("\r\n\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Start sending now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);

	hold_protocol();
	actual_time = xfer_time();

	filelen = 0L;
	retry = 0;
	blocks = 0L;
	quit = 0;
	state = _START;
	crc_flag = 1;
	write_string(new_color(BROWN | BRIGHT));
	write_string("\r\nXmodem receive\r\n");
	write_string("\r\n");
	write_string(new_color(WHITE));
	write_string("Waiting for Xmodem Startup....");

	retry = 0;
	blocks = 0L;
	quit = 0;
	crc_flag = 1;
	
	if (!(fd = file_create(filename,tfile->file_pathname)))
		state = _ABORT;
	else 
		state = _START;

	do
		{
		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{					
			case _START:
				if (retry > (MAX_STARTRETRY >> 1))	/* spend half the time trying for CRC send, then alternate CRC and chksum */
					crc_flag = crc_flag ? 0 : 1;	/* No response to CRC?  Then try chksum */
				
				if (crc_flag)
					send_char_fast('C');
				else
					send_char_fast(NAK);

				inchar = recv_protocol_char(2000);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_STARTRETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == CAN)
		 				state = _OTHER_ABORT;
					else if (inchar == SOH)
						{
						write_string(new_color(CYAN | BRIGHT));
						if (crc_flag)
							write_string("CRC Receive\r\n");
						else 
							write_string("Checksum Receive\r\n");
						write_string(new_color(WHITE));
						state = _GOTSOH;
						retry = 0;
						blocks = 1;
						}
					else
						{
						++retry;
						if (retry == MAX_STARTRETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
			case _GOTSOH:
				count = 0;
				while (count < (crc_flag ? 132 : 131))
					{
					inchar = recv_protocol_char(MAX_TIMEOUT);
					if (inchar == -1)
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					else
						{
						send[count] = (char)inchar;
						++count;
						}
					}
				if (state == _GOTSOH)
					{
					if (send[0] != (char)(unsigned char)(blocks % 256))
						{
						if ((blocks && send[0] < (char)(unsigned char)(blocks % 256)) || (!blocks && send[0] == (char)0xff))
							state = _SENDACK;
						else
							state = _SENDNAK;
						}
					else
						{
						if (crc_flag)
							{
							crc = (int)calc_crc16(128,send + 2);
							if (send[130] != (char)(unsigned char)((unsigned int)crc >> 8) && send[131] != (char)(unsigned char)(crc & 0xff))
								state = _SENDNAK;
							else
								{
								if (fwrite(send + 2,128 * sizeof(char),1,fd))
									state = _SENDACK;
								else
									{
									write_string(new_color(RED | BRIGHT));
									write_string("-> Error writing file.  Aborting.\r\n");
									state = _ABORT;
									}
								}
							}
						else
							{
							cksum = (char)0;
							for (count = 2; count < 130; count++)
								cksum += send[count];
							if (cksum != send[130])
								state = _SENDNAK;
							else
								{
								if (fwrite(send + 2,128 * sizeof(char),1,fd))
									state = _SENDACK;
								else
									{
									write_string(new_color(RED | BRIGHT));
									write_string("-> Error writing file.  Aborting.\r\n");
									state = _ABORT;
									}
								}
							}
						}
					}
                break;
			case _SENDNAK:
				write_string(new_color(RED | BRIGHT));
				sprintf(buffer,"NAK: Resend block %lu!\r\n",blocks);
				write_string(buffer);
				write_string(new_color(WHITE));
				retry = 0;
				send_char_fast(NAK);
				state = _GETSOH;
				break;
			case _SENDACK:
				filelen += 128L;
				cptr = parse_long(filelen);
				sprintf(buffer,"\rReceived block %lu (%s bytes) ",blocks,cptr);
				write_string(buffer);
				send_char_fast(ACK);
				retry = 0;
				state = _GETSOH;
				++blocks;
				break;
            case _GETSOH:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_RETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == SOH)
						{
						state = _GOTSOH;
						retry = 0;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;
					if (inchar == EOT)
						state = _GOTEOT;
					}
				break;
			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Timeout.  Aborting\r\n");
				state = _ABORT;
				break;
			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Other side aborted transfer\r\n");
				state = _ABORT;
				break;
			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
            case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}
			
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				quit = 1;
				break;
            case _GOTEOT:
				send_char_fast(ACK);
				closef(fd);
				fd = NULL;
				actual_time = xfer_time() - actual_time;
				sleep(2000);
				if (filelen)
					{
					fprintf(listfd,"OK  %s %lu\r\n",filename,filelen);

					cur_line = 0;
					show_ulstats(filelen,actual_time,PROT_XMODEM);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);
					}
				else
					{
					fprintf(listfd,"BAD %s 0\r\n",filename);
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
					}
				quit = 1;
				break;
            }
		}
	while (!quit);

	if (fd)
		{
		fprintf(listfd,"BAD %s 0\r\n",filename);
		closef(fd);
		}
	fflush(listfd);

	unhold_protocol();
	if (!(user.user_flags & USER_ANSI) || (user_baud < cfg.cfg_ansibaud && user_baud))
		write_string(new_color(WHITE));
	get_enter();
	}



void x1k_recv(int area,char *filename,FILE *listfd)
	{
	struct file *tfile;
	char buffer[80];
	char buffer1[10];
	char *cptr;
	char cksum;
	STATE state;
	long filelen;
	long blocks;
	long actual_time;
	int crc_flag = 1;
	int new_cursor;
	int cursor;
	int maxlen;
	int crc;
	int inchar;
	int len;
	int quit;
	int count;
	int kount;
	int retry;
	FILE *fd = NULL;

	tfile = get_filearea(area);
	if (area != AREA_UPLOADMAIL)
		{
		if (user.user_flags & USER_CLS)
			send_string("\f",NULL);
		else
			send_string("\r\n\r\n",NULL);
		}

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);

	if (area == AREA_UPLOADMAIL)
		send_string("Ready to receive your message using Xmodem or Xmodem-1K...\r\n\r\n",NULL);
	else
		{
		send_string("        File area: ",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string(tfile->file_areaname,NULL);
		send_string("\r\n",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("       Disk space: ",NULL);
		cptr = parse_long(disk_size(tfile->file_pathname));
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string(cptr,NULL);
		send_string(" bytes free\r\n",NULL);

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("Xmodem-1K receive: ",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string(filename,NULL);
		send_string("\r\n\r\n\r\n",NULL);
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Start sending now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);

	hold_protocol();
	actual_time = xfer_time();
	filelen = 0L;
	retry = 0;
	blocks = 0L;
	quit = 0;
	state = _START;
	crc_flag = 1;
	write_string(new_color(BROWN | BRIGHT));
	write_string("\r\nXmodem-1K receive\r\n");
	write_string("\r\n");
	write_string(new_color(WHITE));
	write_string("Waiting for Xmodem-1K Startup....");

	retry = 0;
	blocks = 0L;
	quit = 0;
	crc_flag = 1;
	
	if (!(fd = file_create(filename,tfile->file_pathname)))
		state = _ABORT;
	else 
		state = _START;

	do
		{
		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{					
			case _START:
				if (retry > (MAX_STARTRETRY >> 1))	/* spend half the time trying for CRC send, then alternate CRC and chksum */
					crc_flag = crc_flag ? 0 : 1;	/* No response to CRC?  Then try chksum */
				
				if (crc_flag)
					send_char_fast('C');
				else
					send_char_fast(NAK);

				inchar = recv_protocol_char(2000);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_STARTRETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == CAN)
		 				state = _OTHER_ABORT;
					else if (inchar == SOH)
						{
						write_string(new_color(CYAN | BRIGHT));
						if (crc_flag)
							write_string("CRC Receive\r\n");
						else 
							write_string("Checksum Receive\r\n");
						write_string(new_color(WHITE));
						maxlen = 128;
						state = _GOTSOH;
						retry = 0;
						blocks = 1;
						}
					else if (inchar == STX)
						{
						write_string(new_color(CYAN | BRIGHT));
						if (crc_flag)
							write_string("CRC Receive\r\n");
						else 
							write_string("Checksum Receive\r\n");
						write_string(new_color(WHITE));
						maxlen = 1024;
						state = _GOTSOH;
						retry = 0;
						blocks = 1;
						}
					else
						{
						++retry;
						if (retry == MAX_STARTRETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					}
				break;
			case _GOTSOH:
				len = maxlen + 3;
				if (crc_flag)
					++len;
				count = 0;
				while (count < len)
					{
					inchar = recv_protocol_char(MAX_TIMEOUT);
					if (inchar == -1)
						{
						++retry;
						if (retry == MAX_RETRY)
							{
							state = _TIMEOUT;
							break;
							}
						}
					else
						{
						send[count] = (char)inchar;
						++count;
						}
					}
				if (state == _GOTSOH)
					{
					if (send[0] != (char)(unsigned char)(blocks % 256))
						{
						if ((blocks && send[0] < (char)(unsigned char)(blocks % 256)) || (!blocks && send[0] == (char)0xff))
							state = _SENDACK;
						else
							state = _SENDNAK;
						}
					else
						{
						if (crc_flag)
							{
							crc = (int)calc_crc16(maxlen,send + 2);
							if (send[len - 2] != (char)(unsigned char)((unsigned int)crc >> 8) && send[len - 1] != (char)(unsigned char)(crc & 0xff))
								state = _SENDNAK;
							else
								{
								if (fwrite(send + 2,maxlen * sizeof(char),1,fd))
									{
									filelen += maxlen;
									state = _SENDACK;
									}
								else
									{
									write_string(new_color(RED | BRIGHT));
									write_string("-> Error writing file.  Aborting.\r\n");
									state = _ABORT;
									}
								}
							}
						else
							{
							cksum = (char)0;
							for (count = 2; count < (maxlen + 2); count++)
								cksum += send[count];
							if (cksum != send[maxlen - 1])
								state = _SENDNAK;
							else
								{
								if (fwrite(send + 2,maxlen * sizeof(char),1,fd))
									{
									filelen += maxlen;
									state = _SENDACK;
									}
								else
									{
									write_string(new_color(RED | BRIGHT));
									write_string("-> Error writing file.  Aborting.\r\n");
									state = _ABORT;
									}
								}
							}
						}
					}
                break;
			case _SENDNAK:
				write_string(new_color(RED | BRIGHT));
				sprintf(buffer,"NAK: Resend block %lu!\r\n",blocks);
				write_string(buffer);
				write_string(new_color(WHITE));
				retry = 0;
				send_char_fast(NAK);
				state = _GETSOH;
				break;
			case _SENDACK:
				cptr = parse_long(filelen);
				sprintf(buffer,"\rReceived block %lu (%s bytes) ",blocks,cptr);
				write_string(buffer);
				send_char_fast(ACK);
				retry = 0;
				state = _GETSOH;
				++blocks;
				break;
            case _GETSOH:
				inchar = recv_protocol_char(MAX_TIMEOUT);
				if (inchar == -1)
					{
					++retry;
					if (retry == MAX_RETRY)
						{
						state = _TIMEOUT;
						break;
						}
					}
				else
					{
					if (inchar == SOH)
						{
						state = _GOTSOH;
						maxlen = 128;
						retry = 0;
						}
					else if (inchar == STX)
						{
						state = _GOTSOH;
						maxlen = 1024;
						retry = 0;
						}
					else if (inchar == CAN)
						state = _OTHER_ABORT;
					else if (inchar == EOT)
						state = _GOTEOT;
					}
				break;
			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Timeout.  Aborting\r\n");
				state = _ABORT;
				break;
			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Other side aborted transfer\r\n");
				state = _ABORT;
				break;
			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;
            case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}
			
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				quit = 1;
				break;
            case _GOTEOT:
				send_char_fast(ACK);
				closef(fd);
				fd = NULL;
				actual_time = xfer_time() - actual_time;
				sleep(2000);
				if (filelen)
					{
					fprintf(listfd,"OK  %s %lu\r\n",filename,filelen);
					show_ulstats(filelen,actual_time,PROT_XMODEM1K);
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);
					}
				else
					{
					fprintf(listfd,"BAD %s 0\r\n",filename);
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
					}
				quit = 1;
				break;
            }
		}
	while (!quit);

	if (fd)
		{
		fprintf(listfd,"BAD %s 0\r\n",filename);
		closef(fd);
		}
	fflush(listfd);

	unhold_protocol();
	if (!(user.user_flags & USER_ANSI) || (user_baud < cfg.cfg_ansibaud && user_baud))
		write_string(new_color(WHITE));
	get_enter();
	}

