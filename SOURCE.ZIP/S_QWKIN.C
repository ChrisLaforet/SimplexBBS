/* s_qwkin.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 15 December 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_qwkin.c_v  $
**                       $Date:   25 Oct 1992 14:08:58  $
**                       $Revision:   1.1  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include <process.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#ifdef XSPAWN
	#include <xspawn.h>
#endif
#include "simplex.h"




#define LINEWRAP			76



#ifndef PROTECTED
	extern int stdout_flag;
#endif

extern jmp_buf reset_bbs;



int unarchive_qwk(char *cmdline)
	{
	char **args = NULL;
	int cur_args = 0;
	int max_args = 0;
	char cbuffer[100];
	char buffer[150];
	char buffer1[150];
	char tbuf[100];
	char *cptr;
	char *cptr0;
	char *cptr1;
	char *cptr2;
	int gotfile = 0;
	int gotarc = 0;
	int ok = 0;
	int ctype;
	int rtn;

	strcpy(cbuffer,cmdline);
	cptr = cbuffer;
	cptr0 = cptr;
	while (*cptr0 && *cptr0 != ' ')
		++cptr0;

	while (*cptr)
		{
		if (*cptr0)
			*cptr0++ = (char)'\0';
		ctype = 0;
		cptr1 = cptr;
		while (*cptr1 && *(cptr1 + 1))
			{
			if (*cptr1 == (char)'%')
				{
				if (*(cptr1 + 1) == (char)'s' || *(cptr1 + 1) == (char)'S')
					{
					ctype = 1;
					break;
					}
				if (*(cptr1 + 1) == (char)'d' || *(cptr1 + 1) == (char)'D')
					{
					ctype = 2;
					break;
					}
				}
			++cptr1;
			}

		if ((cur_args + 1) >= max_args)
			{
			if (!(args = realloc(args,(max_args += 5) * sizeof(char *))))
				{
				_error(E_ERROR,"Out of memory to allocate unarchive args");
				return -1;
				}
			}

		cptr1 = cptr;
		while (isspace(*cptr1))		/* walk off leading spaces */
			++cptr1;
		if (!ctype)
			args[cur_args++] = cptr1;
		else if (ctype == 1)
			{
			cptr2 = buffer;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'s' || *(cptr1 + 1) == (char)'S'))
					{
					strcpy(tbuf,cfg.cfg_fapath);
					if (tbuf[0] && tbuf[strlen(tbuf) - 1] != P_CSEP)
						strcat(tbuf,P_SSEP);
					if (cfg.cfg_qwkname[0])
						{
						strcat(tbuf,cfg.cfg_qwkname);
						strcat(tbuf,".rep");
						}
					else 
						strcat(tbuf,"simplex.rep");

					strcpy(cptr2,tbuf);
					cptr2 += strlen(tbuf);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotarc = 1;
			args[cur_args++] = buffer;
			}
		else
			{
			cptr2 = buffer1;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'d' || *(cptr1 + 1) == (char)'D'))
					{
					strcpy(tbuf,cfg.cfg_fapath);
					strcpy(cptr2,tbuf);
					cptr2 += strlen(tbuf);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotfile = 1;
			args[cur_args++] = buffer1;
			}
		args[cur_args] = NULL;

		cptr = cptr0;
		while (*cptr0 && *cptr0 != ' ')		/* get next token */
			++cptr0;
		}

	if (gotarc && gotfile)
		{
	 	log_entry(L_DMAIL_UNARCHIVE,args[0]);

		init_archiver();

#ifndef PROTECTED
		stop_timer();
#endif

#ifdef XSPAWN
		rtn = xspawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#else
		rtn = spawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#endif

#ifndef PROTECTED
		if (!start_timer())
			{
			cptr = "Unable to restart timer process.  Hanging up!";
			_error(E_ERROR,cptr);
			system_message(cptr);
			hangup();
			longjmp(reset_bbs,2);
			}
#endif

		if (!local_flag)
			reinit_fossil(cfg.cfg_port);		/* reinits when BBS is reentered  */
		deinit_archiver();

		if (rtn == -1)
			{
			sprintf(buffer,"Failed to spawn unarchiver (%s).",args[0]);
		 	log_entry(L_DMAIL_UNARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else if (rtn)
			{
			sprintf(buffer,"Unarchiver (%s) failed and reported error %d.",args[0],rtn);
		 	log_entry(L_DMAIL_UNARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else 
			ok = 1;
		free(args);
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Error: No %S or %D options were found on unarchiver command.  Notify Sysop!\r\n\r\n",NULL);
		}

	if (!ok)
		return 1;
	return 0;
	}



int check_qwk(char *name)
	{
	char buffer[20];

	if (cfg.cfg_qwkname[0])
		sprintf(buffer,"%s.rep",cfg.cfg_qwkname);
	else
		strcpy(buffer,"simplex.rep");
	if (!stricmp(name,buffer))
		return 1;
	return 0;
	}



int qwk_handler(int key)		/* normal pause-stop handler */
	{
	switch (key)
		{
		case '1':
		case '2':
		case '3':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



void receive_qwk_mail(void)
	{
	struct nlix tnlix;
	struct nl tnl;
	struct qwkh tqwkh;
	struct msgh tmsgh;
	struct msg *tmsg;
	struct mlink tmlink;
	char buffer[130];
	char buffer1[81];
	char fname[15];
	char *tonames[2];
	char name[41];
	char *cptr;
	char *cptr1;
	long tlong;
	int tzone;
	int tnet;
	int tnode;
	int tcost;
	int tflags;
	int tval;
	int found;
	int valid;
	int cur_zone;
	int noarchiver = 0;
	int protocol;
	int received = 0;
	int unarced = 0;
	int quit = 0;
	int abort = 0;
	int private;
	int curchar;
	int blocks;
	int msgnum = 0;
	int message;
	int prev;
	int count;
	int total;
	int area;
	int len;
	int key = 0;
	int ok = 0;
	int nl;
	FILE *listfd;
	FILE *fd;

	if (cfg.cfg_fapath[0])
		{
		strcpy(buffer,cfg.cfg_fapath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		if (cfg.cfg_qwkname[0])
			{
			strcat(buffer,cfg.cfg_qwkname);
			strcat(buffer,".rep");
			}
		else 
			strcat(buffer,"simplex.rep");

		if (!access(buffer,0))
			unlink(buffer);

		if (!user_baud)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\n\r\nCopy from where (ENTER=Quit)? ",NULL);
			get_fname(buffer1,48,0,1);
			if (buffer1[0])
				{
				if (cfg.cfg_qwkname[0])
					sprintf(buffer,"%s.rep",cfg.cfg_qwkname);
				else 
					strcpy(buffer,"simplex.rep");

				if (buffer1[strlen(buffer1) - 1] != P_CSEP)
					strcat(buffer1,P_SSEP);
				expand_safe_fname(buffer1,buffer,PROT_DIRECT);
				if (cur_fnames)
					{
					copy_in(AREA_FATTACH,buffer1,fnames,cur_fnames,0);
					received = 1;

					for (count = 0; count < cur_fnames; count++)
						free(fnames[count]);
					free(fnames);
					fnames = NULL;
					cur_fnames = 0;
					max_fnames = 0;
					}
				else
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\nThe file you specified does not exist on the provided path!\r\n\r\n",NULL);
					get_enter();
					}
				}
			}
		else 
			{
			cur_line = 0;
			quit = 0;

			if (cfg.cfg_qwkname[0])
				sprintf(buffer1,"%s.rep",cfg.cfg_qwkname);
			else
				strcpy(buffer1,"simplex.rep");
			strupr(buffer1);
			sprintf(buffer,"\r\n\r\n--- Choose an Upload Protocol for the QWK \"%s\"  File ---\r\n\r\n",buffer1);

			do
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(WHITE | BRIGHT),NULL);
				key = send_string(buffer,qwk_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string("<1> Xmodem         <2> Xmodem-1K\r\n<3> Zmodem         <X> Exit\r\n\r\n",qwk_handler);
					else
						key = send_string("[ 123X ]\r\n\r\n",qwk_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Exit)? ",qwk_handler);
					}
				ok = 0;

				do
					{
					if (!key)
						key = get_char();
					else
						send_string("\r\n\r\nUpload using ",NULL);
					switch (key)
						{
						case '1':
							send_string("Xmodem\r\n",NULL);
							protocol = 0;
							quit = 1;
							ok = 1;
							break;
						case '2':
							send_string("Xmodem-1K\r\n",NULL);
							protocol = 1;
							quit = 1;
							ok = 1;
							break;
						case '3':
							send_string("Zmodem\r\n",NULL);
							protocol = 2;
							quit = 1;
							ok = 1;
							break;
						case 'X':
						case 'x':
						case '\r':
						case '\n':
							quit = 1;
							abort = 1;
							ok = 1;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!quit);

			if (!abort)
				{
				strcpy(buffer,cfg.cfg_fapath);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				sprintf(buffer1,"upload#%u.bbs",cfg.cfg_port);
				strcat(buffer,buffer1);

				if (!(listfd = fopen(buffer,"w+b")))
					{
					sprintf(buffer,"Unable to open %s in local f/attach area!",buffer1);
					_error(E_ERROR,buffer);
					system_message(buffer);
					return;
					}

				if (cfg.cfg_qwkname[0])
					sprintf(buffer1,"%s.rep",cfg.cfg_qwkname);
				else
					strcpy(buffer1,"simplex.rep");

				if (!protocol)
					x_recv(AREA_FATTACH,buffer1,listfd);		/* f/attach area is "dummy" 0 */
				else if (protocol == 1)
					x1k_recv(AREA_FATTACH,buffer1,listfd);	/* f/attach area is "dummy" 0 */
				else
					z_recv(AREA_FATTACH,listfd,check_qwk);			/* f/attach area is "dummy" 0 */

				fseek(listfd,0L,SEEK_SET);
				while (fgets(buffer,sizeof(buffer),listfd))
					{
					if (!strnicmp(buffer,"OK ",3))
						{
						++received;
						cptr = buffer + 4;
						cptr1 = fname;

						while (*cptr > ' ')
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
							++cptr;

						sprintf(buffer,"\"%s\" in local f/attach area.",fname);
						log_entry(L_UPLOAD,buffer);
						}
					else	   		/* delete any bad file fragments we might have left! */
						{
						cptr = buffer + 4;
						cptr1 = buffer1;

						while (*cptr > ' ')
							*cptr1++ = *cptr++;
						*cptr1 = '\0';

						strcpy(buffer,cfg.cfg_fapath);
						if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						strcat(buffer,buffer1);

						unlink(buffer);
						}
					}
				fclose(listfd);
				}
			}

		if (received)
			{
			/* now to unarchive the response messages */

			strcpy(buffer,cfg.cfg_fapath);
			if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			if (cfg.cfg_qwkname[0])
				{
				strcat(buffer,cfg.cfg_qwkname);
				strcat(buffer,".rep");
				}
			else 
				strcat(buffer,"simplex.rep");
			if (fd = fopen(buffer,"rb"))
				{
				buffer1[0] = '\0';
				fread(buffer1,4,1,fd);
				fclose(fd);

				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(CYAN | BRIGHT),NULL);
				send_string("Step 1:  QWK reply file was received....\r\n",NULL);

				if (buffer1[0] == '\x1a')
					{
					if (cfg.cfg_unarc[0])
						{
						send_string("Step 2:  Attempting to unARC file....\r\n",NULL);
						if (!unarchive_qwk(cfg.cfg_unarc))
							unarced = 1;
						}
					else
						noarchiver = 1;
					}
				else if (buffer1[0] == 'P' && buffer1[1] == 'K')
					{
					if (cfg.cfg_unzip[0])
						{
						send_string("Step 2:  Attempting to unZIP file....\r\n",NULL);
						if (!unarchive_qwk(cfg.cfg_unzip))
							unarced = 1;
						}
					else
						noarchiver = 1;
					}
				else if (buffer1[0] == 0x60 && buffer1[1] == 0xea)
					{
					if (cfg.cfg_unarj[0])
						{
						send_string("Step 2:  Attempting to unARJ file....\r\n",NULL);
						if (!unarchive_qwk(cfg.cfg_unarj))
							unarced = 1;
						}
					else
						noarchiver = 1;
					}
				else if (buffer1[0] == 'Z' && buffer1[1] == 'O')
					{
					if (cfg.cfg_unzoo[0])
						{
						send_string("Step 2:  Attempting to unZOO file....\r\n",NULL);
						if (!unarchive_qwk(cfg.cfg_unzoo))
							unarced = 1;
						}
					else
						noarchiver = 1;
					}
				else if (buffer1[2] == '-' && buffer1[3] == 'l')		/* bytes 2 and 3 are "-l" for LZH */
					{
					if (cfg.cfg_unlzh[0])
						{
						send_string("Step 2:  Attempting to unLZH file....\r\n",NULL);
						if (!unarchive_qwk(cfg.cfg_unlzh))
							unarced = 1;
						}
					else
						noarchiver = 1;
					}
				}
			if (unarced)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(CYAN | BRIGHT),NULL);
				send_string("Step 3:  Attempting to open QWK reply .MSG packet....\r\n",NULL);

				strcpy(buffer,cfg.cfg_fapath);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				if (cfg.cfg_qwkname[0])
					{
					strcat(buffer,cfg.cfg_qwkname);
					strcat(buffer,".msg");
					}
				else 
					strcat(buffer,"simplex.msg");

				if (fd = fopen(buffer,"rb"))
					{
					send_string("Step 4:  Checking that QWK reply .MSG packet is valid....\r\n",NULL);

					if (fread(buffer,128,1,fd) == 1)
						{
						if (cfg.cfg_qwkname[0])
							strcpy(buffer1,cfg.cfg_qwkname);
						else
							strcpy(buffer1,"simplex");
						strupr(buffer1);

						if (strnicmp(buffer,buffer1,strlen(buffer1)))
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("Error:  Invalid BBSID signature detected.\r\n\r\n",NULL);
							}
						else
							{
							send_string("Step 5:  Importing messages from QWK reply packet....\r\n\r\n",NULL);

							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(BROWN | BRIGHT),NULL);
							send_string("Msg #  Addressee (To)             Area  Area Name                         Type\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN | BRIGHT),NULL);
							send_string("-----  -------------------------  ----  --------------------------------  -----\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);

							while (fread(&tqwkh,sizeof(struct qwkh),1,fd))
								{
								cptr = tqwkh.qwkh_blks;
								cptr1 = buffer1;
								while (isdigit(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								blocks = atoi(buffer1);

								cptr = tqwkh.qwkh_number;
								cptr1 = buffer1;
								while (isdigit(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								area = atoi(buffer1);
								if (!area)
									area = tqwkh.qwkh_conf;			/* check alternate area location since area 0 is invalid */

								cur_line = 0;
								++msgnum;
								sprintf(buffer,"%5u  ",msgnum);
								send_string(buffer,NULL);

								if (tmsg = get_msgarea(area))
									{
									len = 0;		/* length read */
									tzone = 0;
									tnet = 0;
									tnode = 0;
									tcost = 0;
									tflags = 0;

									if ((unsigned int)user.user_priv < (unsigned int)tmsg->msg_writepriv || (tmsg->msg_writeflags & user.user_uflags) != tmsg->msg_writeflags)
										{
										sprintf(buffer,"Error:  You do not have write access to area number %u on this system.\r\n",area);
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(RED | BRIGHT),NULL);
										send_string(buffer,NULL);
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										fseek(fd,(long)(blocks - 1) * 128L,SEEK_CUR);
										}
									else if (tmsg->msg_flags & MSG_NET)		/* per Brady Flowers: this is the way Maximus does it */
										{
										tlong = ftell(fd);

										found = 0;

										fread(buffer,sizeof(char),4,fd);
										if (!strnicmp(buffer,"TO: ",4))
											{
											len = 4;		/* length read */
											cptr = buffer;
											while ((curchar = fgetc(fd)) != EOF)
												{
												++len;

												if (curchar == '\n' || curchar == '\r' || curchar == 0xe3)
													{
													*cptr = '\0';
													break;
													}
												else
													*cptr++ = (char)(unsigned char)curchar;
												}

											tzone = cfg.cfg_zone;	/* default to our zone if only net/node entered */
											tnet = cfg.cfg_net;		/* default to our net if only node entered */
											tnode = 0;

											cptr = buffer;
											if (isdigit(*cptr))
												{
												cptr1 = buffer1;
												while (isdigit(*cptr))
													*cptr1++ = *cptr++;
												*cptr1 = '\0';	
												tval = atoi(buffer1);	
												if (*cptr == ':')			/* was ZONE provided? Parse NET/NODE next */
													{
													tzone = tval;

													while (*cptr && !isdigit(*cptr))
														++cptr;
													cptr1 = buffer1;
													while (isdigit(*cptr))
														*cptr1++ = *cptr++;
													*cptr1 = '\0';
													tval = atoi(buffer1);
													if (*cptr == '/')
														{
														tnet = tval;

														while (*cptr && !isdigit(*cptr))
															++cptr;
														if (*cptr)
															{
															cptr1 = buffer1;
															while (isdigit(*cptr))
																*cptr1++ = *cptr++;
															*cptr1 = '\0';

															tnode = atoi(buffer1);
															found = 1;
															}
														}
													}
												else if (*cptr == '/')		/* was NET provided?  Parse NODE next */
													{
													tnet = tval;
													while (*cptr && !isdigit(*cptr))
														++cptr;
													if (*cptr)
														{
														cptr1 = buffer1;
														while (isdigit(*cptr))
															*cptr1++ = *cptr++;
														*cptr1 = '\0';
														tnode = atoi(buffer1);
														found = 1;
														}
													}
												else						/* was NODE provided alone? */
													{
													tnode = tval;
													found = 1;
													}
												}

											if (found)
												{
												count = 0;
												valid = 0;
												cur_zone = 0;
												fseek(nidxfd,0L,SEEK_SET);
												while (fread(&tnlix,sizeof(struct nlix),1,nidxfd))
													{
													if (tnlix.nlix_net != -1)
														{
														/* Version 6 nodelist encodes zones as node == -2  and regions as -1 */
														if (tnlix.nlix_node == NLIX_ZONE && tnlix.nlix_net != cur_zone)
															cur_zone = tnlix.nlix_net;
														if (tnlix.nlix_node == NLIX_ZONE || tnlix.nlix_node == NLIX_REGION)		/* so we can match network zone and regional hubs! */
															tnlix.nlix_node = 0;

														if (tnode == tnlix.nlix_node && tnet == tnlix.nlix_net && ((tzone && tzone == cur_zone) || !tzone))
															{
					   										valid = 1;
															break;
															}
														}
													++count;
													}
												if (valid)
													{
													fseek(nlstfd,(long)count * (long)sizeof(struct nl),SEEK_SET);
													fread(&tnl,sizeof(struct nl),1,nlstfd);

													/* look at cost and decide */
													if (tnl.nl_cost <= user.user_credit)
														{
														tcost = tnl.nl_cost;
														tflags = NET_DIRECT | NET_KILLSENT;
														}
													else
														{
														tcost = 0;
														tflags = NET_ROUTE | NET_KILLSENT;
														}
													}
												else
													{
													/* held by default -- if not in nodelist! */
													tcost = 0;
													tflags = NET_HOLD | NET_KILLSENT;
													}
												}
											}

										if (!found)
											{
											fseek(fd,tlong,SEEK_SET);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(RED | BRIGHT),NULL);
											send_string("Error:  Incorrect format for Netmail messages with an offline reader\r\n",NULL);
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
							
											fseek(fd,(long)(blocks - 1) * 128L,SEEK_CUR);
											}
										}
									else
										found = 1;

									if (found)
										{
										cptr = tqwkh.qwkh_to + 25;
										*cptr = (char)'\0';
										while ((isspace(*cptr) || !*cptr) && (cptr - tqwkh.qwkh_to) > 0)
											--cptr;
										if (!isspace(*cptr))
											++cptr;
										*cptr = (char)'\0';

										if (!stricmp(tqwkh.qwkh_to,"sysop") && cfg.cfg_sysopname[0] && ((tmsg->msg_flags & MSG_LOCAL) || ((tmsg->msg_flags & MSG_ECHO) && user.user_priv >= tmsg->msg_sysoppriv)))
											strcpy(name,cfg.cfg_sysopname);
										else
											strcpy(name,tqwkh.qwkh_to);

										tonames[0] = name;
										tonames[1] = NULL;

										cptr = tqwkh.qwkh_subject + 25;
										*cptr = (char)'\0';
										while ((isspace(*cptr) || !*cptr) && (cptr - tqwkh.qwkh_subject) > 0)
											--cptr;
										if (!isspace(*cptr))
											++cptr;
										*cptr = (char)'\0';


										/* now look for an antecedent message with the same subject */
										cptr = tqwkh.qwkh_subject;
										while (!strnicmp(cptr,"re:",3))
											{
											cptr += 3;
											while (*cptr && isspace(*cptr))
												++cptr;
											}

										prev = 0;
										message = (int)(filelength(fileno(msglfd)) / (long)sizeof(struct mlink)) - 1;
										fseek(msglfd,(long)message * (long)sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
												{
												fseek(msghfd,(long)message * (long)sizeof(struct msgh),SEEK_SET);
												if (fread(&tmsgh,sizeof(struct msgh),1,msghfd))
													{
													cptr1 = tmsgh.msgh_subject;
													while (!strnicmp(cptr1,"re:",3))
														{
														cptr1 += 3;
														while (*cptr1 && isspace(*cptr1))
															++cptr1;
														}
													if (!stricmp(cptr,cptr1))
														{
														prev = message + 1;				/* we found a match */
														break;
														}
													}
												}
											--message;
											}

										/* read in the message body and format it */
										total = (blocks - 1) * 128;
										cptr = buffer;
										*cptr = '\0';
										while ((len < total) && (curchar = fgetc(fd)) != EOF)
											{
											if (curchar == 0xe3)
												nl = 2;
											else if (curchar == '\t')
												*cptr++ = ' ';
											else if (curchar == 0x1b)			/* strip ESC from message */
												;
											else if (curchar >= ' ')
												*cptr++ = (char)(unsigned char)curchar;

											if (!nl && ((cptr - buffer) >= LINEWRAP))
												nl = 1;

											if (nl)
												{
												if (nl == 2)
													{
													if ((cptr - buffer1) > 0)		/* trim trailing spaces */
														{
														--cptr;		
														while (((cptr - buffer1) > 0) && isspace(*cptr))
															--cptr;
														++cptr;
														}
													*cptr++ = '\r';
													*cptr = '\0';

													if (!load_msg_line(buffer))
														{
														system_message("Fatal error in editor: Out of memory.  Message aborted!");
														fclose(fd);
														return;
														}

													cptr = buffer;
													*cptr = '\0';
													}
												else
													{
													*cptr = '\0';
													--cptr;
													if (isspace(*cptr))
														buffer1[0] = '\0';
													else
														{
														while (((cptr - buffer) >= 0) && !isspace(*cptr))
															--cptr;
														++cptr;
														if (strlen(cptr) <= LINEWRAP / 2)		/* LINEWRAP/2 key wrap limit */
															{
															strcpy(buffer1,cptr);			/* move the data to the new line */
															*cptr++ = (char)' ';
															*cptr = '\0';					/* cut off the end of the string which is now on another line */
															}
														else
															buffer1[0] = '\0';
														}

													*cptr++ = (char)(unsigned char)'\x8d';		/* soft-CR */
													*cptr = (char)'\0';

													if (!load_msg_line(buffer))
													 	{
													 	system_message("Fatal error in editor: Out of memory.  Message aborted!");
													 	fclose(fd);
													 	return;
														}

													strcpy(buffer,buffer1);
													cptr = buffer + strlen(buffer);
													}
												nl = 0;
												}
											++len;
											}

										if ((cptr - buffer) > 0)
											{
											if ((cptr - buffer) > 0)		/* trim trailing spaces */
												{
												--cptr;		
												while (((cptr - buffer) > 0) && isspace(*cptr))
													--cptr;
												++cptr;
												}
											*cptr++ = '\r';
											*cptr = '\0';

											if (!load_msg_line(buffer))
												{
												system_message("Fatal error in editor: Out of memory.  Message aborted!");
												fclose(fd);
												return;
												}
											}

										if ((tqwkh.qwkh_status == '+' || tqwkh.qwkh_status == '*') && tmsg->msg_flags & MSG_PRIVATE)
											private = MESSAGE_PRIVATE;
										else
											private = 0;

										if (!stricmp(tonames[0],"QMAIL") || !stricmp(tonames[0],"SIMPLEX") || !stricmp(tonames[0],cfg.cfg_qwkname))
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(RED | BRIGHT),NULL);
											send_string("Error:  Unable to handle QWK configuration messages.\r\n\r\n",NULL);
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											}
										else if (!stricmp(tonames[0],"users"))
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(RED | BRIGHT),NULL);
											send_string("Error:  Unable to send a message to \"users\".\r\n\r\n",NULL);
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											}
										else
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(CYAN | BRIGHT),NULL);
											sprintf(buffer,"%-25.25s  ",tonames[0]);
											send_string(buffer,NULL);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(MAGENTA | BRIGHT),NULL);
											sprintf(buffer,"%4u  %-32.32s  ",tmsg->msg_number,tmsg->msg_areaname);
											send_string(buffer,NULL);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(WHITE | BRIGHT),NULL);
											sprintf(buffer,"%s\r\n",(char *)(tmsg->msg_flags & MSG_NET ? "Net" : (tmsg->msg_flags & MSG_ECHO ? "Echo" : "Local")));
											send_string(buffer,NULL);

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);

											do_message(user.user_name,tonames,tqwkh.qwkh_subject,area,(unsigned int)user.user_priv,user.user_uflags,prev,private | MESSAGE_LOADED,tzone,tnet,tnode,tcost,tflags);
											}
										for (count = 0; count < cur_mlines; count++)
											{
											free(mlines[count]);
											mlines[count] = NULL;
											}
										cur_mlines = 0;
										}
									}
								else
									{
									sprintf(buffer,"Error:  There is no area number %u on this system.\r\n",area);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string(buffer,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									fseek(fd,(long)(blocks - 1) * 128L,SEEK_CUR);
									}
								}

							sprintf(buffer,"\r\nFinished importing %d message%s!\r\n\a\r\n",msgnum,(char *)(msgnum == 1 ? "" : "s"));
							send_string(buffer,NULL);
							get_enter();

							if (max_mlines)
								{
								free(mlines);
								mlines = NULL;
								max_mlines = 0;
								}
							}
						}
					else
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("Error:  Unable to read the QWK reply .MSG packet header.\r\n\r\n",NULL);
						}

					fclose(fd);
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("Error:  Unable to open QWK reply .MSG packet.\r\n\r\n",NULL);
					}
				}
			else if (noarchiver)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Error:  There is no unarchiver available to unarchive QWK reply packet.\r\n\r\n",NULL);
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Error:  Unable to unarchive QWK reply packet.\r\n\r\n",NULL);
				}
			}

		strcpy(buffer,cfg.cfg_fapath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		if (cfg.cfg_qwkname[0])
			{
			strcat(buffer,cfg.cfg_qwkname);
			strcat(buffer,".rep");
			}
		else 
			strcat(buffer,"simplex.rep");
		unlink(buffer);

		strcpy(buffer,cfg.cfg_fapath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		if (cfg.cfg_qwkname[0])
			{
			strcat(buffer,cfg.cfg_qwkname);
			strcat(buffer,".msg");
			}
		else 
			strcat(buffer,"simplex.msg");
		unlink(buffer);
		}
	else
		{
		sprintf(buffer,"There is no valid local file-attach path on this system!");
		_error(E_ERROR,buffer);
		system_message(buffer);
		}
	}

