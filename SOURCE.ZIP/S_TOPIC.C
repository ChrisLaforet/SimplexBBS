/* s_topic.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 25 May 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_topic.c_v  $
**                       $Date:   25 Oct 1992 14:07:56  $
**                       $Revision:   1.21  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"



extern struct msgh _far read_msg;		/* in read_indiv() - message header just read! */
struct top **topics = NULL;
int cur_topics = 0;
int max_topics = 0;
int topic_area = -1;	/* holds the number of last area scanned! */
struct mdata _far topic_mdata;


int max_topic;
int cur_topic_page;
int max_topic_page;


void deinit_topics(void)
	{
	int count;

	if (max_topics)
		{
		for (count = 0; count < cur_topics; count++)
			{
			free(topics[count]->top_subject);
			free(topics[count]);
			}
		free(topics);
		}
	topics = NULL;
	cur_topics = 0;
	max_topics = 0;
	topic_area = -1;
	}



int topic_handler(int key)
	{
	int tval;

	key = toupper(key);
	if (key == '?')
		return key;
	else if (isdigit(key))
		{
		tval = key - '0';
		if (tval <= max_topic)
			return key;
		}
	else if (key >= 'A' && key < ('A' + max_topic))
		return key;
	else if (key == 'N' && cur_topic_page != max_topic_page)
		return key;
	else if (key == 'P' && cur_topic_page)
		return key;
	return 0;
	}



void read_topics(int area,int priv,int pflags,int *total_msgs)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char buffer[100];
	char *cptr;
	int hold_total;
	int msgnum;
	int current;
	int tval;
	int found;
	int count;
	int quit = 0;
	int top = 0;
	int key;
	int ok;
	int new;
	int direction;
	int pause;
	int end;
	int rtn;

	tmsg = get_msgarea(area);
	if (area != topic_area || topic_mdata.mdata_msgs != mdata.mdata_msgs || topic_mdata.mdata_del != mdata.mdata_del)		/* rescan if different area or msg counts have changed */
		{
		deinit_topics();

		current = 0;
		for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
			{
			if (area == lastread[count]->lr_area)
				{
				current = lastread[count]->lr_prev + 1;
				break;
				}
			}

		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nPlease wait a few moments.  Scanning available topics....",NULL);
		fseek(msglfd,0L,SEEK_SET);
		tval = 0;
		while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
			{
			if (!(tmlink.mlink_flags & MSGH_DELETED) && tmlink.mlink_area == area)		/* message is not deleted */
				{
				fseek(msghfd,(long)tval * (long)sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh,sizeof(struct msgh),1,msghfd);

				strncpy(buffer,tmsgh.msgh_subject,70);
				buffer[70] = '\0';

				/* strip off trailing spaces */
				if (buffer[0])
					{
					cptr = buffer + (strlen(buffer) - 1);
					while ((cptr - buffer) != 0 && isspace(*cptr))
						*cptr-- = '\0';
					}

				/* strip off leading spaces and RE:'s */
				cptr = buffer;
				while (*cptr && (isspace(*cptr) || !strnicmp(cptr,"RE:",3)))
					{
					if (isspace(*cptr))
						++cptr;
					else
						cptr += 3;
					}

				for (count = 0, found = 0; count < cur_topics; count++)
					{
					if (!stricmp(topics[count]->top_subject,cptr))
						{
						found = 1;
						break;
						}
					}
				if (found)
					{
					++topics[count]->top_total;
					if (current <= tmsgh.msgh_number)
						{
						if (!topics[count]->top_new)
							topics[count]->top_startnew = tval + 1;		/* systemwide message # */
					    ++topics[count]->top_new;
						}
					}
				else 
					{
					if (cur_topics >= max_topics)
						{
						if (!(topics = realloc(topics,(max_topics += 50) * sizeof(struct top *))))
							{
							send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
							_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
							}
						}
					if (!(topics[cur_topics] = calloc(1,sizeof(struct top))))
						{
						send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
						_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
						}
					if (!(topics[cur_topics]->top_subject = calloc(strlen(cptr) + 1,sizeof(char))))
						{
						send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
						_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
						}
					strcpy(topics[cur_topics]->top_subject,cptr);
					topics[cur_topics]->top_start = tval + 1;		/* systemwide message number */
					topics[cur_topics]->top_total = 1;
					if (current <= tmsgh.msgh_number)
						{
						topics[cur_topics]->top_startnew = tval + 1;		/* systemwide message # */
				    	topics[cur_topics]->top_new = 1;
						}
					else
						{
				    	topics[cur_topics]->top_startnew = 0;
				    	topics[cur_topics]->top_new = 0;
						}
					++cur_topics;
					}
				}
			++tval;
			}
		topic_area = area;		/* set the area to ours */
		memcpy(&topic_mdata,&mdata,sizeof(struct mdata));	/* keep current message counts */
		send_string("Finished!\r\n\r\n",NULL);
		}

	do
		{
		cur_line = 0;
		if (!cur_topics)
			{
			topics = NULL;
			cur_topics = 0;
			max_topics = 0;
			topic_area = -1;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("There are not any topics in this area....\r\n\r\n",NULL);
			get_enter();
			break;
			}

		if (top && top >= cur_topics)
			top = ((top / 10) - 1) * 10;

		max_topic = (top + 9) < cur_topics ? 9 : cur_topics - top - 1;
		cur_topic_page = top / 10;
		max_topic_page = (cur_topics - 1) / 10;

		if (user.user_flags & USER_CLS)
			send_string("\f",NULL);
		else
			send_string("\r\n\r\n",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		sprintf(buffer,"Topics in Message Area \"%s\":  ",tmsg->msg_areaname);
		key = send_string(buffer,topic_handler);
		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(MAGENTA | BRIGHT),NULL);
			sprintf(buffer,"Page %d of %d.\r\n\r\n",cur_topic_page + 1,max_topic_page + 1);
			key = send_string(buffer,topic_handler);
			}
		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			key = send_string("Press  Topic or Subject Name [# of Msgs/# of New Msgs]\r\n",topic_handler);
			}
		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			key = send_string("-----  --------------------------------------------------------------------\r\n",topic_handler);
			}

		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN | BRIGHT),NULL);
			for (count = 0; count <= max_topic && !key; count++)
				{
				cur_line = 0;
				sprintf(buffer," %d %c%c  %-.55s [%d/%d]\r\n",count,(char)(topics[top + count]->top_new ? ('A' + count) : ' '),(char)(topics[top + count]->top_new ? '*' : ' '),topics[top + count]->top_subject[0] ? topics[top + count]->top_subject : "<No subject line>",topics[top + count]->top_total,topics[top + count]->top_new);
				if (key = send_string(buffer,topic_handler))
					break;
				}
			}

		if (!key)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Read Topics Menu ---\r\n\r\n",topic_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					if (!top)
						{
						if ((count + top) < cur_topics)
							sprintf(buffer,"<0-%d,A-%c> Read Topic  <N> Next  <?> Help!  <X> Exit\r\n\r\n",max_topic,'A' + max_topic);
						else 
							sprintf(buffer,"<0-%d,A-%c> Read Topic  <?> Help!  <X> Exit\r\n\r\n",max_topic,'A' + max_topic);
						}
					else if ((count + top) >= cur_topics)
						{
						if (!top)
							sprintf(buffer,"<0-%d,A-%c> Read Topic  <?> Help!  <X> Exit\r\n\r\n",max_topic,'A' + max_topic);
						else 
							sprintf(buffer,"<0-%d,A-%c> Read Topic  <P> Previous  <?> Help!  <X> Exit\r\n\r\n",max_topic,'A' + max_topic);
						}
					else 
						sprintf(buffer,"<0-%d,A-%c> Read Topic  <P> Previous  <N> Next  <?> Help!  <X> Exit\r\n\r\n",max_topic,'A' + max_topic);
					key = send_string(buffer,topic_handler);
					}
				else
					{
					if (!top)
						{
						if ((count + top) < cur_topics)
							sprintf(buffer,"[0->%d, A->%c or N?X ]\r\n\r\n",max_topic,'A' + (max_topic - 1));
						else 
							sprintf(buffer,"[0->%d, A->%c or ?X ]\r\n\r\n",max_topic,'A' + (max_topic - 1));
						}
					else if ((count + top) < cur_topics)
						{
						if (!top)
							sprintf(buffer,"[0->%d, A->%c or ?X ]\r\n\r\n",max_topic,'A' + (max_topic - 1));
						else 
							sprintf(buffer,"[0->%d, A->%c or P?X ]\r\n\r\n",max_topic,'A' + (max_topic - 1));
						}
					else 
						sprintf(buffer,"[0->%d or PN?X ]\r\n\r\n",max_topic);
					key = send_string(buffer,topic_handler);
					}
				}
			if (!key)
				key = send_string("What is your choice (ENTER=Exit)? ",topic_handler);
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
				case 'A':
				case 'a':
				case 'B':
				case 'b':
				case 'C':
				case 'c':
				case 'D':
				case 'd':
				case 'E':
				case 'e':
				case 'F':
				case 'f':
				case 'G':
				case 'g':
				case 'H':
				case 'h':
				case 'I':
				case 'i':
				case 'J':
				case 'j':
					if (isdigit(key))
						{
						tval = (int)(key - '0');
						new = 0;
						}
					else
						{
						tval = (int)(toupper(key) - 'A');
						if (tval <= max_topic)
							{
							if (topics[top + tval]->top_new)
								new = 1;
							else
								new = -1;
							}
						}
					if (tval <= max_topic && new != -1)
						{
						direction = 1;		/* forwards */

						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						sprintf(buffer,"\r\n\r\nReading topic thread \"%s\"\r\n",topics[top + tval]->top_subject);
						send_string(buffer,NULL);

						if (new)
							current = topics[top + tval]->top_startnew;
						else 
							current = topics[top + tval]->top_start;

						send_string("Do you want to pause after each message (ENTER=Yes)? ",NULL);
						if (get_yn_enter(1))
							pause = 1;
						else
							pause = 0;
						end = 0;
						hold_total = *total_msgs;
						do
							{
							if (rtn = read_individual(area,priv,pflags,total_msgs,current,1,pause,1,0,direction))
								{
								if (rtn == 2)
									direction = direction ? 0 : 1;

								if (read_msg.msgh_flags & MSGH_DELETED && read_msg.msgh_number == 1)	/* we deleted the first of our topic */
									topics[top + tval]->top_start = read_msg.msgh_next;

								if (direction)
									current = read_msg.msgh_next;	
								else
									current = read_msg.msgh_prev;
								if (!current)
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\nEnd of messages.   Press any key to continue or wait 5 seconds...",NULL);
									wait_key(5);
									send_string("\r\n\r\n",NULL);
									end = 1;
									}
								}
							else
								end = 1;
							}
						while (!end);

						if (hold_total != *total_msgs)
							{
							topics[top + tval]->top_total -= (hold_total - *total_msgs);  	/* will subtract if deleted, add if replies were added */
							if (!topics[top + tval]->top_total)		/* if we killed a topic completely, consolidate pointers */
								{
								free(topics[top + tval]->top_subject);
								free(topics[top + tval]);
								if ((top + tval + 1) < cur_topics)
									memmove(topics + (top + tval),topics + (top + tval + 1),(cur_topics - (top + tval + 1)) * sizeof(struct top *));
								--cur_topics;
								}
							else			/* in case we deleted the first of the chain! */
								{
								msgnum = topics[top + tval]->top_start;
								fseek(msghfd,(msgnum - 1) * sizeof(struct msgh),SEEK_SET);
								fread(&tmsgh,1,sizeof(struct msgh),msghfd);
								while (tmsgh.msgh_flags & MSGH_DELETED)
									{
									msgnum = tmsgh.msgh_next;
									fseek(msghfd,(msgnum - 1) * sizeof(struct msgh),SEEK_SET);
									fread(&tmsgh,1,sizeof(struct msgh),msghfd);
									}
								if (msgnum)
									topics[top + tval]->top_start = msgnum;
								}
							memcpy(&topic_mdata,&mdata,sizeof(struct mdata));	/* keep current message counts! -- Prevent rescan if we added/deleted in this area! */
							}
						ok = 1;
						}
					break;
				case 'P':
				case 'p':
					if (top)
						{
						top -= 10;
						ok = 1;
						}
					break;
				case 'N':
				case 'n':
					if ((top + count) < cur_topics)
						{
						top += 10;
						ok = 1;
						}
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					cur_line = 0;
					send_ansifile(cfg.cfg_screenpath,"TOPICHLP",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);
	}


