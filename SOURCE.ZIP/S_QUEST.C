/* s_quest.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 30 May 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_quest.c_v  $
**                       $Date:   25 Oct 1992 14:08:56  $
**                       $Revision:   1.20  $
**
*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include "simplex.h"



extern jmp_buf reset_bbs;



/* Questionnaire Language
**
**
** ASK (variable) (len)
**
** This will accept up to the maximum length specified of a user's input and
** store it in the variable specified.  After hitting Enter, the system will
** go to the next line.
**
**
** CHOOSE (variable) (choices)
**
** This will load the variable specified with the choice letter selected from
** the list of choices.
**
**
** CLS
**
** Clears the screen to the current color.
**
**
** COLOR (foreground) [(background)]
**
** Sets the current color to the specified foreground/background (optional)
** color.
**
**
** EXIT
**
** Immediately exits the questionnaire file.
**
**
** GOTO (labelname)
**
** Jumps to the label specified.  If label is not found, it will exit.
**
**
** HANGUP
**
** Disconnects the user immediately.
**											
**
** IF (variable) = ("string")  -or-  IF (variable) != ("string")
**  -or-  IF (variable) = (variable)  -or-  IF (variable) != (variable)
** ENDIF
**
** If the case is true, the questionnaire will fall into the if-endif.
** If it is not true, it will skip over it.
**
**
** LABEL (labelname)
**
** Sets the labelname as a point to which the GOTO will jump.  If a label is
** reused, then it will replace the previous use.
**
**
** LEAVEMESSAGE (area#) ("Username")
**
** Enters the message editor leaving a message the the specified user in the
** specified area.
**
**
** LOGENTRY ("Message")
**
** Enters the specified message in the Simplex sysop log.
**
**
** PRINT ("string")  -or-  PRINT (variable)
**
** Shows a string of contents of a variable on the screen.  Does not go to
** the next line.
**
**
** PRINTLINE ("string")  -or-  PRINTLINE (variable)
**
** Shows a string of contents of a variable on the screen.  This will then go
** to the next line.
**
**
** SET (variable) = ("string")  -or-  SET (variable) = (variable)
**
** Sets a variable to a string value or to the value of another variable.
**
**
** SETFLAG ("string")
**
** Turns on the flags indicated in the string for the user and makes a
** permanent change in their record.
**
**
** SETPRIV (Priv)
**
** Sets Users Privilege To Priv - If It's Legal.
**
**
** SHOW ("filename")
**
** Shows a file (filename.ans if ansi is on, otherwise filename.asc if it
** is not.
**
**
** UNSETFLAG ("string")
**
** Turns off the flags indicated in the string for the user and makes a
** permanent change in their record.
**
** WRITEINFO
**
** Writes the user's name, time and date, and other info to the questionnaire
** answer file.
**
**
** WRITE ("string")  -or-  WRITE (variable)
**
** Writes the string or variable to the questionnaire answer file.  This does
** not add a CR-LF pair at the end.
**
**
** WRITELINE ("string")  -or-  WRITELINE (variable)
**
** Writes the string or variable to the questionnaire answer file.  This adds
** a CR-LF pair at the end.
** 
*/


struct lbl
	{
	char *lbl_name;
	long lbl_offset;
	};

struct var
	{
	char *var_name;
	char var_value[81];
	};


struct lbl **labels = NULL;
int cur_labels = 0;
int max_labels = 0;
struct var **variables;
int cur_variables = 0;
int max_variables = 0;



int add_label(char *labelname,long offset)
	{
	int count;

	for (count = 0; count < cur_labels; count++)
		{
		if (!stricmp(labelname,labels[count]->lbl_name))
			{
			labels[count]->lbl_offset = offset;
			break;
			}
		}
	if (count >= cur_labels)
		{
		if (cur_labels >= max_labels)
			{
			if (!(labels = realloc(labels,(max_labels += 10) * sizeof(struct lbl *))))
				{
				send_string("Error: Out of memory for labels....Please notify Sysop...\r\n",NULL);
				return 1;
				}
			}
		if (!(labels[cur_labels] = calloc(1,sizeof(struct lbl))))
			{
			send_string("Error: Out of memory for labels....Please notify Sysop...\r\n",NULL);
			return 1;
			}
		if (!(labels[cur_labels]->lbl_name = calloc(strlen(labelname) + 1,sizeof(char))))
			{
			send_string("Error: Out of memory for labels....Please notify Sysop...\r\n",NULL);
			return 1;
			}
		strcpy(labels[cur_labels]->lbl_name,labelname);
		labels[cur_labels]->lbl_offset = offset;
		++cur_labels;
		}
	return 0;
	}



long get_label(char *labelname)
	{
	int count;

	for (count = 0; count < cur_labels; count++)
		{
		if (!stricmp(labelname,labels[count]->lbl_name))
			return labels[count]->lbl_offset;
		}
	return -1L;
	}



int add_variable(char *variablename)
	{
	int count;

	for (count = 0; count < cur_variables; count++)
		{
		if (!stricmp(variablename,variables[count]->var_name))
			break;
		}
	if (count >= cur_variables)
		{
		if (cur_variables >= max_variables)
			{
			if (!(variables = realloc(variables,(max_variables += 10) * sizeof(struct var *))))
				{
				send_string("Error: Out of memory for variables....Please notify Sysop...\r\n",NULL);
				return 1;
				}
			}
		if (!(variables[cur_variables] = calloc(1,sizeof(struct var))))
			{
			send_string("Error: Out of memory for variables....Please notify Sysop...\r\n",NULL);
			return 1;
			}
		if (!(variables[cur_variables]->var_name = calloc(strlen(variablename) + 1,sizeof(char))))
			{
			send_string("Error: Out of memory for variables....Please notify Sysop...\r\n",NULL);
			return 1;
			}
		strcpy(variables[cur_variables]->var_name,variablename);
		++cur_variables;
		}
	return 0;
	}



char *get_variable(char *variablename)
	{
	int count;

	for (count = 0; count < cur_variables; count++)
		{
		if (!stricmp(variablename,variables[count]->var_name))
			return variables[count]->var_value;
		}
	return NULL;
	}



static char _far buffer[256];
static char _far buffer1[256];
static char _far buffer2[256];



void do_questionnaire(char *filename)
	{
	char *cptr;
	char *cptr1;
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	DATE_T date;
	TIME_T time;
	long offset = 0L;
	int open_answer = 0;
	int key;
	int len;
	int fore;
	int tval;
	int comp;
	FILE *qfd;
	FILE *afd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nPlease wait a few moments...\r\n",NULL);

	strcpy(buffer,cfg.cfg_screenpath);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	_makepath(buffer,drive,path,fname,"QF");		/* questionnaire file */
	if (qfd = fopen(buffer,"rb"))
		{
		while (fgets(buffer,sizeof(buffer),qfd))
			{
			cptr = buffer;
			while (*cptr && !isalpha(*cptr))
				++cptr;
			cptr1 = buffer1;
			while (*cptr && !isspace(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (!stricmp(buffer1,"LABEL"))
				{
				while (*cptr && !isalpha(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					strupr(buffer1);
					add_label(buffer1,offset);
					}
				}
			else if (!stricmp(buffer1,"ASK"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					strupr(buffer1);
					if (add_variable(buffer1))
						{
						fclose(qfd);
						return;
						}
					}
				}
			else if (!stricmp(buffer1,"SET"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					strupr(buffer1);
					if (add_variable(buffer1))
						{
						fclose(qfd);
						return;
						}
					}
				}
			else if (!stricmp(buffer1,"CHOOSE"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					strupr(buffer1);
					if (add_variable(buffer1))
						{
						fclose(qfd);
						return;
						}
					}
				}
			else if (!stricmp(buffer1,"IF"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					strupr(buffer1);
					if (add_variable(buffer1))
						{
						fclose(qfd);
						return;
						}
					while (*cptr && !isalnum(*cptr) && *cptr != '"')
						++cptr;
					if (*cptr && *cptr != '"')
						{
						cptr1 = buffer1;
						while (*cptr && !isspace(*cptr))
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
						if (buffer1[0])
							{
							strupr(buffer1);
							if (add_variable(buffer1))
								{
								fclose(qfd);
								return;
								}
							}
						}
					}
				}
			else if (!stricmp(buffer1,"PRINT"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						strupr(buffer1);
						if (add_variable(buffer1))
							{
							fclose(qfd);
							return;
							}
						}
					}
				}
			else if (!stricmp(buffer1,"PRINTLINE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						strupr(buffer1);
						if (add_variable(buffer1))
							{
							fclose(qfd);
							return;
							}
						}
					}
				}
			else if (!stricmp(buffer1,"WRITE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						strupr(buffer1);
						if (add_variable(buffer1))
							{
							fclose(qfd);
							return;
							}
						}
					}
				open_answer = 1;
				}
			else if (!stricmp(buffer1,"WRITELINE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						strupr(buffer1);
						if (add_variable(buffer1))
							{
							fclose(qfd);
							return;
							}
						}
					}
				open_answer = 1;
				}
			else if (!stricmp(buffer1,"WRITEINFO"))
				open_answer = 1;

			offset = ftell(qfd);
			}

		if (open_answer)
			{
			_makepath(buffer,drive,path,fname,"AF");	/* answer file */
			if (!(afd = fopen(buffer,"r+b")))
				afd = fopen(buffer,"w+b");
			if (!afd)
				{
				sprintf(buffer,"Answer \"%s\" cannot be opened - please notify Sysop!",fname);
				_error(E_ERROR,buffer);
				system_message(buffer);
				fclose(qfd);
				return;
				}
			fseek(afd,0L,SEEK_END);
			}

		fseek(qfd,0L,SEEK_SET);
		while (fgets(buffer,sizeof(buffer),qfd))
			{
			cur_line = 0;		/* turns off more */
			cptr = buffer;
			while (*cptr && !isalpha(*cptr))
				++cptr;
			cptr1 = buffer1;
			while (*cptr && !isspace(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (!stricmp(buffer1,"ASK"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					while (*cptr && !isdigit(*cptr))
						++cptr;
					len = atoi(cptr);
					if (!len || len > 80)
						len = 80;
					if (cptr1 = get_variable(buffer1))
						get_field(cptr1,len,0);
					}
				}
			else if (!stricmp(buffer1,"HANGUP"))
				{
				hangup();
				longjmp(reset_bbs,2);
				}
			else if (!stricmp(buffer1,"CHOOSE"))
				{
				while (*cptr && !isalnum(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					cptr1 = buffer2;
					while (*cptr && isspace(*cptr))
						++cptr;
					while (*cptr && !isspace(*cptr))
						{
						if (*cptr != '"')
							*cptr1++ = *cptr++;
						else
							++cptr;
						}
					*cptr1 = '\0';
					cptr = get_variable(buffer1);
					if (cptr && buffer2[0])
						{
						strupr(buffer2);
						do
							{
							key = get_char();
							key = toupper(key);
							cptr1 = buffer2;
							while (*cptr1 && key != *cptr1)
								++cptr1;
							}
						while (!*cptr1);
						sprintf(cptr,"%c\0",key);
						sprintf(buffer,"%c\r\n",key);
						send_string(buffer,NULL);
						}
					}
				}
			else if (!stricmp(buffer1,"CLS"))
				{
				if (user.user_flags & USER_CLS)
					send_string("\f",NULL);
				else
					send_string("\r\n\r\n\r\n",NULL);
				}
			else if (!stricmp(buffer1,"COLOR"))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					{
					while (*cptr && !isdigit(*cptr))
						++cptr;
					if (*cptr)
						{
						fore = atoi(cptr);
						while (*cptr && !isspace(*cptr))
							++cptr;
						while (*cptr && !isdigit(*cptr))
							++cptr;
						if (*cptr)
							{
							tval = atoi(cptr);
							fore |= (tval << 4);
							}
						send_string(new_color(fore),NULL);
						}
					}
				}
			else if (!stricmp(buffer1,"ENDIF"))
				{
				/* skip over this now */
				}
			else if (!stricmp(buffer1,"EXIT"))
				break;
			else if (!stricmp(buffer1,"GOTO"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if ((offset = get_label(buffer1)) == -1L)
					break;
				else
					fseek(qfd,offset,SEEK_SET);
				}
			else if (!stricmp(buffer1,"IF"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					while (*cptr && *cptr != '!' && *cptr != '=')
						++cptr;
					if (*cptr == '=')
						comp = 1;		/* check for equality */
					else
						comp = 0;		/* check for inequality */
					while (*cptr && !isalnum(*cptr) && *cptr != '"')
						++cptr;
					if (*cptr)
						{
						if (*cptr != '"')
							{
							cptr1 = buffer2;
							while (*cptr && !isspace(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';
							cptr1 = get_variable(buffer2);
							}
						else
							{
							++cptr;
							cptr1 = buffer2;
							while (*cptr && *cptr != '"' && *cptr != '\r')
								*cptr1++ = *cptr++;
							*cptr1 = '\0';
							cptr1 = buffer2;
							}
						}
					cptr = get_variable(buffer1);
					if (cptr && cptr1)
						{
						if (comp)
							tval = stricmp(cptr,cptr1);
						else 
							tval = !stricmp(cptr,cptr1);
						if (tval)
							{
							while (fgets(buffer,sizeof(buffer),qfd))
								{
								cptr = buffer;
								while (*cptr && !isalpha(*cptr))
									++cptr;
								cptr1 = buffer1;
								while (*cptr && !isspace(*cptr))
									*cptr1++ = *cptr++;
								*cptr1 = '\0';
								if (!stricmp(buffer1,"ENDIF"))
									break;
								}
							}
						}
					}
				}
			else if (!stricmp(buffer1,"LABEL"))
				{
				/* skip over this now */
				}
			else if (!stricmp(buffer1,"PRINT"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (cptr1 = get_variable(buffer1))
						send_string(cptr1,NULL);
					}
				else
					{
					++cptr;
					cptr1 = buffer1;
					while (*cptr && *cptr != '"' && *cptr != '\r')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					send_string(buffer1,NULL);
					}
				}
			else if (!stricmp(buffer1,"PRINTLINE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (cptr1 = get_variable(buffer1))
						{
						send_string(cptr1,NULL);
						send_string("\r\n",NULL);
						}
					}
				else
					{
					++cptr;
					cptr1 = buffer1;
					while (*cptr && *cptr != '"' && *cptr != '\r')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					send_string(buffer1,NULL);
					send_string("\r\n",NULL);
					}
				}
			else if (!stricmp(buffer1,"LOGENTRY"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (cptr1 = get_variable(buffer1))
						log_entry(L_SYSOP_DEFINED,cptr1);
					}
				else
					{
					++cptr;
					cptr1 = buffer1;
					while (*cptr && *cptr != '"' && *cptr != '\r')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					log_entry(L_SYSOP_DEFINED,buffer1);
					}
				}
			else if (!stricmp(buffer1,"SET"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr))
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					while (*cptr && isspace(*cptr))
						++cptr;
					if (*cptr == '=')
						{
						++cptr;
						while (*cptr && isspace(*cptr))
							++cptr;
						if (*cptr != '"')
							{
							cptr1 = buffer2;
							while (*cptr && !isspace(*cptr))
								*cptr1++ = *cptr++;
							*cptr1 = '\0';
							cptr = get_variable(buffer1);
							cptr1 = get_variable(buffer2);
							if (cptr && cptr1)
								strcpy(cptr,cptr1);
							}
						else
							{
							++cptr;
							cptr1 = buffer2;
							while (*cptr && *cptr != '"' && *cptr != '\r')
								*cptr1++ = *cptr++;
							*cptr1 = '\0';
							cptr = get_variable(buffer1);
							if (cptr)
								strcpy(cptr,buffer2);
							}
						}
					}
				}
			else if (!stricmp(buffer1,"LEAVEMESSAGE"))
				{
				while (*cptr && !isdigit(*cptr))
					++cptr;
				if (*cptr)
					{
					tval = atoi(cptr);
					while (*cptr && isdigit(*cptr))
						++cptr;
					}
				else
					tval = 0;
				if (tval)			/* tval is the message area number! */
					{
					while (*cptr && (isspace(*cptr) || *cptr == '"'))
						++cptr;
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr) && *cptr != '"')
						{
						if (*cptr == '_')
							*cptr1++ = ' ';
						else
							*cptr1++ = *cptr;
						++cptr;
						}
					*cptr1 = '\0';
					if (buffer1[0])			/* we have an addressee! */
						dispatch_message(user.user_name,buffer1,NULL,tval,user.user_priv,user.user_uflags,0,0,0,0,0,0);
					}
				}
			else if (!stricmp(buffer1,"SETFLAG"))
				{
				while (*cptr && (isspace(*cptr) || *cptr == '"'))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr) && *cptr != '"')
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					add_flags(buffer1);
				}
			else if (!stricmp(buffer1,"SETPRIV"))
				{
				while (*cptr && !isdigit(*cptr))
					++cptr;
				if (*cptr)
					tval = atoi(cptr);
				else
					tval = 0;
				if (tval)
					set_privilege(tval);
				}
			else if (!stricmp(buffer1,"UNSETFLAG"))
				{
				while (*cptr && (isspace(*cptr) || *cptr == '"'))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr) && *cptr != '"')
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					del_flags(buffer1);
				}
			else if (!stricmp(buffer1,"SHOW"))
				{
				while (*cptr && (isspace(*cptr) || *cptr == '"'))
					++cptr;
				cptr1 = buffer1;
				while (*cptr && !isspace(*cptr) && *cptr != '"')
					*cptr1++ = *cptr++;
				*cptr1 = '\0';
				if (buffer1[0])
					{
					send_ansifile(cfg.cfg_screenpath,buffer1,0);
					send_string("\r\n",NULL);
					}
				}
			else if (!stricmp(buffer1,"WRITE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (cptr1 = get_variable(buffer1))
						fprintf(afd,"%s",cptr1);
					}
				else
					{
					++cptr;
					cptr1 = buffer1;
					while (*cptr && *cptr != '"' && *cptr != '\r')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					fprintf(afd,"%s",buffer1);
					}
				}
			else if (!stricmp(buffer1,"WRITELINE"))
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (*cptr != '"')
					{
					cptr1 = buffer1;
					while (*cptr && !isspace(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (cptr1 = get_variable(buffer1))
						fprintf(afd,"%s\r\n",cptr1);
					}
				else
					{
					++cptr;
					cptr1 = buffer1;
					while (*cptr && *cptr != '"' && *cptr != '\r')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					fprintf(afd,"%s\r\n",buffer1);
					}
				}
			else if (!stricmp(buffer1,"WRITEINFO"))
				{
				date = get_cdate();
				time = get_ctime();
				fprintf(afd,"\r\n*--------------------------------------------*\r\n");
				fprintf(afd,"* Questionnaire \"%s\" answered on %2d/%02d/%02d at %2d:%02d\r\n",fname,(date >> 5) & 0xf,date & 0x1f,((date >> 9) + 1980) % 100,
					time >> 11,(time >> 5) & 0x3f);
				fprintf(afd,"* User: %s\r\n",user.user_name);
				fprintf(afd,"* From: %s\r\n",user.user_city);
				fprintf(afd,"* Priv: %u\r\n\r\n",(unsigned int)user.user_priv);
				}
			}

		if (open_answer)
			fclose(afd);
		fclose(qfd);
		get_enter();
		}
	else
		{
		sprintf(buffer,"Questionnaire \"%s\" not found!!",fname);
		_error(E_ERROR,buffer);
		sprintf(buffer,"Questionnaire \"%s\" not found - please notify Sysop!",fname);
		system_message(buffer);
		}
	}
