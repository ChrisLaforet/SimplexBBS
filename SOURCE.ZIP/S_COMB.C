/* s_comb.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 17 March 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_comb.c_v  $
**                       $Date:   25 Oct 1992 14:08:46  $
**                       $Revision:   1.6  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include <io.h>
#include "simplex.h"




struct comb _far tcomb;
int comb_found = 0;
long comb_offset = 0L;
extern jmp_buf reset_bbs;



int cfgcomb_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'P':
		case 'A':
		case 'F':
		case 'S':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int scancomb_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'R':
		case 'N':
		case 'S':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int scancomb_search_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'T':
		case 'F':
		case 'S':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



void show_settings(int arc_flags)
	{
	char buffer[80];
	char *type;

	type = "None";
	if ((arc_flags & ARC_FLAG) && tcomb.comb_flags & COMB_USEARC)
		type = "Arc";
	if ((arc_flags & ZIP_FLAG) && tcomb.comb_flags & COMB_USEZIP)
		type = "Zip";
	if ((arc_flags & ARJ_FLAG) && tcomb.comb_flags & COMB_USEARJ)
		type = "Arj";
	if ((arc_flags & LZH_FLAG) && tcomb.comb_flags & COMB_USELZH)
		type = "Lzh";
	if ((arc_flags & ZOO_FLAG) && tcomb.comb_flags & COMB_USEZOO)
		type = "Zoo";

	sprintf(buffer,"  Mail packet type: %s\r\n",(char *)(tcomb.comb_flags & COMB_QWK ? "QWK" : "ASCII"));
	send_string(buffer,NULL);
	sprintf(buffer,"  Default archiver: %s\r\n",type);
	send_string(buffer,NULL);
//	sprintf(buffer," Personal messages: %s\r\n",(char *)(tcomb.comb_flags & COMB_PERSONAL ? "Include" : "Exclude"));
//	send_string(buffer,NULL);
	if (tcomb.comb_flags & COMB_QWK)
		{
		sprintf(buffer,"      Welcome file: %s\r\n",(char *)(tcomb.comb_flags & COMB_WELCOME ? "Include" : "Exclude"));
		send_string(buffer,NULL);
		sprintf(buffer,"Bulletin/news file: %s\r\n",(char *)(tcomb.comb_flags & COMB_NEWS ? "Include" : "Exclude"));
		send_string(buffer,NULL);
		sprintf(buffer,"      Goodbye file: %s\r\n",(char *)(tcomb.comb_flags & COMB_GOODBYE ? "Include" : "Exclude"));
		send_string(buffer,NULL);
		}
	sprintf(buffer,"    Sort topically: %s\r\n",(char *)(tcomb.comb_flags & COMB_TOPIC_SORT ? "Yes" : "No"));
	send_string(buffer,NULL);
	send_string("\r\n",NULL);
	}



void configure_combination(void)
	{
	char buffer[100];
	int arc_flags;
	int finished;
	int change = 0;
	int quit = 0;
	int showset = 1;
	int key;
	int ok;
	int ok1;

	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();

	arc_flags = 0;
	if (cfg.cfg_arc[0])
		arc_flags |= ARC_FLAG;
	if (cfg.cfg_zip[0])
		arc_flags |= ZIP_FLAG;
	if (cfg.cfg_lzh[0])
		arc_flags |= LZH_FLAG;
	if (cfg.cfg_arj[0])
		arc_flags |= ARJ_FLAG;
	if (cfg.cfg_zoo[0])
		arc_flags |= ZOO_FLAG;

	do
		{
		cur_line = 0;			/* defeat more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		purge_input(cfg.cfg_port);
		send_string("\r\n\r\n--- Combined Boards Configuration Menu ---\r\n\r\n",cfgcomb_handler);
		if (showset)
			{
			show_settings(arc_flags);
			showset = 0;
			}

		if (!(user.user_flags & USER_EXPERT))
			{					
			sprintf(buffer,"<C> Chg %s -> %s  <A> Set Archiver Type   <F> Set Flags\r\n",(char *)(tcomb.comb_flags & COMB_QWK ? "QWK" : "ASCII"),(char *)(tcomb.comb_flags & COMB_QWK ? "ASCII" : "QWK"));
			key = send_string(buffer,cfgcomb_handler);
			if (!key)				   
				key = send_string("<S> Show settings     <?> Help!   <X> Exit\r\n\r\n",cfgcomb_handler);
			}
		else
			key = send_string("[ CAFS?X ]\r\n\r\n",cfgcomb_handler);

		if (!key)
			key = send_string("What is your choice (ENTER=Exit)? ",cfgcomb_handler);

		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'C':
				case 'c':
					if (tcomb.comb_flags & COMB_QWK)
						tcomb.comb_flags &= ~COMB_QWK;
					else 
						tcomb.comb_flags |= COMB_QWK;
					change = 1;
					ok = 1;
					break;
				case 'A':
				case 'a':
					if (arc_flags)
						{
						finished = 0;
						do
							{
							ok1 = 0;
							do
								{
								cur_line = 0;			/* defeat more */
								send_string("\r\n\r\n---- Configure Default Archiver ----\r\n\r\n",NULL);
	 							if (arc_flags & ARC_FLAG)
									{
									sprintf(buffer,"<A> Select ARC (%s)\r\n",(char *)(tcomb.comb_flags & COMB_USEARC ? "ON" : "OFF"));
									send_string(buffer,NULL);
									}
	 							if (arc_flags & ZIP_FLAG)
									{
									sprintf(buffer,"<Z> Select ZIP (%s)\r\n",(char *)(tcomb.comb_flags & COMB_USEZIP ? "ON" : "OFF"));
									send_string(buffer,NULL);
									}
	 							if (arc_flags & LZH_FLAG)
									{
									sprintf(buffer,"<L> Select LZH (%s)\r\n",(char *)(tcomb.comb_flags & COMB_USELZH ? "ON" : "OFF"));
									send_string(buffer,NULL);
									}
	 							if (arc_flags & ARJ_FLAG)
									{
									sprintf(buffer,"<R> Select ARJ (%s)\r\n",(char *)(tcomb.comb_flags & COMB_USEARJ ? "ON" : "OFF"));
									send_string(buffer,NULL);
									}
	 							if (arc_flags & ZOO_FLAG)
									{
									sprintf(buffer,"<O> Select ZOO (%s)\r\n",(char *)(tcomb.comb_flags & COMB_USEZOO ? "ON" : "OFF"));
									send_string(buffer,NULL);
									}
								send_string("<C> Cancel Archiver\r\n",NULL);
								send_string("<X> Exit\r\n",NULL);
								send_string("\r\nWhat is your choice (ENTER=Exit)? ",NULL);

								key = get_char();
								switch (key)
									{
									case 'A':
									case 'a':
			 							if (arc_flags & ARC_FLAG)
											{
											tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
											tcomb.comb_flags |= COMB_USEARC;
											ok1 = 1;
											}
										break;
									case 'Z':
									case 'z':
			 							if (arc_flags & ZIP_FLAG)
											{
											tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
											tcomb.comb_flags |= COMB_USEZIP;
											ok1 = 1;
											}
										break;
									case 'L':
									case 'l':
			 							if (arc_flags & LZH_FLAG)
											{
											tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
											tcomb.comb_flags |= COMB_USELZH;
											ok1 = 1;
											}
										break;
									case 'R':
									case 'r':
			 							if (arc_flags & ARJ_FLAG)
											{
											tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
											tcomb.comb_flags |= COMB_USEARJ;
											ok1 = 1;
											}
										break;
									case 'O':
									case 'o':
			 							if (arc_flags & ZOO_FLAG)
											{
											tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
											tcomb.comb_flags |= COMB_USEZOO;
											ok1 = 1;
											}
										break;
									case 'C':
									case 'c':
										tcomb.comb_flags &= ~(COMB_USEARC | COMB_USEZIP | COMB_USELZH | COMB_USEZOO | COMB_USEARJ);
										ok1 = 1;
										break;
									case 'X':
									case 'x':
									case '\r':
									case '\n':
										finished = 1;
										ok1 = 1;
										break;
									}
								}
							while (!ok1);
							}
						while (!finished);
						change = 1;
						ok = 1;
						}
					break;
				case 'F':
				case 'f':
					finished = 0;
					do
						{
						ok1 = 0;
						do
							{
							cur_line = 0;			/* defeat more */
							send_string("\r\n\r\n---- Configure Includes ----\r\n\r\n",NULL);
//								sprintf(buffer,"<1> Include personal messages (%s) [Not Implemented].\r\n",(char *)(tcomb.comb_flags & COMB_PERSONAL ? "ON" : "OFF"));
//								send_string(buffer,NULL);
							sprintf(buffer,"<0> Sort messages topically (%s).\r\n",(char *)(tcomb.comb_flags & COMB_TOPIC_SORT ? "ON" : "OFF"));
							send_string(buffer,NULL);
							if (tcomb.comb_flags & COMB_QWK)
								{
								sprintf(buffer,"<1> Include welcome file (%s).\r\n",(char *)(tcomb.comb_flags & COMB_WELCOME ? "ON" : "OFF"));
								send_string(buffer,NULL);
								sprintf(buffer,"<2> Include bulletin/news file (%s).\r\n",(char *)(tcomb.comb_flags & COMB_NEWS ? "ON" : "OFF"));
								send_string(buffer,NULL);
								sprintf(buffer,"<3> Include goodbye file (%s).\r\n",(char *)(tcomb.comb_flags & COMB_GOODBYE ? "ON" : "OFF"));
								send_string(buffer,NULL);
								}
							send_string("<X> Exit\r\n",NULL);
							send_string("\r\nWhat is your choice (ENTER=Exit)? ",NULL);
						
							key = get_char();
							switch (key)
								{
								case '0':
									if (tcomb.comb_flags & COMB_TOPIC_SORT)
										tcomb.comb_flags &= ~COMB_TOPIC_SORT;
									else 
										tcomb.comb_flags |= COMB_TOPIC_SORT;
									break;
//									case '1':
//										if (tcomb.comb_flags & COMB_PERSONAL)
//											tcomb.comb_flags &= ~COMB_PERSONAL;
//										else 
//											tcomb.comb_flags |= COMB_PERSONAL;
//										break;
								case '1':
									if (tcomb.comb_flags & COMB_QWK)
										{
										if (tcomb.comb_flags & COMB_WELCOME)
											tcomb.comb_flags &= ~COMB_WELCOME;
										else 
											tcomb.comb_flags |= COMB_WELCOME;
										ok1 = 1;
										}
									break;
								case '2':
									if (tcomb.comb_flags & COMB_QWK)
										{
										if (tcomb.comb_flags & COMB_NEWS)
											tcomb.comb_flags &= ~COMB_NEWS;
										else 
											tcomb.comb_flags |= COMB_NEWS;
										ok1 = 1;
										}
									break;
								case '3':
									if (tcomb.comb_flags & COMB_QWK)
										{
										if (tcomb.comb_flags & COMB_GOODBYE)
											tcomb.comb_flags &= ~COMB_GOODBYE;
										else 
											tcomb.comb_flags |= COMB_GOODBYE;
										ok1 = 1;
										}
									break;
								case 'X':
								case 'x':
								case '\r':
								case '\n':
									finished = 1;
									ok1 = 1;
									break;
								}
							}
						while (!ok1);
						}
					while (!finished);
					change = 1;
					ok = 1;
					break;
				case 'S':
				case 's':
					showset = 1;
					ok = 1;
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					cur_line = 0;
					send_ansifile(cfg.cfg_screenpath,"COMBCFG",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);

	if (change)
		{
		fseek(combfd,comb_offset,SEEK_SET);
		fwrite(&tcomb,sizeof(struct comb),1,combfd);
		fflush(combfd);
		}
	}



void get_combination(void)
	{
	long offset;

	comb_found = 0;
	offset = ftell(combfd);
	fseek(combfd,0L,SEEK_SET);
	while (fread(&tcomb,sizeof(struct comb),1,combfd))
		{
		if (tcomb.comb_user == user_number)
			{
			comb_offset = offset;
			comb_found = 1;
			break;
			}
		offset = ftell(combfd);
		}
	if (!comb_found)
		{
		memset(&tcomb,0,sizeof(struct comb));
		tcomb.comb_user = user_number;
		comb_found = 1;
		comb_offset = filelength(fileno(combfd));
		}
	}



void set_combination(void)
	{
	struct msg *tmsg;
	char buffer[81];
	char buffer1[81];
	char *cptr;
	char *cptr1;
	int stop_flag = 0;
	int current;
	int change = 0;
	int quit = 0;
	int ok;
	int count;
	int kount;
	int key;
	int tval;
	int byte;
	int bit;
	int prev = 0;

	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nSet Combined Message Boards.  Please choose which boards you want to turn\r\n",NULL);
		send_string("  on or off.  Type in their numbers below and hit ENTER when finished.\r\n\r\n",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		current = 0;
		cur_line = 0;
		ok = 1;
		for (count = get_minmsgarea(); ok && count <= get_maxmsgarea(); count++)
			{
			if (tmsg = get_msgarea(count))
				{
				if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
					{
					if (current && !(current % 3))
						{
						send_string("\r\n",NULL);
						if (more_flag)
							stop_flag = 1;
						}
					byte = count / 8;
					bit = count % 8;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						{
						if (prev && !(tcomb.comb_areas[byte] & (1 << bit)))
							{
							send_string(new_color(CYAN | BRIGHT),NULL);
							if (more_flag)
								stop_flag = 1;
							prev = 0;
							}
						else if (!prev && (tcomb.comb_areas[byte] & (1 << bit)))
							{
							send_string(new_color(BROWN | BRIGHT),NULL);
							if (more_flag)
								stop_flag = 1;
							prev = 1;
							}
						}
					sprintf(buffer,"%4d: %-3.3s %.15s",count,(char *)(tcomb.comb_areas[byte] & (1 << bit) ? "ON" : "OFF"),tmsg->msg_areaname);
					send_string(buffer,NULL);
					if (more_flag)
						stop_flag = 1;
					for (kount = (int)strlen(buffer); kount < 26; kount++)
						{
						send_string(" ",NULL);
						if (more_flag)
							stop_flag = 1;
						}
					++current;
					}
				}

			if (!(current % 3))
				{
				if (stop_flag)
					ok = 0;
				else
					{
					update_clock();
					key = '\0';
					if (user_baud && !cd)
						longjmp(reset_bbs,1);
					if (user_baud && peek_input(cfg.cfg_port) != -1)
						key = read_input(cfg.cfg_port);
					else
						key = get_kb();
					switch (key)
						{
						case 'S':
						case 's':
							ok = 0;
							break;
						case 'P':
						case 'p':
							if (dopause())
								ok = 0;
							break;
						}
					}
				}
			}

		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nWhich boards to toggle, +/- = All on/off (ENTER=Exit)? ",NULL);
		get_numlist(buffer,22);
		if (!buffer[0])
			quit = 1;
		else 
			{
			cptr = buffer;
			while (*cptr)
				{
				while (*cptr && isspace(*cptr))
					++cptr;
				if (isdigit(*cptr))
					{
					cptr1 = buffer1;
					while (*cptr && isdigit(*cptr))
						*cptr1++ = *cptr++;
					*cptr1 = '\0';
					if (buffer1[0])
						{
						tval = atoi(buffer1);
						if (tval && (tmsg = get_msgarea(tval)))
							{
							if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
								{
								byte = tval / 8;
								bit = tval % 8;
								if (tcomb.comb_areas[byte] & (1 << bit))
									tcomb.comb_areas[byte] &= ~(1 << bit);
								else 
									tcomb.comb_areas[byte] |= (1 << bit);
								change = 1;
								}
							}
						}
					}
				else
					{
					if (*cptr == '+')
						{
						for (count = 0; count < MSG_AREAS; count++)
							tcomb.comb_areas[count] = (char)0xff;		/* all bits on */
						change = 1;
						}
					else if (*cptr == '-')
						{
						for (count = 0; count < MSG_AREAS; count++)
							tcomb.comb_areas[count] = (char)0;		/* all bits off */
						change = 1;
						}
					++cptr;
					}
				}

			}

		}
	while (!quit);

	if (change)
		{
		fseek(combfd,comb_offset,SEEK_SET);
		fwrite(&tcomb,sizeof(struct comb),1,combfd);
		fflush(combfd);
		}
	}



void read_combination(void)
	{
	char buffer[100];
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char *cptr;
	int total_msgs;
	int key;
	int which;
	int count;
	int kount;
	int actual;
	int quit = 0;
	int direction;
	int current;
	int pause;
	int out;
	int found;
	int rtn;
	int ok;
	int end;
	int done;
	int mode;
	int byte;
	int bit;

	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();
	do
		{
		cur_line = 0;			/* defeat more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		purge_input(cfg.cfg_port);
		key = send_string("\r\n\r\n--- Combined Boards Message Read Menu ---\r\n\r\n",scancomb_handler);
		if (!key)
			{
			if (!(user.user_flags & USER_EXPERT))
				{
				key = send_string("<F> Read Forward  <R> Read Reverse  <N> Read New      <S> Read Search\r\n",scancomb_handler);
				if (!key)
					key = send_string("<?> Help!         <X> Exit\r\n\r\n",scancomb_handler);
				}
			else
				key = send_string("[ FRNS?X ]\r\n\r\n",scancomb_handler);
			if (!key)
				key = send_string("What is your choice (ENTER=Exit)? ",scancomb_handler);
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'F':
				case 'f':
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
					if (get_yn_enter(1))
						pause = 1;
					else
						pause = 0;
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}

									end = 0;
									search_message();
									if (total_msgs)
										{
										actual = 1;
										current = 1;
										kount = 0;
										direction = 1;			/* forwards! */
										fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
												++kount;
											if (kount == current)
												break;
											++actual;
											}
										do
											{
											if (rtn = read_individual(which,user.user_priv,user.user_uflags,&total_msgs,actual,1,pause,1,1,direction))
												{
												if (rtn == 4)
													{
													end = 1;
													break;
													}

												if (rtn == 2)
													direction = direction ? 0 : 1;
												if (direction)
													{
													if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
														{
														++current;
														++actual;
														}
													else
														--kount;
													if (current > total_msgs)
														end = 1;
													else
														{
														search_message();
														fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																++kount;
															if (kount == current)
																break;
															++actual;
															}
														}
													}
												else
													{
													--current;
													--actual;
													if (!current || !actual)
														end = 1;
													else
														{
														search_message();
														fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																--kount;
															if (kount == current)
																break;
															--actual;
															fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
															}
														}
													}
												}
											else
												{
												end = 1;
												out = 1;
												}
											}
										while (!out && !end);
										}
									}
								}
							}
						}
					if (!out)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nEnd of messages....",NULL);
						}
					ok = 1;
					break;
				case 'R':
				case 'r':
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
					if (get_yn_enter(1))
						pause = 1;
					else
						pause = 0;
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}

									end = 0;
									search_message();
									if (total_msgs)
										{
										actual = mdata.mdata_msgs;
										kount = total_msgs + 1;
										current = total_msgs;
										direction = 0;			/* backwards! */
										fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
										while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
											{
											if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
												--kount;
											if (kount == current)
												break;
											--actual;
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											}
										do
											{
											if (rtn = read_individual(which,user.user_priv,user.user_uflags,&total_msgs,actual,1,pause,1,1,direction))
												{
												if (rtn == 4)
													{
													end = 1;
													break;
													}

												if (rtn == 2)
													direction = direction ? 0 : 1;
												if (direction)
													{
													if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
														{
														++current;
														++actual;
														}
													else
														--kount;
													if (current > total_msgs)
														end = 1;
													else
														{
														search_message();
														fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																++kount;
															if (kount == current)
																break;
															++actual;
															}
														}
													}
												else
													{
													--current;
													--actual;
													if (!current || !actual)
														end = 1;
													else
														{
														search_message();
														fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																--kount;
															if (kount == current)
																break;
															--actual;
															fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
															}
														}
													}
												}
											else
												{
												end = 1;
												out = 1;
												}
											}
										while (!end);
										}
									}
								}
							}
						}
					if (!out)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nEnd of messages....",NULL);
						}
					ok = 1;
					break;
				case 'N':
				case 'n':
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
					if (get_yn_enter(1))
						pause = 1;
					else
						pause = 0;
					out = 0;
					found = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount && !out; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if (total_msgs)
										{
										actual = 1;
										current = 1;
										for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
											{
											if (lastread[count]->lr_area == which)
												{
												current = lastread[count]->lr_prev + 1;
												break;
												}
											}

										if (!current)
											current = 1;
										direction = 1;		/* forwards first! */
										end = 0;
										for (count = current, kount = 0; count <= total_msgs && !out && !end; count++)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												if (kount == count)
													break;
												++actual;
												}

											do
												{
												found = 1;
												if (rtn = read_individual(which,user.user_priv,user.user_uflags,&total_msgs,actual,1,pause,1,1,direction))
													{
													if (rtn == 4)
														{
														end = 1;
														break;
														}

													if (rtn == 2)
														direction = direction ? 0 : 1;
													if (direction)
														{
														if (rtn != 3)		/* not deleted previous message, otherwise next message has same number! */
															{
															++current;
															++actual;
															}
														else
															--kount;
														if (current > total_msgs)
															end = 1;
														else
															{
															search_message();
															fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
															while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
																{
																if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																	++kount;
																if (kount == current)
																	break;
																++actual;
																}
															}
														}
													else
														{
														--current;
														--actual;
														if (!current || !actual)
															end = 1;
														else
															{
															search_message();
															fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
															while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
																{
																if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																	--kount;
																if (kount == current)
																	break;
																--actual;
																fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
																}
															}
														}
													}
												else
													{
													end = 1;
													out = 1;
													}
												}
											while (!end);
											}
										}
									}
								}
							}
						}
					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No new messages that you can access were found!\r\n",NULL);
						}
					else if (!out)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nEnd of messages....",NULL);
						}
					ok = 1;
					break;
				case 'S':
				case 's':
					end = 0;
					do
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(menu_color),NULL);
						purge_input(cfg.cfg_port);
						key = send_string("\r\n\r\n--- Combined Boards Read Search Menu ---\r\n\r\n",scancomb_search_handler);
						if (!key)
							{
							if (!(user.user_flags & USER_EXPERT))
								key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",scancomb_search_handler);
							else
								key = send_string("[ TFSX ]\r\n\r\n",scancomb_search_handler);
							if (!key)
								key = send_string("What is your choice (ENTER=Exit)? ",scancomb_search_handler);
							}
						done = 0;
						do
							{
							if (!key)
								key = get_char();
							switch (key)
								{
								case 'T':
								case 't':
								case 'F':
								case 'f':
								case 'S':
								case 's':
									cur_line = 0;
									if (key == 'T' || key == 't')
										mode = 0;
									else if (key == 'F' || key == 'f')
										mode = 1;
									else
										mode = 2;
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\n",NULL);
									if (!mode)
										send_string("Search for what in TO (ENTER=quit)? ",NULL);
									else if (mode == 1)
										send_string("Search for what in FROM (ENTER=quit)? ",NULL);
									else 
										send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
									get_field(buffer,30,1);

									if (buffer[0])
										{
										bm_setup(buffer,1);
										found = 0;
										send_string("\r\nDo you want to pause after each message (ENTER=Yes)? ",NULL);
										if (get_yn_enter(1))
											pause = 1;
										else
											pause = 0;
										out = 0;
										kount = 0;

										search_message();
										for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
											{
											byte = which / 8;
											bit = which % 8;
											if (tcomb.comb_areas[byte] & (1 << bit))
												{
												if (tmsg = get_msgarea(which))
													{
													if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
														{
														total_msgs = 0;
														for (count = 0; count < max_msgcount; count++)
															{
															if (msgcount[count].mc_area == which)
																{
																total_msgs = msgcount[count].mc_msgs;
																break;
			  													}
															}

														if (total_msgs)
															{
															actual = 1;

															fseek(msglfd,0L,SEEK_SET);
															while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
																{
																if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																	{
																	fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
																	fread(&tmsgh,1,sizeof(struct msgh),msghfd);
																	if (!mode)
																		cptr = tmsgh.msgh_to;
																	else if (mode == 1)
																		cptr = tmsgh.msgh_from;
																	else
																		cptr = tmsgh.msgh_subject;

																	if (bm_search(cptr) == -1)
																		{
																		++kount;
																		if (kount == 1 || !(kount % 10))
																			show_message_search(kount);
																		++actual;
																		continue;
																		}

//																	if (bm_search(cptr) != -1)
//																		{
																	rtn = read_individual(which,user.user_priv,user.user_uflags,&total_msgs,actual,1,pause,0,1,-1);
																	if (rtn == 4)
																		{
																		search_message();
																		break;
																		}
																	else if (!rtn)
																		{
																		out = 1;
																		break;
																		}
																	search_message();
																	found = 1;
																	fseek(msglfd,(long)actual * (long)sizeof(struct mlink),SEEK_SET);
//																		}
																	++kount;
																	if (kount == 1 || !(kount % 10))
																		show_message_search(kount);
																	}
																++actual;
																}
															}
														}
													}
												}
											}

										if (!found)
											{
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
											}
										}
									done = 1;
									break;
								case 'X':
								case 'x':
								case '\r':
								case '\n':
									end = 1;
									done = 1;
									break;
								}
							key = 0;
							}
						while (!done);
						}
					while (!end);
					ok = 1;
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					cur_line = 0;
					send_ansifile(cfg.cfg_screenpath,"READHELP",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);
	}



void scan_combination(void)
	{
	char buffer[100];
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char *cptr;
	int total_msgs;
	int key;
	int which;
	int count;
	int kount;
	int current;
	int actual;
	int quit = 0;
	int out;
	int found;
	int rtn;
	int mark = 0;
	int ok;
	int end;
	int mode;
	int byte;
	int bit;

	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();

	do
		{
		cur_line = 0;			/* defeat more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		purge_input(cfg.cfg_port);
		key = send_string("\r\n\r\n--- Combined Boards Message Scan Menu ---\r\n\r\n",scancomb_handler);
		if (!key)
			{
			if (!(user.user_flags & USER_EXPERT))
				{
				key = send_string("<F> Scan Forward  <R> Scan Reverse  <N> Scan New      <S> Scan Search\r\n",scancomb_handler);
				if (!key)
					key = send_string("<?> Help!         <X> Exit\r\n\r\n",scancomb_handler);
				}
			else
				key = send_string("[ FRNS?X ]\r\n\r\n",scancomb_handler);
			if (!key)
				key = send_string("What is your choice (ENTER=Exit)? ",scancomb_handler);
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'F':
				case 'f':
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
					if (get_yn_enter(0))
						mark = 1;
					else
						mark = 0;
					found = 0;
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\r\nScan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = 1;
										for (count = 1, kount = 0; count <= total_msgs; count++)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												++actual;
												if (kount == count)
													break;
												}

											if (rtn = do_scan(which,actual - 1,mark,total_msgs))
												{
												found = 1;
												if (rtn == 1)
													{
													out = 1;
													break;
													}
												}
											}
										}
									}
								}
							}
						}

					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'R':
				case 'r':
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
					if (get_yn_enter(0))
						mark = 1;
					else
						mark = 0;
					found = 0;
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\r\nScan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = mdata.mdata_msgs;

										for (count = total_msgs, kount = total_msgs + 1; count; count--)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													--kount;
												if (kount == count)
													break;
												--actual;
												fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
												}
											if (actual)
												{
												if (rtn = do_scan(which,actual,mark,total_msgs))
													{
	 												found = 1;
													if (rtn == 1)
														{
														out = 1;
														break;
														}
													}
												--actual;
												}
											else
												break;
											}
										}
									}
								}
							}
						}
					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'N':
				case 'n':
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
					if (get_yn_enter(0))
						mark = 1;
					else
						mark = 0;
					found = 0;
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\r\nScan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = 1;
										current = 1;
										for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
											{
											if (lastread[count]->lr_area == which)
												{
												current = lastread[count]->lr_prev + 1;
												break;
												}
											}

										if (!current)
											current = 1;

										for (count = current, kount = 0; count <= total_msgs; count++)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												++actual;
												if (kount == count)
													break;
												}
											if (rtn = do_scan(which,actual - 1,mark,total_msgs))
												{
												found = 1;
												if (rtn == 1)
													{
													out = 1;
													break;
													}
												}
											}
										}
									}
								}
							}
						}

					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'S':
				case 's':
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(menu_color),NULL);
					purge_input(cfg.cfg_port);
					key = send_string("\r\n\r\n--- Combined Boards Scan Search Menu ---\r\n\r\n",scancomb_search_handler);
					if (!key)
						{
						if (!(user.user_flags & USER_EXPERT))
							key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",scancomb_search_handler);
						else
							key = send_string("[ TFSX ]\r\n\r\n",scancomb_search_handler);
						if (!key)
							key = send_string("What is your choice (ENTER=Exit)? ",scancomb_search_handler);
						}
					end = 0;
					do
						{
						if (!key)
							key = get_char();
						switch (key)
							{
							case 'T':
							case 't':
							case 'F':
							case 'f':
							case 'S':
							case 's':
								cur_line = 0;
								if (key == 'T' || key == 't')
									mode = 0;
								else if (key == 'F' || key == 'f')
									mode = 1;
								else
									mode = 2;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\n",NULL);
								if (!mode)
									send_string("Search for what in TO (ENTER=quit)? ",NULL);
								else if (mode == 1)
									send_string("Search for what in FROM (ENTER=quit)? ",NULL);
								else 
									send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
								get_field(buffer,30,1);
								if (buffer[0])
									{
									bm_setup(buffer,1);
									found = 0;
									send_string("\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
									if (get_yn_enter(0))
										mark = 1;
									else
										mark = 0;
									out = 0;

									for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
										{
										byte = which / 8;
										bit = which % 8;
										if (tcomb.comb_areas[byte] & (1 << bit))
											{
											if (tmsg = get_msgarea(which))
												{
												if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
													{
													total_msgs = 0;
													for (count = 0; count < max_msgcount; count++)
														{
														if (msgcount[count].mc_area == which)
															{
															total_msgs = msgcount[count].mc_msgs;
															break;
			  												}
														}
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN | BRIGHT),NULL);
													send_string("\r\nScan of message board \"",NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(BROWN | BRIGHT),NULL);
													send_string(tmsg->msg_areaname,NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN | BRIGHT),NULL);
													send_string("\"....\r\n",NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN),NULL);

													if (total_msgs)
														{
														actual = 1;

														fseek(msglfd,0L,SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																{
																fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
																fread(&tmsgh,1,sizeof(struct msgh),msghfd);
																if (!mode)
																	cptr = tmsgh.msgh_to;
																else if (mode == 1)
																	cptr = tmsgh.msgh_from;
																else
																	cptr = tmsgh.msgh_subject;
																if (bm_search(cptr) != -1)
																	{
																	if (rtn = do_scan(which,actual,mark,total_msgs))
																		{
																		found = 1;
																		if (rtn == 1)
																			{
																			out = 1;
																			break;
																			}
																		}
																	}
																}
															++actual;
															}
														}
													}
												}
											}
										}

									if (!found)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
										}
									}
								end = 1;
								break;
							case 'X':
							case 'x':
							case '\r':
							case '\n':
								end = 1;
								break;
							}
						key = 0;
						}
					while (!end);
					ok = 1;
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					send_ansifile(cfg.cfg_screenpath,"SCANHELP",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);
	}



void qscan_combination(void)
	{
	char buffer[100];
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char *cptr;
	int total_msgs;
	int key;
	int actual;
	int count;
	int kount;
	int current;
	int quit = 0;
	int out;
	int found;
	int which;
	int rtn;
	int ok;
	int end;
	int mode;
	int byte;
	int bit;

	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();

	do
		{
		cur_line = 0;			/* defeat more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		purge_input(cfg.cfg_port);
		key = send_string("\r\n\r\n--- Combined Boards QuickScan Menu ---\r\n\r\n",scancomb_handler);
		if (!key)
			{
			if (!(user.user_flags & USER_EXPERT))
				{
				key = send_string("<F> Qscan Forward <R> Qscan Reverse <N> Qscan New     <S> Qscan Search\r\n",scancomb_handler);
				if (!key)
					key = send_string("<?> Help!         <X> Exit\r\n\r\n",scancomb_handler);
				}
			else
				key = send_string("[ FRNS?X ]\r\n\r\n",scancomb_handler);
			if (!key)
				key = send_string("What is your choice (ENTER=Exit)? ",scancomb_handler);
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'F':
				case 'f':
					found = 0;
					do_quickscanheader();
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("      Quickscan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = 1;

										for (count = 1, kount = 0; count <= total_msgs; count++)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												++actual;
												if (kount == count)
													break;
												}

											if (rtn = do_quickscan(which,actual - 1))
												{
												found = 1;
												if (rtn == 1)
													{
													out = 1;
													break;
													}
												}
											}
										}
									}
								}
							}
						}

					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'R':
				case 'r':
					found = 0;
					do_quickscanheader();
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("      Quickscan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = mdata.mdata_msgs;

										for (count = total_msgs, kount = total_msgs + 1; count; count--)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													--kount;
												if (kount == count)
													break;
												--actual;
												fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
												}
											if (actual)
												{
												if (rtn = do_quickscan(which,actual))
													{
													found = 1;
													if (rtn == 1)
														{
														out = 1;
														break;
														}
													}
												--actual;
												}
											else
												break;
											}
										}
									}
								}
							}
						}
					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'N':
				case 'n':
					found = 0;
					do_quickscanheader();
					out = 0;

					for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
						{
						byte = which / 8;
						bit = which % 8;
						if (tcomb.comb_areas[byte] & (1 << bit))
							{
							if (tmsg = get_msgarea(which))
								{
								if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
									{
									total_msgs = 0;
									for (count = 0; count < max_msgcount; count++)
										{
										if (msgcount[count].mc_area == which)
											{
											total_msgs = msgcount[count].mc_msgs;
											break;
			  								}
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("      Quickscan of message board \"",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("\"....\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);

									if (total_msgs)
										{
										actual = 1;
										current = 1;
										for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
											{
											if (lastread[count]->lr_area == which)
												{
												current = lastread[count]->lr_prev + 1;
												break;
												}
											}

										if (!current)
											current = 1;

										for (count = current, kount = 0; count <= total_msgs; count++)
											{
											fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
													++kount;
												++actual;
												if (kount == count)
													break;
												}
											if (rtn = do_quickscan(which,actual - 1))
												{
												found = 1;
												if (rtn == 1)
													{
													out = 1;
													break;
													}
												}
											}
										}
									}
								}
							}
						}
					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
						}
					ok = 1;
					break;
				case 'S':
				case 's':
					found = 0;
					cur_line = 0;

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(menu_color),NULL);
					purge_input(cfg.cfg_port);
					key = send_string("\r\n\r\n--- Combined Boards QuickScan Search Menu ---\r\n\r\n",scancomb_search_handler);
					if (!key)
						{
						if (!(user.user_flags & USER_EXPERT))
							key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",scancomb_search_handler);
						else
							key = send_string("[ TFSX ]\r\n\r\n",scancomb_search_handler);
						if (!key)
							key = send_string("What is your choice (ENTER=Exit)? ",scancomb_search_handler);
						}
					end = 0;
					do
						{
						if (!key)
							key = get_char();
						switch (key)
							{
							case 'T':
							case 't':
							case 'F':
							case 'f':
							case 'S':
							case 's':
								cur_line = 0;
								if (key == 'T' || key == 't')
									mode = 0;
								else if (key == 'F' || key == 'f')
									mode = 1;
								else
									mode = 2;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\n",NULL);
								if (!mode)
									send_string("Search for what in TO (ENTER=quit)? ",NULL);
								else if (mode == 1)
									send_string("Search for what in FROM (ENTER=quit)? ",NULL);
								else 
									send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
								get_field(buffer,30,1);
								if (buffer[0])
									{
									bm_setup(buffer,1);
									found = 0;
									do_quickscanheader();
									out = 0;

									for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
										{
										byte = which / 8;
										bit = which % 8;
										if (tcomb.comb_areas[byte] & (1 << bit))
											{
											if (tmsg = get_msgarea(which))
												{
												if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
													{
													total_msgs = 0;
													for (count = 0; count < max_msgcount; count++)
														{
														if (msgcount[count].mc_area == which)
															{
															total_msgs = msgcount[count].mc_msgs;
															break;
			  												}
														}
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN | BRIGHT),NULL);
													send_string("      Quickscan of message board \"",NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(BROWN | BRIGHT),NULL);
													send_string(tmsg->msg_areaname,NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN | BRIGHT),NULL);
													send_string("\"....\r\n",NULL);
													if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
														send_string(new_color(CYAN),NULL);

													if (total_msgs)
														{
														actual = 1;

														fseek(msglfd,0L,SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																{
																fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
																fread(&tmsgh,1,sizeof(struct msgh),msghfd);
																if (!mode)
																	cptr = tmsgh.msgh_to;
																else if (mode == 1)
																	cptr = tmsgh.msgh_from;
																else
																	cptr = tmsgh.msgh_subject;
																if (bm_search(cptr) != -1)
																	{
																	if (rtn = do_quickscan(which,actual))
																		{
																		found = 1;
																		if (rtn == 1)
																			{
																			out = 1;
																			break;
																			}
																		}
																	}
																}
															++actual;
															}
														}
													}
												}
											}
										}
									if (!found)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
										}
									}
								end = 1;
								break;
							case 'X':
							case 'x':
							case '\r':
							case '\n':
								end = 1;
								break;
							}
						key = 0;
						}
					while (!end);
					ok = 1;
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					send_ansifile(cfg.cfg_screenpath,"QSHELP",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);
	}
