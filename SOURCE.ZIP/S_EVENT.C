/* s_event.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 27 October 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_event.c_v  $
**                       $Date:   25 Oct 1992 14:08:28  $
**                       $Revision:   1.18  $
**
*/


#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "simplex.h"



struct evt **events = NULL;
int max_events = 0;
int cur_events = 0;

TIME_T next_etime = 0;
DATE_T next_edate = 0;
int next_eerrorlevel = 0;
int next_eforced = 0;
char next_etitle[21] = "\0";




static int comp_event(struct evt **arg1,struct evt **arg2)
	{
	return (int)((*arg1)->evt_time - (*arg2)->evt_time);
	}



void load_events(char *filename)
	{
	struct evt tevt;
	int count;
	FILE *fd;

	if (cur_events)		/* in case we are re-initializing */
		{
		for (count = 0; count < cur_events; count++)
			free(events[count]);
		free(events);
		events = NULL;
		cur_events = 0;
		max_events = 0;
		}

	if (fd = fopen(filename,"rb"))
		{
		while (fread(&tevt,sizeof(struct evt),1,fd))
			{
			if (tevt.evt_enabled && !tevt.evt_deleted)
				{
				if (cur_events >= max_events)
					{
					if (!(events = realloc(events,(max_events += 10) * sizeof(struct evt *))))
						_error(E_FATAL,"Out of memory while allocating for events...Aborting!");
					}
				if (!(events[cur_events] = malloc(sizeof(struct evt))))
					_error(E_FATAL,"Out of memory while allocating for events...Aborting!");
				memcpy(events[cur_events],&tevt,sizeof(struct evt));
				++cur_events;
				}
			}
		if (cur_events)
			qsort(events,cur_events,sizeof(struct evt *),comp_event);
		fclose(fd);
		}
	}



void get_next_event(void)
	{
	struct tm *tmptr;
	struct tm ttm;
	long midnight;
	int curtime;
	int evttime;
	int today;
	int tomorrow;
	int count;
	int next_evttime = 0x7fff;
	int day;

	time((time_t *)&midnight);				/* we need a starting position for midnight today! */
	tmptr = localtime((time_t *)&midnight);

	day = tmptr->tm_wday;
	curtime = tmptr->tm_hour * 60 + tmptr->tm_min;

	memcpy(&ttm,tmptr,sizeof(struct tm));
	ttm.tm_sec = 0;
	ttm.tm_min = 0;
	ttm.tm_hour = 0;
	midnight = (long)mktime(&ttm);		/* get midnight */
	
	next_etime = -1;
	next_edate = -1;

	switch (day)
		{
		case 0:
			today = 0x40;
			tomorrow = 0x20;
			break;
		case 1:
			today = 0x20;
			tomorrow = 0x10;
			break;
		case 2:
			today = 0x10;
			tomorrow = 0x8;
			break;
		case 3:
			today = 0x8;
			tomorrow = 0x4;
			break;
		case 4:
			today = 0x4;
			tomorrow = 0x2;
			break;
		case 5:
			today = 0x2;
			tomorrow = 0x1;
			break;
		case 6:
			today = 0x1;
			tomorrow = 0x40;
			break;
		default:
			today = 0;
			tomorrow = 0;
			break;
		}

	/* now to scan and discover the next event time */
	for (count = 0; count < cur_events; count++)
		{
		if (events[count]->evt_days & (today | tomorrow))
			{
			if (events[count]->evt_days & today)
				{
				evttime = (events[count]->evt_time >> 11) * 60 + ((events[count]->evt_time >> 5) & 0x3f);
				if (evttime >= curtime && evttime < next_evttime)
					{
					next_evttime = evttime;
					next_etime = events[count]->evt_time;
					next_edate = get_cdate();
					next_eerrorlevel = (unsigned int)(unsigned char)events[count]->evt_errorlevel;
					strcpy(next_etitle,events[count]->evt_title);
					next_eforced = events[count]->evt_forced;
					}
				}
			if (events[count]->evt_days & tomorrow)
				{
				evttime = (events[count]->evt_time >> 11) * 60 + ((events[count]->evt_time >> 5) & 0x3f) + 1440;
				if (evttime >= curtime && evttime < next_evttime)
					{
					next_evttime = evttime;
					next_etime = events[count]->evt_time;
					next_edate = new_date(get_cdate(),1);
					next_eerrorlevel = (unsigned int)(unsigned char)events[count]->evt_errorlevel;
					strcpy(next_etitle,events[count]->evt_title);
					next_eforced = events[count]->evt_forced;
					}
				}
			}
		}
	}		 



int check_events(void)
	{
	struct tm *tmptr;
	struct tm ttm;
	char buffer[100];
	long midnight;
	long event_logoff;
	long new_time;
	int curtime;
	int evttime;
	int today;
	int tomorrow;
	int count;
	int next_evt;
	int next_evttime = 0x7fff;
	int day;

	time((time_t *)&midnight);				/* we need a starting position for midnight today! */
	tmptr = localtime((time_t *)&midnight);

	day = tmptr->tm_wday;
	curtime = tmptr->tm_hour * 60 + tmptr->tm_min;

	memcpy(&ttm,tmptr,sizeof(struct tm));
	ttm.tm_sec = 0;
	ttm.tm_min = 0;
	ttm.tm_hour = 0;
	midnight = (long)mktime(&ttm);		/* get midnight */
	
	next_etime = -1;
	next_edate = -1;

	switch (day)
		{
		case 0:
			today = 0x40;
			tomorrow = 0x20;
			break;
		case 1:
			today = 0x20;
			tomorrow = 0x10;
			break;
		case 2:
			today = 0x10;
			tomorrow = 0x8;
			break;
		case 3:
			today = 0x8;
			tomorrow = 0x4;
			break;
		case 4:
			today = 0x4;
			tomorrow = 0x2;
			break;
		case 5:
			today = 0x2;
			tomorrow = 0x1;
			break;
		case 6:
			today = 0x1;
			tomorrow = 0x40;
			break;
		default:
			today = 0;
			tomorrow = 0;
			break;
		}

	/* now to scan and discover the next event time */
	for (count = 0; count < cur_events; count++)
		{
		if (events[count]->evt_enabled)
			{
			if (events[count]->evt_forced)
				{
				if (events[count]->evt_days & (today | tomorrow))
					{
					if (events[count]->evt_days & today)
						{
						evttime = (events[count]->evt_time >> 11) * 60 + ((events[count]->evt_time >> 5) & 0x3f);
						if (evttime >= curtime && evttime < next_evttime)
							{
							next_evttime = evttime;
							next_etime = events[count]->evt_time;
							next_edate = get_cdate();
							next_eerrorlevel = (unsigned int)(unsigned char)events[count]->evt_errorlevel;
							strcpy(next_etitle,events[count]->evt_title);
							next_eforced = 1;
							next_evt = count;
							}
						}
					if (events[count]->evt_days & tomorrow)
						{
						evttime = (events[count]->evt_time >> 11) * 60 + ((events[count]->evt_time >> 5) & 0x3f) + 1440;
						if (evttime >= curtime && evttime < next_evttime)
							{
							next_evttime = evttime;
							next_etime = events[count]->evt_time;
							next_edate = new_date(get_cdate(),1);
							next_eerrorlevel = (unsigned int)(unsigned char)events[count]->evt_errorlevel;
							strcpy(next_etitle,events[count]->evt_title);
							next_eforced = 1;
							next_evt = count;
							}
						}
					}
				}
			}
		}

	if (next_evttime != 0x7fff)
		{
		event_logoff = midnight + ((long)next_evttime * 60L);
		new_time = event_logoff - projected_time(0L) - 120L;

		if (event_logoff <= logoff_time)
			{
			if (new_time <= 120L)
				set_logofftime(120L);		/* give person 2 minutes to leave */
			else
				set_logofftime(new_time);
			user_time = remaining_time();

			cur_line = 0;
			if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			sprintf(buffer,"\r\n\aNotice: A forced system event is scheduled to occur in %d minutes.\r\n",next_evttime - curtime);
			send_string(buffer,NULL);
			if (events[next_evt]->evt_title[0])
				{
				sprintf(buffer,"The event is called \"%s\".\r\n",events[next_evt]->evt_title);
				send_string(buffer,NULL);
				}
			sprintf(buffer,"Your time online has been set to %ld minutes.\r\n",user_time / 60L);
			send_string(buffer,NULL);
			return 1;
			}
		}
	return 0;
	}		 
