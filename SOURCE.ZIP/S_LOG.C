/* s_log.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 26 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_log.c_v  $
**                       $Date:   25 Oct 1992 14:09:24  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include "simplex.h"




#define BUFSIZE				1024


static char logbuf[BUFSIZE];
extern jmp_buf reset_bbs;



void log_entry(int type,char *string)
	{
	static int blown = 0;
	DATE_T date;
	TIME_T time;
	int temp;

	date = get_cdate();
	time = get_ctime();
	temp = ((date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	fseek(logfd,0L,SEEK_END);
	fprintf(logfd,"[%2d-%s-%02d %2d:%02d] ",date & 0x1f,months_table[temp],((date >> 9) + 1980) % 100,
		time >> 11,(time >> 5) & 0x3f);

	switch (type)
		{
		case L_WARNING:
			sprintf(logbuf,"    Warning: %s\r\n",string);
			break;
		case L_ERROR:
			sprintf(logbuf," !  Error: %s\r\n",string);
			break;
		case L_FATAL:
			sprintf(logbuf," !! Fatal Error: %s\r\n",string);
			break;

		case L_START:
			sprintf(logbuf,"    Starting SIMPLEX BBS\r\n");
			break;
		case L_STOP:
			sprintf(logbuf,"    Ending SIMPLEX BBS\r\n");
			break;

		case L_LOGIN:
			sprintf(logbuf," &  Login of %s\r\n",string);
			break;
		case L_LOGOUT:
			sprintf(logbuf,"    Logout of %s\r\n",string);
			break;
		case L_NEWUSER:
			sprintf(logbuf," *  New user %s online\r\n",string);
			break;
		case L_CHANGENAME:
			sprintf(logbuf," !  Reentering name\r\n");
			break;
		case L_INVALID_NAME:
			sprintf(logbuf," !! %s is not a pre-registered user.\r\n",string);
			break;
		case L_INVALID_PWD:
			sprintf(logbuf," !! Invalid password %s\r\n",string);
			break;
		case L_DROPFILE_LOGIN:
			sprintf(logbuf,"    Automatic dropfile login of %s\r\n",string);
			break;
		case L_DROPFILE_ERROR:
			sprintf(logbuf," !  Error with dropfile login: %s\r\n",string);
			break;
		case L_NONGRATA:
			sprintf(logbuf," !! Dropping \"%s\" as a persona-non-grata\r\n",string);
			break;
		case L_CHANGEALIAS:
			sprintf(logbuf," &  User changed alias \"%s\".\r\n",string);
			break;
		case L_NEWALIAS:
			sprintf(logbuf," &  User set new alias \"%s\".\r\n",string);
			break;
		case L_DELETEALIAS:
			sprintf(logbuf," &  User deleted alias.\r\n");
			break;
		case L_INVALIDALIAS:
			sprintf(logbuf," !& User attempted to enter invalid alias \"%s\".\r\n",string);
			break;

		case L_NOCARRIER:
			sprintf(logbuf," ** Carrier was dropped/Lost caller!\r\n");
			break;
		case L_ONLINE:
			sprintf(logbuf," *  %s\r\n",string);
			break;
		case L_CONNECT:
			sprintf(logbuf,"    Connect at %s baud\r\n",string);
			break;
		case L_YELL:
			sprintf(logbuf,"    Yelling for chat with Sysop\r\n");
			break;
		case L_YELLREASON:
			sprintf(logbuf,"    Yell Reason: %s\r\n",string);
			break;
		case L_CHAT:
			sprintf(logbuf,"    Entered chat mode with Sysop\r\n");
			break;

		case L_MSGENTERED:
			sprintf(logbuf,"    Entered message %s\r\n",string);
			break;
		case L_MSGALIAS:
			sprintf(logbuf,"    User entered message with alias \"%s\"\r\n",string);
			break;
		case L_MSGDELETED:
			sprintf(logbuf,"    Deleted message %s\r\n",string);
			break;
		case L_MSGMOVED:
			sprintf(logbuf,"    Moved message %s\r\n",string);
			break;
		case L_MSGEXPORTED:
			sprintf(logbuf,"    Exported message %s to disk\r\n",string);
			break;

		case L_FILEDELETED:
			sprintf(logbuf,"    Killed file %s\r\n",string);
			break;

		case L_ADENTERED:
			sprintf(logbuf,"    Entered advertisement in area \"%s\"\r\n",string);
			break;
		case L_ADDELETED:
			sprintf(logbuf,"    Deleted advertisement %s\r\n",string);
			break;

		case L_RUN:
			sprintf(logbuf,"    Running command \"%s\"\r\n",string);
			break;
		case L_RUN_FAILED:
			sprintf(logbuf," !  Failed run: %s\r\n",string);
			break;

		case L_USERCHANGE:
			sprintf(logbuf,"    Changed information on user %s\r\n",string);
			break;

		case L_USERSTAT_POSTED:
			sprintf(logbuf," *     User posted %s\r\n",string);
			break;
		case L_USERSTAT_READ:
			sprintf(logbuf," *     User read %s\r\n",string);
			break;
		case L_USERSTAT_UPLOADED:
			sprintf(logbuf," *     User uploaded %s\r\n",string);
			break;
		case L_USERSTAT_DOWNLOADED:
			sprintf(logbuf," *     User downloaded %s\r\n",string);
			break;
		case L_USERSTAT_TIMEON:
			sprintf(logbuf," *     User was online for %s\r\n",string);
			break;
		case L_USERSTAT_AREA_READ:
			sprintf(logbuf," +     User read messages in area %s\r\n",string);
			break;

		case L_FREQ:
			sprintf(logbuf,"    File request generated for %s\r\n",string);
			break;

		case L_DOWNLOAD_PROTOCOL:
			sprintf(logbuf,"    Downloading using %s protocol\r\n",string);
			break;
		case L_DOWNLOAD:
			sprintf(logbuf,"    Downloaded file %s\r\n",string);
			break;

		case L_DLULSIZE:
			sprintf(logbuf,"       Transfer size was %s bytes\r\n",string);
			break;
		case L_DLULRATE:
			sprintf(logbuf,"       Transfer rate was %s cps\r\n",string);
			break;
		case L_DLULPERCENT:
			sprintf(logbuf,"       Transfer efficiency was %s%%\r\n",string);
			break;

		case L_UPLOAD_PROTOCOL:
			sprintf(logbuf,"    Uploading using %s protocol\r\n",string);
			break;
		case L_UPLOAD:
			sprintf(logbuf,"    Uploaded file %s\r\n",string);
			break;
		case L_DESCRIP_ERROR:
			sprintf(logbuf," !  Unable to open filelist for description of %s\r\n",string);
			break;
		case L_KILL_ERROR:
			sprintf(logbuf," !  Not enough disk space to remove entry for %s\r\n",string);
			break;

		case L_INVALID_AREA_PWD:
			sprintf(logbuf," !! Invalid password %s\r\n",string);
			break;

		case L_DMAIL_ALL:
			sprintf(logbuf,"    Downloading all messages in selected combined boards\r\n");
			break;
		case L_DMAIL_NEW:
			sprintf(logbuf,"    Downloading new messages in selected combined boards\r\n");
			break;
		case L_DMAIL_FAILED:
			sprintf(logbuf," !  Failed to prepare mail.  Disk might be full\r\n");
			break;
		case L_DMAIL_ARCHIVE:
			sprintf(logbuf,"    Attempting to archive mail with %s\r\n",string);
			break;
		case L_DMAIL_ARCHIVE_FAILED:
			sprintf(logbuf," !  Failed archive: %s\r\n",string);
			break;
		case L_DMAIL_UNARCHIVE:
			sprintf(logbuf,"    Attempting to unarchive mail with %s\r\n",string);
			break;
		case L_DMAIL_UNARCHIVE_FAILED:
			sprintf(logbuf," !  Failed unarchive: %s\r\n",string);
			break;

		case L_SYSOP_DEFINED:
			sprintf(logbuf,"    Sysop defined: %s\r\n",string);
			break;

		default:
			log_entry(L_WARNING,"Unknown log option!");
			break;
		}

	if (!blown)
		{
		if (!fwrite(logbuf,strlen(logbuf),1,logfd))
			{
			blown = 1;

			if (check_cd(cfg.cfg_port) || !user_baud)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT | BLINK),NULL);
				send_string("\r\n\r\n\a\aFatal Error:\r\n",NULL);
				send_string("Due to an out of disk space error on the logging drive,",NULL);
				send_string("you must be logged off of this system.  Sorry for the",NULL);
				send_string("inconvenience that this might cause you.  Please call",NULL);
				send_string("back at some later time when this problem might be fixed!\r\n\r\n",NULL);
				hangup();
				longjmp(reset_bbs,3);
				}
			else
				_error(L_FATAL,"Unable to write to Simplex's log.");
			}
		else 
			fflush(logfd);
		}
	}


