/* s_msg.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 6 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_msg.c_v  $
**                       $Date:   25 Oct 1992 14:08:50  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include "simplex.h"



extern struct msg **msgs;	/* found in s_msgutl.c */
extern int cur_msgs;
extern int max_msgs;
char *attachname;		/* used by file-attach verifying function and zmodem */





char *check_user(char *username,struct msg *msg,unsigned char user_priv)
	{
	static char _far buffer[100];
	struct user tuser;
	char *cptr;
	int count;
	int ok = 0;

	strncpy(buffer,username,99);
	buffer[99] = '\0';

	cptr = buffer;
	while (*cptr && *cptr <= ' ')
		++cptr;
	if ((cptr - buffer) > 0)
		memmove(buffer,cptr,strlen(cptr) + 1);
	if (!buffer[0])
		ok = 0;
	else if (!stricmp(buffer,"sysop"))
		{
		if (msg->msg_flags & MSG_LOCAL)
			{
			if (cfg.cfg_sysopname[0])
				strcpy(buffer,cfg.cfg_sysopname);
			ok = 1;
			}
		else if (msg->msg_flags & MSG_ECHO)
			{
			if (user_priv >= msg->msg_sysoppriv)
				ok = 1;
			else
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("You cannot address a message to SYSOP in an Echomail message area!\r\n\r\n",NULL);
				}
			}
		else 
			ok = 1;			/* netmail and echomail are left as "sysop" */
		}
	else if (((msg->msg_flags & MSG_LOCAL || msg->msg_flags & MSG_LOCAL_FILEATTACH) && user.user_priv >= msg->msg_sysoppriv) && !stricmp(buffer,"users"))
		ok = 1;
	else if (((msg->msg_flags & MSG_NET) || (msg->msg_flags & MSG_ECHO)) && stricmp(buffer,"all"))
		ok = 1;
	else if (((msg->msg_flags & MSG_NET) || (msg->msg_flags & MSG_ECHO)) && !stricmp(buffer,"all"))
		ok = 1;
	else if ((msg->msg_flags & MSG_PUBLIC) && !stricmp(buffer,"all"))
		ok = 1;
	else if (!(msg->msg_flags & MSG_PUBLIC) && !stricmp(buffer,"all"))
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("You cannot address a message to ALL in a RESTRICTED message area!\r\n\r\n",NULL);
		}
	else if (msg->msg_flags & MSG_NET)			/* net messages can go to ANYONE */
		ok = 1;
	else if (msg->msg_flags & MSG_LOCAL)
		{
		fseek(userfd,0L,SEEK_SET);
		while (!ok && fread(&tuser,1,sizeof(struct user),userfd))
			{
			if (!(tuser.user_flags & USER_DELETED))
				{
				if (!stricmp(buffer,tuser.user_name))
					ok = 1;
				else
					{
					for (count = 0; count < 4; count++)
						{
						if (tuser.user_alias[count][0] && !stricmp(buffer,tuser.user_alias[count]))
							{
							ok = 1;
							break;
							}
						}
					}
				}
			}
		if (!ok)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("There is not a user called \"",NULL);
			send_string(buffer,NULL);
			send_string("\" on this system!\r\n",NULL);
			}
		}
	if (ok)
		return buffer;
	return NULL;
	}



int ask_message_upload(void)
	{
	char *prompt;

	if (!user_baud)
		prompt = "\r\nDo you wish to take this message from a file (y/N)? ";
	else
		{
		if (!get_filearea(AREA_UPLOADMAIL))		/* see if we have an uploadable mail area! */
			return 0;
		prompt = "\r\nDo you wish to UPLOAD this message using Xmodem or Xmodem-1K (y/N)? ";
		}

	if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string(prompt,NULL);
	return get_yn_enter(0);
	}



int load_msg_line(char *line)
	{
	int count;

	if (cur_mlines >= max_mlines)
		{
		if (!(mlines = realloc(mlines,(max_mlines += 25) * sizeof(char *))))
			{
			max_mlines = 0;
			cur_mlines = 0;
			return 0;
			}
		}

	if (!(mlines[cur_mlines] = malloc(strlen(line) + 1)))
		{
		for (count = 0; count < cur_mlines; count++)
			free(mlines[count]);
		free(mlines);
		mlines = NULL;
		max_mlines = 0;
		cur_mlines = 0;
		return 0;
		}
	strcpy(mlines[cur_mlines],line);
	++cur_mlines;

	return 1;
	}



int do_message(char *from,char **to,char *subject,int area,int priv,int pflags,int prev,
	int flags,int zone,int net,int node,int cost,int net_flags)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *msg;
	char buffer[150];
	char buffer1[20];
	char *cptr;
	char **toptr = to;
	char **cc;
	DATE_T date;
	TIME_T time;
	long len;
	int rtn = 0;
	int save = 0;
	int character;
	int count;
	int found = 0;
	int total_msgs;
	int prev_msg = 0;
	int kludge = 0;
	int szone;
	int snet;
	int snode;
	int tval;
	FILE *fd;

	if (msg = get_msgarea(area))
		{
		if (priv >= (int)msg->msg_writepriv && (msg->msg_writeflags & pflags) == msg->msg_writeflags)
			{
			if (prev)		/* check if reply is to same area! */
				{
				fseek(msghfd,(long)(prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh,sizeof(struct msgh),1,msghfd);
				if (tmsgh.msgh_area == area)
					prev_msg = prev;
				}
			if (!(flags & MESSAGE_LOADED))
				{
				if (ask_message_upload())
					save = upload_message();
				else if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud) && user.user_flags & USER_EDITOR)
					{
					if (priv >= (int)msg->msg_sysoppriv && (msg->msg_flags & MSG_ECHO || msg->msg_flags & MSG_NET))
						kludge = 1;
					save = fullscreen_edit_message(prev,kludge);
					if (save == -1)
						save = line_edit_message();
					}
				else
					save = line_edit_message();
				}
			else
				save = 1;

			if (save)
				{
				/* trim off trailing lines */
				if (cur_mlines)
					{
					count = cur_mlines - 1;
					while (1)
						{
						if (!mlines[count][0] || mlines[count][0] == '\r' || mlines[count][0] == '\x8d')
							{
							free(mlines[count]);
							--cur_mlines;
							}
						else
							break;
						if (!count)
							break;
						--count;
						}
					}
				if (!cur_mlines && !(net_flags & MSGH_LOCAL_FILEATTACH))
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nNothing to save as a message!  Cancelling save.",NULL);
					get_enter();
					save = 0;
					}
				}
			if (save)
				{
				cur_line = 0;
				if (!(flags & MESSAGE_LOADED))
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\n",NULL);
					}

				date = get_cdate();
				time = get_ctime();

				while (*toptr)		/* as long as we have someone to send to! */
					{
					if (!(flags & MESSAGE_LOADED))
						{
						send_string("Saving message to \"",NULL);
						send_string(*toptr,NULL);
						send_string("\" to disk....",NULL);
						}

					++user.user_msgsent;			/* increment user's record of messages sent */
					++userinfo.ui_msgposted;		/* increment the messages posted this session counter */

					memset(&tmsgh,0,sizeof(struct msgh));
					tmsgh.msgh_area = area;

					/* update message data file */
					total_msgs = mdata.mdata_msgs;
					++mdata.mdata_msgs;
					fseek(msgdfd,0L,SEEK_SET);		   
					fwrite(&mdata,sizeof(struct mdata),1,msgdfd);
            
					/* update message count data */
					for (count = 0; count < cur_msgcount; count++)
						{
						if (msgcount[count].mc_area == area)
							{
							++msgcount[count].mc_msgs;
							tmsgh.msgh_number = msgcount[count].mc_msgs;		/* message number is next of area */
							fseek(msgdfd,(long)sizeof(struct mdata) + (long)count * (long)sizeof(struct mc),SEEK_SET);	/* seek to position */
							fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
							found = 1;
							break;
							}
						}

					if (!found)
						{
						if (cur_msgcount >= max_msgcount)
							{
							if (!(msgcount = realloc(msgcount,(max_msgcount += 100) * sizeof(struct mc))))
								_error(E_FATAL,"Out of memory to rebuild message area information!");
							}
						msgcount[cur_msgcount].mc_area = area;
						msgcount[cur_msgcount].mc_msgs = 1;
			  			tmsgh.msgh_number = 1;			/* message number is next of area */

						fseek(msgdfd,(long)sizeof(struct mdata) + (long)cur_msgcount * (long)sizeof(struct mc),SEEK_SET);		/* append mc data to data file */
						fwrite(&msgcount[cur_msgcount],sizeof(struct mc),1,msgdfd);
						++cur_msgcount;
						}
					fflush(msgdfd);

					if (toptr == to)
						rtn = mdata.mdata_msgs;	   /* return value is the new systemwide message number for FIRST addressee! */

					strncpy(tmsgh.msgh_to,*toptr,40);
					strncpy(tmsgh.msgh_from,from,40);
					strncpy(tmsgh.msgh_subject,subject,70);

					tmsgh.msgh_flags = 0;
					tmsgh.msgh_date = date;
					tmsgh.msgh_time = time;
				
					tmsgh.msgh_prev = prev_msg;		/* prev is the systemwide message number or 0 if no previous msg */

					if (*(toptr + 1))		/* is there another name in our list? */
						tmsgh.msgh_next = mdata.mdata_msgs + 1;		/* next message is the next! */
					else 
						tmsgh.msgh_next = 0;		/* message 0 is non-existant */

					prev_msg = mdata.mdata_msgs;	/* if multiple addressees, prev message of next is this one! */

					/* now to write out message body */
					fseek(msgbfd,0L,SEEK_END);
					tmsgh.msgh_offset = ftell(msgbfd);
					len = 0L;

#ifdef SAUDI_NET
					if (saudi_message_flag)
						{
						sprintf(buffer,"        Message courtesy of SaudiNet Electronic Communications\r\rLOCAL FORCES\r");
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);

						len += (long)strlen(to[0]);
						fputs(to[0],msgbfd);

						if (saudi_rank[0])
							{
							sprintf(buffer,", %s, %s",saudi_rank,saudi_ssn);
							len += (long)strlen(buffer);
							fputs(buffer,msgbfd);
							}

						sprintf(buffer,"\rOperation Desert Storm\r");
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);

						if (saudi_unit[0])
							{
							sprintf(buffer,"%s\r",saudi_unit);
							len += (long)strlen(buffer);
							fputs(buffer,msgbfd);
							}

						sprintf(buffer,"%s New York, NY %s\r\r",saudi_po,saudi_zip);
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);

						sprintf(buffer,"-------------------------------- Message -----------------------------------\r");
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);
						}
#endif
					if (cur_mlines)
						{
						for (count = 0; count < cur_mlines; count++)
							{
							len += (long)strlen(mlines[count]);
							fputs(mlines[count],msgbfd);		/* add check for space? */
							}
						}
					else if (!cur_mlines && (net_flags & MSGH_LOCAL_FILEATTACH))
						{
						sprintf(buffer,"The file \"%s\" has been file-attached to you.\r\r",subject);
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);		/* add check for space? */
						}

					if (toptr != to || *(toptr + 1))		/* are we sending multiple copies?  Add CC: lines to end. */
						{
						cc = to;
						while (*cc)
							{
							if (cc != toptr)
								{
								sprintf(buffer,"\r\ncc: %s",*cc);
								len += (long)strlen(buffer);
								fputs(buffer,msgbfd);
								}
							++cc;
							}
						}

					if (flags & MESSAGE_PRIVATE)
						tmsgh.msgh_flags |= MSGH_PRIVATE;
					tmsgh.msgh_flags |= net_flags;

					if (msg->msg_flags & MSG_ECHO)
						{
#ifdef PROTECTED
						sprintf(buffer,"\r\n--- Simplex/2 BBS (v%u.%02u.%02u%s [OS/2])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#else
						sprintf(buffer,"\r\n--- Simplex BBS (v%u.%02u.%02u%s [DOS])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#endif
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);
						}

					if (msg->msg_flags & (MSG_ECHO | MSG_NET))
						{
						szone = cfg.cfg_zone;
						snet = cfg.cfg_net;
						snode = cfg.cfg_node;
						for (count = 0; count < cur_msgs; count++)
							{
							if (msgs[count]->msg_number == area)
								{
								tval = msgs[count]->msg_source;
								if (tval < 0 || tval > 5)
									tval = 0;
								if (tval)
									{
									if (cfg.cfg_akanet[tval - 1])
										{
										szone = cfg.cfg_akazone[tval - 1];
										snet = cfg.cfg_akanet[tval - 1];
										snode = cfg.cfg_akanode[tval - 1];
										}
									}
								break;
								}
							}
						tmsgh.msgh_szone = szone;
						tmsgh.msgh_snet = snet;
						tmsgh.msgh_snode = snode;
						}

					if (msg->msg_flags & MSG_ECHO)
						{
						sprintf(buffer," * Origin: %s (%u:%u/%u)\r\n",msg->msg_origin,szone,snet,snode);
						len += (long)strlen(buffer);
						fputs(buffer,msgbfd);
						tmsgh.msgh_flags |= MSGH_ECHO;
						tmsgh.msgh_flags |= MSGH_ECHO_UNSENT;
						echomail_entered = 1;
						}
					if (msg->msg_flags & MSG_NET)
						{
						tmsgh.msgh_dzone = zone;
						tmsgh.msgh_dnet = net;
						tmsgh.msgh_dnode = node;
						tmsgh.msgh_cost = cost;
						tmsgh.msgh_flags |= MSGH_NET;
						tmsgh.msgh_flags |= MSGH_NET_UNSENT;
						netmail_entered = 1;

						if (toptr == to)		/* only generate one file attach */
							{
							if (net_flags & NET_FILEATTACH)
								{
								sprintf(buffer1,"%04x%04x.%s",net,node,net_flags & NET_DIRECT ? "clo" : "hlo");
								sprintf(buffer,"%s%s",get_outbound(zone),buffer1);
								if (!(fd = fopen(buffer,"r+b")))
									fd = fopen(buffer,"wb");
								if (fd)
									{
									fseek(fd,0L,SEEK_END);
									if (ftell(fd))
										{
										fseek(fd,-1L,SEEK_CUR);
										character = fgetc(fd);
										fseek(fd,0L,SEEK_END);
										if (character != '\r' && character != '\n')
											fputc('\n',fd);
										}
									fprintf(fd,"%s\r\n",subject);
									fclose(fd);
									}
								else
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string("\r\nError: Unable to generate the file attach.  Message still being sent!\r\n\r\n",NULL);
									}
								cptr = subject + strlen(subject);
								while (cptr != subject && *cptr != ':' && *cptr != P_CSEP)
									--cptr;
								if (*cptr == ':' || *cptr == P_CSEP)
									++cptr;
								if (cptr != subject)
									memcpy(subject,cptr,strlen(cptr) + 1);
								sprintf(buffer,"File attach of \"%s\"",subject);
								strncpy(tmsgh.msgh_subject,buffer,70);
								tmsgh.msgh_subject[70] = '\0';
								}
							}

						/* update the user's credit */
						if (net_flags & NET_DIRECT)
							user.user_credit -= cost;
						fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
						fwrite(&user,sizeof(struct user),1,userfd);
						fflush(userfd);
						}
					fflush(msgbfd);

					/* is this urgent mail to "Users"?  If so we must mark it! */
					if ((msg->msg_flags & MSG_LOCAL || msg->msg_flags & MSG_LOCAL_FILEATTACH) && !stricmp(*toptr,"users"))
						tmsgh.msgh_flags |= MSGH_URGENT;

					/* write out message header */
					tmsgh.msgh_length = len;
					fseek(msghfd,(long)total_msgs * (long)sizeof(struct msgh),SEEK_SET);
					fwrite(&tmsgh,sizeof(struct msgh),1,msghfd);
					fflush(msghfd);

					/* write out message link */
					tmlink.mlink_area = area;
					tmlink.mlink_number = tmsgh.msgh_number;	/* link is area number of message */
					tmlink.mlink_flags = tmsgh.msgh_flags;
					tmlink.mlink_cksum = 0;
					cptr = get_addressee(tmsgh.msgh_to);
					while (*cptr)
						{
						tmlink.mlink_cksum += toupper(*cptr);
						++cptr;
						}
					fseek(msglfd,(long)total_msgs * (long)sizeof(struct mlink),SEEK_SET);
					fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
					fflush(msglfd);

					sprintf(buffer,"#%u (System #%u) on board %u%s%s%s",tmsgh.msgh_number,prev_msg,area,msg->msg_areaname[0] ? " (" : "",msg->msg_areaname,msg->msg_areaname[0] ? ")" : "");
					log_entry(L_MSGENTERED,buffer);
					if (stricmp(tmsgh.msgh_from,user.user_name))	/* message aliased? */
						log_entry(L_MSGALIAS,tmsgh.msgh_from);

					if (!(flags & MESSAGE_LOADED))
						{
						sprintf(buffer,"Message #%u\r\n",tmsgh.msgh_number);
						send_string(buffer,NULL);
						}

					++toptr;		/* get next addressee */
					}
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(WHITE | BRIGHT),NULL);
				send_string("\r\nMessage has been aborted at user's request....\r\n\r\n",NULL);
				}
			}
		}
	else
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		}

	if (max_mlines)		/* free memory that we used */
		{
		for (count = 0; count < cur_mlines; count++)
			free(mlines[count]);
		free(mlines);
		mlines = NULL;
		cur_mlines = 0;
		max_mlines = 0;
		}
	return rtn;
	}



int forward_message(struct msg *tmsg,struct msgh *tmsgh,long toffset)
	{
	struct mlink tmlink;
	struct msgh fmsgh;
	struct msgh nmsgh;
	char buffer[100];
	char *cptr;
	long len;
	long tpos;
	long tlen;
	int total_msgs;
	int maximum;
	int found;
	int count;
	int quit = 0;
	int zone;
	int net;
	int node;
	int tzone;
	int tnet;
	int ok = 0;
	int cost;
	int through_net = 0;
	int net_flags = 0;
	int temp;
	int good = 0;

	cur_line = 0;
	if (mdata.mdata_msgs == 0x7fff)
		{
		system_message("Sorry: You cannot add any more messages to the message base!");
		return 0;
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("\r\n\r\n",NULL);
	if (tmsg->msg_flags & MSG_PUBLIC)
		send_string("         Forward to \"All\" if it is a general message.\r\n",NULL);
	if ((tmsg->msg_flags & MSG_LOCAL || tmsg->msg_flags & MSG_LOCAL_FILEATTACH) && user.user_priv >= tmsg->msg_sysoppriv)
		send_string("         Forward to \"Users\" if it is an urgent All Points Bulletin.\r\n",NULL);
	if ((tmsg->msg_flags & MSG_LOCAL) && cfg.cfg_sysopname[0])
		{
		send_string("         Forward to \"Sysop\" if it is for \"",NULL);
		send_string(cfg.cfg_sysopname,NULL);
		send_string("\".\r\n",NULL);
		}
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	if (tmsg->msg_flags & MSG_PUBLIC && !(tmsg->msg_flags & MSG_PRIVATE))
		send_string("This will be a PUBLIC message\r\n",NULL);
	else if (tmsg->msg_flags & MSG_PRIVATE && !(tmsg->msg_flags & MSG_PUBLIC))
		send_string("This will be a PRIVATE message\r\n",NULL);
	else 
		send_string("This may be a PRIVATE or a PUBLIC message\r\n",NULL);

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nForward message to (ENTER=Quit)? ",NULL);
		get_field(buffer,40,1);
		if (buffer[0])
			{
			if (cptr = check_user(buffer,tmsg,user.user_priv))
				{
				strcpy(buffer,cptr);
				quit = 1;
				good = 1;
				}
			}
		else
			quit = 1;
		}
	while (!quit);

	if (!good)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("\r\nForwarding process aborted....Returning to message\r\n",NULL);
		get_enter();
		return 0;
		}

	memcpy(&fmsgh,tmsgh,sizeof(struct msgh));
	strcpy(fmsgh.msgh_to,buffer);
	fmsgh.msgh_date = get_cdate();
	fmsgh.msgh_time = get_ctime();

	if ((tmsg->msg_flags & MSG_PRIVATE) && (tmsg->msg_flags & MSG_PUBLIC) && stricmp(fmsgh.msgh_to,"all"))		/* if it can go either way and it is not addressed to all! */
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("Make this message restricted (y/N)? ",NULL);
		fmsgh.msgh_flags &= (tmsgh->msgh_flags & ~MSGH_PRIVATE) | (get_yn_enter(0) ? MSGH_PRIVATE : 0);
		}
	else if (!stricmp(fmsgh.msgh_to,"all"))
		fmsgh.msgh_flags &= ~MSGH_PRIVATE;		/* cannot have a private message to ALL! */
	fmsgh.msgh_flags &= ~MSGH_RECEIVED;

	if (tmsg->msg_flags & MSG_NET)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\nDo you want to forward the message through the network (Y/n)? ",NULL);
		if (get_yn_enter(1))
			{
			if (cfg.cfg_zone && (tmsg->msg_source <= 0 || tmsg->msg_source > 5))
				{
				tzone = cfg.cfg_zone;
				tnet = cfg.cfg_net;
				ok = 1;
				}
			else 
				{
				if (cfg.cfg_akazone[tmsg->msg_source - 1])
					{
					tzone = cfg.cfg_akazone[tmsg->msg_source - 1];
					tnet = cfg.cfg_akanet[tmsg->msg_source - 1];
					ok = 1;
					}
				else
					{
					tzone = cfg.cfg_zone;
					tnet = cfg.cfg_net;
					ok = 1;
					}
				}

			if (ok)
				{
				through_net = get_net_address("Forward Netmail to what Net Address (ENTER=Quit)?","Forwarding Netmail to:",&zone,&net,&node,&cost,tzone,tnet);
				if (through_net)
					{
					net_flags = get_net_route(user.user_credit,cost);

					send_string("Kill message after sending (Y/n)? ",NULL);
					if (get_yn_enter(1))
						net_flags |= NET_KILLSENT;
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\nNo net/node provided, cancelling forwarding through network!\r\n",NULL);
					}
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nError: We cannot send Netmail.  System is not configured with a valid address.\r\n",NULL);
				send_string("       Address MUST have Zone:Net/Node in the configuration.\r\n",NULL);
				send_string("       Please inform Sysop.\r\n",NULL);
				get_enter();
				through_net = 0;
				}
			}
		}

	if (tmsg->msg_flags & MSG_ECHO)
		{
		fmsgh.msgh_flags |= MSGH_ECHO_UNSENT | MSGH_ECHO;
		echomail_entered = 1;
		}
	else if (tmsg->msg_flags & MSG_NET)
		{
		if (through_net)
			{
			fmsgh.msgh_flags |= MSGH_NET_UNSENT | MSGH_NET;
			fmsgh.msgh_flags |= net_flags;
			fmsgh.msgh_dzone = zone;
			fmsgh.msgh_dnet = net;
			fmsgh.msgh_dnode = node;
			fmsgh.msgh_cost = cost;
			netmail_entered = 1;

			/* update the user's credit */
			if (net_flags & NET_DIRECT)
				user.user_credit -= cost;
			fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
			fwrite(&user,sizeof(struct user),1,userfd);
			fflush(userfd);
			}
		else
			{
			fmsgh.msgh_flags |= MSGH_NET;
			fmsgh.msgh_flags &= ~MSGH_NET_UNSENT;
			fmsgh.msgh_dzone = cfg.cfg_zone;
			fmsgh.msgh_dnet = cfg.cfg_net;
			fmsgh.msgh_dnode = cfg.cfg_node;
			fmsgh.msgh_cost = 0;
			}

		fmsgh.msgh_szone = cfg.cfg_zone;
		fmsgh.msgh_snet = cfg.cfg_net;
		fmsgh.msgh_snode = cfg.cfg_node;
		}

	cur_line = 0;
	send_string("\r\n\r\nPlease wait a few moments.  Forwarding message....",NULL);

	/* update message data file */
	total_msgs = mdata.mdata_msgs;
	++mdata.mdata_msgs;
	fseek(msgdfd,0L,SEEK_SET);		   
	fwrite(&mdata,sizeof(struct mdata),1,msgdfd);

	/* update message count data */
	for (count = 0; count < cur_msgcount; count++)
		{
		if (msgcount[count].mc_area == tmsg->msg_number)
			{
			++msgcount[count].mc_msgs;
			fmsgh.msgh_number = msgcount[count].mc_msgs;		/* message number is next of area */
			fseek(msgdfd,(long)sizeof(struct mdata) + (long)count * (long)sizeof(struct mc),SEEK_SET);	/* seek to position */
			fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
			found = 1;
			break;
			}
		}

	if (!found)
		{
		if (cur_msgcount >= max_msgcount)
			{
			if (!(msgcount = realloc(msgcount,(max_msgcount += 50) * sizeof(struct mc))))
				_error(E_FATAL,"Out of memory to rebuild message area information!");		/* hope we never blow here! */
			}
		msgcount[cur_msgcount].mc_area = tmsg->msg_number;
		msgcount[cur_msgcount].mc_msgs = 1;
		fmsgh.msgh_number = 1;			/* message number is next of area */

		fseek(msgdfd,(long)sizeof(struct mdata) + (long)cur_msgcount * (long)sizeof(struct mc),SEEK_SET);		/* append mc data to data file */
		fwrite(&msgcount[cur_msgcount],sizeof(struct mc),1,msgdfd);
		++cur_msgcount;
		}
	fflush(msgdfd);

	/* write out message body */
	fseek(msgbfd,0L,SEEK_END);
	fmsgh.msgh_offset = ftell(msgbfd);
	len = 0L;
#ifdef PROTECTED
	sprintf(buffer,"* Message forwarded by Simplex/2 BBS (v %u.%02u.%02u%s)\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#else
	sprintf(buffer,"* Message forwarded by Simplex BBS (v %u.%02u.%02u%s)\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#endif
	len += strlen(buffer);
	fputs(buffer,msgbfd);
	sprintf(buffer,"* Original Message forwarded by %s\r\n",user.user_name);
	len += strlen(buffer);
	fputs(buffer,msgbfd);
	if (tmsgh->msgh_flags & MSGH_NET)
		{
		sprintf(buffer,"* Original message was addressed to %s on %d/%d\r\n",tmsgh->msgh_to,tmsgh->msgh_dnet,tmsgh->msgh_dnode);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}
	else 
		{
		sprintf(buffer,"* Original message was addressed to %s\r\n",tmsgh->msgh_to);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}
	if (tmsgh->msgh_flags & MSGH_NET)
		{
		sprintf(buffer,"* Original message was from %s on %d/%d\r\n",tmsgh->msgh_from,tmsgh->msgh_snet,tmsgh->msgh_snode);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}
	else
		{
		sprintf(buffer,"* Original message was from %s\r\n",tmsgh->msgh_from);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}

	temp = ((tmsgh->msgh_date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"* Original message was timestamped %d %s %02d at %2d:%02d\r\n\r\n",tmsgh->msgh_date & 0x1f,months_table[temp],((tmsgh->msgh_date >> 9) + 1980) % 100,
		tmsgh->msgh_time >> 11,(tmsgh->msgh_time >> 5) & 0x3f);
	len += strlen(buffer);
	fputs(buffer,msgbfd);

	tpos = tmsgh->msgh_offset;
	tlen = 0L;
	while (tlen < tmsgh->msgh_length)
		{
		maximum = (tmsgh->msgh_length - tlen) >= 100L ? 100 : (int)(tmsgh->msgh_length - tlen);
		fseek(msgbfd,tpos,SEEK_SET);
		fread(buffer,maximum,sizeof(char),msgbfd);
		tpos += (long)maximum;
		len += (long)maximum;
		tlen += (long)maximum;
		fseek(msgbfd,0L,SEEK_END);
		fwrite(buffer,maximum,sizeof(char),msgbfd);		/* add check for space? */
		}

	if (tmsg->msg_flags & MSG_ECHO || tmsg->msg_flags & MSG_NET)
		{
#ifdef PROTECTED
		sprintf(buffer,"\r\n--- Simplex/2 BBS (v%u.%02u.%02u%s [OS/2])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#else
		sprintf(buffer,"\r\n--- Simplex BBS (v%u.%02u.%02u%s [DOS])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#endif
		len += (long)strlen(buffer);
		fputs(buffer,msgbfd);
		}

	if (tmsg->msg_flags & MSG_ECHO)
		{
		sprintf(buffer," * Origin: %s (%u:%u/%u)\r\n",tmsg->msg_origin,cfg.cfg_zone,cfg.cfg_net,cfg.cfg_node);
		len += (long)strlen(buffer);
		fputs(buffer,msgbfd);
		}

	fmsgh.msgh_length = len;

	/* we must find the true end of the chain */
	memcpy(&nmsgh,tmsgh,sizeof(struct msgh));
	if (tmsgh->msgh_next)
		{
		while (nmsgh.msgh_next)
			{
			toffset = (long)(nmsgh.msgh_next - 1) * (long)sizeof(struct msgh);
			fseek(msghfd,toffset,SEEK_SET);
			fread(&nmsgh,1,sizeof(struct msgh),msghfd);
			}
		}

	/* now we make sure that we write the updated chain member */
	nmsgh.msgh_next = mdata.mdata_msgs;		/* next points to systemwide message number */
	fseek(msghfd,toffset,SEEK_SET);
	fwrite(&nmsgh,sizeof(struct msgh),1,msghfd);
	if (tmsgh->msgh_number == nmsgh.msgh_number)	/* if next is off of the current message */
		tmsgh->msgh_next = nmsgh.msgh_next;			/* update next pointer to reflect it */

	fmsgh.msgh_prev = (int)(toffset / (long)sizeof(struct msgh)) + 1;	/* prev is systemwide message number */
	fmsgh.msgh_next = 0;
	fseek(msghfd,(long)total_msgs * (long)sizeof(struct msgh),SEEK_SET);
	fwrite(&fmsgh,sizeof(struct msgh),1,msghfd);	/* write header out */
	fflush(msghfd);

	/* write out message link */
	tmlink.mlink_area = tmsg->msg_number;
	tmlink.mlink_number = fmsgh.msgh_number;	/* link is area number of message */
	tmlink.mlink_flags = fmsgh.msgh_flags;
	tmlink.mlink_cksum = 0;
	cptr = get_addressee(fmsgh.msgh_to);
	while (*cptr)
		{
		tmlink.mlink_cksum += toupper(*cptr);
		++cptr;
		}
	fseek(msglfd,(long)total_msgs * (long)sizeof(struct mlink),SEEK_SET);
	fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
	fflush(msglfd);
	send_string("Message has been forwarded!\r\n",NULL);
	return 1;
	}


	
void move_message(struct msg *tmsg,struct msgh *tmsgh,int current,int new_area)
	{
	struct msg *tmsg1;
	struct mlink tmlink;
	struct msgh tmsgh1;
	struct msgh pmsgh;
	struct msgh nmsgh;
	char buffer[200];
	DATE_T date;
	TIME_T time;
	long len;
	long tpos;
	long tlen;
	int was_marked = 0;
	int mark_offset;
	int found;
	int count;
	int renum;
	int temp;
	int maximum;

	cur_line = 0;
	if (mdata.mdata_msgs == 0x7fff)
		{
		system_message("Sorry: You cannot add any more messages to the message base!");
		return;
		}
	send_string("\r\nPlease wait a few moments.  Moving message....",NULL);

	tmsg1 = get_msgarea(new_area);

	for (count = 0; count < cur_marked; count++)
		{
		if (marked[count].mark_area == tmsgh->msgh_area)
			{
			if (marked[count].mark_number == current)
				{
				was_marked = 1;
				mark_offset = count;
				break;
				}
			}
		}
	/* forge message links first */
	if (tmsgh->msgh_prev)
		{
		/**** Check that our message number is existant ****/
		if (tmsgh->msgh_prev < 0 || tmsgh->msgh_prev > mdata.mdata_msgs)
			{
			sprintf(buffer,"Invalid prev message %d while linking reply chain during delete.",tmsgh->msgh_prev);
			log_entry(L_ERROR,buffer);
			}
		else
			{
			fseek(msghfd,(long)(tmsgh->msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fread(&pmsgh,1,sizeof(struct msgh),msghfd);
			pmsgh.msgh_next = tmsgh->msgh_next;		/* may be valid or 0 */
			fseek(msghfd,(long)(tmsgh->msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fwrite(&pmsgh,sizeof(struct msgh),1,msghfd);
			}
		}
	if (tmsgh->msgh_next)
		{
		/**** Check that our message number is existant ****/
		if (tmsgh->msgh_next < 0 || tmsgh->msgh_next > mdata.mdata_msgs)
			{
			sprintf(buffer,"Invalid next message %d while linking reply chain during delete.",tmsgh->msgh_next);
			log_entry(L_ERROR,buffer);
			}
		else
			{
			fseek(msghfd,(long)(tmsgh->msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fread(&nmsgh,1,sizeof(struct msgh),msghfd);
			nmsgh.msgh_prev = tmsgh->msgh_prev;		/* may be valid of 0 */
			fseek(msghfd,(long)(tmsgh->msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fwrite(&nmsgh,sizeof(struct msgh),1,msghfd);
			}
		}


	/* now to mark the message with the new area info */

	if (tmsgh->msgh_flags & MSGH_ECHO_UNSENT)		/* clean up old header */
		tmsgh->msgh_flags &= ~MSGH_ECHO_UNSENT;
	if (tmsgh->msgh_flags & MSGH_NET_UNSENT)
		tmsgh->msgh_flags &= ~MSGH_NET_UNSENT;

	memcpy(&tmsgh1,tmsgh,sizeof(struct msgh));		/* copy header */

	/* delete this current message header, we will add a new one at the end of message file */
	renum = tmsgh->msgh_number;		/* save for later use */
	tmsgh->msgh_number = 0;
	tmsgh->msgh_flags |= MSGH_DELETED;
	tmsgh->msgh_prev = 0;
	tmsgh->msgh_next = 0;
	fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
	fwrite(tmsgh,sizeof(struct msgh),1,msghfd);
	fflush(msghfd);

	/* now to update the record link file for deleted header */
	fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
	fread(&tmlink,sizeof(struct mlink),1,msglfd);
	tmlink.mlink_flags |= MSGH_DELETED;		/* mark message as deleted */
	fseek(msglfd,(long)(current - 1) * (long)sizeof(struct mlink),SEEK_SET);
	fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
	fflush(msglfd);

	/* update message count file */
	for (count = 0; count < cur_msgcount; count++)		/* update current area's count */
		{
		if (msgcount[count].mc_area == tmsgh->msgh_area)
			{
			if (msgcount[count].mc_msgs)
				{
				--msgcount[count].mc_msgs;
				fseek(msgdfd,(long)sizeof(struct mdata) + (long)count * (long)sizeof(struct mc),SEEK_SET);	/* seek to position */
				fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
				}
			break;
			}
		}
	found = 0;
	for (count = 0; count < cur_msgcount; count++)		/* update new message area's count */
		{
		if (msgcount[count].mc_area == new_area)
			{
			++msgcount[count].mc_msgs;
			tmsgh1.msgh_number = msgcount[count].mc_msgs;	/* we get the last number of the area */
			fseek(msgdfd,(long)sizeof(struct mdata) + (long)count * (long)sizeof(struct mc),SEEK_SET);	/* seek to position */
			fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
			found = 1;
			break;
			}
		}
	if (!found)
		{
		if (cur_msgcount >= max_msgcount)
			{
			if (!(msgcount = realloc(msgcount,(max_msgcount += 100) * sizeof(struct mc))))
				_error(E_FATAL,"Out of memory to rebuild message area information!");
			}
		msgcount[cur_msgcount].mc_area = new_area;
		msgcount[cur_msgcount].mc_msgs = 1;
		tmsgh1.msgh_number = 1;		/* we get the last number of the area */

		fseek(msgdfd,(long)sizeof(struct mdata) + (long)cur_msgcount * (long)sizeof(struct mc),SEEK_SET);		/* append mc data to data file */
		fwrite(&msgcount[cur_msgcount],sizeof(struct mc),1,msgdfd);
		++cur_msgcount;
		}

	/* now update data file */
	++mdata.mdata_msgs;			/* we added a header */
	++mdata.mdata_del;			/* we deleted a header */
	fseek(msgdfd,0L,SEEK_SET);
	fwrite(&mdata,sizeof(struct mdata),1,msgdfd);
	fflush(msgdfd);			/* flush it to disk! */

	/* now prepare our new header for writing */
	tmsgh1.msgh_area = new_area;
	tmsgh1.msgh_prev = 0;
	tmsgh1.msgh_next = 0;

	/* make sure that message won't be a "sore thumb" in the new area */
	if ((tmsg1->msg_flags & MSG_PRIVATE) && !(tmsg1->msg_flags & MSG_PUBLIC))
		tmsgh1.msgh_flags |= MSGH_PRIVATE;
	else if ((tmsg1->msg_flags & MSG_PUBLIC) && !(tmsg1->msg_flags & MSG_PRIVATE))
		tmsgh1.msgh_flags &= ~MSGH_PRIVATE;
	if (tmsg1->msg_flags & MSG_NET)
		{
		tmsgh1.msgh_flags &= ~MSGH_ECHO;
		tmsgh1.msgh_flags |= MSGH_NET;
		tmsgh1.msgh_flags &= ~MSGH_NET_UNSENT;
		if (!(tmsgh->msgh_flags & MSGH_NET) && !(tmsgh->msgh_flags & MSGH_ECHO))	/* previous area was not echo nor netmail area */
			{
			tmsgh1.msgh_szone = cfg.cfg_zone;	/* sent from us */
			tmsgh1.msgh_snet = cfg.cfg_net;
			tmsgh1.msgh_snode = cfg.cfg_node;
			}
		tmsgh1.msgh_dzone = cfg.cfg_zone;	/* sent to us */
		tmsgh1.msgh_dnet = cfg.cfg_net;
		tmsgh1.msgh_dnode = cfg.cfg_node;
		}
	else if (tmsg1->msg_flags & MSG_ECHO)
		{
		tmsgh1.msgh_flags &= ~MSGH_NET;
		tmsgh1.msgh_flags |= MSGH_ECHO;
		tmsgh1.msgh_flags |= MSGH_ECHO_UNSENT;
		tmsgh1.msgh_szone = cfg.cfg_zone;	/* sent from us */
		tmsgh1.msgh_snet = cfg.cfg_net;
		tmsgh1.msgh_snode = cfg.cfg_node;
		}
	else
		tmsgh1.msgh_flags &= ~(MSGH_NET | MSGH_ECHO);

	/* write out message body */
	fseek(msgbfd,0L,SEEK_END);
	tmsgh1.msgh_offset = ftell(msgbfd);
	len = 0L;
#ifdef PROTECTED
	sprintf(buffer,"* Message moved by Simplex/2 BBS (v %u.%02u.%02u%s)\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA ? "Beta" : ""));
#else
	sprintf(buffer,"* Message moved by Simplex BBS (v %u.%02u.%02u%s)\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA ? "Beta" : ""));
#endif
	len += strlen(buffer);
	fputs(buffer,msgbfd);
	sprintf(buffer,"* Message moved by %s\r\n",user.user_name);
	len += strlen(buffer);
	fputs(buffer,msgbfd);
	if (tmsg->msg_areaname[0])
		{
		sprintf(buffer,"* Message moved from area \"%s\"\r\n",tmsg->msg_areaname);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}
	if (tmsgh->msgh_flags & MSGH_NET)
		{
		sprintf(buffer,"* Message is from network address %d/%d\r\n",tmsgh->msgh_snet,tmsgh->msgh_snode);
		len += strlen(buffer);
		fputs(buffer,msgbfd);
		}

	date = get_cdate();
	time = get_ctime();
	temp = ((date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"* Message was moved %d %s %02d at %2d:%02d\r\n\r\n",date & 0x1f,months_table[temp],((date >> 9) + 1980) % 100,
		time >> 11,(time >> 5) & 0x3f);
	len += strlen(buffer);
	fputs(buffer,msgbfd);

	tpos = tmsgh->msgh_offset;
	tlen = 0L;
	while (tlen < tmsgh->msgh_length)
		{
		maximum = (tmsgh->msgh_length - tlen) >= 100L ? 100 : (int)(tmsgh->msgh_length - tlen);
		fseek(msgbfd,tpos,SEEK_SET);
		fread(buffer,maximum,sizeof(char),msgbfd);
		tpos += (long)maximum;
		len += (long)maximum;
		tlen += (long)maximum;
		fseek(msgbfd,0L,SEEK_END);
		fwrite(buffer,maximum,sizeof(char),msgbfd);		/* add check for space? */
		}

	if (tmsg1->msg_flags & MSG_ECHO)	/* moved mail to netmail area is not sent out! */
		{
#ifdef PROTECTED
		sprintf(buffer,"\r\n--- Simplex/2 BBS (v%u.%02u.%02u%s [OS/2])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#else
		sprintf(buffer,"\r\n--- Simplex BBS (v%u.%02u.%02u%s [DOS])\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#endif
		len += (long)strlen(buffer);
		fputs(buffer,msgbfd);

		sprintf(buffer," * Origin: %s (%u:%u/%u)\r\n",tmsg1->msg_origin,cfg.cfg_zone,cfg.cfg_net,cfg.cfg_node);
		len += (long)strlen(buffer);
		fputs(buffer,msgbfd);
		echomail_entered = 1;
		}

	tmsgh1.msgh_length = len;

	/* now to write out new header at the end of the file */
	fseek(msghfd,(long)(mdata.mdata_msgs - 1) * (long)sizeof(struct msgh),SEEK_SET);
	fwrite(&tmsgh1,sizeof(struct msgh),1,msghfd);
	fflush(msghfd);

	/* now to prepare and write out a message link */
	tmlink.mlink_area = tmsgh1.msgh_area;
	tmlink.mlink_number = tmsgh1.msgh_number;
	tmlink.mlink_flags = tmsgh1.msgh_flags;
	/* tmlink.mlink_cksum is already set from when we deleted */
	fseek(msglfd,(long)(mdata.mdata_msgs - 1) * (long)sizeof(struct mlink),SEEK_SET);
	fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
	fflush(msglfd);

	/* change the mark if message was originally marked */
	if (was_marked)
		{
		marked[mark_offset].mark_area = new_area;
		marked[mark_offset].mark_number = mdata.mdata_msgs;
		}

	/* log the entry */
	sprintf(buffer,"#%u on board %u%s%s%s to #%u on board %u%s%s%s",renum,tmsgh->msgh_area,tmsg->msg_areaname[0] ? " (" : "",tmsg->msg_areaname,tmsg->msg_areaname[0] ? ")" : "",
		tmsgh1.msgh_number,new_area,tmsg1->msg_areaname[0] ? " (" : "",tmsg1->msg_areaname,tmsg1->msg_areaname[0] ? ")" : "");
	log_entry(L_MSGMOVED,buffer);

	if (tmsg1->msg_flags & MSG_NET)
		netmail_entered = 1;
	else if (tmsg1->msg_flags & MSG_ECHO)
		echomail_entered = 1;

	/* now to renumber all consecutive messages */
	count = current + 1;
	fseek(msglfd,(long)(count - 1) * (long)sizeof(struct mlink),SEEK_SET);
	while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
		{
		if (tmlink.mlink_area == tmsgh->msgh_area && !(tmlink.mlink_flags & MSGH_DELETED))
			{
			fseek(msghfd,(long)(count - 1) * (long)sizeof(struct msgh),SEEK_SET);
			fread(&nmsgh,sizeof(struct msgh),1,msghfd);
			fseek(msghfd,(long)(count - 1) * (long)sizeof(struct msgh),SEEK_SET);
			nmsgh.msgh_number = renum;
			fwrite(&nmsgh,sizeof(struct msgh),1,msghfd);

			fseek(msglfd,(long)(count - 1) * (long)sizeof(struct mlink),SEEK_SET);
			tmlink.mlink_number = renum;
			fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
			fseek(msglfd,0L,SEEK_CUR);
			++renum;
			}
		++count;
		}
	fflush(msghfd);

	send_string("Message has been moved!\r\n",NULL);
	}



int check_attach(char *name)
	{
	if (!stricmp(name,attachname))
		return 1;
	return 0;
	}



int attach_handler(int key)		/* normal pause-stop handler */
	{
	switch (key)
		{
		case '1':
		case '2':
		case '3':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



void dispatch_message(char *from,char *to,char *subject,int area,int priv,int pflags,int previous,int zone,int net,int node,int cost,int net_flags)
	{
	struct user tuser;
	char buffer[120];
	char buffer1[15];
	char path[51];
	char fname[15];
	char addressee[41];
	char *tonames[2];
	char *cptr;
	char *cptr1;
	struct msg *tmsg;
	struct file *tfile;
	int received = 0;
	int private = 0;
	int found = 0;
	int send = 1;
	int quit = 0;
	int key = 0;
	int abort = 0;
	int count;
	int ok = 0;
	int protocol;
	FILE *listfd;

	if (tmsg = get_msgarea(area))
		{
		send_string("\r\n",NULL);
		if (mdata.mdata_msgs == 0x7fff)
			{
			system_message("Sorry: You cannot add any more messages to the message base!");
			return;
			}
		if (priv < (int)tmsg->msg_writepriv || (tmsg->msg_writeflags & pflags) != tmsg->msg_writeflags)
			{
			system_message("You have insufficient privilege to enter messages here!");
			return;
			}
		if ((tmsg->msg_flags & 0x7) == MSG_LOCAL_FILEATTACH)
			{
			if (tfile = get_filearea(0))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(BROWN | BRIGHT),NULL);
				send_string("\r\n\r\n",NULL);
				if (cfg.cfg_sysopname[0])
					{
					send_string("         Address to \"Sysop\" if it is for \"",NULL);
					send_string(cfg.cfg_sysopname,NULL);
					send_string("\".\r\n\r\n",NULL);
					}
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				if (tmsg->msg_flags & MSG_PUBLIC && !(tmsg->msg_flags & MSG_PRIVATE))
					send_string("         This will be a PUBLIC message\r\n",NULL);
				else if (tmsg->msg_flags & MSG_PRIVATE && !(tmsg->msg_flags & MSG_PUBLIC))
					send_string("         This will be a RESTRICTED message\r\n",NULL);
				else 
					send_string("         This may be a PUBLIC or a RESTRICTED message\r\n",NULL);
				do
					{
		 			cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
	 				send_string("     To: ",NULL);
	 				get_field(addressee,40,1);
					if (!addressee[0])
						quit = 1;
					else
						{
						cptr = addressee;
						while (*cptr && *cptr <= ' ')
							++cptr;
						if ((cptr - addressee) > 0)
							memmove(addressee,cptr,strlen(cptr) + 1);
						if (!addressee[0])
							quit = 1;
						else if (!stricmp(addressee,"sysop"))
							{
							if (cfg.cfg_sysopname[0])
								{
								strcpy(addressee,cfg.cfg_sysopname);
								quit = 1;
								}
							else
								{
								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("You cannot address a message to SYSOP!\r\n\r\n",NULL);
								}
							}
						else if (!stricmp(addressee,"all"))
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("You cannot address a message to ALL in a file-attach message area!\r\n\r\n",NULL);
							}
						else
							{
							fseek(userfd,0L,SEEK_SET);
							while (fread(&tuser,1,sizeof(struct user),userfd))
								{
								if (!(tuser.user_flags & USER_DELETED) && !stricmp(addressee,tuser.user_name))
									{
									found = 1;
									quit = 1;
									break;
									}
								}
							if (!found)
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("There is not a user called \"",NULL);
								send_string(addressee,NULL);
								send_string("\" on this system!\r\n",NULL);
								}
							}
						}
					}
				while (!quit);

				if (!addressee[0])
					return;

				tonames[0] = addressee;
				tonames[1] = NULL;

	 			cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
 				send_string("   File: ",NULL);
				get_fname(fname,12,0,0);

				if (!fname[0])
					return;

				strcpy(buffer,tfile->file_pathname);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				strcat(buffer,fname);

				if ((tmsg->msg_flags & MSG_PRIVATE) && (tmsg->msg_flags & MSG_PUBLIC))
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("Make this message restricted (y/N)? ",NULL);
					private = get_yn_enter(0);
					}
				else 
					private = tmsg->msg_flags & MSG_PRIVATE ? 1 : 0;

				if (!access(buffer,0))
					{
	 				cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
 					send_string("\r\nFile aleady exists.  Do you want to skip uploading the file (Y/n)? ",NULL);
					if (get_yn_enter(1))
						{
						send = 0;
						received = 1;
						}
					}

				if (send)
					{
					if (!user_baud)
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\nCopy from where (ENTER=Quit)? ",NULL);
						get_fname(path,48,0,1);
						if (path[0])
							{
							if (path[strlen(path) - 1] != P_CSEP)
								strcat(path,P_SSEP);
							expand_safe_fname(path,fname,PROT_DIRECT);
							if (cur_fnames)
								{
								copy_in(AREA_FATTACH,path,fnames,cur_fnames,0);
								received = 1;
								}
							else
								{
								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\nThe file you specified does not exist on the provided path!\r\n\r\n",NULL);
								get_enter();
								abort = 1;
								}
							for (count = 0; count < cur_fnames; count++)
								free(fnames[count]);
							free(fnames);
							fnames = NULL;
							cur_fnames = 0;
							max_fnames = 0;
							}
						else
							abort = 1;
						}
					else
						{
						attachname = fname;
						cur_line = 0;
						quit = 0;
						do
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(WHITE | BRIGHT),NULL);
							key = send_string("\r\n\r\n--- Choose an Upload Protocol ---\r\n\r\n",attach_handler);
							if (!key)
								{
								if (!(user.user_flags & USER_EXPERT))
									key = send_string("<1> Xmodem         <2> Xmodem-1K\r\n<3> Zmodem         <X> Exit\r\n\r\n",attach_handler);
								else
									key = send_string("[ 123X ]\r\n\r\n",attach_handler);
								if (!key)
									key = send_string("What is your choice (ENTER=Exit)? ",attach_handler);
								}
							ok = 0;

							do
								{
								if (!key)
									key = get_char();
								else
									send_string("\r\n\r\nUpload using ",NULL);
								switch (key)
									{
									case '1':
										send_string("Xmodem",NULL);
										protocol = 0;
										quit = 1;
										ok = 1;
										break;
									case '2':
										send_string("Xmodem-1K",NULL);
										protocol = 1;
										quit = 1;
										ok = 1;
										break;
									case '3':
										send_string("Zmodem",NULL);
										protocol = 2;
										quit = 1;
										ok = 1;
										break;
									case 'X':
									case 'x':
									case '\r':
									case '\n':
										quit = 1;
										abort = 1;
										ok = 1;
										break;
									}
								key = 0;
								}
							while (!ok);
							}
						while (!quit);

						if (!abort)
							{
							strcpy(buffer,tfile->file_pathname);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							sprintf(buffer1,"upload#%u.bbs",cfg.cfg_port);
							strcat(buffer,buffer1);

							if (!(listfd = fopen(buffer,"w+b")))
								{
								sprintf(buffer,"Unable to open %s in local f/attach area!",buffer1);
								_error(E_ERROR,buffer);
								system_message(buffer);
								return;
								}

							if (!protocol)
								x_recv(AREA_FATTACH,fname,listfd);		/* f/attach are is "dummy" 0 */
							else if (protocol == 1)
								x1k_recv(AREA_FATTACH,fname,listfd);		/* f/attach are is "dummy" 0 */
							else
								z_recv(AREA_FATTACH,listfd,check_attach);		/* f/attach are is "dummy" 0 */

							fseek(listfd,0L,SEEK_SET);
							while (fgets(buffer,sizeof(buffer),listfd))
								{
								if (!strnicmp(buffer,"OK ",3))
									{
									++received;
									cptr = buffer + 4;
									cptr1 = fname;

									while (*cptr > ' ')
										*cptr1++ = *cptr++;
									*cptr1 = '\0';
										++cptr;

									sprintf(buffer,"\"%s\" in local f/attach area.",fname);
									log_entry(L_UPLOAD,buffer);
									}
								else	   		/* delete any bad file fragments we might have left! */
									{
									cptr = buffer + 4;
									cptr1 = buffer1;

									while (*cptr > ' ')
										*cptr1++ = *cptr++;
									*cptr1 = '\0';

									strcpy(buffer,tfile->file_pathname);
									if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
										strcat(buffer,P_SSEP);
									strcat(buffer,buffer1);

									unlink(buffer);
									}
								}
							fclose(listfd);
							}
						}
					}
				if (received)
					{
			 		if (!do_message(from,tonames,fname,area,priv,pflags,0,private ? MESSAGE_PRIVATE : 0,zone,net,node,cost,net_flags | MSGH_LOCAL_FILEATTACH) && send)
						{
						strcpy(buffer,tfile->file_pathname);
						if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
							strcat(buffer,P_SSEP);
						strcat(buffer,fname);
						unlink(buffer);
						}
					}
				}
			else
				{
				sprintf(buffer,"There is no valid local file-attach path on this system!");
				_error(E_ERROR,buffer);
				system_message(buffer);
				}
			}
		else
			enter_message(from,to,subject,area,priv,pflags,previous,zone,net,node,cost,net_flags);
		}
	else
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		}
	}



void enter_message(char *from,char *to,char *subject,int area,int priv,int pflags,int previous,int zone,int net,int node,int cost,int net_flags)
	{
	struct msg *tmsg;
	char **tonames = NULL;
	int max_tonames = 0;
	int cur_tonames = 0;
	char buffer[80];
	char buffer1[80];
	char buffer2[50];
	char *from_name[5];
	char *cptr;
	int private = 0;
	int tzone;
	int tnet;
	int count;
	int found;
	int quit;
	int valid;
	int total;
	int key;
	int ok = 0;

	cur_line = 0;
	if (tmsg = get_msgarea(area))
		{
		send_string("\r\n",NULL);
		if (mdata.mdata_msgs == 0x7fff)
			{
			system_message("Sorry: You cannot add any more messages to the message base!");
			return;
			}
		if (priv < (int)tmsg->msg_writepriv || (tmsg->msg_writeflags & pflags) != tmsg->msg_writeflags)
			{
			system_message("You have insufficient privilege to enter messages here!");
			return;
			}
		if (tmsg->msg_flags & MSG_NET)
			{
			if (cfg.cfg_zone && (tmsg->msg_source <= 0 || tmsg->msg_source > 5))
				{
				tzone = cfg.cfg_zone;
				tnet = cfg.cfg_net;
				ok = 1;
				}
			else 
				{
				if (cfg.cfg_akazone[tmsg->msg_source - 1])
					{
					tzone = cfg.cfg_akazone[tmsg->msg_source - 1];
					tnet = cfg.cfg_akanet[tmsg->msg_source - 1];
					ok = 1;
					}
				else
					{
					tzone = cfg.cfg_zone;
					tnet = cfg.cfg_net;
					ok = 1;
					}
				}

			if (ok)
				{
				valid = get_net_address("Send Netmail to what Net Address (ENTER=Quit)?","Sending Netmail to:",&zone,&net,&node,&cost,tzone,tnet);
				if (valid)
					{
					net_flags |= get_net_route(user.user_credit,cost);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("Kill message after sending (Y/n)? ",NULL);
					if (get_yn_enter(1))
						net_flags |= NET_KILLSENT;

					if (cfg.cfg_outboundpath[0] && user.user_flags & USER_FILEATTACH && (net_flags & NET_DIRECT || net_flags & NET_HOLD))
						{
						send_string("Attach a file to this Netmail message (y/N)? ",NULL);
						if (get_yn_enter(0))
							{
							quit = 0;
							do
								{
								send_string("\r\nEnter full pathname to file for attach (ENTER=Skip it):\r\n",NULL);
								send_string("File: ",NULL);
								get_fname(buffer1,72,0,1);
								if (buffer1[0])
									{
									if (!access(buffer1,0))
										{
										subject = buffer1;
										net_flags |= NET_FILEATTACH;
										quit = 1;
										}
									else
										{
										send_string("\r\nFile does not exist.  Attach anyway (y/N)? ",NULL);
										if (get_yn_enter(0))
											{
											subject = buffer1;
											net_flags |= NET_FILEATTACH;
											quit = 1;
											}
										}
									}
								else
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string("\r\nNo filename entered, skipping file attach!\r\n",NULL);
									quit = 1;
									}
								}
							while (!quit);
							}
						}
					}
				else
					return;			/* can't netmail to nowhere! */
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nError: We cannot send Netmail.  System is not configured with a valid address.\r\n",NULL);
				send_string("       Address MUST have Zone:Net/Node in the configuration.\r\n",NULL);
				send_string("       Please inform Sysop.\r\n",NULL);
				get_enter();
				return;
				}
			}
		if (!to)
			{
			quit = 0;
			do
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(BROWN | BRIGHT),NULL);
				send_string("\r\n\r\n",NULL);
				if (tmsg->msg_flags & MSG_PUBLIC)
					send_string("         Address to \"All\" if it is a general message.\r\n",NULL);
				if ((tmsg->msg_flags & MSG_LOCAL || tmsg->msg_flags & MSG_LOCAL_FILEATTACH) && user.user_priv >= tmsg->msg_sysoppriv)
					send_string("         Address to \"Users\" if it is an urgent All Points Bulletin.\r\n",NULL);
				if ((tmsg->msg_flags & MSG_LOCAL) && cfg.cfg_sysopname[0])
					{
					send_string("         Address to \"Sysop\" if it is for \"",NULL);
					send_string(cfg.cfg_sysopname,NULL);
					send_string("\".\r\n",NULL);
					}
				else if ((tmsg->msg_flags & MSG_ECHO) && ((unsigned char)priv >= tmsg->msg_sysoppriv))
					send_string("         Address to \"Sysop\" if it is for all sysops receiving this echo.\r\n",NULL);
				send_string("\r\n",NULL);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				if (tmsg->msg_flags & MSG_PUBLIC && !(tmsg->msg_flags & MSG_PRIVATE))
					send_string("         This will be a PUBLIC message\r\n",NULL);
				else if (tmsg->msg_flags & MSG_PRIVATE && !(tmsg->msg_flags & MSG_PUBLIC))
					send_string("         This will be a RESTRICTED message\r\n",NULL);
				else 
					send_string("         This may be a PUBLIC or a RESTRICTED message\r\n",NULL);
				if (tmsg->msg_flags & MSG_NET)
					{
	 				cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
	 				send_string("     To: ",NULL);
	 				get_field(buffer,40,1);
					if (!buffer[0])
						quit = 1;
					else 
						{
						if (cptr = check_user(buffer,tmsg,(unsigned char)priv))
							{
							strcpy(buffer,cptr);
							max_tonames = 2;
							if (!(tonames = malloc(max_tonames * sizeof(char *))))
								{
								system_message("Fatal error loading names: Out of memory.  Message aborted!");
								return;
								}
							tonames[0] = buffer;
							tonames[1] = NULL;
							quit = 1;
							}
						}
					}
				else
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("         You may enter all users who are to receive this message.\r\n",NULL);
					send_string("         Press ENTER on a blank line when you are finished.\r\n",NULL);
					do
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						if (!cur_tonames)
							send_string("     To: ",NULL);
						else 
							send_string("Copy To: ",NULL);
						get_field(buffer,40,1);
						if (buffer[0])
							{
							if (cptr = check_user(buffer,tmsg,(unsigned char)priv))
								{
								found = 0;
								for (count = 0; count < cur_tonames; count++)
									{
									if (!stricmp(tonames[count],cptr))
										{
										found = 1;
										break;
										}
									}
								if (!found)
									{
									if ((cur_tonames + 1) > max_tonames)
										{
										if (!(tonames = realloc(tonames,(max_tonames += 10) * sizeof(char *))))
											{
											system_message("Fatal error loading names: Out of memory.  Message aborted!");
											return;
											}
										}
									if (!(tonames[cur_tonames] = malloc((strlen(cptr) + 1) * sizeof(char))))
										{
										system_message("Fatal error loading names: Out of memory.  Message aborted!");
										return;
										}
									strcpy(tonames[cur_tonames],cptr);
									++cur_tonames;
									tonames[cur_tonames] = NULL;
									}
								else
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string("You already have this message addressed to \"",NULL);
									send_string(cptr,NULL);
									send_string("\"!\r\n\r\n",NULL);
									}
								}
							}
						else
							quit = 1;
						}
					while (!quit);
					}
				}
			while (!quit);

			if (!max_tonames)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nMessage aborted!\r\n",NULL);
				get_enter();
				return;
				}
			else
				{
				if ((unsigned int)(mdata.mdata_msgs + cur_tonames) >= (unsigned int)0x7fff)
					{
					system_message("Sorry: You cannot add any more messages to the message base!");
					return;
					}
				}
			}
		else
			{
			max_tonames = 2;
			if (!(tonames = malloc(max_tonames * sizeof(char *))))
				{
				system_message("Fatal error loading names: Out of memory.  Message aborted!");
				return;
				}
			tonames[0] = to;
			tonames[1] = NULL;
			}

		if (!subject)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("Subject: ",NULL);
			get_field(buffer1,60,0);
			if (!buffer1[0])
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nMessage aborted!\r\n",NULL);
				get_enter();
				return;
				}
			subject = buffer1;
			}
		if (cur_tonames)
			{
			found = 0;
			for (count = 0; count < cur_tonames; count++)
				{
				if (!stricmp(tonames[count],"all"))
					{
					found = 1;
					break;
					}
				}
			}
		else
			found = !stricmp(tonames[0],"all");

		if ((tmsg->msg_flags & MSG_PRIVATE) && (tmsg->msg_flags & MSG_PUBLIC) && !found)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			if (tmsg->msg_flags & MSG_NET)
				{
				if (cur_tonames > 2)
					send_string("Make these messages restricted (Y/n)? ",NULL);
				else 
					send_string("Make this message restricted (Y/n)? ",NULL);
				private = get_yn_enter(1);
				}
			else
				{
				if (cur_tonames > 2)
					send_string("Make these messages restricted (y/N)? ",NULL);
				else 
					send_string("Make this message restricted (y/N)? ",NULL);
				private = get_yn_enter(0);
				}
			}
		else if (found)
			private = 0;
		else 
			private = tmsg->msg_flags & MSG_PRIVATE ? 1 : 0;

		if (tmsg->msg_flags & MSG_ALIAS)
			{
			if (user.user_alias[0][0] || user.user_alias[1][0] || user.user_alias[2][0] || user.user_alias[3][0])
				{
				from_name[0] = user.user_name;
				total = 1;

				for (count = 0; count < 4; count++)
					{
					if (user.user_alias[count][0])
						{
						from_name[total] = user.user_alias[count];
						++total;
						}
					}

				/* now for a menu of name choices */
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\nAliases are allowed in this message area.  Choose which of the following\r\n",NULL);
				send_string("   names you wish to use in this message:\r\n\r\n",NULL);

				for (count = 0; count < total; count++)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					sprintf(buffer2,"      %d) ",count + 1);
					send_string(buffer2,NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(CYAN | BRIGHT),NULL);
					send_string("\"",NULL);
					send_string(from_name[count],NULL);
					send_string("\"\r\n",NULL);
					}
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(WHITE | BRIGHT),NULL);
				sprintf(buffer2,"\r\nWhat is your choice [1-%d] (ENTER=1)? ",total);
				send_string(buffer2,NULL);

				ok = 0;
				do
					{
					key = get_char();
					switch (key)
						{
						case '1':
						case '\r':
						case '\n':
							from = from_name[0];
							ok = 1;
							break;

						case '2':
							if (total > 1)
								{
								from = from_name[1];
								ok = 1;
								}
							break;

						case '3':
							if (total > 2)
								{
								from = from_name[2];
								ok = 1;
								}
							break;

						case '4':
							if (total > 3)
								{
								from = from_name[3];
								ok = 1;
								}
							break;

						case '5':
							if (total > 4)
								{
								from = from_name[4];
								ok = 1;
								}
							break;
						}
					}
				while (!ok);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\n   From: ",NULL);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(field_color),NULL);
				mark_field(40);
				send_string(from,NULL);
				unmark_field();
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\n\r\n",NULL);
				}
			}
		do_message(from,tonames,subject,area,priv,pflags,previous,private ? MESSAGE_PRIVATE : 0,zone,net,node,cost,net_flags);

		if (max_tonames)
			{
			for (count = 0; count < cur_tonames; count++)
				free(tonames[count]);
			free(tonames);
			}
		}
	else
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		}
	}
