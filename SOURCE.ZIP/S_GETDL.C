/* s_getdl.c
**
** Copyright (c) 1992, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 11 August 1992
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_getdl.c_v  $
**                       $Date:   25 Oct 1992 14:08:44  $
**                       $Revision:   1.0  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#include "simplex.h"



struct dep *deps = NULL;
int cur_deps = 0;
int max_deps = 0;



int filelist_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'S':
		case 'C':
		case 'R':
		case 'D':
		case 'H':
		case 'A':
			return key;
			break;
		}
	return 0;
	}



int download_choice_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'D':
		case 'A':
			return key;
			break;
		}
	return 0;
	}



int download_hangup_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'D':
		case 'H':
		case 'A':
			return key;
			break;
		}
	return 0;
	}



int movelist_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'S':
		case 'C':
		case 'R':
		case 'M':
		case 'A':
			return key;
			break;
		}
	return 0;
	}



int killlist_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'S':
		case 'C':
		case 'R':
		case 'D':
		case 'A':
			return key;
			break;
		}
	return 0;
	}



int get_filelist(struct file *tfile,int protocol,char *protname)
	{
	char buffer[100];
	char fname[15];
	long ftime;
	int retval = 0;
	int which;
	int count;
	int kount;
	int quit = 0;
	int key = 0;
	int menu;
	int ok;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	if (protocol == PROT_DIRECT)
		send_string("\r\nMultiple files may be copied",NULL);
	else
		{
		send_string("\r\n\r\nMultiple files may be sent using ",NULL);
		send_string(protname,NULL);
		}
	send_string(". Wildcards (? and *) may be used!\r\n\r\n",NULL);

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("Tag which file for download (ENTER=Menu)? ",NULL);
		get_fname(fname,12,1,0);
		if (fname[0])
			{
			if (expand_fname(tfile,fname,protocol,cfg.cfg_flags & CFG_CROSSAREA_DL ? 1 : 0))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Unable to allocate structures....Transfer cancelled!\r\n",NULL);
				cur_flist = max_flist = 0;
				get_enter();
				break;
				}
			}
		else
			{
			menu = 0;
			do
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);

				sprintf(buffer,"\r\n\r\n--- File Tagging Menu [%u file%s tagged] ---\r\n\r\n",cur_flist,(char *)(cur_flist == 1 ? "" : "s"));
				key = send_string(buffer,filelist_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string("<S> Show tagged list       <C> Continue tagging       <R> Remove tagged file\r\n<D> Download tagged files  <A> Abort Download\r\n<H> Download tagged files & hangup\r\n\r\n",filelist_handler);
					else
						key = send_string("[ SCRDAH ]\r\n\r\n",filelist_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Download)? ",filelist_handler);
					}
				ok = 0;
				do
					{
					if (!key)
						key = get_char();
					switch (key)
						{
						case 'S':
						case 's':
							cur_line = 0;
			 				send_string("\r\n",NULL);
							for (count = 0; count < cur_flist; count++)
								{
								send_string("\r\n",NULL);
								sprintf(buffer,"%5u  ",count + 1);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%-12.12s ",flist[count]->fl_name);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(BROWN | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"(Area %u)",flist[count]->fl_location);
								for (kount = strlen(buffer); kount < 12; kount++)
									strcat(buffer," ");
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%9lu ",flist[count]->fl_size);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(MAGENTA),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%02u-%02u-%02u ",(flist[count]->fl_date >> 5) & 0xf,flist[count]->fl_date & 0x1f,(((flist[count]->fl_date >> 9) & 0x7f) + 80) % 100);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_string(buffer,NULL);

								if (protocol != PROT_DIRECT)
									{
									ftime = xmit_time(protocol,flist[count]->fl_size);

									sprintf(buffer,"%3lu:%02lu",ftime / 60L,ftime % 60L);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(WHITE | BRIGHT),NULL);
									send_string(buffer,NULL);
									}
								}
							ok = 1;
							break;
						case 'C':
						case 'c':
							send_string("\r\n",NULL);
							menu = 1;
							ok = 1;
							break;
						case 'R':
						case 'r':
							if (cur_flist)
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nRemove which tagged file from list (ENTER=None)? ",NULL);
								which = get_number(0,cur_flist);

								if (which > 0 && which <= cur_flist)
									{
									--which;
									cur_line = 0;

									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);

									sprintf(buffer,"Deleted entry %u \"%s\" from list...\r\n",which + 1,flist[which]->fl_name);
									send_string(buffer,NULL);

									free(flist[which]);
									if (which < (cur_flist - 1))
										memmove(flist + which,flist + (which + 1),(cur_flist - (which + 1)) * sizeof(struct fl *));

									--cur_flist;
									}
								}
							ok = 1;
							break;
						case 'D':
						case 'd':
						case '\r':
						case '\n':
							if (cur_flist)
								retval = 1;		/* bit 0 means download */
							else 
								retval = 0;
							quit = 1;
							menu = 1;
							ok = 1;
							break;
						case 'H':
						case 'h':
							if (cur_flist)
								retval = 3;		/* bit 1 means hangup after download */
							else
								retval = 0;
							quit = 1;
							menu = 1;
							ok = 1;
							break;
						case 'A':
						case 'a':
							for (count = 0; count < cur_flist; count++)
								{
								free(flist[count]->fl_name);
								free(flist[count]);
								}
							free(flist);
							flist = NULL;
							cur_flist = 0;
							max_flist = 0;

							retval = 0;
							quit = 1;
							menu = 1;
							ok = 1;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!menu);

			send_string("\r\n",NULL);
			}
		}
	while (!quit);


	return retval;
	}



int get_xmodem_file(struct file *tfile,int protocol,char *xmitname,int *xmitarea)
	{
	struct file *tfile1;
	struct file *tfile2;
	struct fi tfi;
	struct fe tfe;
	char buffer[100];
	char buffer1[100];
	char fname[20];
	long ftime;
	int found = 0;
	int hicolor;
	int color;
	int count;
	int kount;
	int valid;
	FILE *fd;

	cur_line = 0;
	send_string("\r\n\r\n",NULL);
	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Download which file (ENTER=Exit)? ",NULL);
	get_fname(fname,12,0,0);
	if (fname[0])
		{
		if (tfile->file_descname[0])
			strcpy(buffer,tfile->file_descname);
		else 
			strcpy(buffer,tfile->file_pathname);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		strcat(buffer,"filelist.bbs");

		if (fd = open_filelist_read(buffer))
			{
			/* check file access permissions */
			while (fread(&tfe,sizeof(struct fe),1,fd))
				{
				if (!stricmp(fname,tfe.fe_name))
					{
					if (tfe.fe_location == tfile->file_number || (tfile1 = get_filearea(tfe.fe_location)))		/* location is current area, or we can find it */
						{
						if (tfe.fe_priv <= user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
							{
							if (tfe.fe_location == tfile->file_number)
								strcpy(buffer,tfile->file_pathname);
							else 
								strcpy(buffer,tfile1->file_pathname);

							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,tfe.fe_name);

							if (get_firstfile(&tfi,buffer))
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("Found this file: ",NULL);

								sprintf(buffer,"%-12.12s ",tfi.fi_name);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(BROWN | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%9lu ",tfi.fi_size);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(MAGENTA),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_string(buffer,NULL);

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nDo you want to download it (Y/n)? ",NULL);
								if (get_yn_enter(1))
									{
									ftime = xmit_time(protocol,tfi.fi_size);
									if (ftime > user_time)
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(RED | BRIGHT),NULL);
										sprintf(buffer,"Download of this file will take %lu minutes %lu seconds\r\n",ftime / 60L,ftime % 60L);
										send_string(buffer,NULL);
										send_string("You do not have enough time for this download!\r\n",NULL);
										get_enter();
										}
									else
										{
										strcpy(xmitname,tfi.fi_name);
										*xmitarea = tfe.fe_location;
										found = 1;
										}
									}
								}
							get_closefile();
							}
						}
					break;
					}
				}
			closef(fd);
			}

		if (!found && (cfg.cfg_flags & CFG_CROSSAREA_DL))
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("\r\nThe file \"",NULL);
			send_string(fname,NULL);
			send_string("\" was not found here.  Want me to search across\r\n",NULL);
			send_string("all file areas for it (Y/n)? ",NULL);
			if (get_yn_enter(1))
				{
				send_string("\r\n",NULL);
				for (count = get_minfilearea(); !found && count <= get_maxfilearea(); count++)
					{
					if (count != tfile->file_number)
						{
						if (tfile1 = get_filearea(count))
							{
							if (user.user_priv >= tfile1->file_priv && (tfile1->file_flags & user.user_uflags) == tfile1->file_flags)
								{
								if (tfile1->file_descname[0])
									strcpy(buffer,tfile1->file_descname);
								else 
									strcpy(buffer,tfile1->file_pathname);
								if (buffer[0])
									{
									if (buffer[strlen(buffer) - 1] != P_CSEP)
										strcat(buffer,P_SSEP);
									}
								strcat(buffer,"filelist.bbs");

								strcpy(filepath,tfile1->file_pathname);
								if (filepath[0])
									{
									if (filepath[strlen(filepath) - 1] != P_CSEP)
										strcat(filepath,P_SSEP);
									}

								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									{
									color = count & 0x7;
									color = color ? color : 7;
									hicolor = color | 0x8;
									send_string(new_color(color),NULL);
									}

								send_string("Area: ",NULL);
								strcpy(buffer1,tfile1->file_areaname);
								for (kount = (int)strlen(buffer1); kount < 40; kount++)
									strcat(buffer1," ");
								strcat(buffer1,"\r");
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(hicolor),NULL);
					    		send_string(buffer1,NULL);

								if (fd = open_filelist_read(buffer))		/* now open the list file itself */
									{
									while (fread(&tfe,sizeof(struct fe),1,fd))
										{
										if (!stricmp(fname,tfe.fe_name))
											{
											if (tfe.fe_priv <= (unsigned int)user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
												{
												valid = 1;
												if (tfe.fe_location == count)
													strcpy(buffer,filepath);
												else if (tfile2 = get_filearea(tfe.fe_location))
													{
													strcpy(buffer,tfile2->file_pathname);
													if (buffer[0])
														{
														if (buffer[strlen(buffer) - 1] != P_CSEP)
															strcat(buffer,P_SSEP);
														}
													}
												else
													valid = 0;

												if (valid)
													{
													strcat(buffer,tfe.fe_name);
													if (get_firstfile(&tfi,buffer))
														{
														cur_line = 0;
														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(GREEN | BRIGHT),NULL);
														send_string("\r\nFound this file: ",NULL);

														sprintf(buffer,"%-12.12s ",tfi.fi_name);
														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(BROWN | BRIGHT),NULL);
														send_string(buffer,NULL);

														sprintf(buffer,"%9lu ",tfi.fi_size);
														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(MAGENTA | BRIGHT),NULL);
														send_string(buffer,NULL);

														sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(CYAN | BRIGHT),NULL);
														send_string(buffer,NULL);

														if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
															send_string(new_color(GREEN | BRIGHT),NULL);
														send_string("\r\nDo you want to download it (Y/n)? ",NULL);
														if (get_yn_enter(1))
															{
															ftime = xmit_time(protocol,tfi.fi_size);
															if (ftime > user_time)
																{
																if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
																	send_string(new_color(RED | BRIGHT),NULL);
																sprintf(buffer,"Download of this file will take %lu minutes %lu seconds\r\n",ftime / 60L,ftime % 60L);
																send_string(buffer,NULL);
																send_string("You do not have enough time for this download!\r\n",NULL);
																get_enter();
																}
															else
																{
																strcpy(xmitname,tfi.fi_name);
																*xmitarea = tfe.fe_location;
																found = 1;
																}
															}
														else
															send_string("\r\n",NULL);
														}
													get_closefile();
													}
												}
											break;
											}
										}
									closef(fd);
									}
								}
							}
						}
					}
				send_string("\r",NULL);					/* wipe out search area line */
				for (count = 0; count < 50; count++)
					send_string(" ",NULL);

				if (!found)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\nUnable to locate a file called \"",NULL);
					send_string(fname,NULL);
					send_string("\" on this system.\r\n\r\n",NULL);
					get_enter();
					}
				}
			send_string("\r\n",NULL);
			}
		else if (!found)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nUnable to locate a file called \"",NULL);
			send_string(fname,NULL);
			send_string("\" on this system.\r\n\r\n",NULL);
			get_enter();
			}
		}

	return found;
	}



int get_download_choice(int hangup)
	{
	int retval = 0;
	int key = 0;
	int menu;
	int ok;

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		if (hangup)
			key = send_string("\r\n\r\n--- Download Choice Menu ---\r\n\r\n",download_hangup_handler);
		else 
			key = send_string("\r\n\r\n--- Download Choice Menu ---\r\n\r\n",download_choice_handler);

		if (!key)
			{
			if (!(user.user_flags & USER_EXPERT))
				{
				if (hangup)
					key = send_string("<D> Download file  <A> Abort Download  <H> Download file & hangup\r\n\r\n",download_hangup_handler);
				else 
					key = send_string("<D> Download file  <A> Abort Download\r\n\r\n",download_choice_handler);
				}
			else
				{
				if (hangup)
					key = send_string("[ DAH ]\r\n\r\n",download_hangup_handler);
				else 
					key = send_string("[ DA ]\r\n\r\n",download_choice_handler);
				}
			if (!key)
				{
				if (hangup)
					key = send_string("What is your choice (ENTER=Download)? ",download_hangup_handler);
				else 
					key = send_string("What is your choice (ENTER=Download)? ",download_choice_handler);
				}
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'D':
				case 'd':
				case '\r':
				case '\n':
					retval = 1;		/* bit 0 means download */
					menu = 1;
					ok = 1;
					break;
				case 'H':
				case 'h':
					if (hangup)
						{
						retval = 3;		/* bit 1 means hangup after download */
						menu = 1;
						ok = 1;
						}
					break;
				case 'A':
				case 'a':
					retval = 0;
					menu = 1;
					ok = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!menu);
	send_string("\r\n",NULL);

	return retval;
	}



int get_movelist(struct file *tfile)
	{
	char buffer[100];
	char fname[15];
	int retval = 0;
	int which;
	int count;
	int quit = 0;
	int key = 0;
	int menu;
	int ok;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\nMultiple files may be moved. Wildcards (? and *) may be used!\r\n\r\n",NULL);

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("Tag which file for moving (ENTER=Menu)? ",NULL);
		get_fname(fname,12,1,0);
		if (fname[0])
			{
			if (expand_fname(tfile,fname,PROT_DIRECT,0))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Unable to allocate structures....Transfer cancelled!\r\n",NULL);
				cur_flist = max_flist = 0;
				get_enter();
				break;
				}
			}
		else
			{
			menu = 0;
			do
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);

				sprintf(buffer,"\r\n\r\n--- Move Tagging Menu [%u file%s tagged] ---\r\n\r\n",cur_flist,(char *)(cur_flist == 1 ? "" : "s"));
				key = send_string(buffer,movelist_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string("<S> Show tagged list       <C> Continue tagging       <R> Remove tagged file\r\n<M> Move tagged files      <A> Abort Move\r\n\r\n",movelist_handler);
					else
						key = send_string("[ SCRMA ]\r\n\r\n",movelist_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Move)? ",movelist_handler);
					}
				ok = 0;
				do
					{
					if (!key)
						key = get_char();
					switch (key)
						{
						case 'S':
						case 's':
							cur_line = 0;
			 				send_string("\r\n",NULL);
							for (count = 0; count < cur_flist; count++)
								{
								sprintf(buffer,"%5u  ",count + 1);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%-12.12s ",flist[count]->fl_name);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(BROWN | BRIGHT),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%9lu ",flist[count]->fl_size);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(MAGENTA),NULL);
								send_string(buffer,NULL);

								sprintf(buffer,"%02u-%02u-%02u\r\n",(flist[count]->fl_date >> 5) & 0xf,flist[count]->fl_date & 0x1f,(((flist[count]->fl_date >> 9) & 0x7f) + 80) % 100);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_string(buffer,NULL);
								}
							ok = 1;
							break;
						case 'C':
						case 'c':
							send_string("\r\n",NULL);
							menu = 1;
							ok = 1;
							break;
						case 'R':
						case 'r':
							if (cur_flist)
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nRemove which tagged file from list (ENTER=None)? ",NULL);
								which = get_number(0,cur_flist);

								if (which > 0 && which <= cur_flist)
									{
									--which;
									cur_line = 0;

									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);

									sprintf(buffer,"Deleted entry %u \"%s\" from list...\r\n",which + 1,flist[which]->fl_name);
									send_string(buffer,NULL);

									free(flist[which]);
									if (which < (cur_flist - 1))
										memmove(flist + which,flist + (which + 1),(cur_flist - (which + 1)) * sizeof(struct fl *));

									--cur_flist;
									}
								}
							ok = 1;
							break;
						case 'M':
						case 'm':
						case '\r':
						case '\n':
							retval = 1;
							quit = 1;
							menu = 1;
							ok = 1;
							break;
						case 'A':
						case 'a':
							for (count = 0; count < cur_flist; count++)
								{
								free(flist[count]->fl_name);
								free(flist[count]);
								}
							free(flist);
							flist = NULL;
							cur_flist = 0;
							max_flist = 0;

							retval = 0;
							quit = 1;
							menu = 1;
							ok = 1;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!menu);

			send_string("\r\n",NULL);
			}
		}
	while (!quit);

	return retval;
	}



int get_killlist(struct file *tfile,char *listpath)
	{
	struct file *tfile1;
	struct file *tfile2;
	struct fe tfe;
	struct fe tfe1;
	struct fi tfi;
	char buffer[100];
	char fname[15];
	int retval = 0;
	int scanned = 0;
	int which;
	int count;
	int kount;
	int found;
	int quit = 0;
	int key = 0;
	int menu;
	int skip;
	int ok;
	FILE *fd;
	FILE *fd1;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\nEnter the names of files to delete...\r\n\r\n",NULL);

	strcpy(buffer,listpath);
	strcat(buffer,"filelist.bbs");

	if (fd = open_filelist_read(buffer))
		{
		do
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("Tag which file for deletion (ENTER=Menu)? ",NULL);
			get_fname(fname,12,1,0);
			if (fname[0])
				{
				strupr(fname);

				found = 0;
				for (count = 0; count < cur_flist; count++)
					{
					if (!stricmp(flist[count]->fl_name,fname))
						{
						found = 1;
						break;
						}
					}

				if (!found)
					{
					fseek(fd,0L,SEEK_SET);
					while (fread(&tfe,sizeof(struct fe),1,fd))
						{
						if (!stricmp(fname,tfe.fe_name))
							{
							if (tfe.fe_location == tfile->file_number || (tfile1 = get_filearea(tfe.fe_location)))		/* location is current area, or we can find it */
								{
								skip = 0;
								for (count = 0; count < cur_flist; count++)
									{
									if (!stricmp(fname,flist[count]->fl_name))
										skip = 1;
									}

								if (!skip)
									{
									if (cur_flist >= max_flist)
										{
										if (!(flist = realloc(flist,(max_flist += 10) * sizeof(struct fl *))))
											{
											_error(E_ERROR,"Unable to allocate memory for filenames.");
											cur_flist = 0;
											max_flist = 0;
											closef(fd);

											if (cur_deps)
												free(deps);
											deps = NULL;
											max_deps = 0;
											cur_deps = 0;

											return 0;
											}
										}
									if (!(flist[cur_flist] = malloc(sizeof(struct fl))))
										{
										_error(E_ERROR,"Unable to allocate memory for filenames.");
										cur_flist = 0;
										max_flist = 0;
										closef(fd);

										if (cur_deps)
											free(deps);
										deps = NULL;
										max_deps = 0;
										cur_deps = 0;

										return 0;
										}
									if (!(flist[cur_flist]->fl_name = malloc(strlen(fname) + 1)))
										{
										_error(E_ERROR,"Unable to allocate memory for filenames.");
										cur_flist = 0;
										max_flist = 0;
										closef(fd);

										if (cur_deps)
											free(deps);
										deps = NULL;
										max_deps = 0;
										cur_deps = 0;

										return 0;
										}
									strcpy(flist[cur_flist]->fl_name,fname);
									flist[cur_flist]->fl_location = tfe.fe_location;
									flist[cur_flist]->fl_size = 0L;
									flist[cur_flist]->fl_date = 0;
									++cur_flist;

									sprintf(buffer,"%5u  ",cur_flist);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string(buffer,NULL);

									sprintf(buffer,"%-12.12s ",fname);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(buffer,NULL);

									if (tfe.fe_location == tfile->file_number)
										strcpy(buffer,tfile->file_pathname);
									else 
										strcpy(buffer,tfile1->file_pathname);
									if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
										strcat(buffer,P_SSEP);
									strcat(buffer,fname);

									if (get_firstfile(&tfi,buffer))
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(MAGENTA),NULL);
										send_string("Wait...\b\b\b\b\b\b\b",NULL);

										if (!scanned)			/* scan areas for references */
											{
											scanned = 1;

											for (count = get_minfilearea(); scanned != -1 && count < get_maxfilearea(); count++)
												{
												if (count != tfile->file_number)
													{
													if (tfile2 = get_filearea(count))
														{
														if (tfile2->file_descname[0])
															strcpy(buffer,tfile2->file_descname);
														else 
															strcpy(buffer,tfile2->file_pathname);
														if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
															strcat(buffer,P_SSEP);
														strcat(buffer,"filelist.bbs");

														if (fd1 = open_filelist_read(buffer))
															{
															while (fread(&tfe1,sizeof(struct fe),1,fd1))
																{
																if (tfe1.fe_location != count)		/* aliased file */
																	{
																	found = 0;
																	for (kount = 0; kount < cur_deps; kount++)
																		{
																		if (deps[kount].dep_area == tfe1.fe_location && deps[kount].dep_check == count)
																			{
																			found = 1;
																			break;
																			}
																		}

																	if (!found)
																		{
																		if (cur_deps >= max_deps)
																			{
																			if (!(deps = realloc(deps,(max_deps += 25) * sizeof(struct dep))))
																				{
																				scanned = -1;
																				break;
																				}
																			}
																		deps[cur_deps].dep_area = tfe1.fe_location;
																		deps[cur_deps].dep_check = count;
																		++cur_deps;
																		}
																	}
																}
															closef(fd1);
															}
														}
													}
												}
											}

										/* now we need to check EVERY aliased area to see if this file is aliased */
										ok = 1;
										for (count = 0; ok && count < cur_deps; count++)
											{
											if (deps[count].dep_area == tfe.fe_location && count != tfile->file_number)
												{
												if (tfile2 = get_filearea(deps[count].dep_check))		/* have to check a dependent area */
													{
													if (tfile2->file_descname[0])
														strcpy(buffer,tfile2->file_descname);
													else 
														strcpy(buffer,tfile2->file_pathname);
													if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
														strcat(buffer,P_SSEP);
													strcat(buffer,"filelist.bbs");

													if (fd1 = open_filelist_read(buffer))
														{
														while (fread(&tfe1,sizeof(struct fe),1,fd1))
															{
															if (tfe1.fe_location == tfe.fe_location && !stricmp(tfe1.fe_name,fname))
																{
																ok = 0;
																break;
																}
															}
														closef(fd1);
														}
													}
												}
											}

										if (ok)
											{
											sprintf(buffer,"%9lu ",tfi.fi_size);
											send_string(buffer,NULL);

											sprintf(buffer,"%02u-%02u-%02u ",(tfi.fi_date >> 5) & 0xf,tfi.fi_date & 0x1f,(((tfi.fi_date >> 9) & 0x7f) + 80) % 100);
											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(CYAN),NULL);
											send_string(buffer,NULL);

											flist[cur_flist - 1]->fl_size = tfi.fi_size;
											flist[cur_flist - 1]->fl_date = tfi.fi_date;
											flist[cur_flist - 1]->fl_update = 1;		/* flag that file exists */
											}
										else
											{
											send_string("Aliased elsewhere: Only entry will be deleted.",NULL);
											flist[cur_flist - 1]->fl_size = tfi.fi_size;
											flist[cur_flist - 1]->fl_date = tfi.fi_date;
											flist[cur_flist - 1]->fl_update = 0;		/* flag that file can't be deleted */
											}
										}
									else
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(MAGENTA),NULL);
										send_string("Missing: Deletion of entry will occur.",NULL);

										flist[cur_flist - 1]->fl_update = 0;		/* flag that file doesn't exist */
										}

									get_closefile();

									send_string("\r\n",NULL);
									}
								}
							}
						}
					}
				else
					{
					sprintf(buffer,"%5u  ",count + 1);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string(buffer,NULL);

					sprintf(buffer,"%-12.12s ",fname);
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(BROWN | BRIGHT),NULL);
					send_string(buffer,NULL);

					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(MAGENTA),NULL);

					send_string("Already in deletion list.\r\n",NULL);
					}
				}
			else
				{
				menu = 0;
				do
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(menu_color),NULL);

					sprintf(buffer,"\r\n\r\n--- Deletion Tagging Menu [%u file%s tagged] ---\r\n\r\n",cur_flist,(char *)(cur_flist == 1 ? "" : "s"));
					key = send_string(buffer,killlist_handler);
					if (!key)
						{
						if (!(user.user_flags & USER_EXPERT))
							key = send_string("<S> Show tagged list       <C> Continue tagging       <R> Remove tagged file\r\n<D> Delete tagged files    <A> Abort delete\r\n\r\n",killlist_handler);
						else
							key = send_string("[ SCRDA ]\r\n\r\n",killlist_handler);
						if (!key)
							key = send_string("What is your choice (ENTER=Delete)? ",killlist_handler);
						}
					ok = 0;
					do
						{
						if (!key)
							key = get_char();
						switch (key)
							{
							case 'S':
							case 's':
								cur_line = 0;
			 					send_string("\r\n",NULL);
								for (count = 0; count < cur_flist; count++)
									{
									sprintf(buffer,"%5u  ",count + 1);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(RED | BRIGHT),NULL);
									send_string(buffer,NULL);

									sprintf(buffer,"%-12.12s ",flist[count]->fl_name);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(buffer,NULL);

									sprintf(buffer,"%9lu ",flist[count]->fl_size);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(MAGENTA),NULL);
									send_string(buffer,NULL);

									sprintf(buffer,"%02u-%02u-%02u\r\n",(flist[count]->fl_date >> 5) & 0xf,flist[count]->fl_date & 0x1f,(((flist[count]->fl_date >> 9) & 0x7f) + 80) % 100);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);
									send_string(buffer,NULL);
									}
								ok = 1;
								break;
							case 'C':
							case 'c':
								send_string("\r\n",NULL);
								menu = 1;
								ok = 1;
								break;
							case 'R':
							case 'r':
								if (cur_flist)
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\n\r\nRemove which tagged file from list (ENTER=None)? ",NULL);
									which = get_number(0,cur_flist);

									if (which > 0 && which <= cur_flist)
										{
										--which;
										cur_line = 0;

										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(RED | BRIGHT),NULL);

										sprintf(buffer,"Deleted entry %u \"%s\" from list...\r\n",which + 1,flist[which]->fl_name);
										send_string(buffer,NULL);

										free(flist[which]);
										if (which < (cur_flist - 1))
											memmove(flist + which,flist + (which + 1),(cur_flist - (which + 1)) * sizeof(struct fl *));

										--cur_flist;
										}
									}
								ok = 1;
								break;
							case 'D':
							case 'd':
							case '\r':
							case '\n':
								retval = 1;
								quit = 1;
								menu = 1;
								ok = 1;
								break;
							case 'A':
							case 'a':
								for (count = 0; count < cur_flist; count++)
									{
									free(flist[count]->fl_name);
									free(flist[count]);
									}
								free(flist);
								flist = NULL;
								cur_flist = 0;
								max_flist = 0;

								retval = 0;
								quit = 1;
								menu = 1;
								ok = 1;
								break;
							}
						key = 0;
						}
					while (!ok);
					}
				while (!menu);

				send_string("\r\n",NULL);
				}
			}
		while (!quit);

		closef(fd);
		}

	if (cur_deps)
		free(deps);
	deps = NULL;
	max_deps = 0;
	cur_deps = 0;

	return retval;
	}
