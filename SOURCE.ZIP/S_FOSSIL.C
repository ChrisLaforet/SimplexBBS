/* s_fossil.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 23 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_fossil.c_v  $
**                       $Date:   25 Oct 1992 14:08:24  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <string.h>
#include <process.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_KBD 
	#define INCL_DOSPROCESS
	#define INCL_DOSFILEMGR
	#define INCL_DOSDEVICES
	#define INCL_DOSSEMAPHORES
	#include <os2.h>
#else
	#include <dos.h>
#endif
#include "simplex.h"



extern jmp_buf reset_bbs;



#ifdef PROTECTED		/* "fossil" routines for OS/2 */

/* ----------------------- Structures for IOCTL ------------------------
**            Taken from MS's OS/2 toolkit -- missing in IBM's!
*/

struct _dcbinfo	
	{
	USHORT usWriteTimeout;
	USHORT usReadTimeout;
	BYTE fbCtlHndShake;
	BYTE fbFlowReplace;
	BYTE fbTimeout;
	BYTE bErrorReplacementChar;
	BYTE bBreakReplacementChar;
	BYTE bXONChar;
	BYTE bXOFFChar;
	};


struct _linecontrol
	{
	BYTE bDataBits;
	BYTE bParity;
	BYTE bStopBits;
	BYTE fTransBreak;
	};


struct _rxqueue
	{
	USHORT cch;
	USHORT cb;
	};


struct _modemstatus
	{
	BYTE fbModemOn;
	BYTE fbModemOff;
	};


/* -------------------- End of Structures for IOCTL -------------------- */


#define KB_STACKSIZE			2048
#define MAX_PORT				8
#define COM_TIMEOUT				1


HFILE hComm[MAX_PORT] =
	{
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	(HFILE)-1,
	};
volatile int kb_hit = 0;
long kbaccess_sem = 0L;
int kbthread = 1;
TID kb_tid;
int kb_stack[KB_STACKSIZE / sizeof(int)];		/* word-align the stack */
int com_port = 0;
int reset_port = 0;


#if 0
	volatile int incom_waiting = 0;
	long incomaccess_sem = 0L;
	int incomthread = 1;
	TID incom_tid;
	int incom_stack[COM_STACKSIZE / sizeof(int)];	/* word-align the stack */
#endif




/* -------------------- Start of Ring Buffer Handlers -------------------- */

#define RING_STACKSIZE			2048
#define RINGBUF_SIZE			2048
#define READ_AHEAD				32

#define MAX_DIFF				1024


int oring_stack[RING_STACKSIZE / sizeof(int)];		/* word-align the stack */
int ringthread = 1;
char inoringbuf[RINGBUF_SIZE];
int inoring;
int outoring;
long oring_sem = 0L;			/* controls access to our oring buffer */
TID oring_tid;

int iring_stack[RING_STACKSIZE / sizeof(int)];		/* word-align the stack */
char iniringbuf[RINGBUF_SIZE];
int iniring;
int outiring;
long iring_sem = 0L;			/* controls access to our oring buffer */
TID iring_tid;



void pascal purge_oringbuf(void)
	{
	DosSemRequest(&oring_sem,SEM_INDEFINITE_WAIT);
	inoring  = outoring = 0;
	DosSemClear(&oring_sem);
	}



int pascal write_oringbuf(char character,int wait)
	{
	int type;
	int ok = 0;

	DosSemRequest(&oring_sem,SEM_INDEFINITE_WAIT);
	if (inoring != outoring)
		{
		type = 0;
		if ((inoring < outoring) && ((inoring + 1) == outoring))
			type = 1;
		else if (!outoring && (inoring == (RINGBUF_SIZE - 1)))		/* no room in the buffer */
			type = 2;

		if (type)
			{
			do
				{
				if (type == 1 && (inoring + 1) != outoring)
					++ok;
				else if (type == 2 && outoring)
					++ok;

				if (!ok && wait)
					{
					DosSemClear(&oring_sem);

					if (user_online && !cd)			/* CD still there? */
				 		longjmp(reset_bbs,1);
					DosSleep(10L);

					DosSemRequest(&oring_sem,SEM_INDEFINITE_WAIT);
					}
				}
			while (!ok && wait);
			}
		else
			++ok;
		}
	else
		++ok;

	if (ok)
		{
		*(unsigned char *)(inoringbuf + inoring) = (unsigned char)character;
		inoring = ++inoring % RINGBUF_SIZE;
		}
	DosSemClear(&oring_sem);

	if (!wait && user_online && !cd)			/* CD still there? */
 		longjmp(reset_bbs,1);

	return ok;
	}



void oring_handler(void far *dummy)
	{
	unsigned char buffer[READ_AHEAD];
	int written;
	int current;
	int slice = 0;
	int send;
	int left;

	DosSetPrty(PRTYS_THREAD,PRTYC_FOREGROUNDSERVER,PRTYD_MAXIMUM,oring_tid);
	while (ringthread)
		{
		DosSemRequest(&oring_sem,SEM_INDEFINITE_WAIT);
		if (inoring != outoring)
			{
			/* send a character */
			send = 0;
			do
				{
				buffer[send++] = (unsigned char)inoringbuf[outoring];
				outoring = ++outoring % RINGBUF_SIZE;
				}
			while (send < READ_AHEAD && inoring != outoring);
			DosSemClear(&oring_sem);

			if (send)
				{
				current = 0;
				left = send - current;
				do
					{
					DosWrite(hComm[com_port],buffer + current,left,&written);
					if (written)
						{
						current += written;
						left = send - current;
						}
					if (written != left)
						{
						if (!ringthread)
							break;
						if (!written && user_online && !cd)
							break;
						if (slice >= 20)
							{
							DosSleep(1L);
							slice = 0;
							}
						else
							++slice;
						}
					}
				while (current < send);
				}
			}
		else
			{
			DosSemClear(&oring_sem);
			DosSleep(40L);
			}
		}
	_endthread();
	}



void pascal purge_iringbuf(void)
	{
	DosSemRequest(&iring_sem,SEM_INDEFINITE_WAIT);
	iniring = outiring = 0;
	DosSemClear(&iring_sem);
	}



int pascal peek_iringbuf(void)
	{
	int rtn;

	DosSemRequest(&iring_sem,SEM_INDEFINITE_WAIT);
	if (iniring == outiring)
		rtn = -1;
	else
		rtn = 0;
	DosSemClear(&iring_sem);
	return rtn;
	}



int pascal read_iringbuf(void)
	{
	int rtn = -1;

	DosSemRequest(&iring_sem,SEM_INDEFINITE_WAIT);
	if (iniring != outiring)
		{
		rtn = (int)(unsigned char)iniringbuf[outiring];
		outiring = ++outiring % RINGBUF_SIZE;
		}
	DosSemClear(&iring_sem);
	return rtn;
	}



void iring_handler(void far *dummy)
	{
	unsigned char buffer[READ_AHEAD];
	int current;
	int bytesread;
	int type;
	int ok;

	DosSetPrty(PRTYS_THREAD,PRTYC_FOREGROUNDSERVER,PRTYD_MAXIMUM,iring_tid);
	while (ringthread)
		{
		DosRead(hComm[com_port],buffer,READ_AHEAD,&bytesread);
		if (bytesread)
			{
			DosSemRequest(&iring_sem,SEM_INDEFINITE_WAIT);
			current = 0;
			do
				{
				if (iniring != outiring)
					{
					type = 0;
					if ((iniring < outiring) && (iniring + 1) == outiring)
						type = 1;
					else if (!outiring && (iniring == (RINGBUF_SIZE - 1)))		/* no room in the buffer */
						type = 2;

					if (type)
						{
						ok = 0;
						do
							{
							DosSemClear(&iring_sem);
							DosSleep(1L);
							DosSemRequest(&iring_sem,SEM_INDEFINITE_WAIT);
							if (type == 1 && (iniring + 1) != outiring)
								ok = 1;
							else if (type == 2 && outiring)
								ok = 1;
							}
						while (!ok);
						}
					}
				*(unsigned char *)(iniringbuf + iniring) = buffer[current];
				iniring = ++iniring % RINGBUF_SIZE;
				++current;
				}
			while (current < bytesread);
			DosSemClear(&iring_sem);
			}
		else
			DosSleep(20L);
		}
	_endthread();
	}



int start_ringthread(void)
	{
	iniring = outiring = 0;
	DosSemClear(&iring_sem);
	if ((iring_tid = _beginthread(iring_handler,iring_stack,RING_STACKSIZE,NULL)) == -1)
		return 0;

	inoring = outoring = 0;
	DosSemClear(&oring_sem);
	if ((oring_tid = _beginthread(oring_handler,oring_stack,RING_STACKSIZE,NULL)) == -1)
		return 0;
	return 1;
	}


/* -------------------- End of Ring Buffer Handlers -------------------- */



void monitor_kb(void far *dummy)
	{
	KBDKEYINFO ki;

	DosSetPrty(PRTYS_THREAD,PRTYC_FOREGROUNDSERVER,PRTYD_MAXIMUM,kb_tid);
	while (kbthread)
		{
		if (!kb_hit)
			{
			DosSemRequest(&kbaccess_sem,SEM_INDEFINITE_WAIT);
			KbdPeek(&ki,0);
			if (ki.fbStatus & 0x40)		/* final character in */
				kb_hit = 1;
			else 
				kb_hit = 0;
			DosSemClear(&kbaccess_sem);

			if (!kb_hit)
				DosSleep(50L);
			}
		else 
			DosSleep(50L);
		}
	_endthread();
	}



int start_kbthread(void)
	{
	if ((kb_tid = _beginthread(monitor_kb,kb_stack,KB_STACKSIZE,NULL)) == -1)
		return 0;
	return 1;
	}



int init_fossil(int port)
	{
	struct _dcbinfo di;
	struct _modemstatus ms;
	UCHAR szBuffer[5];
	USHORT action;
	USHORT error;

	if (port >= MAX_PORT)
		return 0;
	if (hComm[port] == -1)
		{
		sprintf(szBuffer,"COM%u",port + 1);
		if (DosOpen(szBuffer,&hComm[port],&action,0L,FILE_NORMAL,FILE_OPEN,OPEN_ACCESS_READWRITE | OPEN_SHARE_DENYREADWRITE,0L))
			return 0;				/* failed port open */
		DosDevIOCtl(&di,0L,0x73,1,hComm[port]);
		di.usWriteTimeout = COM_TIMEOUT;
		di.usReadTimeout = COM_TIMEOUT;
		di.fbCtlHndShake = (BYTE)1;		/* dtr control */
		di.fbFlowReplace = (BYTE)0x40;	/* flip RTS Control mode on */
		di.fbTimeout &= 0xfa;			/* kill no write timeout and wait read timeout -- LEAVE hardware buffering */
		di.fbTimeout = (BYTE)2; 		/* read timeout */
		DosDevIOCtl(0L,&di,0x53,1,hComm[port]);

		ms.fbModemOn = 0x2;			/* flip RTS on */
		ms.fbModemOff = 0xff;
		DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);		/* set modem control */

		com_port = port;

		fossil_init = 1;
		}
	return 1;
	}



int setup_fossil(int port,int handle)		/* if handle is passed to BBS */
	{
	struct _dcbinfo di;
	struct _modemstatus ms;
	USHORT error;

	if (port >= MAX_PORT)
		return 0;
	if (hComm[port] == -1)
		{
		hComm[port] = handle;
		DosDevIOCtl(&di,0L,0x73,1,hComm[port]);
/*		memcpy(&reset_di,&di,sizeof(struct _dcbinfo)); */
		reset_port = 1;		/* so close-down routines do not close handle */

		di.usWriteTimeout = COM_TIMEOUT;
		di.usReadTimeout = COM_TIMEOUT;
		di.fbCtlHndShake = (BYTE)1;		/* dtr control */
		di.fbCtlHndShake |= (BYTE)0x8;	/* enable CTS control */
		di.fbFlowReplace = (BYTE)0x40;	/* flip RTS Control mode on */
		di.fbTimeout &= 0xfa;			/* kill no write timeout and wait read timeout -- LEAVE hardware buffering */
		di.fbTimeout |= (BYTE)2; 		/* read timeout */
		DosDevIOCtl(0L,&di,0x53,1,hComm[port]);

		ms.fbModemOn = 0x2;			/* flip RTS on */
		ms.fbModemOff = 0xff;
		DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);		/* set modem control */

		com_port = port;
		fossil_init = 1;
		}
	return 1;
	}



void reinit_fossil(int port)		/* reinits when BBS is reentered  */
	{
	struct _dcbinfo di;
	struct _modemstatus ms;
	USHORT error;

	if (port >= MAX_PORT)
		return;
	if (hComm[port] != -1)
		{
		DosDevIOCtl(&di,0L,0x73,1,hComm[port]);
		di.usWriteTimeout = COM_TIMEOUT;
		di.usReadTimeout = COM_TIMEOUT;
		di.fbCtlHndShake = (BYTE)1;		/* enable dtr control */
		di.fbCtlHndShake |= (BYTE)0x8;	/* enable CTS control */
		di.fbFlowReplace = (BYTE)0x40;	/* flip RTS Control mode on */
		di.fbTimeout &= 0xfa;			/* kill no write timeout and wait read timeout -- LEAVE hardware buffering */
		di.fbTimeout = (BYTE)2; 		/* read timeout */
		DosDevIOCtl(0L,&di,0x53,1,hComm[port]);

		ms.fbModemOn = 0x2;			/* flip RTS on */
		ms.fbModemOff = 0xff;
		DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);		/* set modem control */

		fossil_init = 1;
		}
	}



void deinit_fossil(int port)
	{
	struct _dcbinfo di;
	struct _modemstatus ms;
	USHORT error;

	if (port >= MAX_PORT)
		return;
	if (hComm[port] != (HFILE)-1)
		{
		kbthread = 0;
		ringthread = 0;
/*		incomthread = 0; */
		DosSleep(250L);

		if (hComm[port] != -1)
			{
			DosDevIOCtl(&di,0L,0x73,1,hComm[port]);
			di.usWriteTimeout = COM_TIMEOUT;
			di.usReadTimeout = COM_TIMEOUT;
			di.fbCtlHndShake = (BYTE)1;		/* enable dtr control */
			di.fbFlowReplace = (BYTE)0x40;	/* flip RTS Control mode on */
			di.fbTimeout &= 0xfa;			/* kill no write timeout and wait read timeout -- LEAVE hardware buffering */
			di.fbTimeout = (BYTE)2; 		/* read timeout */
			DosDevIOCtl(0L,&di,0x53,1,hComm[port]);
			}
		raise_dtr(port);

		ms.fbModemOn = 0x2;			/* flip RTS on */
		ms.fbModemOff = 0xff;
		DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);		/* set modem control */

		if (!reset_port)
			DosClose(hComm[port]);
		hComm[port] = (HFILE)-1;
		fossil_init = 0;
		}
	}



int set_baud(int port,int baud)
	{
	struct _linecontrol lc;

	if (locked_flag)			/* never change the baud rate */
		baud = locked_baud;
	if (DosDevIOCtl(0L,&baud,0x41,1,hComm[port]))
		return 0;
	lc.bDataBits = 8;
	lc.bParity = 0;
	lc.bStopBits = 0;
	if (DosDevIOCtl(0L,&lc,0x42,1,hComm[port]))
		return 0;
	return 1;
	}



int get_status(int port)
	{
	USHORT flags;
	int rtn = 8;

	DosDevIOCtl(&flags,0L,0x72,1,hComm[port]);		/* get comm event */
	if (flags & 0x1)		/* char received */
		rtn |= 0x100;
	if (flags & 0x4)		/* last char sent */
		rtn |= 0x4000;
	DosDevIOCtl(&flags,0L,0x67,1,hComm[port]);		/* get modem input */
	if (flags & 0x80)		/* DCD on? */
		rtn |= 0x80;
	return rtn;
	}



void raise_dtr(int port)
	{
	struct _modemstatus ms;
	USHORT error;

	ms.fbModemOn = 0x1;			/* DTR on */
	ms.fbModemOff = 0xff;
	DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);
	}



void lower_dtr(int port)
	{
	struct _modemstatus ms;
	USHORT error;

	ms.fbModemOn = 0x0;
	ms.fbModemOff = 0xfe;			/* DTR off */
	DosDevIOCtl(&error,&ms,0x46,1,hComm[port]);
	}



void start_break(int port)
	{
	USHORT err;

	DosDevIOCtl(&err,0L,0x4b,1,hComm[port]);	/* setbreakon */
	}



void stop_break(int port)
	{
	USHORT err;

	DosDevIOCtl(&err,0L,0x45,1,hComm[port]);	/* setbreakoff */
	}



void enable_flowctrl(int port,int cts,int xon_xmit,int xon_recv)
	{
	struct _dcbinfo di;

	DosDevIOCtl(&di,0L,0x73,1,hComm[port]);
	di.fbCtlHndShake = (BYTE)1;		/* DTR control */
	di.fbFlowReplace = (BYTE)0;
	if (cts)
		{
		di.fbCtlHndShake |= 0x8;		/* CTS handshake */
		di.fbFlowReplace |= 0x80;		/* RTS handshake */
		}
	else 
		di.fbFlowReplace |= 0x40;		/* RTS control */
	if (xon_xmit)
		di.fbFlowReplace |= 0x1;		/* XON/XOFF automatic input flow control */
	if (xon_recv)
		di.fbFlowReplace |= 0x2;		/* XON/XOFF automatic output flow control */
	if (xon_xmit || xon_recv)
		{
		di.bXONChar = (BYTE)0x11;
		di.bXOFFChar = (BYTE)0x13;
		}
	DosDevIOCtl(0L,&di,0x53,1,hComm[port]);
	}



void flush_output(int port)
	{
	DosBufReset(hComm[port]);
	}



void purge_output_buffer(int port)		/* clears pending bytes in output buffer */
	{
	purge_oringbuf();
	DosDevIOCtl(0L,0L,0x2,0xb,hComm[port]);		/* dev flush output */
	}



void purge_input_buffer(int port)		/* clears pending bytes in input buffer */
	{
	purge_iringbuf();
	DosDevIOCtl(0L,0L,0x1,0xb,hComm[port]);		/* dev flush input */
	}



int pascal check_cd(int port)
	{
	USHORT flags;

	DosDevIOCtl(&flags,0L,0x67,1,hComm[port]);		/* get modem input */
	if (flags & 0x80)		/* DCD on? */
		return 1;
	return 0;
	}



void pascal output_wait(int port,char character)
	{
	write_oringbuf(character,1);
	}



int pascal output_nowait(int port,char character)
	{
	return write_oringbuf(character,0);
	}



int pascal check_output(int port)
	{
	int notclear = 0;
	int in = inoring;
	int out = outoring;
	int diff;

	if (in != out)
		{
		if (in > out)
			diff = in - out;
		else
			diff = ((RINGBUF_SIZE - 1) - out) + in;
		if (diff >= MAX_DIFF)
			notclear = 1;
		}
	return notclear;
	}



int pascal read_input(int port)
	{
	int rtn;

	do
		{
		rtn = read_iringbuf();
		if (rtn == -1)
			{
			if (user_online && !check_cd(port))
		 		longjmp(reset_bbs,1);
			DosSleep(1L);
			}
		}
	while (rtn == -1);
	return rtn;
	}



int pascal peek_input(int port)
	{
	return peek_iringbuf();
	}



int pascal read_kb(void)
	{
	KBDKEYINFO ki;
	int rtn;
	
	KbdCharIn(&ki,IO_WAIT,0);
	if ((ki.chChar == 0) || (ki.chChar == 0xe0))
		rtn = (int)(unsigned int)ki.chScan << 8;
	else
		rtn = (int)(unsigned int)ki.chChar;
	if (!DosSemRequest(&kbaccess_sem,SEM_IMMEDIATE_RETURN))
		{
		kb_hit = 0;
		DosSemClear(&kbaccess_sem);
		}
	return rtn;
	}



int pascal peek_kb(void)
	{
	if (kb_hit)
		return 0;
	return -1;
	}


#else 			/****************** fossil routines for DOS *************/


struct finfo		/* used to get fossil information */
	{
	int finfo_size;
	char finfo_fossil;
	char finfo_rev;
	char far *fininfo_id;
	int finfo_inputsize;
	int finfo_input;
	int finfo_outputsize;
	int finfo_output;
	char finfo_width;
	char finfo_height;
	char finfo_baud;
	};


static char fossil_init_id;			/* fossil call numbers to activate/inactivate fossil */
static char fossil_deinit_id;			



int init_fossil(int port)
	{
	union REGS registers;
	int count;
	int ok = 0;

	fossil_init_id = 0x1c;			/* start with Ray Gwinn's recommendation */
	fossil_deinit_id = 0x1d;			
	for (count = 0; count < 2; count++)
		{
		registers.x.dx = port;
		registers.x.bx = 0;
		registers.h.ah = fossil_init_id;
		int86(0x14,&registers,&registers);

		if (registers.x.ax == 0x1954)
			{
			ok = 1;		/* "There be fossils here," - Scotty in Star Trek IV */
			break;
			}

		fossil_init_id = 0x4;		/* failed attempt?  Try old fossil numbers */
		fossil_deinit_id = 0x5;			
		}

	if (!ok)
		return 0;
	if (registers.h.bl < 0x1b)
		{
		deinit_fossil(port);
		return 0;		/* minimum function needed is 1b hex - information */
		}

	fossil_init = 1;
	return (int)registers.h.bl;		/* return maximum func number supported */
	}



void reinit_fossil(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.x.bx = 0;
	registers.h.ah = fossil_init_id;
	int86(0x14,&registers,&registers);
	fossil_init = 1;
	}



void deinit_fossil(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = fossil_deinit_id;
	int86(0x14,&registers,&registers);
	fossil_init = 0;
	}



int set_baud(int port,int baud)
	{
	union REGS registers;

	if (locked_flag)			/* never change the baud rate */
		baud = locked_baud;
	switch ((unsigned int)baud)
		{
		case 300:
			registers.h.al = 2;
			break;
		case 1200:
			registers.h.al = 4;
			break;
		case 2400:
			registers.h.al = 5;
			break;
		case 4800:
			registers.h.al = 6;
			break;
		case 9600:
			registers.h.al = 7;
			break;
		case 19200:
			registers.h.al = 0;
			break;
		case 38400:
			registers.h.al = 1;
			break;
		default:
			return 0;
			break;
		}
	registers.h.al <<= 5;
	registers.h.al |= (char)0x3;		/* set lower bits to N-8-1 (00011) */
	registers.x.dx = port;
	registers.h.ah = 0x0;
	int86(0x14,&registers,&registers);
	return (int)registers.x.ax;		/* return status */
	}



int get_status(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x3;
	int86(0x14,&registers,&registers);
	return (int)registers.x.ax;
	}



void raise_dtr(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.al = 1;	
	registers.h.ah = 0x6;
	int86(0x14,&registers,&registers);
	}



void lower_dtr(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.al = 0;	
	registers.h.ah = 0x6;
	int86(0x14,&registers,&registers);
	}



void flush_output(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x8;
	int86(0x14,&registers,&registers);
	}



void purge_output_buffer(int port)		/* clears pending bytes in output buffer */
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x9;
	int86(0x14,&registers,&registers);
	}



void purge_input_buffer(int port)		/* clears pending bytes in input buffer */
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0xa;
	int86(0x14,&registers,&registers);
	}



void start_break(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x1a;
	registers.h.al = 0x1;		/* start breaking */
	int86(0x14,&registers,&registers);
	}



void stop_break(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x1a;
	registers.h.al = 0x0;		/* stop breaking */
	int86(0x14,&registers,&registers);
	}



void enable_flowctrl(int port,int cts,int xon_xmit,int xon_recv)
	{
	union REGS registers;

	registers.h.al = 0;
	if (cts)
		registers.h.al |= 0x2;
	if (xon_xmit)
		registers.h.al |= 0x1;
	if (xon_recv)
		registers.h.al |= 0x8;
	registers.x.dx = port;
	registers.h.ah = 0xf;
	int86(0x14,&registers,&registers);
	}



int pascal check_cd(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x3;
	int86(0x14,&registers,&registers);
	if (registers.h.al & 0x80)
		return 1;
	return 0;		/* no carrier */
	}



void pascal output_wait(int port,char character)
	{
	union REGS registers;

	do
		{
		registers.h.al = character;
		registers.x.dx = port;
		registers.h.ah = 0xb;
		int86(0x14,&registers,&registers);
		if (user_online && !check_cd(port))
		 	longjmp(reset_bbs,1);
		}
	while (!registers.x.ax);		/* 0 if fail */
	}



int pascal output_nowait(int port,char character)
	{
	union REGS registers;

	registers.h.al = character;
	registers.x.dx = port;
	registers.h.ah = 0xb;
	int86(0x14,&registers,&registers);
	return (int)registers.x.ax;			/* 0 if fail */
	}



int pascal read_input(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0x2;
	int86(0x14,&registers,&registers);
	return (int)registers.h.al;			/* character */
	}



int pascal peek_input(int port)
	{
	union REGS registers;

	registers.x.dx = port;
	registers.h.ah = 0xc;
	int86(0x14,&registers,&registers);
	return (int)registers.x.ax;			/* -1 (0xffff) if no character, else character */
	}



int pascal read_kb(void)
	{
	union REGS registers;

	registers.h.ah = 0xe;
	int86(0x14,&registers,&registers);
	if (registers.x.ax & 0xff)
		return registers.x.ax & 0xff;	/* return the character w/o code */
	return (int)registers.x.ax;				/* IBM scan-code */
	}



int pascal peek_kb(void)
	{
	union REGS registers;

	registers.h.ah = 0xd;
	int86(0x14,&registers,&registers);
	return (int)registers.x.ax;			/* 0xffff if no character, else IBM scan-code */
	}



int pascal check_output(int port)
	{
	union REGS registers;
	struct SREGS segments;
	struct finfo info;
	struct finfo *tinfo;

	tinfo = &info;
/*	info.finfo_size = sizeof(struct finfo);	*/
	registers.x.dx = port;
	registers.x.cx = sizeof(struct finfo);
	segments.es = FP_SEG(tinfo);
	registers.x.di = FP_OFF(tinfo);
	registers.h.ah = 0x1b;
	int86x(0x14,&registers,&registers,&segments);
	if (info.finfo_outputsize - info.finfo_output <= 1)
		return 0;
	return 1;
	}

#endif

