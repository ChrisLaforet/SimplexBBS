/* s_dmail.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 10 May 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_dmail.c_v  $
**                       $Date:   25 Oct 1992 14:09:08  $
**                       $Revision:   1.6  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include <process.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#ifdef XSPAWN
	#include <xspawn.h>
#endif
#include "simplex.h"



extern struct top **topics;
extern int cur_topics;
extern int max_topics;
extern int topic_area;




#ifdef PROTECTED
	extern HFILE hComm[];		/* in s_fossil.c */
#else
	extern int stdout_flag;
#endif



static int arc_flags = 0;

extern char *get_fileattachinfo(char *fname);
extern jmp_buf reset_bbs;




int downcomb_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'A':
		case 'N':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int downarc_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'A':
			if (arc_flags & ARC_FLAG)
				return 'A';
			break;
		case 'Z':
			if (arc_flags & ZIP_FLAG)
				return 'Z';
			break;
		case 'L':
			if (arc_flags & LZH_FLAG)
				return 'L';
			break;
		case 'R':
			if (arc_flags & ARJ_FLAG)
				return 'R';
			break;
		case 'O':
			if (arc_flags & ZOO_FLAG)
				return 'O';
			break;
		case 'S':
			return 'S';
			break;
		case 'X':
			return 'X';
			break;
		}
	return 0;
	}



void scan_topics(int area,short start)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	char buffer[100];
	char *cptr;
	unsigned short tval;
	short count;
	short found;

	deinit_topics();
	tval = start;
	fseek(msglfd,(long)start * (long)sizeof(struct mlink),SEEK_SET);
	while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
		{
		if (!(tmlink.mlink_flags & MSGH_DELETED) && tmlink.mlink_area == area)		/* message is not deleted */
			{
			fseek(msghfd,(long)tval * (long)sizeof(struct msgh),SEEK_SET);
			fread(&tmsgh,sizeof(struct msgh),1,msghfd);

			strncpy(buffer,tmsgh.msgh_subject,70);
			buffer[70] = '\0';

			/* strip off trailing spaces */
			if (buffer[0])
				{
				cptr = buffer + (strlen(buffer) - 1);
				while ((cptr - buffer) != 0 && isspace(*cptr))
					*cptr-- = '\0';
				}

			/* strip off leading spaces and RE:'s */
			cptr = buffer;
			while (*cptr && (isspace(*cptr) || !strnicmp(cptr,"RE:",3)))
				{
				if (isspace(*cptr))
					++cptr;
				else
					cptr += 3;
				}

			for (count = 0, found = 0; count < cur_topics; count++)
				{
				if (!stricmp(topics[count]->top_subject,cptr))
					{
					found = 1;
					break;
					}
				}
			if (!found)
				{
				if (cur_topics >= max_topics)
					{
					if (!(topics = realloc(topics,(max_topics += 50) * sizeof(struct top *))))
						{
						send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
						_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
						}
					}
				if (!(topics[cur_topics] = calloc(1,sizeof(struct top))))
					{
					send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
					_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
					}
				if (!(topics[cur_topics]->top_subject = calloc(strlen(cptr) + 1,sizeof(char))))
					{
					send_string("\r\n\r\n\aFatal Error: Out of memory....Alert Sysop....\r\n\r\n",NULL);
					_error(E_FATAL,"Out of memory!");	/* nothing to work with? */
					}
				strcpy(topics[cur_topics]->top_subject,cptr);
				topics[cur_topics]->top_start = tval + 1;		/* systemwide message number */
				topics[cur_topics]->top_total = 1;
				++cur_topics;
				}
			}
		++tval;
		}
	}



int download_combination(void)
	{
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char buffer[100];
	char buffer1[20];
	int total_msgs;
	int current;
	int retval = 0;
	int count;
	int kount;
	int counter;
	int actual;
	int total;
	int which;
	int quit = 0;
	int key;
	int err;
	int out;
	int new;
	int ok;
	int end;
	int byte;
	int bit;
	int kill;
	int type;
	FILE *fd;
	FILE *ndxfd;

	if (!cfg.cfg_fapath[0])
		{
		sprintf(buffer,"There is not a file attach area on this system!");
		_error(E_ERROR,buffer);
		system_message(buffer);
		return 0;
		}
	if (!comb_found || tcomb.comb_user != user_number)
		get_combination();

	type = (tcomb.comb_flags & COMB_QWK) ? 1 : 0;

	do
		{
		cur_line = 0;			/* defeat more */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(menu_color),NULL);
		purge_input(cfg.cfg_port);
		if (!type)
			key = send_string("\r\n\r\n--- Combined Boards Message Download Menu ---\r\n\r\n",downcomb_handler);
		else 
			key = send_string("\r\n\r\n--- Combined Boards Offline Reader Download Menu ---\r\n\r\n",downcomb_handler);
		if (!key)
			{
			if (!(user.user_flags & USER_EXPERT))
				key = send_string("<A> Download All  <N> Download New  <?> Help!  <X> Exit\r\n\r\n",downcomb_handler);
			else
				key = send_string("[ AN?X ]\r\n\r\n",downcomb_handler);
			if (!key)
				key = send_string("What is your choice (ENTER=Exit)? ",downcomb_handler);
			}
		ok = 0;
		do
			{
			if (!key)
				key = get_char();
			switch (key)
				{
				case 'A':
				case 'a':
					strcpy(buffer,cfg.cfg_fapath);
					if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
					if (!type)
						sprintf(buffer1,"mail%04x.dl",user_number);
					else
						strcpy(buffer1,"messages.dat");
					strcat(buffer,buffer1);

					if (type)
						{
						if (qwk_control())
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("\r\n\r\nError: Unable to open/create mail control file!\r\n\r\n",NULL);
							get_enter();
							break;
							}
						}

					if (fd = fopen(buffer,"wb"))
						{
						cur_line = 0;
						total = 0;
						err = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nPreparing messages for downloading....\r\n\r\n",NULL);
						out = 0;

						for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
							{
							byte = (unsigned int)which >> 3;		/* divide by 8 */
							bit = which % 8;
							if (tcomb.comb_areas[byte] & (1 << bit))
								{
								if (tmsg = get_msgarea(which))
									{
									if (type)
										{
										strcpy(buffer,cfg.cfg_fapath);
										if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
											strcat(buffer,P_SSEP);
										sprintf(buffer1,"%03u.ndx",which);
										strcat(buffer,buffer1);

										if (!(ndxfd = fopen(buffer,"wb")))
											{
											err = 1;
											end = 1;
											out = 1;
											break;
											}
										}

									cur_line = 0;
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("All messages from Area: ",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									send_string("\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);

									if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
										{
										total_msgs = 0;
										for (count = 0; count < max_msgcount; count++)
											{
											if (msgcount[count].mc_area == which)
												{
												total_msgs = msgcount[count].mc_msgs;
												break;
			  									}
											}

										end = 0;
										if (total_msgs)
											{
											actual = 1;
											current = 1;
											kount = 0;
											new = 1;
//											for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
//												{
//												if (lastread[count]->lr_area == which)
//													{
//													current = lastread[count]->lr_prev + 1;
//													break;
//													}
//												}

											if (tcomb.comb_flags & COMB_TOPIC_SORT)			/* sort topics together */
												{
												scan_topics(which,0);
												for (count = 0; !err && count < cur_topics; count++)
													{
													counter = topics[count]->top_start;
													while (!err && counter)
														{
														fseek(msghfd,(long)(counter - 1) * (long)sizeof(struct msgh),SEEK_SET);
														fread(&tmsgh,sizeof(struct msgh),1,msghfd);

														if (!(current % 10) || current == 1)
															{
															sprintf(buffer,"%d\r",current);
															send_string(buffer,NULL);
															}

														if (!type)
															{
															if (download_message(counter,total_msgs,tmsg,0,fd))
																{
																err = 1;
																out = 1;
																break;
																}
															}
														else
															{
															if (qwk_message(counter,total_msgs,tmsg,0,fd,ndxfd))
																{
																fclose(ndxfd);
																err = 1;
																out = 1;
																break;
																}
															}
														counter = tmsgh.msgh_next;
														++current;
														++total;
														}
													}
												}
											else
												{
												fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
												while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
													{
													if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
														++kount;
													if (kount == current)
														break;
													++actual;
													}
												do
													{
													if (!(current % 10) || current == 1)
														{
														sprintf(buffer,"%d\r",current);
														send_string(buffer,NULL);
														}
													++total;
													if (!type)
														{
														if (download_message(actual,total_msgs,tmsg,current >= new ? 1 : 0,fd))
															{
															err = 1;
															end = 1;
															out = 1;
															break;
															}
														}
													else
														{
														if (qwk_message(actual,total_msgs,tmsg,current >= new ? 1 : 0,fd,ndxfd))
															{
															fclose(ndxfd);
															err = 1;
															end = 1;
															out = 1;
															break;
															}
														}
													++current;
													++actual;
													if (current > total_msgs)
														end = 1;
													fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
													while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
														{
														if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
															++kount;
														if (kount == current)
															break;
														++actual;
														}
													}
												while (!out && !end);
												}
											}
										}
									if (type && ndxfd)
										{
										fseek(ndxfd,0L,SEEK_END);
										if (ftell(ndxfd))
											kill = 0;
										else
											kill = 1;
										fclose(ndxfd);
										if (kill)
											{
											strcpy(buffer,cfg.cfg_fapath);
											if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
												strcat(buffer,P_SSEP);
											sprintf(buffer1,"%03u.ndx",which);
											strcat(buffer,buffer1);

											unlink(buffer);
											}
										}
									}
								}
							}

						if (tcomb.comb_flags & COMB_PERSONAL)
							{

							}

						fclose(fd);

						send_string("      \r\n",NULL);
						if (!err)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN | BRIGHT),NULL);
							sprintf(buffer,"%u message%s packed.\r\n",total,(char *)(total != 1 ? "s" : ""));
							send_string(buffer,NULL);
							}

						if (!type)
							{
							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							sprintf(buffer1,"mail%04x.dl",user_number);
							strcat(buffer,buffer1);


							if (total)
								log_entry(L_DMAIL_ALL,NULL);
			
							if (!err && total)
								{
								send_string("\a\a",NULL);
								if (send_download_mail())
									retval = 1;
								}
							else if (err)
								{
								log_entry(L_DMAIL_FAILED,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\n\r\nError: Messages could not be exported!  Disk must be full!\r\n\r\n",NULL);
								get_enter();
								}
							unlink(buffer);
							}
						else
							{
							if (total)
								log_entry(L_DMAIL_NEW,NULL);

							if (!err && total)
								{
								send_string("\a\a",NULL);
								if (send_qwk_mail())
									{
									retval = 1;
									quit = 1;
									}
								}
							else if (err)
								{
								log_entry(L_DMAIL_FAILED,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\n\r\nError: Messages could not be exported!  Disk must be full!\r\n\r\n",NULL);
								get_enter();
								}

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"messages.dat");
							unlink(buffer);

							for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
								{
								byte = (unsigned int)which >> 3;		/* divide by 8 */
								bit = which % 8;
								if (tcomb.comb_areas[byte] & (1 << bit))
									{
									if (tmsg = get_msgarea(which))
										{
										strcpy(buffer,cfg.cfg_fapath);
										if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
											strcat(buffer,P_SSEP);
										sprintf(buffer1,"%03u.ndx",which);
										strcat(buffer,buffer1);
										unlink(buffer);
										}
									}
								}

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"control.dat");
							unlink(buffer);

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"door.id");
							unlink(buffer);

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							if (cfg.cfg_qwkname[0])
								{
								strcat(buffer,cfg.cfg_qwkname);
								strcat(buffer,".qwk");
								}
							else 
								strcat(buffer,"simplex.qwk");
							unlink(buffer);
							}

						}
					else
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("\r\n\r\nError: Unable to open mail download file!\r\n\r\n",NULL);
						get_enter();
						}
					ok = 1;
					break;
				case 'N':
				case 'n':
					strcpy(buffer,cfg.cfg_fapath);
					if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
					if (!type)
						sprintf(buffer1,"mail%04x.dl",user_number);
					else
						strcpy(buffer1,"messages.dat");
					strcat(buffer,buffer1);

					if (type)
						{
						if (qwk_control())
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("\r\n\r\nError: Unable to open/create mail control file!\r\n\r\n",NULL);
							get_enter();
							break;
							}
						}

					if (fd = fopen(buffer,"wb"))
						{
						cur_line = 0;
						total = 0;
						err = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nPreparing messages for downloading....\r\n",NULL);
						out = 0;

						for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
							{
							byte = (unsigned int)which >> 3;		/* divide by 8 */
							bit = which % 8;
							if (tcomb.comb_areas[byte] & (1 << bit))
								{
								if (tmsg = get_msgarea(which))
									{
									if (type)
										{
										strcpy(buffer,cfg.cfg_fapath);
										if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
											strcat(buffer,P_SSEP);
										sprintf(buffer1,"%03u.ndx",which);
										strcat(buffer,buffer1);

										if (!(ndxfd = fopen(buffer,"wb")))
											{
											err = 1;
											end = 1;
											out = 1;
											break;
											}
										}

									cur_line = 0;
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN | BRIGHT),NULL);
									send_string("New messages from Area: ",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(BROWN | BRIGHT),NULL);
									send_string(tmsg->msg_areaname,NULL);
									send_string("\r\n",NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);

									if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
										{
										total_msgs = 0;
										for (count = 0; count < max_msgcount && !out; count++)
											{
											if (msgcount[count].mc_area == which)
												{
												total_msgs = msgcount[count].mc_msgs;
												break;
			  									}
											}
										if (total_msgs)
											{
											actual = 1;
											current = 1;
											for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
												{
												if (lastread[count]->lr_area == which)
													{
													current = lastread[count]->lr_prev + 1;
													break;
													}
												}

											if (!current)
												current = 1;
											end = 0;
											if (tcomb.comb_flags & COMB_TOPIC_SORT)			/* sort topics together */
												{
												scan_topics(which,current - 1);
												for (count = 0; !err && count < cur_topics; count++)
													{
													counter = topics[count]->top_start;
													while (!err && counter)
														{
														fseek(msghfd,(long)(counter - 1) * (long)sizeof(struct msgh),SEEK_SET);
														fread(&tmsgh,sizeof(struct msgh),1,msghfd);

														if (!(current % 10) || current == 1)
															{
															sprintf(buffer,"%d\r",current);
															send_string(buffer,NULL);
															}

														if (!type)
															{
															if (download_message(counter,total_msgs,tmsg,0,fd))
																{
																err = 1;
																out = 1;
																break;
																}
															}
														else
															{
															if (qwk_message(counter,total_msgs,tmsg,0,fd,ndxfd))
																{
																fclose(ndxfd);
																err = 1;
																out = 1;
																break;
																}
															}
														counter = tmsgh.msgh_next;
														++current;
														++total;
														}
													}
												}
											else
												{
												for (count = current, kount = 0; count <= total_msgs && !out && !end; count++)
													{
													fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
													while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
														{
														if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
															++kount;
														if (kount == count)
															break;
														++actual;
														}

													do
														{
														if (!(current % 10) || current == 1)
															{
															sprintf(buffer,"%d\r",current);
															send_string(buffer,NULL);
															}
														++total;
														if (!type)
															{
															if (download_message(actual,total_msgs,tmsg,current >= new ? 1 : 0,fd))
																{
																err = 1;
																end = 1;
																out = 1;
																break;
																}
															}
														else
															{
															if (qwk_message(actual,total_msgs,tmsg,current >= new ? 1 : 0,fd,ndxfd))
																{
																fclose(ndxfd);
																err = 1;
																end = 1;
																out = 1;
																break;
																}
															}

														for (counter = 0; counter < cur_lastread; counter++)		/* get lastread pointers */
															{
															if (lastread[counter]->lr_area == which)
																{
																if (current > lastread[counter]->lr_new)
																	{
																	lastread[counter]->lr_new = current;
																	break;
																	}
																}
															}

														++current;
														++actual;
														if (current > total_msgs)
															end = 1;
														fseek(msglfd,(long)(actual - 1) * sizeof(struct mlink),SEEK_SET);
														while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
															{
															if (tmlink.mlink_area == which && !(tmlink.mlink_flags & MSGH_DELETED))
																++kount;
															if (kount == current)
																break;
															++actual;
															}
														}
													while (!end);
													}
												}
											}
										}
									if (type && ndxfd)
										{
										fseek(ndxfd,0L,SEEK_END);
										if (ftell(ndxfd))
											kill = 0;
										else
											kill = 1;
										fclose(ndxfd);
										if (kill)
											{
											strcpy(buffer,cfg.cfg_fapath);
											if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
												strcat(buffer,P_SSEP);
											sprintf(buffer1,"%03u.ndx",which);
											strcat(buffer,buffer1);

											unlink(buffer);
											}
										}
									}
								}
							}

						if (tcomb.comb_flags & COMB_PERSONAL)
							{

							}

						fclose(fd);

						send_string("      \r\n",NULL);
						if (!err)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN | BRIGHT),NULL);
							sprintf(buffer,"%u message%s packed.\r\n",total,(char *)(total != 1 ? "s" : ""));
							send_string(buffer,NULL);
							}

						if (!type)
							{
							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							sprintf(buffer1,"mail%04x.dl",user_number);
							strcat(buffer,buffer1);

							if (total)
								log_entry(L_DMAIL_NEW,NULL);

							if (!err && total)
								{
								send_string("\a\a",NULL);
								if (send_download_mail())
									retval = 1;
								}
							else if (err)
								{
								log_entry(L_DMAIL_FAILED,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\n\r\nError: Messages could not be exported!  Disk must be full!\r\n\r\n",NULL);
								get_enter();
								}

							unlink(buffer);
							}
						else
							{
							if (total)
								log_entry(L_DMAIL_NEW,NULL);

							if (!err && total)
								{
								send_string("\a\a",NULL);
								if (send_qwk_mail())
									{
									retval = 1;
									quit = 1;
									}
								}
							else if (err)
								{
								log_entry(L_DMAIL_FAILED,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("\r\n\r\nError: Messages could not be exported!  Disk must be full!\r\n\r\n",NULL);
								get_enter();
								}

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"messages.dat");
							unlink(buffer);

							for (which = get_minmsgarea(); which <= get_maxmsgarea() && !out; which++)
								{
								byte = (unsigned int)which >> 3;		/* divide by 8 */
								bit = which % 8;
								if (tcomb.comb_areas[byte] & (1 << bit))
									{
									if (tmsg = get_msgarea(which))
										{
										strcpy(buffer,cfg.cfg_fapath);
										if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
											strcat(buffer,P_SSEP);
										sprintf(buffer1,"%03u.ndx",which);
										strcat(buffer,buffer1);
										unlink(buffer);
										}
									}
								}

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"control.dat");
							unlink(buffer);

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,"door.id");
							unlink(buffer);

							strcpy(buffer,cfg.cfg_fapath);
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							if (cfg.cfg_qwkname[0])
								{
								strcat(buffer,cfg.cfg_qwkname);
								strcat(buffer,".qwk");
								}
							else 
								strcat(buffer,"simplex.qwk");
							unlink(buffer);
							}
						}
					else
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("\r\n\r\nError: Unable to open mail download file!\r\n\r\n",NULL);
						get_enter();
						}
					ok = 1;
					break;
				case '?':
					cur_line = 0;
					send_string("\r\n\r\n",NULL);
					cur_line = 0;
					send_ansifile(cfg.cfg_screenpath,"DOWNMAIL",0);
					ok = 1;
					break;
				case 'X':
				case 'x':
				case '\r':
				case '\n':
					ok = 1;
					quit = 1;
					break;
				}
			key = 0;
			}
		while (!ok);
		}
	while (!quit);

	return retval;
	}



int pascal download_message(int msg_num,int total_msgs,struct msg *tmsg,int new,FILE *fd)
	{
	struct msgh tmsgh;
	struct mlink tmlink;
	char buffer[100];
	char from[41];
	char to[41];
	long total = 0L;
	long diff;
	int len;
	int temp;

	if (fd)
		{
		fseek(msghfd,(long)(msg_num - 1) * (long)sizeof(struct msgh),SEEK_SET);
		fread(&tmsgh,1,sizeof(struct msgh),msghfd);

		strcpy(to,get_addressee(tmsgh.msgh_to));
		strcpy(from,get_addressee(tmsgh.msgh_from));
		if (!(tmsgh.msgh_flags & MSGH_PRIVATE) || ((tmsgh.msgh_flags & MSGH_PRIVATE) &&
			(user.user_priv >= tmsg->msg_sysoppriv || check_name(to) || check_name(from) || (tmsgh.msgh_flags & MSGH_URGENT))))
			{
			++user.user_msgread;			/* increment the messages read in userfile */
			++userinfo.ui_msgread;			/* increment the messages read this session counter */
			mark_read(tmsgh.msgh_area);		/* indicates area was read from */

			if (!(tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH) && check_name(to) && !(tmsgh.msgh_flags & MSGH_RECEIVED))
				{
				tmsgh.msgh_flags |= MSGH_RECEIVED;
				fseek(msghfd,(long)(msg_num - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
				fflush(msghfd);

				fseek(msglfd,(long)(msg_num - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fread(&tmlink,sizeof(struct mlink),1,msglfd);
				tmlink.mlink_flags |= MSGH_RECEIVED;
				fseek(msglfd,(long)(msg_num - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
				fflush(msglfd);							  
				}

			fseek(fd,0L,SEEK_END);
			if (!fprintf(fd,"   Area: \"%s\" -> Message #%u of %u\r\n",tmsg->msg_areaname,tmsgh.msgh_number,total_msgs))
				return 1;
			temp = (((unsigned int)tmsgh.msgh_date >> 5) & 0xf) - 1;
			if (temp && (temp >= 12 || temp < 0))
				temp = 11;
			if (!fprintf(fd," Posted: %u %s %02u at %02u:%02u\r\n",tmsgh.msgh_date & 0x1f,months_table[temp],(((unsigned int)tmsgh.msgh_date >> 9) + 80) % 100,
				(unsigned int)tmsgh.msgh_time >> 11,((unsigned int)tmsgh.msgh_time >> 5) & 0x3f))
				return 1;

			if (tmsgh.msgh_flags & MSGH_URGENT)
				{
				if (!fprintf(fd,"     To: %s",user.user_name))
					return 1;
				}
			else
				{
				if (!fprintf(fd,"     To: %s",tmsgh.msgh_to))
					return 1;
				}
			if (tmsgh.msgh_flags & MSGH_NET)
				{
				if (!fprintf(fd," on %d:%d/%d",tmsgh.msgh_dzone,tmsgh.msgh_dnet,tmsgh.msgh_dnode))
					return 1;
				}
			if (tmsgh.msgh_flags & MSGH_URGENT)
				{
				if (!fprintf(fd,"     (Urgent User Message) %s%s\r\n",tmsgh.msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",tmsgh.msgh_flags & MSGH_DELETED ? "(Del)" : ""))
					return 1;
				}
			else
				{
				if (!fprintf(fd,"     %s%s%s%s\r\n",new ? "(New) " : "",tmsgh.msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",tmsgh.msgh_flags & MSGH_RECEIVED ? "(Recvd) " : "",tmsgh.msgh_flags & MSGH_DELETED ? "(Del)" : ""))
					return 1;
				}

			if (!fprintf(fd,"   From: %s",tmsgh.msgh_from))
				return 1;
			if (tmsgh.msgh_flags & MSGH_NET)
				{
				if (!fprintf(fd," on %d:%d/%d",tmsgh.msgh_szone,tmsgh.msgh_snet,tmsgh.msgh_snode))
					return 1;
				}
			if (fputs("\r\n",fd) == EOF)
				return 1;

			if (tmsgh.msgh_flags & NET_FILEATTACH)
				{
				if (!fprintf(fd,"File(s): %s\r\n",tmsgh.msgh_subject))
					return 1;
				}
			else if (tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH)
				{
				if (!fprintf(fd," Attach: %s\r\n",get_fileattachinfo(tmsgh.msgh_subject)))
					return 1;
				}
			else
				{
				if (!fprintf(fd,"Subject: %s\r\n",tmsgh.msgh_subject))
					return 1;
				}
			if (tmsgh.msgh_prev || tmsgh.msgh_next)
				{
				if (tmsgh.msgh_prev)
					{
					fseek(msghfd,(long)(tmsgh.msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
					fread(&tmsgh,sizeof(struct msgh),1,msghfd);
					if (!fprintf(fd,"Prev message is #%u.  ",tmsgh.msgh_number))
						return 1;
					}
				if (tmsgh.msgh_next)
					{
					fseek(msghfd,(long)(tmsgh.msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
					fread(&tmsgh,sizeof(struct msgh),1,msghfd);
					if (!fprintf(fd,"Next message is #%u.",tmsgh.msgh_number))
						return 1;
					}
				if (fputs("\r\n",fd) == EOF)
					return 1;
				}
			if (fputs("\r\n",fd) == EOF)
				return 1;

			fseek(msgbfd,tmsgh.msgh_offset,SEEK_SET);
			while (total < tmsgh.msgh_length)
				{
				diff = tmsgh.msgh_length - total;
				if (diff >= (long)sizeof(buffer))
					len = sizeof(buffer);
				else
					len = (int)diff;

				fread(buffer,len,1,msgbfd);
	
				if (export_message_line(buffer,len,fd))
					return 1;
				total += (long)len;
				}

			if (fputs("\r\n\r\n",fd) == EOF)
				return 1;
			}
		}
	return 0;
	}



int archive_download_mail(char *cmdline,char *filename,char *arcname)
	{
	char **args = NULL;
	int cur_args = 0;
	int max_args = 0;
	char cbuffer[100];
	char buffer[150];
	char buffer1[150];
	char *cptr;
	char *cptr0;
	char *cptr1;
	char *cptr2;
	int gotfile = 0;
	int gotarc = 0;
	int ok = 0;
	int ctype;
	int rtn;

	strcpy(cbuffer,cmdline);
	cptr = cbuffer;
	cptr0 = cptr;
	while (*cptr0 && *cptr0 != ' ')
		++cptr0;

	while (*cptr)
		{
		if (*cptr0)
			*cptr0++ = (char)'\0';
		ctype = 0;
		cptr1 = cptr;
		while (*cptr1 && *(cptr1 + 1))
			{
			if (*cptr1 == (char)'%')
				{
				if (*(cptr1 + 1) == (char)'a' || *(cptr1 + 1) == (char)'A')
					{
					ctype = 1;
					break;
					}
				if (*(cptr1 + 1) == (char)'f' || *(cptr1 + 1) == (char)'F')
					{
					ctype = 2;
					break;
					}
				}
			++cptr1;
			}

		if ((cur_args + 1) >= max_args)
			{
			if (!(args = realloc(args,(max_args += 5) * sizeof(char *))))
				{
				_error(E_ERROR,"Out of memory to allocate archive args");
				return -1;
				}
			}

		cptr1 = cptr;
		while (isspace(*cptr1))		/* walk off leading spaces */
			++cptr1;
		if (!ctype)
			args[cur_args++] = cptr1;
		else if (ctype == 1)
			{
			cptr2 = buffer;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'a' || *(cptr1 + 1) == (char)'A'))
					{
					strcpy(cptr2,arcname);
					cptr2 += strlen(arcname);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotarc = 1;
			args[cur_args++] = buffer;
			}
		else
			{
			cptr2 = buffer1;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'f' || *(cptr1 + 1) == (char)'F'))
					{
					strcpy(cptr2,filename);
					cptr2 += strlen(filename);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotfile = 1;
			args[cur_args++] = buffer1;
			}
		args[cur_args] = NULL;

		cptr = cptr0;
		while (*cptr0 && *cptr0 != ' ')		/* get next token */
			++cptr0;
		}

	if (gotarc && gotfile)
		{
		/* close file handles and spawn archiver */

	 	log_entry(L_DMAIL_ARCHIVE,args[0]);

		fclose(userfd);
		fclose(uinfofd);
		if (msghfd)
			fclose(msghfd);
		if (msgbfd)
			fclose(msgbfd);
		if (msglfd)
			fclose(msglfd);
		if (msgdfd)
			fclose(msgdfd);
		if (msgrfd)
			fclose(msgrfd);
		if (nlstfd)
			fclose(nlstfd);
		if (nidxfd)
			fclose(nidxfd);
		if (combfd)
			fclose(combfd);

#ifndef PROTECTED
		if (stdout_flag)
			freopen("con","w",stdout);		/* stdout is now pointing to the console device (for fossil signon message!) */
#endif

		bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */

#ifndef PROTECTED
		stop_timer();
#endif

#ifdef XSPAWN
		rtn = xspawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#else
		rtn = spawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#endif

#ifndef PROTECTED
		if (!start_timer())
			{
			cptr = "Unable to restart timer process.  Hanging up!";
			_error(E_ERROR,cptr);
			system_message(cptr);
			hangup();
			longjmp(reset_bbs,2);
			}
#endif

		set_inactivetime();
		bios_setcurpos(bottom_line << 8);

		open_files(1);			/* reinitialize the system */

		if ((bios_getcurpos() >> 8) > bottom_line)
			bios_scrollup(0x0,(bottom_line << 8) | 0x4f,(bios_getcurpos() >> 8) - bottom_line,WHITE);

		bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* prepare status lines */
		show_user();

		if (!local_flag)
			reinit_fossil(cfg.cfg_port);		/* reinits when BBS is reentered  */

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(WHITE),NULL);
		else 
			write_string(new_color(WHITE));

		if (rtn == -1)
			{
			sprintf(buffer,"Failed to spawn archiver (%s).",args[0]);
		 	log_entry(L_DMAIL_ARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else if (rtn)
			{
			sprintf(buffer,"Archiver (%s) failed and reported error %d.",args[0],rtn);
		 	log_entry(L_DMAIL_ARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else 
			ok = 1;
		free(args);
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Error: No %A or %F options were found on archiver command.  Notify Sysop!\r\n\r\n",NULL);
		}

	if (!ok)
		return 1;
	return 0;
	}



int send_download_mail(void)
	{
	struct fl *tflist[1];
	struct fl tfl;
	char sendname[100];
	char buffer[100];
	char buffer1[20];
	char keys[15];
	int autoarc = 0;
	int retval = 0;
	int quit = 0;
	int del = 0;
	int ok = 0;
	int key;
	int rtn;

	arc_flags = 0;
	if (cfg.cfg_arc[0])
		arc_flags |= ARC_FLAG;
	if (cfg.cfg_zip[0])
		arc_flags |= ZIP_FLAG;
	if (cfg.cfg_lzh[0])
		arc_flags |= LZH_FLAG;
	if (cfg.cfg_arj[0])
		arc_flags |= ARJ_FLAG;
	if (cfg.cfg_zoo[0])
		arc_flags |= ZOO_FLAG;

	strcpy(sendname,cfg.cfg_fapath);
	if (sendname[0] && sendname[strlen(sendname) - 1] != P_CSEP)
		strcat(sendname,P_SSEP);

	if (arc_flags)
		{
		if ((tcomb.comb_flags & COMB_USEARC) && (arc_flags & ARC_FLAG))
			{
			strcpy(buffer,sendname);
			sprintf(buffer1,"mail%04x.dl",user_number);
			strcat(buffer,buffer1);
			sprintf(buffer1,"mail%04x.arc",user_number);
			strcat(sendname,buffer1);

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while arcing mail....this will take a while.\r\n\r\n",NULL);
	
			if (!archive_download_mail(cfg.cfg_arc,buffer,sendname))
				{
				del = 1;
				autoarc = 1;
				}
			else
				unlink(sendname);
			}
		else if ((tcomb.comb_flags & COMB_USEZIP) && (arc_flags & ZIP_FLAG))
			{
			strcpy(buffer,sendname);
			sprintf(buffer1,"mail%04x.dl",user_number);
			strcat(buffer,buffer1);
			sprintf(buffer1,"mail%04x.zip",user_number);
			strcat(sendname,buffer1);

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while zipping mail....this will take a while.\r\n\r\n",NULL);

			if (!archive_download_mail(cfg.cfg_zip,buffer,sendname))
				{
				del = 1;
				autoarc = 1;
				}
			else
				unlink(sendname);
			}
		else if ((tcomb.comb_flags & COMB_USELZH) && (arc_flags & LZH_FLAG))
			{
			strcpy(buffer,sendname);
			sprintf(buffer1,"mail%04x.dl",user_number);
			strcat(buffer,buffer1);
			sprintf(buffer1,"mail%04x.lzh",user_number);
			strcat(sendname,buffer1);

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while lharcing mail....this will take a while.\r\n\r\n",NULL);
	
			if (!archive_download_mail(cfg.cfg_lzh,buffer,sendname))
				{
				del = 1;
				autoarc = 1;
				}
			else
				unlink(sendname);
			}
		else if ((tcomb.comb_flags & COMB_USEARJ) && (arc_flags & ARJ_FLAG))
			{
			strcpy(buffer,sendname);
			sprintf(buffer1,"mail%04x.dl",user_number);
			strcat(buffer,buffer1);
			sprintf(buffer1,"mail%04x.arj",user_number);
			strcat(sendname,buffer1);

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while arjing mail....this will take a while.\r\n\r\n",NULL);

			if (!archive_download_mail(cfg.cfg_arj,buffer,sendname))
				{
				del = 1;
				autoarc = 1;
				}
			else
				unlink(sendname);
			}
		else if ((tcomb.comb_flags & COMB_USEZOO) && (arc_flags & ZOO_FLAG))
			{
			strcpy(buffer,sendname);
			sprintf(buffer1,"mail%04x.dl",user_number);
			strcat(buffer,buffer1);
			sprintf(buffer1,"mail%04x.zoo",user_number);
			strcat(sendname,buffer1);

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while zooing mail....this will take a while.\r\n\r\n",NULL);

			if (!archive_download_mail(cfg.cfg_zoo,buffer,sendname))
				{
				del = 1;
				autoarc = 1;
				}
			else
				unlink(sendname);
			}

		if (!autoarc)
			{
			do
				{
				buffer[0] = '\0';
				strcpy(keys,"[ ");
	 			if (arc_flags & ARC_FLAG)
					{
					strcat(buffer,"<A> Arc  ");
					strcat(keys,"A");
					}
	 			if (arc_flags & ZIP_FLAG)
					{
					strcat(buffer,"<Z> Zip  ");
					strcat(keys,"Z");
					}
	 			if (arc_flags & LZH_FLAG)
					{
					strcat(buffer,"<L> Lzh  ");
					strcat(keys,"L");
					}
	 			if (arc_flags & ARJ_FLAG)
					{
					strcat(buffer,"<R> Arj  ");
					strcat(keys,"R");
					}
	 			if (arc_flags & ZOO_FLAG)
					{
					strcat(buffer,"<O> Zoo  ");
					strcat(keys,"O");
					}
				strcat(buffer,"<S> Ascii  ");
				strcat(keys,"S");
				strcat(buffer,"<X> Exit (no d/l)\r\n\r\n");
				strcat(keys,"X ]\r\n\r\n");

	 			strcpy(sendname,cfg.cfg_fapath);
				if (sendname[0] && sendname[strlen(sendname) - 1] != P_CSEP)
					strcat(sendname,P_SSEP);

				cur_line = 0;			/* defeat more */
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);
				purge_input(cfg.cfg_port);
				key = send_string("\r\n\r\n--- Message Download Archive Menu ---\r\n\r\n",downarc_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string(buffer,downarc_handler);
					else
						key = send_string(keys,downarc_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Exit)? ",downarc_handler);
					}
				do
					{
					cur_line = 0;			/* defeat more */
					if (!key)
						key = get_char();
					switch (key)
						{
						case 'A':
						case 'a':
				 			if (arc_flags & ARC_FLAG)
								{
								strcpy(buffer,sendname);
								sprintf(buffer1,"mail%04x.dl",user_number);
								strcat(buffer,buffer1);
								sprintf(buffer1,"mail%04x.arc",user_number);
								strcat(sendname,buffer1);

	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while arcing mail....this will take a while.\r\n\r\n",NULL);
						
								if (!archive_download_mail(cfg.cfg_arc,buffer,sendname))
									{
									del = 1;
									quit = 1;
									}
								else
									unlink(sendname);
								}
							ok = 1;
							break;
						case 'Z':
						case 'z':
				 			if (arc_flags & ZIP_FLAG)
								{
								strcpy(buffer,sendname);
								sprintf(buffer1,"mail%04x.dl",user_number);
								strcat(buffer,buffer1);
								sprintf(buffer1,"mail%04x.zip",user_number);
								strcat(sendname,buffer1);

	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while zipping mail....this will take a while.\r\n\r\n",NULL);

								if (!archive_download_mail(cfg.cfg_zip,buffer,sendname))
									{
									del = 1;
									quit = 1;
									}
								else
									unlink(sendname);
								}
							ok = 1;
							break;
						case 'L':
						case 'l':
				 			if (arc_flags & LZH_FLAG)
								{
								strcpy(buffer,sendname);
								sprintf(buffer1,"mail%04x.dl",user_number);
								strcat(buffer,buffer1);
								sprintf(buffer1,"mail%04x.lzh",user_number);
								strcat(sendname,buffer1);

	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while lharcing mail....this will take a while.\r\n\r\n",NULL);
						
								if (!archive_download_mail(cfg.cfg_lzh,buffer,sendname))
									{
									del = 1;
									quit = 1;
									}
								else
									unlink(sendname);
								}
							ok = 1;
							break;
						case 'R':
						case 'r':
				 			if (arc_flags & ARJ_FLAG)
								{
								strcpy(buffer,sendname);
								sprintf(buffer1,"mail%04x.dl",user_number);
								strcat(buffer,buffer1);
								sprintf(buffer1,"mail%04x.arj",user_number);
								strcat(sendname,buffer1);

	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while arjing mail....this will take a while.\r\n\r\n",NULL);

								if (!archive_download_mail(cfg.cfg_arj,buffer,sendname))
									{
									del = 1;
									quit = 1;
									}
								else
									unlink(sendname);
								}
							ok = 1;
							break;
						case 'O':
						case 'o':
				 			if (arc_flags & ZOO_FLAG)
								{
								strcpy(buffer,sendname);
								sprintf(buffer1,"mail%04x.dl",user_number);
								strcat(buffer,buffer1);
								sprintf(buffer1,"mail%04x.zoo",user_number);
								strcat(sendname,buffer1);

	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while zooing mail....this will take a while.\r\n\r\n",NULL);

								if (!archive_download_mail(cfg.cfg_zoo,buffer,sendname))
									{
									del = 1;
									quit = 1;
									}
								else
									unlink(sendname);
								}
							ok = 1;
							break;
						case 'S':
						case 's':
							sprintf(buffer1,"mail%04x.dl",user_number);
							strcat(sendname,buffer1);
							ok = 1;
							quit = 1;
							break;
						case 'X':
						case 'x':
						case '\r':
						case '\n':
							return 0;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!quit);
			}
		}
	else
		{
	 	strcpy(sendname,cfg.cfg_fapath);
		if (sendname[0] && sendname[strlen(sendname) - 1] != P_CSEP)
			strcat(sendname,P_SSEP);
		sprintf(buffer1,"mail%04x.dl",user_number);
		strcat(sendname,buffer1);
		}
	send_string("\a\a",NULL);

	if (!user_baud)
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nCopy to where (ENTER=Quit)? ",NULL);
		get_fname(buffer,48,0,1);
		if (buffer[0])
			{
			if (buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			tfl.fl_name = buffer1;
			tfl.fl_location = 0;
			tfl.fl_update = 0;
			tflist[0] = &tfl;
			copy_out(AREA_FATTACH,buffer,tflist,1);
			}
		}
	else
		{
		do
			{
			rtn = xmit_onefile(AREA_FATTACH,buffer1,1);
			if (!rtn || rtn == 2)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\nAn error was reported while downloading.\n\n",NULL);
				}
			else if (rtn == 3)
				retval = 1;
			}
		while (!rtn || rtn == 2);
		}

	if (del)
		unlink(sendname);

	return retval;
	}
