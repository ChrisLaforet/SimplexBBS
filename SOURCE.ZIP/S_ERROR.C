/* s_error.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 26 November 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_error.c_v  $
**                       $Date:   25 Oct 1992 14:07:02  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include "simplex.h"






void _error(int type,char *string)
	{
	if (type == E_NOTICE)
		{
		write_string("\r\n� Notice: ");
		write_string(string);
		}
	else if (type == E_WARNING)
		{
		log_entry(L_WARNING,string);
		write_string("\r\n� Warning: ");
		write_string(string);
		}
	else if (type == E_ERROR)
		{
		log_entry(L_ERROR,string);
		write_string("\r\n� Error: ");
		write_string(string);
		}
	else
		{
		log_entry(L_FATAL,string);
		write_string("\r\n� Fatal Error: ");
		write_string(string);
		if (fossil_init && check_cd(cfg.cfg_port))
			{
			send_string("\r\nA Fatal Error occurred in Simplex! ",NULL);
			send_string(string,NULL);
			send_string("\r\nSorry, but we must drop the line and exit.....\r\n\r\n",NULL);
			}
		write_string("\r\n� Notice: Fatal Error exit with errorlevel 1\r\n");
		exit(1);
		}
	}


