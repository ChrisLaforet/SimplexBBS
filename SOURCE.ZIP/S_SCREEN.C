/* s_screen.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 2 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_screen.c_v  $
**                       $Date:   25 Oct 1992 14:07:48  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#ifdef PROTECTED
	#define INCL_SUB
	#include <os2.h>
#else
	#include <dos.h>
#endif
#include "simplex.h"



#if !defined(PROTECTED) && !defined(__ZTC__) && !defined(__WATCOMC__)		/* this stuff requires MSC's 6.0 _asm stuff */

/* Much thanks to Dave Neathery of Dave Neathery Software for some of the
** concepts used herein.  This is non-portable code and may even be non-
** portable across DOS compilers.  Sorry about that, but most of the stuff
** should be readily portable back into MASM format.  Remember if you do
** that, you must start all functions with:
**
**			proc		xxx, far
**			push		bp
**			mov			bp,sp
**
** and on exit:
**			pop			bp
**			ret
**
** The unfortunate thing is that the BIOS handling is so poor in some
** machines that it is worthwhile to be non-portable for the perfomance!
*/


#define CURPOS  (cur_scr->cursor_posn[(cur_scr->active_page)])

int directwrite = 0;
int mono_here = 0;
int cga_here = 0;
int ega_here = 0;
int max_retrace = 0;
int snow_flag = 0;


struct scr_vals
	{
	unsigned char crt_mode;
	unsigned int crt_cols;
	unsigned int crt_len;
	unsigned int crt_start;
	unsigned int cursor_posn[8];
	unsigned int cursor_mode;
	unsigned char active_page;
	unsigned int addr_6845;
	unsigned char crt_mode_set;
	unsigned char crt_palette;
	};

struct scr_vals *cur_scr = (struct scr_vals *)0x400049;


int get_max_retrace(void)		/* get max number of chars writable in a retrace period */
	{
	int factor;
	int rtn;

	_asm
		{
			push 		ds
			push 		es
			push 		si
			push 		di
			mov  		ax,50
			mov  		factor,ax
			mov  		ax,0b800H
			mov  		ds,ax
			mov  		es,ax
			mov  		bx,100
			mov  		dx,3DAH
			cld
		again:
			add  		bx,factor
			mov  		cx,bx
			xor  		si,si
			xor  		di,di
		wait1:
			in   		al,dx
			test 		al,1000B
			jnz  		wait1
		wait2:
			in   		al,dx
			test 		al,1000B
			jz   		wait2
			cli  	
			sub			ax,ax
			rep  		movsw
			sti
			in 			al,dx
			test		al,1000B
			jnz 		again
			sub 		bx,factor
			mov 		ax,factor
			shr 		ax,1
			cmp 		ax,0
			je  		exit
			mov 		factor,ax
			jmp 		again
		exit:
			sub 		bx,5		;** subtract 5 for good measure.
			mov 		rtn,bx		;** return value
			pop 		di
			pop 		si
			pop 		es
			pop 		ds
		}
	return rtn;
	}




int bufwrite(void *bptr,int location,int len)
	{
	int scrnlen;
	int max_chars;
	int remaining_chars;

	_asm
		{
			push		ds
			push		es
			push		di
			push		si
			pushf					; direction flag must be preserved

		; Initialize for writing!

			mov			ax,0b800h	;default regenbuf seg
			mov			es,ax
			mov			ax,40h
			mov			ds,ax
			mov			bx,4ch		;crt_len in 40:4c
			mov			ax,[bx]		;default screen length
			mov			scrnlen,ax	;default screen length
			mov			bx,49h
			mov			al,[bx]		;get current video mode
			cmp			al,7		;test for mono mode
			jne			notmono
			mov			ax,0b000h	;seg of regenbuf
			mov			es,ax
			push		ds
			mov			ax,seg mono_here
			mov			ds,ax
			mov			ax,mono_here
			or			ax,ax
			jz			ega
			mov			scrnlen,4000	;screen length on mono card
		ega:
			pop			ds
		notmono:
			mov			cx,location		;location on screen
			shl			cx,1		;multiply both hor and vert by 2
			mov			al,ch		;vertical position
			cbw
			mov			bx,4ah		;screen width
			mov			dx,[bx]
			mov			ch,dl		;screen width ready to multiply
			mul			ch
			xor			ch,ch
			add			ax,cx		;add horiz pos
			mov			dx,len		;length of write
			shl			dx,1		;multiply by 2
			add			dx,ax		;offset of end of write
			cmp			dx,scrnlen	;check for excessive length
			jbe			lenok
			cmp			ax,scrnlen	;check for cursor off page
			jb			curok
			xor			dx,dx
			mov			len,dx	;zero length written
			mov			ax,3
			jmp			cont

		curok:
			mov			cx,scrnlen	;get length of cur page
			sub			cx,ax		;max len that can write in bytes
			shr			cx,1		;convert back to words to write
			mov			len,cx		;adjust requested len
		lenok:
			mov			bx,4eh		;start address for this page
			add			ax,[bx]		;new starting offset in regenbuf
			mov			di,ax		;set destination register
			cld						;set direction flag (up)
			mov			ax,seg cga_here
			mov			ds,ax
			cmp			cga_here,0	;test for cga card present
			je			fast_out
			mov			ax,seg snow_flag	;check if snow flag is set and if so
			mov			ds,ax				;then even a color monitor will run at full 
			cmp			snow_flag,0			;speed ahead!!
			jne			fast_out
			mov			ax,es
			cmp			ax,0b800h	;check for cga active
			je			slow_writ
		fast_out:
			mov			cx,len		;read length to write
			or			cx,cx		;test for 0 length
			jnz			_not_zero	;no characters to write?
			mov			ax,3		;return 3 if no chars to write
			jmp			cont

		_not_zero:
			mov			ax,0	;return 0 if fast write
			jmp			cont

		slow_writ:
			mov			ax,seg max_retrace
			mov			ds,ax
			mov			ax,max_retrace
			mov			max_chars,ax		;get maximum chars per vert retrace into
											;a local variable.
			mov			cx,len		;read length to write
			or			cx,cx		;test for 0 length
			jnz			not_zero	;no characters to write?
			mov			ax,3		;return 3 if no chars to write
			jmp			cont

		not_zero:
			mov			ax,1		;return 1 if slow write

		cont:
			cmp			ax,3
			je			end_proc
			or			ax,ax
			jz			fast
			mov			remaining_chars,cx		;store total length to write in remaining chars
			lds			si,bptr					;get source of data's address

		; if we have reached this point we are in trouble and must write S L O W L Y
		; to the screen due to IBM's STUPIDITY!  Here is retrace checking!

		start:
			mov			cx,remaining_chars	;get remaining length
			cmp			cx,max_chars	;check if number of bytes to write is less than
			jbe			get_next
			mov			cx,max_chars	;get maximum words per retrace
		get_next:
			lodsw					;get next word into ax
			mov			bx,ax		;save data to write
			mov			ah,9		;hor-vert retrace mask
			mov			dx,3daH		;port address of video status word
		hv_wait1:
			in			al,dx		;get video status
			test		al,ah		;check for a retrace
			jnz			hv_wait1	;if in vertical retrace then wait for horizontal
			cli						;no need for interrupts to slow us down
		v_wait2:
			in			al,dx		;wait for vertical retrace
			test		al,ah		;saves 12 clock cycles on 8086?
			jz			v_wait2
			mov			ax,bx		;restore data to write
			stosw					;write one word
			in			al,dx		;is it a vertical retrace?
			test		al,8
			jz			hor_end		;no then clean up
			mov			dx,cx		;save length written
			dec			cx			;decrement the count
			rep			movsw		;write to regen buffer
			sti						;reset interrrrupts
			mov			bx,remaining_chars
			sub			bx,dx
			mov			remaining_chars,bx	;save new remaining length
			jnz			start
		hor_end:
			sti						;interrupts back on
			mov			bx,remaining_chars
			dec			bx			;dec remaining write count
			mov			remaining_chars,bx	;save new remaining length
			jnz			start

			jmp			end_proc

		fast:
			lds			si,bptr					;get source of data's address
			mov			cx,len					;read length to write
			rep 		movsw
		end_proc:
			mov			ax,len					;return length written
			popf
			pop			si
			pop			di
			pop			es
			pop			ds
		}
	return len;
	}



int charwrite(char character,int attribute,int cursor,int length)
	{
	unsigned int buffer[80];
	unsigned int far *sptr;
	int count;

	if (length > 80)
		return 0;
	sptr = buffer;
	attribute <<= 8;
	attribute += (unsigned char)character;
	for (count = 0; count < length; count++)
		*sptr++ = attribute;
	return bufwrite(buffer,cursor,length);
	}

#endif




#if defined(PROTECTED)

static USHORT row;		/* saves time getting current cursor position! */
static USHORT col;


void pascal init_screen(void)
	{
	VIOMODEINFO viomodeinfo;

	row = 0;
	col = 0;
	viomodeinfo.cb = sizeof(VIOMODEINFO);
	if (!VioGetMode(&viomodeinfo,0))
		bottom_line = (int)viomodeinfo.row - 4;
	}

#else

void pascal init_screen(void)
	{
	union REGS registers;

	registers.h.ah = 15;
	int86(0x10,&registers,&registers);
	if (registers.h.al != 7)
		{
		registers.h.ah = 0;			/* not mono, go into 80x25 color */
		registers.h.al = 3;
		int86(0x10,&registers,&registers);
		}
	bottom_line = 21;
	}



void pascal reinit_screen(void)
	{
	union REGS registers;
	unsigned int far *screen;
	unsigned int screen_val;

#if !defined(__ZTC__) && !defined(__WATCOMC__)
	if (cfg.cfg_flags & CFG_DIRECT)
		directwrite = 1;
	else
		directwrite = 0;
#endif

	bottom_line = 21;
#if !defined(__ZTC__) && !defined(__WATCOMC__)
	if (directwrite)
		{
		if (cfg.cfg_flags & CFG_SNOW)
			snow_flag = 1;
		else
			snow_flag = 0;

		registers.h.ah = 0x12;
		registers.h.bl = 0x10;
		int86(0x10,&registers,&registers);
		if ((registers.x.bx & 0xff) != 0x10)
			ega_here = 1;
		if (ega_here)
			{
			if (*(char far *)(0x400084) > (char)25)
				bottom_line = 39;
			}
		if (!ega_here)		/* MGA? */
			{
			screen = (unsigned int far *)(0xb0000000);
			screen_val = *screen;
			*screen = (~(screen_val));
			mono_here = (screen_val == (~(*screen))) ? 1 : 0;
			*screen = screen_val;
			if (mono_here && cur_scr->crt_mode != 7)
				mono_here = 0;
			}
		if (!ega_here && !mono_here) 	/* CGA? */
			{
			screen = (unsigned int far *)(0xb8000000);
			screen_val = *screen;
			*screen = (~(screen_val));
			cga_here = (screen_val == (~(*screen))) ? 1 : 0;
			*screen = screen_val;
			if (cga_here && cur_scr->crt_mode == 7)
				cga_here = 0;
			if (cga_here)
				max_retrace = get_max_retrace(); 	/* gets max number of words per vert retrace */
			}
		}
#endif
	}

#endif



void pascal bios_outchar(char character,int color,int reps)
	{
#if defined(PROTECTED)
	BYTE cell[2];

	cell[0] = character;
	cell[1] = (BYTE)color;
	VioWrtNCell(cell,reps,row,col,0);
	col += reps;
	row += (col / 80);
	col %= 80;

#elif defined(__ZTC__) || defined(__WATCOMC__)

	union REGS registers;

	registers.h.ah = 9;
	registers.h.bh = 0;
	registers.x.cx = reps;
	registers.h.al = character;
	registers.x.bx = color;
	int86(0x10,&registers,&registers);

#else

	union REGS registers;
	int written;

	if (directwrite)
		{
		written = charwrite(character,color,CURPOS,reps);
		bios_setcurpos(CURPOS + written);
		}
	else
		{
		registers.h.ah = 9;
		registers.h.bh = 0;
		registers.x.cx = reps;
		registers.h.al = character;
		registers.x.bx = color;
		int86(0x10,&registers,&registers);
		}

#endif
	}



#if defined(PROTECTED)
void pascal bios_atpos_outchar(char character,int color,int pos)
	{
	BYTE cell[2];

	cell[0] = character;
	cell[1] = (BYTE)color;
	VioWrtNCell(cell,1,(unsigned int)pos >> 8,pos & 0xff,0);
	}
#endif



int pascal bios_inchar(int curpos)
	{
#if defined(PROTECTED)
	BYTE cell[2];
	int len = 2;

	VioReadCellStr(cell,&len,(unsigned int)curpos >> 8,curpos & 0xff,0);
	return (cell[1] << 8) | cell[0];

#else

	union REGS registers;
	int cursor = bios_getcurpos();

	bios_setcurpos(curpos);
	registers.h.ah = 8;
	registers.h.bh = 0;
	int86(0x10,&registers,&registers);
	bios_setcurpos(cursor);
	return (int)registers.x.ax;

#endif
	}



int pascal bios_getcurpos(void)
	{
#if defined(PROTECTED)
	return (int)((row << 8) | col);
#else
	union REGS registers;

	registers.h.ah = 3;
	registers.h.bh = 0;
	int86(0x10,&registers,&registers);
	return (int)registers.x.dx;
#endif
	}



void pascal bios_setcurpos(int curpos)
	{
#if defined(PROTECTED)
	row = (unsigned int)curpos >> 8;
	col = curpos & 0xff;
	VioSetCurPos(row,col,0);
#else
	union REGS registers;

	registers.h.ah = 2;
	registers.h.bh = 0;
	registers.x.dx = curpos;
	int86(0x10,&registers,&registers);
#endif
	}



void pascal bios_clrblk(int tlc,int brc,int color)
	{
#if defined(PROTECTED)
	BYTE cell[2];

	cell[0] = ' ';
	cell[1] = (BYTE)color;
	VioScrollUp((unsigned int)tlc >> 8,tlc & 0xff,(unsigned int)brc >> 8,brc & 0xff,((unsigned int)(brc - tlc) >> 8) + 1,cell,0);
#else
	union REGS registers;

	registers.h.ah = 6;
	registers.h.al = 0;
	registers.h.bh = (char)color;
	registers.x.cx = tlc;
	registers.x.dx = brc;
	int86(0x10,&registers,&registers);
#endif
	}



void pascal bios_scrollup(int tlc,int brc,int color,int lines)
	{
#if defined(PROTECTED)
	BYTE cell[2];

	cell[0] = ' ';
	cell[1] = (BYTE)color;
	VioScrollUp((unsigned int)tlc >> 8,tlc & 0xff,(unsigned int)brc >> 8,brc & 0xff,lines,cell,0);
#else
	union REGS registers;

	registers.h.ah = 6;
	registers.h.al = (char)lines;
	registers.h.bh = (char)color;
	registers.x.cx = tlc;
	registers.x.dx = brc;
	int86(0x10,&registers,&registers);
#endif
	}



