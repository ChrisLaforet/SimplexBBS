/* s_run.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 3 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_run.c_v  $
**                       $Date:   25 Oct 1992 14:09:20  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <direct.h>
#include <process.h>
#include <setjmp.h>
#include <ctype.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#ifdef XSPAWN
	#include <xspawn.h>
#endif
#include "simplex.h"



#ifdef PROTECTED
	extern HFILE hComm[];		/* in s_fossil.c */
	extern TID kb_tid;
	extern TID oring_tid;
	extern TID iring_tid;
#else
	extern int stdout_flag;
#endif


extern jmp_buf reset_bbs;



void shell(void)
	{
	char *cptr;

#ifndef PROTECTED
	if (stdout_flag)
		freopen("con","w",stdout);		/* stdout is now pointing to the console device (for fossil signon message!) */
#endif

	fprintf(stderr,"\r\n\r\nType EXIT to return to program....\r\n");
	if (!(cptr = getenv("COMSPEC")))
		{
#ifdef PROTECTED
		cptr = "CMD.EXE";
#else
		cptr = "COMMAND.COM";
#endif
		}

#ifndef PROTECTED
	stop_timer();
#endif

#ifdef XSPAWN
	if (xspawnlp(P_WAIT,cptr,cptr,NULL) == -1)
#else
	if (spawnlp(P_WAIT,cptr,cptr,NULL) == -1)
#endif
		{
#ifdef PROTECTED
		fprintf(stderr,"Error: Unable to shell to OS/2\n");
#else
		fprintf(stderr,"Error: Unable to shell to DOS\n");
#endif
		}

#ifndef PROTECTED
	if (!start_timer())
		{
		cptr = "Unable to restart timer process.  Hanging up!";
		_error(E_ERROR,cptr);
		system_message(cptr);
		hangup();
		longjmp(reset_bbs,2);
		}
#endif

#ifndef PROTECTED
	if (stdout_flag)
		freopen("nul","w",stdout);		/* stdout is now pointing to the nul device (for fossil signon message!) */
#endif
	}



/* Format of DORINFO#.DEF
**
** BBS Name
** Sysop's First Name
** Sysop's Last Name
** COM Port as COM? (in OS/2, File Handle) (DOS: COM0 in local mode. OS/2: -1 in local mode)
** Baud Rate and Parity
** Network Type (0=DOS or OS/2, 1=MultiLink, 2=OmniNet, 3=PC-Net, 4=DESQview, 5=10-Net, 6=NETBIOS)
** User First Name
** User Last Name
** User City, State
** User Graphic Type (1=ASCII, 2=IBM Graphics, 3=ANSI Graphics)
** User Security Level
** User Timer Remaining
** (Fossil Present 0=NO)
** 
*/



void run_program(char *command)
	{
	struct file *tfile;
	struct user tuser;
	char cbuffer[100];
	char buffer[200];
	char tbuf[200];
	char *cptr;
	char *cptr1;
	char **args = NULL;
	TIME_T time;
	DATE_T date;
	int max_args = 0;
	int cur_args = 0;
	int pause = 0;
	int keeptime = 0;
	int count;
	int ttime;
	int otime;
	int tval;
	FILE *fd;

	strcpy(cbuffer,command);
	cptr = cbuffer;
	while (*cptr && *cptr == ' ')
		++cptr;

	while (*cptr)
		{
		cptr1 = buffer;
		while (*cptr && *cptr != ' ')
			{
			tbuf[0] = 0;
			if (*cptr == '$')
				{
				switch (*(cptr + 1))
					{
					case '$':				/* $$ is translated to $ */
						strcpy(tbuf,"$");
						++cptr;
						break;
					case '*':				/* hot fossil */
						++cptr;
						break;
					case 'e':				/* pause to get ENTER when returning */
						pause = 1;
						++cptr;
						break;
					case 'k':				/* do not change user's time upon return */
						keeptime = 1;
						++cptr;
						break;
					case 'd':				/* date */
						date = get_cdate();
						sprintf(tbuf,"%02u/%02u/%02u",date & 0x1f,(date >> 5) & 0xf,((date >> 9) + 80) % 100);
						++cptr;
						break;
					case 't':				/* time */
						time = get_ctime();
						sprintf(tbuf,"%02u:%02u",time >> 11,(time >> 5) & 0x3f);
						++cptr;
						break;
					case 'r':				/* user's time remaining */
						sprintf(tbuf,"%u",(int)(user_time / 60L) + 1);
						++cptr;
						break;
					case 'b':				/* user's baud rate */
						sprintf(tbuf,"%u",user_baud);
						++cptr;
						break;
					case 'm':				/* locked baud rate IF locked else current baud */
						if (locked_flag)
							sprintf(tbuf,"%u",(unsigned int)locked_baud);
						else 
							sprintf(tbuf,"%u",(unsigned int)user_baud);
						++cptr;
						break;
					case 'f':				/* user's first name */
						strcpy(tbuf,user_firstname);
						++cptr;
						break;
					case 'l':				/* user's last name */
						strcpy(tbuf,user_lastname);
						++cptr;
						break;
					case 'a':				/* ANSI flag */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							strcpy(tbuf,"1");
						else 
							strcpy(tbuf,"0");
						++cptr;
						break;
					case 'u': 				/* user's number in user file */
						sprintf(tbuf,"%u",user_number);
						++cptr;
						break;
					case 'p':				/* com port number or handle in OS/2 */
#ifdef PROTECTED						
						sprintf(tbuf,"%d",hComm[cfg.cfg_port]);
#else
						sprintf(tbuf,"%d",cfg.cfg_port);		/* -1 means unused: 0 = com1 */
#endif
						++cptr;
						break;
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
						++cptr;
						tval = atoi(cptr);
						if (tfile = get_filearea(tval))
							{
							strcpy(tbuf,tfile->file_pathname);
							if (tbuf[0] && tbuf[strlen(tbuf) - 1] == P_CSEP)		/* remove trailing backslash */
								tbuf[strlen(tbuf) - 1] = '\0';
							}
						else
							tbuf[0] = '\0';
						while (*cptr && isdigit(*cptr))
							++cptr;
						--cptr;
						break;
					}
				}
			else
				{
				tbuf[0] = *cptr;
				tbuf[1] = '\0';
				}
			strcpy(cptr1,tbuf);
			cptr1 += strlen(tbuf);
			++cptr;
			}
		*cptr1 = '\0';

		if ((cptr1 - buffer) != 0)
			{
			if ((cur_args + 1) >= max_args)
				{
				if (!(args = realloc(args,(max_args += 10) * sizeof(char *))))
					{
					_error(E_FATAL,"Out of memory in external program run!");	/* nothing to work with? */
					system_message("\aFatal Error: Out of memory....Alert Sysop....");
					return;
					}
				}

			if (!(args[cur_args] = malloc((strlen(buffer) + 1) * sizeof(char))))
				{
				_error(E_FATAL,"Out of memory in external program run!");	/* nothing to work with? */
				system_message("\aFatal Error: Out of memory....Alert Sysop....");

				for (count = 0; count < cur_args; count++)
					free(args[count]);
				free(args);
				return;
				}

			strcpy(args[cur_args],buffer);
			++cur_args;

			args[cur_args] = NULL;
			}

		while (*cptr && *cptr == ' ')
			++cptr;
		}

	if (!cur_args)
		{
		_error(E_ERROR,"External program to run but no command line provided!");
		system_message("No command line provided to run program....Alert Sysop....");
		}
	else
		{
		sprintf(buffer,"%sdorinfo%u.def",bbspath,cfg.cfg_port + 1);		/* need to open and write DORINFO1.DEF */
		if (fd = fopen(buffer,"wb"))
			{
			sprintf(buffer,"%s\r\n",cfg.cfg_bbsname);
			fputs(buffer,fd);

			strcpy(tbuf,cfg.cfg_sysopname);
			cptr = tbuf;
			while (*cptr && *cptr != ' ')
				++cptr;
			if (*cptr)
				{
				*cptr = '\0';
				++cptr;
				}

			sprintf(buffer,"%s\r\n",tbuf);
			fputs(buffer,fd);

			while (*cptr && *cptr == ' ')
				++cptr;

			sprintf(buffer,"%s\r\n",cptr);
			fputs(buffer,fd);

#ifdef PROTECTED
			if (user_baud)
				sprintf(buffer,"%d\r\n",port);
			else
				strcpy(buffer,"-1\r\n");
#else
			if (user_baud)
				sprintf(buffer,"COM%d\r\n",cfg.cfg_port + 1);
			else
				strcpy(buffer,"COM0\r\n");
#endif

			fputs(buffer,fd);
			sprintf(buffer,"%d BAUD,N,8,1\r\n",user_baud);
			fputs(buffer,fd);
			sprintf(buffer,"0\r\n");		/* Network type = DOS or OS/2 */
			fputs(buffer,fd);
			sprintf(buffer,"%s\r\n",user_firstname);
			fputs(buffer,fd);
			sprintf(buffer,"%s\r\n",user_lastname);
			fputs(buffer,fd);
			sprintf(buffer,"%s\r\n",user.user_city);
			fputs(buffer,fd);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				sprintf(buffer,"3\r\n");
			else 
				sprintf(buffer,"1\r\n");
			fputs(buffer,fd);
			sprintf(buffer,"%d\r\n",(int)(unsigned int)user.user_priv);
			fputs(buffer,fd);
			sprintf(buffer,"%lu\r\n",user_time / 60L);
			fputs(buffer,fd);
#ifdef PROTECTED
			sprintf(buffer,"0\r\n");		/* no fossil in OS/2 */
#else
			sprintf(buffer,"1\r\n");		/* DOS version uses a fossil */
#endif
			fputs(buffer,fd);

			fclose(fd);
			}
		else 
			log_entry(L_ERROR,"Unable to create/open DORINFO1.DEF");


		log_entry(L_RUN,command);

		cur_line = 0;
		send_string("\r\n\r\n",NULL);
		bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */

		fclose(userfd);
		fclose(uinfofd);
		if (msghfd)
			fclose(msghfd);
		if (msgbfd)
			fclose(msgbfd);
		if (msglfd)
			fclose(msglfd);
		if (msgdfd)
			fclose(msgdfd);
		if (msgrfd)
			fclose(msgrfd);
		if (nlstfd)
			fclose(nlstfd);
		if (nidxfd)
			fclose(nidxfd);
		if (combfd)
			fclose(combfd);
		fflush(logfd);

#ifndef PROTECTED
		if (stdout_flag)
			freopen("con","w",stdout);		/* stdout is now pointing to the console device (for fossil signon message!) */
#endif

		if (keeptime)
			{
			nolimit_flag = 1;
			start_holdtime();
			}

#ifdef PROTECTED
		DosSuspendThread(kb_tid);
		DosSuspendThread(iring_tid);
		DosSuspendThread(oring_tid);
#else
		stop_timer();
#endif

#ifdef XSPAWN
		tval = xspawnvp(P_WAIT,args[0],args);		/* attempt to spawn program */
#else
		tval = spawnvp(P_WAIT,args[0],args);		/* attempt to spawn program */
#endif

#ifndef PROTECTED
		if (!start_timer())
			{
			cptr = "Unable to restart timer process.  Hanging up!";
			_error(E_ERROR,cptr);
			system_message(cptr);
			hangup();
			longjmp(reset_bbs,2);
			}
#endif

		set_inactivetime();
		bios_setcurpos(bottom_line << 8);

		open_files(1);			/* reinitialize the system */

		if ((bios_getcurpos() >> 8) > bottom_line)
			bios_scrollup(0x0,(bottom_line << 8) | 0x4f,(bios_getcurpos() >> 8) - bottom_line,WHITE);

		bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* prepare status lines */
		show_user();

		load_msglast();

		/* get the user's record -- in case it was changed */

		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fread(&tuser,1,sizeof(struct user),userfd);
		strcpy(user.user_name,tuser.user_name);
		strcpy(user.user_city,tuser.user_city);
		strcpy(user.user_password,tuser.user_password);
		strcpy(user.user_home,tuser.user_home);
		strcpy(user.user_data,tuser.user_data);
		user.user_priv = tuser.user_priv;
		user.user_uflags = tuser.user_uflags;
		user.user_flags = tuser.user_flags;
		user.user_screenlen = tuser.user_screenlen;
		user.user_credit = tuser.user_credit;

		if (!local_flag)
			reinit_fossil(cfg.cfg_port);		/* reinits when BBS is reentered  */
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(WHITE),NULL);
		else 
			write_string(new_color(WHITE));

#ifdef PROTECTED
		DosResumeThread(kb_tid);
		DosResumeThread(iring_tid);
		DosResumeThread(oring_tid);
#endif

		/* recalc the online time */

		if (!keeptime)
			{
			otime = (int)((projected_time(0L) - login_time) / 60L);
			if (otime < 0)
				otime = 0;

			if (!time_flag)
				{
				ttime = logon_times[(int)user.user_priv] - otime;
				ttime -= user.user_timeused;
				}
			else
				{
				ttime = time_flag;
				if (ttime > (logon_times[(int)user.user_priv] + otime))
					ttime = logon_times[(int)user.user_priv] - otime;
				ttime -= user.user_timeused;
				}
			if (ttime < 2)
				ttime = 2;

			set_logofftime((long)ttime * 60L);
			user_time = remaining_time();
			}
		else
			{
			nolimit_flag = 0;
			stop_holdtime();
			}

		user_warning = 0;			/* set 2 minute warning flag off! */
		show_user();
		if (check_events())
			{
			user_online = 1;   			/* ok, continue timing!!!! */
			show_user();
			get_enter();
			}
		else
			user_online = 1;   			/* ok, continue timing!!!! */

		if (tval == -1)
			{
			sprintf(buffer,"Error spawning %s!",args[0]);
			log_entry(L_RUN_FAILED,buffer);
			system_message("\r\n\aError occurred while spawning program....Alert Sysop....");
			}
		else if (pause)
			get_enter();

		for (count = 0; count < cur_args; count++)
			free(args[count]);
		free(args);
		}
	}
