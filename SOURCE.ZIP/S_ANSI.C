/* s_ansi.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 2 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_ansi.c_v  $
**                       $Date:   25 Oct 1992 14:06:46  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "simplex.h"



int cur_line = 0;
int cur_color = WHITE;
int bottom_line = 21;
int inansi_flag = 0;		/* true if in middle of ansi sequence! */
static char _far buf1[100];




void init_color(void)
	{
	cur_color = WHITE;
	cur_line = 0;
	write_string(new_color(WHITE));
	}



char *new_color(int color)
	{
	static char _far ansi[20];

	strcpy(ansi,"[");
	if (!(color & BLINK) && (cur_color & BLINK))
		{
		strcat(ansi,"0;");
		cur_color = WHITE;
		}
	if (!(color & BRIGHT) && (cur_color & BRIGHT))
		{
		strcat(ansi,"0;");
		cur_color = WHITE;
		}
	switch (color & 7)
		{
		case BLACK:
			strcat(ansi,"30");
			break;
		case RED:
			strcat(ansi,"31");
			break;
		case GREEN:
			strcat(ansi,"32");
			break;
		case BROWN:
			strcat(ansi,"33");
			break;
		case BLUE:
			strcat(ansi,"34");
			break;
		case MAGENTA:
			strcat(ansi,"35");
			break;
		case CYAN:
			strcat(ansi,"36");
			break;
		case WHITE:
			strcat(ansi,"37");
			break;
		}
	switch (color & 0x70)
		{
		case ON_BLACK:
			if (!(cur_color & ON_BLACK))
				strcat(ansi,";40");
			break;
		case ON_RED:
			if (!(cur_color & ON_RED))
				strcat(ansi,";41");
			break;
		case ON_GREEN:
			if (!(cur_color & ON_GREEN))
				strcat(ansi,";42");
			break;
		case ON_BROWN:
			if (!(cur_color & ON_BROWN))
				strcat(ansi,";43");
			break;
		case ON_BLUE:
			if (!(cur_color & ON_BLUE))
				strcat(ansi,";44");
			break;
		case ON_MAGENTA:
			if (!(cur_color & ON_MAGENTA))
				strcat(ansi,";45");
			break;
		case ON_CYAN:
			if (!(cur_color & ON_CYAN))
				strcat(ansi,";46");
			break;
		case ON_WHITE:
			if (!(cur_color & ON_WHITE))
				strcat(ansi,";47");
			break;
		}
	if ((color & BRIGHT) && !(cur_color & BRIGHT))
		strcat(ansi,";1");
	if ((color & BLINK) && !(cur_color & BLINK))
		strcat(ansi,";5");
	strcat(ansi,"m");
	return ansi;
	}



char *new_color1(int color,int prev_color)		/* returns string for menu colors */
	{
	static char _far ansi[20];

	strcpy(ansi,"[");
	if (!(color & BLINK) && (prev_color & BLINK))
		{
		strcat(ansi,"0;");
		prev_color = WHITE;
		}
	if (!(color & BRIGHT) && (prev_color & BRIGHT))
		{
		strcat(ansi,"0;");
		prev_color = WHITE;
		}
	switch (color & 7)
		{
		case BLACK:
			strcat(ansi,"30");
			break;
		case RED:
			strcat(ansi,"31");
			break;
		case GREEN:
			strcat(ansi,"32");
			break;
		case BROWN:
			strcat(ansi,"33");
			break;
		case BLUE:
			strcat(ansi,"34");
			break;
		case MAGENTA:
			strcat(ansi,"35");
			break;
		case CYAN:
			strcat(ansi,"36");
			break;
		case WHITE:
			strcat(ansi,"37");
			break;
		}
	switch (color & 0x70)
		{
		case ON_BLACK:
			if (!(prev_color & ON_BLACK))
				strcat(ansi,";40");
			break;
		case ON_RED:
			if (!(prev_color & ON_RED))
				strcat(ansi,";41");
			break;
		case ON_GREEN:
			if (!(prev_color & ON_GREEN))
				strcat(ansi,";42");
			break;
		case ON_BROWN:
			if (!(prev_color & ON_BROWN))
				strcat(ansi,";43");
			break;
		case ON_BLUE:
			if (!(prev_color & ON_BLUE))
				strcat(ansi,";44");
			break;
		case ON_MAGENTA:
			if (!(prev_color & ON_MAGENTA))
				strcat(ansi,";45");
			break;
		case ON_CYAN:
			if (!(prev_color & ON_CYAN))
				strcat(ansi,";46");
			break;
		case ON_WHITE:
			if (!(prev_color & ON_WHITE))
				strcat(ansi,";47");
			break;
		}
	if ((color & BRIGHT) && !(prev_color & BRIGHT))
		strcat(ansi,";1");
	if ((color & BLINK) && !(prev_color & BLINK))
		strcat(ansi,";5");
	strcat(ansi,"m");
	return ansi;
	}



static void pascal delete_character(void)
	{
	int cursor = bios_getcurpos();
	int maximum;
	int cell;
	int count;

	maximum = 79 - (cursor & 0xff);
	for (count = 0; count < maximum; count++)
		{
		cell = bios_inchar(cursor + count + 1);
#ifdef PROTECTED
		bios_atpos_outchar((char)(cell & 0xff),(unsigned int)cell >> 8,cursor + count);
#else
		bios_setcurpos(cursor + count);
		bios_outchar((char)(cell & 0xff),(unsigned int)cell >> 8,1);
#endif
		}
#ifdef PROTECTED
   	bios_atpos_outchar(' ',(unsigned int)cell >> 8,(int)((cursor & 0xff00) | 79));
#else
	bios_setcurpos((int)((cursor & 0xff00) | 79));		/* delete the last character */
	bios_outchar(' ',(unsigned int)cell >> 8,1);
	bios_setcurpos(cursor);
#endif
	}



static void pascal insert_character(void)
	{
	int cursor = bios_getcurpos();
	int maximum;
	int cell;
	int count;

	maximum = 79 - (cursor & 0xff);
	for (count = maximum; count > 0; count--)
		{
		cell = bios_inchar(cursor + count - 1);
#ifdef PROTECTED
		bios_atpos_outchar((char)(cell & 0xff),(unsigned int)cell >> 8,cursor + count);
#else
		bios_setcurpos(cursor + count);
		bios_outchar((char)(cell & 0xff),(unsigned int)cell >> 8,1);
#endif
		}
#ifdef PROTECTED
  	bios_atpos_outchar(' ',cur_color,cursor);
#else
	bios_setcurpos(cursor);			/* delete the current character */
	bios_outchar(' ',cur_color,1);
	bios_setcurpos(cursor);
#endif
	}



void pascal write_char(char character)
	{
	int cursor;
	int tval;

	if (character && character != '\r' && character != '\n' && character != '\a' && character != '\b' && character != '\t' && character != '\b' && character != '\x11' && character != '\x13' && character != '\f')
		{
		cursor = bios_getcurpos();
		bios_outchar(character,cur_color,1);
		if ((cursor & 0xff) < 79)
			++cursor;
		else
			{
			if ((int)((unsigned int)cursor >> 8) < bottom_line)
				cursor = (int)((cursor & 0xff00) + 0x100);
			else
				{
				bios_scrollup(0x0,(bottom_line << 8) | 0x4f,cur_color,1);
				cursor = bottom_line << 8;
				}
			}
		bios_setcurpos(cursor);
		}
	else
		{
		switch (character)
			{
			case '\0':
				break;
			case '\r':
				cursor = bios_getcurpos();
				bios_setcurpos((int)(cursor & 0xff00));
				break;
            case '\n':
				cursor = bios_getcurpos();
				if ((int)((unsigned int)cursor >> 8) < bottom_line)
					cursor = (int)((cursor & 0xff00) + 0x100);
				else
					{
					bios_scrollup(0x0,(bottom_line  << 8) | 0x4f,cur_color,1);
					cursor = bottom_line << 8;
					}
				bios_setcurpos(cursor);
				break;
			case '\a':		/* trap beeping unless local login */
				if (!user_baud)
					sound_tone(880,150);
				break;
            case '\t':
				cursor = bios_getcurpos();
				tval = (cursor & 0xff) + 1;
				tval = tval / 8;
				++tval;
				tval *= 8;
				if (tval > 80)
					tval = 80;
				cursor = (int)((cursor & 0xff00) + (tval - 1));
				bios_setcurpos(cursor);
				break;
			case '\b':
				cursor = bios_getcurpos();
				if (cursor & 0xff)
					{
					--cursor;
//					bios_outchar(' ',cur_color,1);
					bios_setcurpos(cursor);
					}
				break;
			case '\f':
				cur_line = 0;
				bios_clrblk(0x0,(bottom_line << 8) + 0x4f,cur_color);
				bios_setcurpos(0x0);
				break;
			}
		}
	}



void pascal write_string(char *string)
	{
	char tbuf[50];
	char *cptr = string;
	static char *cptr1;
	char *cptr2;
	static int save_cursor = 0;
	int cursor;
	int valid = 0;
	int tcolor;
	int row;
	int col;

	while (*cptr)
		{
		if (*cptr == '\x1b' && !inansi_flag)
			{
			inansi_flag = 1;
			cptr1 = buf1;
			}
		else if (*cptr == '\x1b' && inansi_flag)
			cptr1 = buf1;
		if (inansi_flag)
			{
			if ((cptr1 == (buf1 + 1) && *cptr == '[') || cptr1 != (buf1 + 1))
				{
				*cptr1++ = *cptr;
				if (isalpha(*cptr) || *cptr == '@')
					{
					valid = 0;
					*cptr1 = '\0';
					switch (*cptr)
						{
						case 's': 	/* SCP */
							if (buf1[2] == 's')
								{
								save_cursor = bios_getcurpos();
								valid = 1;
								}
							break;
						case 'u':	/* RCP */
							if (buf1[2] == 'u')
								{
								bios_setcurpos(save_cursor);
								valid = 1;
								}
							break;
						case 'P':	/* DCH */
							delete_character();
							valid = 1;
							break;
						case '@':	/* ICH */
							insert_character();
							valid = 1;
							break;
						case 'D':	/* CUB */
							if (buf1[2] == 'D')
								{
								cursor = bios_getcurpos();
								if (cursor & 0xff)
									bios_setcurpos(cursor - 1);
								valid = 1;
								}
							else
								{
								col = atoi(buf1 + 2);
								cursor = bios_getcurpos();
								if ((cursor & 0xff) >= col)
									bios_setcurpos(cursor - col);
								valid = 1;
                            	}
							break;
                    	case 'B':	/* CUD */
							if (buf1[2] == 'B')
								{
								cursor = bios_getcurpos();
								if ((int)((unsigned int)cursor >> 8) < bottom_line)
									bios_setcurpos(cursor + 0x100);
								valid = 1;
								}
							else
								{
								row = atoi(buf1 + 2);
								cursor = bios_getcurpos();
								if (((int)((unsigned int)cursor >> 8) + row) < bottom_line)
									bios_setcurpos(cursor + (row << 8));
								else
									bios_setcurpos(((bottom_line - 1) << 8) + (cursor & 0xff));
                        
								valid = 1;
                            	}
							break;
                    	case 'C':	/* CUF */
							if (buf1[2] == 'C')
								{
								cursor = bios_getcurpos();
								if ((cursor & 0xff) < 79)
									bios_setcurpos(cursor + 1);
								valid = 1;
								}
							else
								{
								col = atoi(buf1 + 2);
								cursor = bios_getcurpos();
								if (((cursor & 0xff) + col) < 79)
									bios_setcurpos(cursor + col);
								valid = 1;
                            	}
							break;
                    	case 'H':	/* CUP */
							if (buf1[2] == 'H')
								{
								bios_setcurpos(0x0);
								valid = 1;
								}
							else
								{
								if (buf1[2] == ';')
									{
									if (buf1[3] == 'H')
										{
										bios_setcurpos(0x0);
										valid = 1;
										}
									else
										{
										col = atoi(buf1 + 3);
										--col;
										if (col <= 79)
											bios_setcurpos(col);
										valid = 1;
										}
									}
								else
									{
									cptr1 = buf1 + 2;
									cptr2 = tbuf;
									while (isdigit(*cptr1))
										*cptr2++ = *cptr1++;
									*cptr2 = '\0';
									row = atoi(tbuf);
									col = 1;
									if (*cptr1 == ';')
										{
										++cptr1;
										if (isdigit(*cptr1))
											{
											cptr2 = tbuf;
											while (isdigit(*cptr1))
												*cptr2++ = *cptr1++;
											*cptr2 = '\0';
											col = atoi(tbuf);
											}
										}
									--row;
									--col;
									if (row > bottom_line)
										row = (bottom_line - 1);
									if (col > 79)
										col = 79;
									bios_setcurpos((row << 8) + col);
									valid = 1;
									}
								}
							break;
						case 'A':	/* CUU */
							if (buf1[2] == 'A')
								{
								cursor = bios_getcurpos();
								if ((unsigned int)cursor >> 8)
									bios_setcurpos(cursor - 0x100);
								valid = 1;
								}
							else
								{
								row = atoi(buf1 + 2);
								cursor = bios_getcurpos();
								if ((int)((unsigned int)cursor >> 8) >= row)
									bios_setcurpos(cursor - (row << 8));
								else
									bios_setcurpos(cursor & 0xff);
								valid = 1;
                            	}
							break;
						case 'n':	/* DSR */
							cursor = bios_getcurpos();
							sprintf(tbuf,"\x1b[%u;%uR",((unsigned int)cursor >> 8) + 1,(cursor & 0xff) + 1);
							send_string(tbuf,NULL);		/* change to "blind" no-echo send */
							valid = 1;
							break;
                    	case 'J':	/* ED */
							if (buf1[2] == 'J')
								{
								cursor = bios_getcurpos();
								if ((cursor & 0xff) <= 79)
									bios_outchar(' ',cur_color,80 - (cursor & 0xff));
								bios_scrollup((int)((cursor & 0xff00) + 0x100),(bottom_line << 8) | 0x4f,cur_color,0);
								bios_setcurpos(cursor);
								valid = 1;
								}
							else
								{
								switch (atoi(buf1 + 2))
									{
									case 0:
										cursor = bios_getcurpos();
										if ((cursor & 0xff) <= 79)
											bios_outchar(' ',cur_color,80 - (cursor & 0xff));
										bios_scrollup((int)((cursor & 0xff00) + 0x100),(bottom_line << 8) | 0x4f,cur_color,0);
										bios_setcurpos(cursor);
										valid = 1;
										break;
									case 1:
										cursor = bios_getcurpos();
										if (cursor & 0xff00)
											bios_scrollup(0,(int)(((cursor & 0xff00) - 0x100) | 0x4f),cur_color,0);
										bios_outchar(' ',cur_color,(cursor & 0xff) + 1);
										bios_setcurpos(cursor);
										valid = 1;
										break;
									case 2:
										bios_clrblk(0x0,(bottom_line << 8) + 0x4f,cur_color);
										bios_setcurpos(0x0);
										cur_line = 0;
										valid = 1;
										break;
									default:
										break;
									}
                            	}
							break;
                    	case 'K':	/* EL */
							cursor = bios_getcurpos();
							if ((cursor & 0xff) <= 79)
								bios_outchar(' ',cur_color,80 - (cursor & 0xff));
							bios_setcurpos(cursor);
							valid = 1;
							break;
                    	case 'f':	/* HVP */
							if (buf1[2] == 'f')
								{
								bios_setcurpos(0x0);
								valid = 1;
								}
							else
								{
								if (buf1[2] == ';')
									{
									if (buf1[3] == 'f')
										{
										bios_setcurpos(0x0);
										valid = 1;
										}
									else
										{
										col = atoi(buf1 + 3);
										--col;
										if (col <= 79)
											bios_setcurpos(col);
										valid = 1;
										}
									}
								else
									{
									cptr1 = buf1 + 2;
									cptr2 = tbuf;
									while (isdigit(*cptr1))
										{
										*cptr2++ = *cptr1++;
										}
									*cptr2 = '\0';
									row = atoi(tbuf);
									col = 1;
									if (*cptr1 == ';')
										{
										++cptr1;
										if (isdigit(*cptr1))
											{
											cptr2 = tbuf;
											while (isdigit(*cptr1))
												*cptr2++ = *cptr1++;
											*cptr2 = '\0';
											col = atoi(tbuf);
											}
										}
									--row;
									--col;
									if (row > bottom_line)
										row = bottom_line - 1;
									if (col > 79)
										col = 79;
									bios_setcurpos((row << 8) + col);
									valid = 1;
									}
								}
							break;
                    	case 'm':	/* SGR */
							if (buf1[2] == 'm')
								{
								cur_color = WHITE;
								valid = 1;
								}
							else
								{
								strcpy(tbuf,buf1 + 2);
								cptr1 = strtok(tbuf,";m");
								while (cptr1)
									{
									tcolor = atoi(cptr1);
									switch (tcolor)
										{
										case 0:
											cur_color = WHITE;
											valid = 1;
											break;
										case 1:
											cur_color |= BRIGHT;
											valid = 1;
											break;
                                    	case 5:
											cur_color |= BLINK;
											valid = 1;
											break;
                                    	case 7:
											cur_color = (cur_color & BLINK) | ((cur_color & 0x7) << 4) | ((cur_color & 0x70) >> 4) | (cur_color & 0x8);
											valid = 1;
											break;
										case 8:
											cur_color = 0;
											valid = 1;
											break;
                                    	case 30:
											cur_color &= 0xf8;
											valid = 1;
											break;
                                    	case 31:
											cur_color = (cur_color & 0xf8) + RED;
											valid = 1;
											break;
                                    	case 32:
											cur_color = (cur_color & 0xf8) + GREEN;
											valid = 1;
											break;
                                    	case 33:
											cur_color = (cur_color & 0xf8) + BROWN;
											valid = 1;
											break;
                                    	case 34:
											cur_color = (cur_color & 0xf8) + BLUE;
											valid = 1;
											break;
                                    	case 35:
											cur_color = (cur_color & 0xf8) + MAGENTA;
											valid = 1;
											break;
                                    	case 36:
											cur_color = (cur_color & 0xf8) + CYAN;
											valid = 1;
											break;
                                    	case 37:
											cur_color = (cur_color & 0xf8) + WHITE;
											valid = 1;
											break;
                                    	case 40:
											cur_color &= 0x8f;
											valid = 1;
											break;
                                    	case 41:
											cur_color = (cur_color & 0x8f) + ON_RED;
											valid = 1;
											break;
                                    	case 42:
											cur_color = (cur_color & 0x8f) + ON_GREEN;
											valid = 1;
											break;
                                    	case 43:
											cur_color = (cur_color & 0x8f) + ON_BROWN;
											valid = 1;
											break;
                                    	case 44:
											cur_color = (cur_color & 0x8f) + ON_BLUE;
											valid = 1;
											break;
                                    	case 45:
											cur_color = (cur_color & 0x8f) + ON_MAGENTA;
											valid = 1;
											break;
                                    	case 46:
											cur_color = (cur_color & 0x8f) + ON_CYAN;
											valid = 1;
											break;
                                    	case 47:
											cur_color = (cur_color & 0x8f) + ON_WHITE;
											valid = 1;
											break;
										}
									cptr1 = strtok(NULL,";m");
									}
								}
							break;
                    	}
					if (!valid)
						{
						cptr1 = buf1;
						while (*cptr1)
							{
							write_char(*cptr1);
							++cptr1;
							}
						}
					inansi_flag = 0;
					cptr1 = buf1;
					}
				}
			else 
				{
				cptr1 = buf1;
				while (*cptr1)
					{
					write_char(*cptr1);
					++cptr1;
					}
				cptr1 = buf1;
				inansi_flag = 0;
				}
			}
		else
			write_char(*cptr);

		++cptr;
		}
	}

