/* s_futl.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 16 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_futl.c_v  $
**                       $Date:   25 Oct 1992 14:07:06  $
**                       $Revision:   1.24  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <setjmp.h>
#include <ctype.h>
#include "simplex.h"



struct arj
	{
	int arj_id;				/* should be 0xea60 */	
	int arj_headsz;			/* size from next byte to end of comment */
	char arj_firstheadsz;	/* size from next byte up to extra_date */
	char arj_version;
	char arj_minversion;	/* minimum version to extract */
	char arj_os;			/* OS to archive it: 0=MSDOS  1=PRIMOS  2=UNIX  3=AMIGA  4=MACDOS */
	char arj_flags;			/* 1=GARBLED (passworded)  2=RESERVED  4=VOLUME_FLAG  8=EXTFILE_FLAG  16=PATHSYM_FLAG */
	char arj_method;		/* 0=stored 1=compressed most -> 4=compressed fastest */
	char arj_ftype;			/* file type: 0=binary  1=text  2=comment header */
	char arj_reserved;

	int arj_time;			/* time modified DOS encoded */
	int arj_date;			/* date modified DOS encoded */
	long arj_csize;			/* compressed size */
	long arj_size;			/* original size */
	long arj_crc;			/* original file's CRC-32 */

	int arj_fspecpos;		/* filespec position in filename */
	int arj_fmode;			/* file access mode DOS encoded */
	int arj_hostdata;		/* currently unused */
	};


struct zip
	{
	long zip_signiture;
	int zip_version;
	int zip_gp;
	int zip_method;
	int zip_time;
	int zip_date;
	long zip_crc;
	long zip_csize;
	long zip_size;
	int zip_fnamelen;
	int zip_extralen;
	};


struct arc
	{
	char arc_mark; 		/* should be 0x1a */
	char arc_method; 	/* archive method */
	char arc_name[13];	/* file name */
	long arc_size;  	/* size of compressed file */
	int arc_date;		/* file date */
	int arc_time;  		/* file time */
	int arc_crc;    	/* cyclic redundancy check */
	long arc_length;  	/* size of uncompressed file */
	};


struct zoo_header 
	{
	char text[20];     	/* archive header text */
	long zoo_tag;      	/* identifies archives           */
	long zoo_start;     /* where the archive's data starts        */
	long zoo_minus;     /* for consistency checking of zoo_start  */
	char major_ver;
	char minor_ver;     /* minimum version to extract all files   */
	};


struct zoo 
	{
	long zoo_tag;     	/* tag -- redundancy check */
	char zoo_type;     	/* type of entry. Always 1 for now */
	char zoo_method;	/* 0 = no packing, 1 = normal LZW */
	long zoo_next;      /* pos'n of next directory entry */
	long zoo_offset;    /* position of this file */
	int zoo_date;   	/* DOS format date */
	int zoo_time;   	/* DOS format time */
	int zoo_crc;    	/* CRC of this file */
	long zoo_size;		/* original file size */
	long zoo_csize;		/* compressed size */
	char zoo_maj_ver;
	char zoo_min_ver;   /* minimum version needed to extract */
	char zoo_deleted;   /* will be 1 if deleted, 0 if not */
	char zoo_struc;     /* file structure if any */
	long zoo_comment;   /* points to comment;  zero if none */
	int zoo_cmtlen; 	/* length of comment, 0 if none */
	char zoo_name[13]; 	/* filename */
	int zoo_var_len; 	/* length of variable part of dir entry */
	};


struct lzh 
	{
	char lzh_headsize;
	char lzh_chk;
	char lzh_id[5];
	long lzh_csize;
	long lzh_size;
	int lzh_time;
	int lzh_date;
	int lzh_attr;
	char lzh_namelen;
	};


struct pak
	{
	char pak_marker;
	char pak_method;
	char pak_name[13];
	long pak_csize;
	int pak_date;
	int pak_time;
	int pak_crc;
	long pak_size;
	};


struct pak_foot
	{
	char pak_marker;
	char pak_eof;
	};


struct pak_extfoot
	{
	char pak_marker;
	char pak_type;
	int pak_file;
	long pak_len;
	};




extern jmp_buf reset_bbs;




char *permit_file(struct file *tfile,char *fname)
	{
	struct file *tfile1;
	struct fe tfe;
	char buffer[100];
	int ok = 0;
	FILE *fd;

	if (tfile->file_descname[0])
		strcpy(buffer,tfile->file_descname);
	else 
		strcpy(buffer,tfile->file_pathname);
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,"filelist.bbs");

	if (fd = open_filelist_read(buffer))		/* now open the list file itself */
		{
		while (fread(&tfe,sizeof(struct fe),1,fd))
			{
			if (!stricmp(tfe.fe_name,fname))
				{
				if (tfe.fe_priv <= user.user_priv && (tfe.fe_flags & user.user_uflags) == tfe.fe_flags)
					{
					ok = 1;
					if (tfe.fe_location == tfile->file_number)
						strcpy(filepath,tfile->file_pathname);
					else if (tfile1 = get_filearea(tfe.fe_location))
						strcpy(filepath,tfile1->file_pathname);
					else
						ok = 0;

					if (ok)
						{
						if (filepath[0])
							{
							if (filepath[strlen(filepath) - 1] != P_CSEP)
								strcat(filepath,P_SSEP);
							}
						}
					}
				break;
				}
			}
		closef(fd);
		}
	if (ok)
		return filepath;
	return NULL;
	}



void read_files(int area)	 
	{
	struct file *tfile;
	char buffer[150];
	char fname[13];
	char ext[5];
	char *cptr;
	char *cptr1;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nRead what text file (ENTER=Quit)? ",NULL);
		get_fname(fname,12,0,0);
		if (fname[0])
			{
			strlwr(fname);
			cptr = fname + strlen(fname);
			while ((cptr - fname) > 0 && *cptr != '.')
				--cptr;
			cptr1 = ext;
			while (*cptr && (cptr1 - ext) < 4)
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (!stricmp(ext,".ARC") || !stricmp(ext,".ICE") || !stricmp(ext,".LZH") || !stricmp(ext,".PAK") || !stricmp(ext,".ZIP") || !stricmp(ext,".ZOO") ||
				!stricmp(ext,".COM") || !stricmp(ext,".EXE") || !stricmp(ext,".OBJ") || !stricmp(ext,".O") || !stricmp(ext,"DAT") || !stricmp(ext,".NDX") ||
				!stricmp(ext,".ARJ") || !stricmp(ext,".DB") || !stricmp(ext,".NTX"))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("You can only read non-binary text files!\r\n",NULL);
				}
			else
				{
				if (cptr = permit_file(tfile,fname))
					{
					strcpy(buffer,cptr);
					strcat(buffer,fname);
					if (!access(buffer,0))
						{
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(WHITE),NULL);
						send_file(filepath,fname,0,ps_handler);
						get_enter();
						}
					else
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						sprintf(buffer,"The file \"%s\" does not exist!\r\n",fname);
						send_string(buffer,NULL);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					sprintf(buffer,"The file \"%s\" does not exist!\r\n",fname);
					send_string(buffer,NULL);
					}
				}
			}
		}
	while (fname[0]);
	}



static char *convert_zip_date(int date)
	{
	static char _far buffer[20];
	int month = ((unsigned int)date >> 5) & 0xf;
	int day = date & 0x1f;
	int year = (unsigned int)date >> 9;

	sprintf(buffer,"%2u %s %04u",day,months_table[month - 1],1980 + year);
	return buffer;
	}



static char *convert_zip_time(int time)
	{
	static char _far buffer[20];

	sprintf(buffer,"%2u:%02u",(unsigned int)time >> 11,((unsigned int)time >> 5) & 0x3f);
	return buffer;
	}



void show_lzh(char *name,FILE *fd)
	{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char buffer[100];
	char buffer1[100];
	long total_comp = 0L;
	long total_size = 0L;
	struct lzh lzh;
	int stop_flag = 0;
	int key;
	int quit = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nListing of the contents of the LZH file \"",NULL);
	send_string(name,NULL);
	send_string("\":\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("Filename        Method    Comp Size   Norm Size   Date         Time\r\n",NULL);
	send_string("-------------   --------  ----------  ----------  -----------  -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	while (!quit && fread(&lzh,sizeof(struct lzh),1,fd))
		{
		memset(buffer1,0,sizeof(buffer1));
		fread(buffer1,lzh.lzh_namelen,1,fd);
		_splitpath(buffer1,drive,dir,fname,ext);
		_makepath(buffer1,"","",fname,ext);
		strlwr(buffer1);

		sprintf(buffer,"%-13.13s   %-5.5s     %10lu  %10lu  %s  %s\r\n",buffer1,lzh.lzh_id,lzh.lzh_csize,lzh.lzh_size,convert_zip_date(lzh.lzh_date),convert_zip_time(lzh.lzh_time));
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;

		total_comp += lzh.lzh_csize;
		total_size += lzh.lzh_size;
		if (lzh.lzh_headsize - lzh.lzh_namelen >= 22)
			fseek(fd,lzh.lzh_csize + 2L,SEEK_CUR);
		else
			fseek(fd,lzh.lzh_csize,SEEK_CUR);

		if (stop_flag)
			quit = 1;
		else
			{
			update_clock();
			key = '\0';
			if (user_baud && !cd)
				longjmp(reset_bbs,1);
			if (user_baud && peek_input(cfg.cfg_port) != -1)
				key = read_input(cfg.cfg_port);
			else
				key = get_kb();
			switch (key)
				{
				case 'S':
				case 's':
					quit = 1;
					break;
				case 'P':
				case 'p':
					if (dopause())
						quit = 1;
					break;
				}
			}
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("                          ----------  ----------\r\n",NULL);
	sprintf(buffer,"                          %10lu  %10lu\r\n",total_comp,total_size);
	send_string(buffer,NULL);
	}




void show_pak(char *name,FILE *fd)
	{
	char buffer[100];
	long total_comp = 0L;
	long total_size = 0L;
	char *method;
	struct pak pak;
	int stop_flag = 0;
	int key;
	int quit = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nListing of the contents of the ARC/PAK file \"",NULL);
	send_string(name,NULL);
	send_string("\":\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("Filename        Method     Comp Size   Norm Size   Date         Time\r\n",NULL);
	send_string("-------------   ---------  ----------  ----------  -----------  -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	while (!quit && fread(&pak,sizeof(struct pak),1,fd))
		{
		if (pak.pak_marker != 0x1a || !pak.pak_method)		/* marker is ^Z or EOF*/
			break;
		strlwr(pak.pak_name);
		switch (pak.pak_method)
			{
			case 1:
			case 2:
				method = "Stored";
				break;
			case 3:
				method = "Packed";
				break;
			case 4:
				method = "Squeezed";
				break;
			case 5:
			case 6:
			case 7:
			case 8:
				method = "Crunched";
				break;
			case 9:
				method = "Squashed";
				break;
			case 10:
				method = "Crushed";
				break;
			case 11:
				method = "Distilled";
				break;
			default:
				method = "Unknown";
				break;
			}
		sprintf(buffer,"%-13.13s   %-9.9s  %10lu  %10lu  %s  %s\r\n",pak.pak_name,method,pak.pak_csize,pak.pak_size,convert_zip_date(pak.pak_date),convert_zip_time(pak.pak_time));
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;

		total_comp += pak.pak_csize;
		total_size += pak.pak_size;
		
		fseek(fd,pak.pak_csize,SEEK_CUR);

		if (stop_flag)
			quit = 1;
		else
			{
			update_clock();
			key = '\0';
			if (user_baud && !cd)
				longjmp(reset_bbs,1);
			if (user_baud && peek_input(cfg.cfg_port) != -1)
				key = read_input(cfg.cfg_port);
			else
				key = get_kb();
			switch (key)
				{
				case 'S':
				case 's':
					quit = 1;
					break;
				case 'P':
				case 'p':
					if (dopause())
						quit = 1;
					break;
				}
			}
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("                           ----------  ----------\r\n",NULL);
	sprintf(buffer,"                           %10lu  %10lu\r\n",total_comp,total_size);
	send_string(buffer,NULL);
	}



void show_zip(char *name,FILE *fd)
	{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char buffer[100];
	char buffer1[100];
	long total_comp = 0L;
	long total_size = 0L;
	char *method;
	struct zip zip;
	int stop_flag = 0;
	int key;
	int quit = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nListing of the contents of the ZIP file \"",NULL);
	send_string(name,NULL);
	send_string("\":\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("Filename        Method    Comp Size   Norm Size   Date         Time\r\n",NULL);
	send_string("-------------   --------  ----------  ----------  -----------  -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	while (!quit && fread(&zip,sizeof(struct zip),1,fd))
		{
		if (zip.zip_signiture != 0x4034b50L)
			break;
		memset(buffer1,0,sizeof(buffer1));
		fread(buffer1,zip.zip_fnamelen,1,fd);
		_splitpath(buffer1,drive,dir,fname,ext);
		_makepath(buffer1,"","",fname,ext);
		strlwr(buffer1);
		switch (zip.zip_method)
			{
			case 0:
				method = "Stored";
				break;
			case 1:
				method = "Shrunk";
				break;
			case 2:
			case 3:
			case 4:
			case 5:
				method = "Reduced";
				break;
			case 6:
				method = "Implode";
				break;
			case 7:
				method = "Token";
				break;
			case 8:
				method = "A-Xtra";
				break;
			default:
				method = "Unknown";
				break;
			}
		sprintf(buffer,"%-13.13s   %-8.8s %10lu  %10lu  %s  %s\r\n",buffer1,method,zip.zip_csize,zip.zip_size,convert_zip_date(zip.zip_date),convert_zip_time(zip.zip_time));
		send_string(buffer,NULL);
		if (more_flag)
			stop_flag = 1;

		total_comp += zip.zip_csize;
		total_size += zip.zip_size;
		fseek(fd,zip.zip_csize,SEEK_CUR);

		if (stop_flag)
			quit = 1;
		else
			{
			update_clock();
			key = '\0';
			if (user_baud && !cd)
				longjmp(reset_bbs,1);
			if (user_baud && peek_input(cfg.cfg_port) != -1)
				key = read_input(cfg.cfg_port);
			else
				key = get_kb();
			switch (key)
				{
				case 'S':
				case 's':
					quit = 1;
					break;
				case 'P':
				case 'p':
					if (dopause())
						quit = 1;
					break;
				}
			}
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("                          ----------  ----------\r\n",NULL);
	sprintf(buffer,"                          %10lu  %10lu\r\n",total_comp,total_size);
	send_string(buffer,NULL);
	}



void show_arj(char *name,FILE *fd)
	{
	struct arj arj;
	char buffer[100];
	char buffer1[100];
	char *method;
	char *cptr;
	long total_comp = 0L;
	long total_size = 0L;
	long skip;
	long tcrc;
	int inchar;
	int tval;
	int stop_flag = 0;
	int key;
	int first = 1;
	int quit = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nListing of the contents of the ARJ file \"",NULL);
	send_string(name,NULL);
	send_string("\":\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("Filename        Method    Comp Size   Norm Size   Date         Time\r\n",NULL);
	send_string("-------------   --------  ----------  ----------  -----------  -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	while (!quit && fread(&arj,sizeof(struct arj),1,fd))
		{
		if ((unsigned int)arj.arj_id != 0xea60)
			break;
		skip = ftell(fd) - (long)sizeof(struct arj) + (long)(2 * sizeof(int)) + (long)arj.arj_headsz;

		if (!first)
			{
			if (arj.arj_flags & 0x8)	/* if EXTFILE_FLAG is set, skip over 4 bytes of extra data */
				fseek(fd,4L,SEEK_CUR);
			if (arj.arj_fspecpos)
				fseek(fd,(long)arj.arj_fspecpos,SEEK_CUR);		/* find the position with the filename portion */
			cptr = buffer1;
			do
				{
				inchar = fgetc(fd);
				if (inchar != EOF)
					*cptr++ = (char)inchar;
				}
			while (inchar != EOF && inchar);
			if (inchar == EOF)
				break;

			strlwr(buffer1);
			switch (arj.arj_method)
				{
				case 0:
					method = "Stored";
					break;
				case 1:
					method = "Type 1";
					break;
				case 2:
					method = "Type 2";
					break;
				case 3:
					method = "Type 3";
					break;
				case 4:
					method = "Type 4";
					break;
				default:
					method = "Unknown";
					break;
				}
			sprintf(buffer,"%-13.13s   %-8.8s  %10lu  %10lu  %s  %s\r\n",buffer1,method,arj.arj_csize,arj.arj_size,convert_zip_date(arj.arj_date),convert_zip_time(arj.arj_time));
			send_string(buffer,NULL);
			if (more_flag)
				stop_flag = 1;

			total_comp += arj.arj_csize;
			total_size += arj.arj_size;

			}
		else		/* first header just holds info about the archive itself */
			first = 0;
		fseek(fd,skip,SEEK_SET);	/* lets get ready for the next */
		if (!fread(&tcrc,sizeof(long),1,fd))	/* read header CRC */
			break;
		if (!fread(&tval,sizeof(int),1,fd))		/* read 1st extended header size */
			break;
		if (tval)
			{
			fseek(fd,(long)tval,SEEK_CUR);			/* skip over 1st extended header */
			if (!fread(&tcrc,sizeof(long),1,fd))	/* read 1st extended header CRC */
				break;
			}

		if (arj.arj_csize)			/* skip over compressed file */
			fseek(fd,arj.arj_csize,SEEK_CUR);

		if (stop_flag)
			quit = 1;
		else
			{
			update_clock();
			key = '\0';
			if (user_baud && !cd)
				longjmp(reset_bbs,1);
			if (user_baud && peek_input(cfg.cfg_port) != -1)
				key = read_input(cfg.cfg_port);
			else
				key = get_kb();
			switch (key)
				{
				case 'S':
				case 's':
					quit = 1;
					break;
				case 'P':
				case 'p':
					if (dopause())
						quit = 1;
					break;
				}
			}
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("                          ----------  ----------\r\n",NULL);
	sprintf(buffer,"                          %10lu  %10lu\r\n",total_comp,total_size);
	send_string(buffer,NULL);
	}



void show_zoo(char *name,FILE *fd)
	{
	char buffer[100];
	long total_comp = 0L;
	long total_size = 0L;
	char *method;
	struct zoo zoo;
	int stop_flag = 0;
	int key;
	int quit = 0;

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("\r\nListing of the contents of the ZOO file \"",NULL);
	send_string(name,NULL);
	send_string("\":\r\n\r\n",NULL);

	fseek(fd,(long)sizeof(struct zoo_header),SEEK_SET);	/* seek to first entry */

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("Filename        Method    Comp Size   Norm Size   Date         Time\r\n",NULL);
	send_string("-------------   --------  ----------  ----------  -----------  -----\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	while (!quit && fread(&zoo,sizeof(struct zoo),1,fd))
		{
		if (!zoo.zoo_deleted && zoo.zoo_name[0])
			{
			if (zoo.zoo_tag != 0xfdc4a7dc)		/* valid tag */
				break;
			switch (zoo.zoo_method)
				{
				case 0:
					method = "Stored";
					break;
				case 1:
					method = "Compress";
					break;
				default:
					method = "Unknown";
					break;
				}
			sprintf(buffer,"%-13.13s   %-8.8s  %10lu  %10lu  %s  %s\r\n",zoo.zoo_name,method,zoo.zoo_csize,zoo.zoo_size,convert_zip_date(zoo.zoo_date),convert_zip_time(zoo.zoo_time));
			send_string(buffer,NULL);
			if (more_flag)
				stop_flag = 1;

			total_comp += zoo.zoo_csize;
			total_size += zoo.zoo_size;
			}
		if (zoo.zoo_next)
			fseek(fd,zoo.zoo_next,SEEK_SET);
		else
			break;

		if (stop_flag)
			quit = 1;
		else
			{
			update_clock();
			key = '\0';
			if (user_baud && !cd)
				longjmp(reset_bbs,1);
			if (user_baud && peek_input(cfg.cfg_port) != -1)
				key = read_input(cfg.cfg_port);
			else
				key = get_kb();
			switch (key)
				{
				case 'S':
				case 's':
					quit = 1;
					break;
				case 'P':
				case 'p':
					if (dopause())
						quit = 1;
					break;
				}
			}
		}
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	send_string("                          ----------  ----------\r\n",NULL);
	sprintf(buffer,"                          %10lu  %10lu\r\n",total_comp,total_size);
	send_string(buffer,NULL);
	}



void show_contents(int area)
	{
	struct file *tfile;
	char buffer[100];
	char fname[13];
	char tbuf[2];
	char *cptr;
	long tlong;
	int tint;
	int found;
	FILE *fd;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nShow contents of what Archive (ENTER=Quit)? ",NULL);
		get_fname(fname,12,0,0);
		if (fname[0])
			{
			if (cptr = permit_file(tfile,fname))
				{
				strlwr(fname);
				strcpy(buffer,cptr);
				strcat(buffer,fname);
				found = 0;

				if (fd = openf(buffer,"rb"))
					{
					if (!fread(tbuf,sizeof(char),1,fd))
						break;
					if (tbuf[0] == (char)'\x1a')		/* got an ARC or a PAK */
						{
						fseek(fd,0L,SEEK_SET);
						show_pak(fname,fd);
						found = 1;
						}
					else
						{
						fseek(fd,0L,SEEK_SET);
						if (!fread(&tint,sizeof(int),1,fd))
							break;
						if (tint == (unsigned int)0xea60)		/* got an ARJ */
							{
							fseek(fd,0L,SEEK_SET);
							show_arj(fname,fd);
							found = 1;
							}
						else
							{
							fseek(fd,0L,SEEK_SET);
							if (!fread(&tlong,sizeof(long),1,fd))
								break;
							if (tlong == 0x4034b50L)		/* got a ZIP */
								{
								fseek(fd,0L,SEEK_SET);
								show_zip(fname,fd);
								found = 1;
								}
							else
								{
								fseek(fd,2L,SEEK_SET);
								if (!fread(tbuf,2 * sizeof(char),1,fd))
									break;
								if (tbuf[0] == (char)'-' && tbuf[1] == (char)'l')
									{
									fseek(fd,0L,SEEK_SET);
									show_lzh(fname,fd);
									found = 1;
									}
								else
									{
									fseek(fd,20L,SEEK_SET);
									if (!fread(&tlong,sizeof(long),1,fd))
										break;
									if ((unsigned long)tlong == (unsigned long)0xfdc4a7dc)		/* got a ZOO */
										{
										fseek(fd,0L,SEEK_SET);
										show_zoo(fname,fd);
										found = 1;
										}
									}
								}
							}
						}
					closef(fd);

					if (!found)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("File is not an ARC, ARJ, LZH, PAK, ZIP or ZOO file!\r\n",NULL);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("Error: Unable to find/open the requested file!\r\n",NULL);
					}
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Cannot find a file named \"",NULL);
				send_string(fname,NULL);
				send_string("\" in this area!\r\n",NULL);
				}
			}
		}
	while (fname[0]);
	}
