/* s_ul.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 13 November 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_ul.c_v  $
**                       $Date:   25 Oct 1992 14:08:00  $
**                       $Revision:   1.16  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include <time.h>
#ifdef PROTECTED
	#define INCL_DOSFILEMGR
	#include <os2.h>
#else
	#include <dos.h>
#endif
#include "simplex.h"




extern int xmit_handler(int key);
extern char *protocol_list;




void edit_description(int current,char *fname,long size,char *descrip)
	{
	char buffer[100];
	char buffer1[5];
	char *cptr;
	int count;
	int line;
	int ok = 0;

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);

		sprintf(buffer,"\r\n%u. Please enter description for \"",current);
		send_string(buffer,NULL);

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string(fname,NULL);

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string("\" (",NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);

		cptr = parse_long(size);
		send_string(cptr,NULL);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(CYAN | BRIGHT),NULL);
		send_string(" bytes).  You have\r\n",NULL);
		send_string("4 lines for text.  Word-wrap is automatic at the end of each line.\r\n",NULL);

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string(fname,NULL);
		send_string(":",NULL);
		for (count = strlen(fname); count < 12; count++)
			send_string(" ",NULL);

		descrip[0] = (char)'\0';
		buffer[0] = (char)'\0';
		for (line = 0; line < 4; line++)
			{
			cur_line = 0;
			sprintf(buffer1,"%u>",line + 1);
			send_string(buffer1,NULL);

			cptr = get_wrap_field(buffer,63,(line != 3) ? 1 : 0);
			if (!buffer[0])
				break;
			strcat(descrip,buffer);
			if (!isspace(buffer[strlen(buffer) - 1]))
				strcat(descrip," ");

			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			if (line < 3)
				{
				strcpy(buffer,cptr);			/* get wordwrap residue */
				for (count = 0; count < 13; count++)
					send_string(" ",NULL);
				}
			}

		if (!descrip[0])
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\n\aNotice: You MUST enter a description for this file!\r\n",NULL);
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nDo you wish to re-enter this description (y/N)? ",NULL);
			if (!get_yn_enter(0))
				ok = 1;
			}
		}
	while (!ok);
	}



void recv_file(int area)
	{
	char buffer[100];
	int key = 0;
	int ok = 0;
	int quit = 0;

	cur_line = 0;
	if (!get_filearea(area))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}

	if (!user_baud)
		recv_files(area,PROT_DIRECT);
	else
		{
		do
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			key = send_string("\r\n\r\n--- Upload Menu ---\r\n\r\n",xmit_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					key = send_string(protocol_list,xmit_handler);
				else
					key = send_string("[ 12345?X ]\r\n\r\n",xmit_handler);
				if (!key)
					key = send_string("What is your choice (ENTER=Exit)? ",xmit_handler);
				}
			do
				{
				if (!key)
					key = get_char();
				else
					send_string("\r\n\r\nUpload using ",NULL);
				switch (key)
					{
					case '1':
						recv_files(area,PROT_XMODEM);
						ok = 1;
						quit = 1;
						break;
					case '2':
						recv_files(area,PROT_XMODEM1K);
						ok = 1;
						quit = 1;
						break;
					case '3':
						recv_files(area,PROT_YMODEM);
						ok = 1;
						quit = 1;
						break;
					case '4':
						recv_files(area,PROT_YMODEMG);
						ok = 1;
						quit = 1;
						break;
					case '5':
						recv_files(area,PROT_ZMODEM);
						ok = 1;
						quit = 1;
						break;
					case '?':
						cur_line = 0;
						send_string("\r\n\r\n",NULL);
						send_ansifile(cfg.cfg_screenpath,"ULHELP",0);
						ok = 1;
						break;
					case 'X':
					case 'x':
					case '\r':
					case '\n':
						ok = 1;
						quit = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (!quit);
		}
	}



void recv_files(int area,int protocol)
	{
	struct file *tfile;
	struct fe tfe;
	char vcpath[150];
	char buffer[100];
	char buffer1[20];
	char fname[20];
	char *cptr;
	char *cptr1;
	char *protname;
	long uploaded = 0L;
	long tlong;
	int received;
	int count = 0;
	int abort = 0;
	int entered = 0;
	FILE *listfd;
	FILE *bbsfd;

	cur_line = 0;
	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}

	if (protocol != PROT_DIRECT)
		{
		if (tfile->file_descname[0])
			strcpy(buffer,tfile->file_descname);
		else 
			strcpy(buffer,tfile->file_pathname);
		if (buffer[0])
			{
			if (buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			}
		sprintf(buffer1,"upload#%u.bbs",cfg.cfg_port);
		strcat(buffer,buffer1);

		if (!(listfd = openf(buffer,"w+b")))
			{
			sprintf(buffer,"Unable to open %s in area %u!",buffer1,area);
			_error(E_ERROR,buffer);
			system_message(buffer);
			return;
			}
		}

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(menu_color),NULL);
	switch (protocol)
		{
		case PROT_DIRECT:
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			send_string("\r\n\r\nLocal \"Upload\" permits you to copy files FROM a different directory.\r\n\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("Copy from where (ENTER=Quit)? ",NULL);
			get_fname(buffer,48,0,1);
			if (buffer[0])
				{
				if (buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				send_string("\r\nMultiple files may be copied. Wildcards (? and *) may be used!\r\n",NULL);
				do
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("Copy which file (ENTER=End list)? ",NULL);
					get_fname(fname,12,1,0);
					if (fname[0])
						{
						if (expand_safe_fname(buffer,fname,PROT_DIRECT))
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("Unable to allocate structures....Copy cancelled!\r\n",NULL);
							cur_fnames = max_fnames = 0;
							get_enter();
							break;
							}
						entered = 1;
						}
					}
				while (fname[0]);
		
				if (cur_fnames)
					{
					copy_in(area,buffer,fnames,cur_fnames,1);
					for (count = 0; count < cur_fnames; count++)
						free(fnames[count]);
					free(fnames);
					fnames = NULL;
					cur_fnames = 0;
					max_fnames = 0;
					}
				else if (entered)
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("Invalid file name(s) provided....Copy cancelled!\r\n",NULL);
					get_enter();
					}
				}
			break;

		case PROT_XMODEM:
			protname = "Xmodem";
			send_string("\r\n\r\nUpload using ",NULL);
			send_string(protname,NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\n\r\nUpload which file (ENTER=Exit)? ",NULL);
			get_fname(fname,12,0,0);
			if (fname[0])
				{
				log_entry(L_UPLOAD_PROTOCOL,protname);
				x_recv(area,fname,listfd);
				}
			else
				abort = 1;
			break;

		case PROT_XMODEM1K:
			send_string("\r\n\r\nUpload using ",NULL);
			protname = "Xmodem-1K";
			send_string(protname,NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\n\r\nUpload which file (ENTER=Exit)? ",NULL);
			get_fname(fname,12,0,0);
			if (fname[0])
				{
				log_entry(L_UPLOAD_PROTOCOL,protname);
				x1k_recv(area,fname,listfd);
				}
			else 
				abort = 1;
			break;

		case PROT_YMODEM:
			send_string("\r\n\r\nUpload using ",NULL);
			protname = "Ymodem";
			send_string(protname,NULL);
			log_entry(L_UPLOAD_PROTOCOL,protname);
			y_recv(area,listfd);
			break;

		case PROT_YMODEMG:
			send_string("\r\n\r\nUpload using ",NULL);
			protname = "Ymodem-G";
			send_string(protname,NULL);
			log_entry(L_UPLOAD_PROTOCOL,protname);
			yg_recv(area,listfd);
			break;

		case PROT_ZMODEM:
			send_string("\r\n\r\nUpload using ",NULL);
			protname = "Zmodem";
			send_string(protname,NULL);
			log_entry(L_UPLOAD_PROTOCOL,protname);
			z_recv(area,listfd,NULL);
			break;
		}

	if (protocol != PROT_DIRECT)
		{
		if (!abort)
			{
			if (cfg.cfg_viruschk[0])
				{
				/* now to handle virus checkers */

				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\nPlease wait while the virus checker is called....\r\n",NULL);

				closef(listfd);

				if (tfile->file_descname[0])
					strcpy(buffer,tfile->file_descname);
				else 
					strcpy(buffer,tfile->file_pathname);
				if (buffer[0])
					{
					if (buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
					}
				sprintf(buffer1,"upload#%u.bbs",cfg.cfg_port);
				strcat(buffer,buffer1);

				sprintf(vcpath,"%s %s %u",cfg.cfg_viruschk,buffer,cfg.cfg_port + 1);
				run_program(vcpath);

				/* reopen file to get filenames */

				if (!(listfd = openf(buffer,"rb")))
					{
					sprintf(buffer,"Unable to open %s in area %u!",buffer1,area);
					_error(E_ERROR,buffer);
					system_message(buffer);
					return;
					}
				}

			/* finally to get the file descriptions */

			received = 0;
			fseek(listfd,0L,SEEK_SET);
			while (fgets(buffer,sizeof(buffer),listfd))
				{
				if (!strnicmp(buffer,"OK ",3))
					{
					++received;
					cptr = buffer + 4;
					cptr1 = buffer1;

					while (*cptr > ' ')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';

					while (*cptr && !isdigit(*cptr))
						++cptr;
					tlong = atol(cptr);
					uploaded += tlong;

					sprintf(buffer,"\"%s\" in area %u.",buffer1,area);
					log_entry(L_UPLOAD,buffer);
					}
				else	   		/* delete any bad file fragments we might have left! */
					{
					cptr = buffer + 4;
					cptr1 = buffer1;

					while (*cptr > ' ')
						*cptr1++ = *cptr++;
					*cptr1 = '\0';

					strcpy(buffer,tfile->file_pathname);
					if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
					strcat(buffer,buffer1);

					unlink(buffer);
					}
				}

			if (received)
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(BROWN | BRIGHT),NULL);
				sprintf(buffer,"\r\n%d file%s successfully received from you.\r\n",received,received != 1 ? "s were" : " was");
				send_string(buffer,NULL);
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				sprintf(buffer,"Please enter the description%s below as you are prompted:\r\n",received != 1 ? "s" : "");
				send_string(buffer,NULL);

				count = 1;
				fseek(listfd,0L,SEEK_SET);
				while (fgets(buffer,sizeof(buffer),listfd))
					{
					if (!strnicmp(buffer,"OK ",3))
						{
						cptr = buffer + 4;
						cptr1 = buffer1;

						while (*cptr > ' ')
							*cptr1++ = *cptr++;
						*cptr1 = '\0';

						tlong = file_size(tfile->file_pathname,buffer1);
						strupr(buffer1);

						memset(&tfe,0,sizeof(struct fe));
						strcpy(tfe.fe_name,buffer1);
						strcpy(tfe.fe_uploader,user.user_name);
						tfe.fe_location = tfile->file_number;
						tfe.fe_priv = tfile->file_priv;
						tfe.fe_flags = tfile->file_flags;
						tfe.fe_uldate = get_cdate();

						edit_description(count,buffer1,tlong,tfe.fe_descrip);
						++count;

						/* now we must open the filelist, get to the end and write the new record */
						if (tfile->file_descname[0])
							strcpy(buffer,tfile->file_descname);
						else 
							strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,"filelist.bbs");

						if (bbsfd = open_filelist_write(buffer))
							{
							fseek(bbsfd,0L,SEEK_END);
							fwrite(&tfe,sizeof(struct fe),1,bbsfd);
					  		closef(bbsfd);
							}
						else
							{
							sprintf(buffer,"\"%s\" in file area %u.",tfe.fe_name,tfile->file_number);
							log_entry(L_DESCRIP_ERROR,buffer);
							}
						}
					else			/* aborted upload */
						{
						cptr = buffer + 4;		/* snag filename */
						cptr1 = buffer1;

						while (*cptr > ' ')
							*cptr1++ = *cptr++;
						*cptr1 = '\0';

						strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,buffer1);

						unlink(buffer);			/* delete the carcass! */
						}
					}

				/* update user's records */
				userinfo.ui_upload += received;
				userinfo.ui_uploadbytes += uploaded;
				user.user_upload += received;
				user.user_uploadbytes += uploaded;
				fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
				fwrite(&user,1,sizeof(struct user),userfd);
				fflush(userfd);
				}
			}
		closef(listfd);
		}
	}



FILE *file_create(char *filename,char *path)
	{
	char pathname[256];
	char fname[32];
	char ext[32];
	char new_ext[5];		/* .xxx needs 5 chars */
	int number = 0;

	_splitpath(filename,pathname,pathname,fname,ext);
	fname[8] = '\0';
	ext[4] = '\0';
	_makepath(pathname,"",path,fname,ext);
	while (!access(pathname,0))
		{
		sprintf(new_ext,"%03u\x0",number++);
		_makepath(pathname,"",path,fname,new_ext);
		_makepath(filename,"","",fname,new_ext);
		}
	strlwr(filename);
	strlwr(path);

	return openf(pathname,"wb");
	}



void show_ulstats(long size,long actual,int protocol)
	{
	long eta;

	eta = xmit_time(protocol,size);
	show_dlstats(size,eta,actual);
	}



long disk_size(char *path)
	{
	unsigned int drive;
	long avail;
#ifdef PROTECTED
	unsigned long tlong;
	FSALLOCATE fa;
#else
	struct diskfree_t df;
#endif

	if (path[1] == ':')
		drive = (toupper(path[0]) - 'A') + 1;
	else
		{
#ifdef PROTECTED
		DosQCurDisk(&drive,&tlong);
#else
		_dos_getdrive(&drive);
#endif
		}

#ifdef PROTECTED
	DosQFSInfo(drive,1,(BYTE *)&fa,sizeof(FSALLOCATE));
	avail = (long)fa.cUnitAvail * (long)fa.cSectorUnit * (long)fa.cbSector;
#else
	_dos_getdiskfree(drive,&df);
	avail = (long)df.avail_clusters * (long)df.sectors_per_cluster * (long)df.bytes_per_sector;
#endif
	return avail;
	}



void set_filetime(int fh,long date)
	{
	struct tm *tmptr;
#ifdef PROTECTED
	FILESTATUS fs;
	FDATE fdate;
	FTIME ftime;
#else
	unsigned short fdate;
	unsigned short ftime;
#endif

	tmptr = localtime((time_t *)&date);
	if (tmptr->tm_year < 80)			/* date was before Jan 1, 1980 */
		{
		tmptr->tm_year = 80;
		tmptr->tm_mon = 0;
		tmptr->tm_mday = 1;
		tmptr->tm_hour = 0;
		tmptr->tm_min = 0;
		tmptr->tm_sec = 0;
		}

#ifdef PROTECTED
	fdate.day = tmptr->tm_mday;
	fdate.month = tmptr->tm_mon + 1;
	fdate.year = tmptr->tm_year - 80;

	ftime.twosecs = tmptr->tm_sec >> 1;
	ftime.minutes = tmptr->tm_min;
	ftime.hours = tmptr->tm_hour;

	DosQFileInfo(fh,1,(PBYTE)&fs,sizeof(FILESTATUS));

	/* Leave creation date as today */
	/* fs.fdateCreation = fdate; */
	/* fs.ftimeCreation = ftime; */
	fs.fdateLastAccess = fdate;
	fs.ftimeLastAccess = ftime;
	fs.fdateLastWrite = fdate;
	fs.ftimeLastWrite = ftime;
	DosSetFileInfo(fh,1,(PBYTE)&fs,sizeof(FILESTATUS));
#else
	fdate = ((tmptr->tm_year - 80) << 9) | ((tmptr->tm_mon + 1) << 5) | tmptr->tm_mday;
	ftime = (tmptr->tm_hour << 11) | (tmptr->tm_min << 5) | (tmptr->tm_sec >> 1);

	#ifdef __ZTC__
		dos_setftime(fh,fdate,ftime);		/* set date/time */
	#else
		_dos_setftime(fh,fdate,ftime);		/* set date/time */
	#endif
#endif
	}
