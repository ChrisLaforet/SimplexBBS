/* s_timer.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 1 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_timer.c_v  $
**                       $Date:   25 Oct 1992 14:07:54  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include "simplex.h"
#ifdef PROTECTED
	#define INCL_DOS
	#define INCL_VIO

	#include <os2.h>
	#include <process.h>
#else
	#ifdef __ZTC__
		#include <int.h>
	#endif
	#include <dos.h>
#endif


#define CHECK_TIME				5


volatile int cd = 0;
volatile int update_time = 1;
void (*timer_function)(void) = NULL;		/* if set, this is a function called by update clock */
int nolimit_flag = 0;						/* turns off check for online time */

extern jmp_buf reset_bbs;
extern int saver_mode;						/* defined for screen-saver mode */



#ifdef PROTECTED

#define TIMER_STACKSIZE			2048

TID timer_tid;
int timer_stack[TIMER_STACKSIZE / sizeof(int)];		/* type is int instead of char to make it word-aligned! */
HSEM timesem;
long update_sem = 0L;
volatile int timethread = 1;



void far timer_thread(void *dummy)
	{
	DosSetPrty(PRTYS_THREAD,PRTYC_TIMECRITICAL,PRTYD_MINIMUM,timer_tid);
	while (timethread)
		{
		DosSemRequest(&update_sem,SEM_INDEFINITE_WAIT);
		if (!local_flag && fossil_init)
			{
			if (check_cd(cfg.cfg_port))
				cd = 1;
			else
				cd = 0;
			}
		update_time = 1;
		DosSemClear(&update_sem);
		DosSleep(950L);
		}
	_endthread();
	}



int start_timer(void)
	{
	char buffer[50];
	PIDINFO pidinfo;

	DosGetPID(&pidinfo);
	sprintf(buffer,"\\sem\\simplex\\stmr%04x.xfr",pidinfo.pid);
	if (DosCreateSem(CSEM_PUBLIC,&timesem,buffer))
		return 0;

	timethread = 1;

	if ((timer_tid = _beginthread(timer_thread,timer_stack,TIMER_STACKSIZE,NULL)) == -1)
		return 0;
	return 1;
	}



int stop_timer(void)
	{
	DosCloseSem(timesem);
	timethread = 0;
	return 1;
	}



void sleep(int msecs)
	{
	HTIMER timehandle;

	DosSemSet(timesem);
	DosTimerAsync((long)msecs,timesem,&timehandle);  
	DosSemWait(timesem,SEM_INDEFINITE_WAIT);
	DosTimerStop(timehandle);
	}



void update_clock(void)
	{
	DATETIME dt;
	char buffer[20];
	long tlong;
	static unsigned char attrib;
	static int check_timer = 0;
	int save_color;

	if (!DosSemRequest(&update_sem,SEM_IMMEDIATE_RETURN))
		{
		if (update_time)
			{
			update_time = 0;
			DosGetDateTime(&dt);

			if (!saver_mode)
				{
				attrib = (unsigned char)status_color[2];
				sprintf(buffer,"%02u:%02u",dt.hours,dt.minutes);
				VioWrtCharStrAtt(buffer,strlen(buffer),bottom_line + 3,0x4a,&attrib,0);
				}

			if (user_online)
				{
				if (check_timer >= CHECK_TIME)
					{
					check_timer = 0;
					user_time = remaining_time();

					if (!update_priv_flag)
						{
						attrib = (unsigned char)status_color[2];
						tlong = user_time / 60L;
						if (tlong < 0L)
							tlong = 0L;
						sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : " "));
						VioWrtCharStrAtt(buffer,strlen(buffer),bottom_line + 2,0x34,&attrib,0);
						}

					if (!nolimit_flag)
						{
						if (user_time < 120L && !user_warning)
							{
							++user_warning;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								{
								save_color = cur_color;
								send_string(new_color(BROWN | BRIGHT),NULL);
								}
							if (cur_line > 2)
								cur_line -= 2;
							else if (cur_line)
								--cur_line;
							send_string("Notice: You have less than 2 minutes left online!!\r\n\r\n",NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(save_color),NULL);
							}
						else if (!user_time)
							{
							user_time = -1L;		/* signals that user's time expired! -- stops endless recursion */
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(WHITE | BRIGHT | BLINK),NULL);
							send_string("\r\n\r\n\aSorry! Your time is up.  Please call back later!\r\n",NULL);
							hangup();
							longjmp(reset_bbs,2);
							}
						}
					}
				else
					++check_timer;
				}

			if (timer_function)
				(*timer_function)();		/* call special function */
			}
		DosSemClear(&update_sem);
		}
	}


#else

static volatile long ticks = 0L;
static int msec_tick = 55;
static int ticks_sec = 18;
static long counts_sec = 0L;
static int timer_int = 0x8;
#ifndef __ZTC__
static void (interrupt far *old_timer)(void);
#endif



static void get_count(void)		/* find how many free counts in a second */
	{
	register long val;
	long count;

	val = ticks;	
	while (ticks == val)	/* skip to make sure we are synchronized */
		;
	val = ticks;
	for (count = 0L; ticks == val; count++)
		;
	++count;
	counts_sec = count * (long)ticks_sec;
	}



void sleep(int msecs)
	{
	register long total;
	long count;

	total = counts_sec * (long)msecs / 1000L;
#ifdef __WATCOMC__
	total <<= 1L;
#endif
	for (count = 0L; count < total; count++)
		;
	}



#ifdef __ZTC__			/* ZTC interrupt routines */

static int far timer(struct INT_DATA *dummy)
	{
	int_on();
	++ticks;
	if (!(ticks % ticks_sec))		/* check CD every second or so */
		{
		++update_time;
		}
	return 0;		/* return of 1 chains to previous handler */
	}



int start_timer(void)
	{
#if 0
	union REGS registers;

	registers.h.ah = 0x7;
	int86(0x14,&registers,&registers);
	msec_tick = (int)registers.x.dx;
	timer_int = (int)registers.h.al;
	ticks_sec = 1000 / msec_tick; 				/* ticks per sec */
#endif

	if (int_intercept(timer_int,timer,1024) == -1)
		return 0;

	get_count();
	return 1;
	}



int stop_timer(void)
	{
	int_restore(timer_int);
	return 1;
	}


#else				/* MSC interrupt routines */

static void interrupt far timer(void)
	{
	_enable();
	++ticks;
	if (!(ticks % ticks_sec))		/* check CD every second or so */
		++update_time;
	_chain_intr(old_timer);
	}



int start_timer(void)
	{
#if 0
	union REGS registers;		

	registers.h.ah = 0x7;			/* can't do this with a dead fossil!  Or no fossil at all! */
	int86(0x14,&registers,&registers);
	msec_tick = (int)registers.x.dx;
	timer_int = (int)registers.h.al;
	ticks_sec = 1000 / msec_tick; 				/* ticks per sec */
#endif

	old_timer = _dos_getvect(timer_int);
	_dos_setvect(timer_int,timer);
	get_count();
	return 1;
	}



int stop_timer(void)
	{
	_dos_setvect(timer_int,old_timer);
	return 1;
	}


#endif


void update_clock(void)
	{
#ifdef __ZTC__
	struct dos_time_t time;
#else
	struct dostime_t time;
#endif
	char buffer[10];
	char *cptr;
	long tlong;
	static int check_timer = 0;
	int cursor;
	int new_cursor;
	int save_color;

	if (update_time)
		{
#ifdef __ZTC__
		int_off();
#else
		_disable();
#endif

		update_time = 0;

#ifdef __ZTC__
		int_on();
#else
		_enable();
#endif

		if (!local_flag && fossil_init)
			cd = check_cd(cfg.cfg_port);	/* check carrier detect */

#ifdef __ZTC__
		dos_gettime(&time);
#else
		_dos_gettime(&time);
#endif
		if (!saver_mode)
			{
			cursor = bios_getcurpos();
			new_cursor = ((bottom_line + 3) << 8) + 0x4a;
			sprintf(buffer,"%02u:%02u",time.hour,time.minute);
			cptr = buffer;
			while (*cptr)
				{
				bios_setcurpos(new_cursor++);
				bios_outchar(*cptr++,status_color[2],1);
				}
			bios_setcurpos(cursor);
			}
		if (user_online)
			{
			if (check_timer >= CHECK_TIME)
				{
				check_timer = 0;
				user_time = remaining_time();

				if (!update_priv_flag)
					{
					cursor = bios_getcurpos();
					tlong = user_time / 60L;
					if (tlong < 0L)
						tlong = 0L;
					sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : " "));
					new_cursor = ((bottom_line + 2) << 8) + 0x34;
					cptr = buffer;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(cursor);
					}

				if (!nolimit_flag)
					{
					if (user_time < 120L && !user_warning)
						{
						++user_warning;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							{
							save_color = cur_color;
							send_string(new_color(BROWN | BRIGHT),NULL);
							}
						if (cur_line > 2)
							cur_line -= 2;
						else if (cur_line)
							--cur_line;
						send_string("Notice: You have less than 2 minutes left online!!\r\n\r\n",NULL);
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(save_color),NULL);
						}
					else if (!user_time)
						{
						user_time = -1L;		/* signals that user's time expired! -- stops endless recursion */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(WHITE | BRIGHT | BLINK),NULL);
						send_string("\r\n\r\n\aSorry! Your time is up.  Please call back later!\r\n",NULL);
						hangup();
						longjmp(reset_bbs,2);
						}
					}
				}
			else
				++check_timer;
			}

		if (timer_function)
			(*timer_function)();		/* call special function */
		}
	}
#endif
