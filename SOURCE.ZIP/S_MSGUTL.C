/* s_msgutl.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 10 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_msgutl.c_v  $
**                       $Date:   25 Oct 1992 14:07:30  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include <io.h>
#include "simplex.h"




struct mdata _far mdata;
struct msg **msgs = NULL;
int cur_msgs = 0;
int max_msgs = 0;
static int min_msgarea = 10000;
static int max_msgarea = 0;
struct mc *msgcount = NULL;
int max_msgcount = 0;
int cur_msgcount = 0;
struct lr **lastread = NULL;
int cur_lastread = 0;



void deinit_msgs(void)
	{
	int count;

	if (cur_msgs)
		{
		for (count = 0; count < cur_msgs; count++)
			free(msgs[count]);
		free(msgs);
		msgs = NULL;
		cur_msgs = 0;
		max_msgs = 0;
		}

	if (cur_msgcount)
		{
		free(msgcount);
		msgcount = NULL;
		max_msgcount = 0;
		cur_msgcount = 0;
		}

	if (cur_lastread)
		{
		for (count = 0; count < cur_lastread; count++)
			free(lastread[count]);
		free(lastread);
		lastread = NULL;
		cur_lastread = 0;
		}
	}



int get_netmail_area(int zone,int net,int node)
	{
	int count;
	int found = 0;
	int def = 0;
	int tval;
	int szone;
	int snet;
	int snode;

	for (count = 0; count < cur_msgs; count++)
		{
		if (msgs[count]->msg_flags & MSG_NET)
			{
			tval = msgs[count]->msg_source;
			if (tval < 0 || tval > 5)
				tval = 0;
			if (tval)
				{
				if (cfg.cfg_akanet[tval - 1])
					{
					szone = cfg.cfg_akazone[tval - 1];
					snet = cfg.cfg_akanet[tval - 1];
					snode = cfg.cfg_akanode[tval - 1];
					}
				else
					tval = 0;
				}
			if (!tval)
				{
				def = msgs[count]->msg_number;		/* get default address */
				szone = cfg.cfg_zone;
				snet = cfg.cfg_net;
				snode = cfg.cfg_node;
				}

			if (snet == net && snode == node && ((szone && zone && szone == zone) || !zone || !szone))
				{
				found = msgs[count]->msg_number;
				break;
				}
			}
		}
	if (found)
		return found;
	else if (def)
		return def;
	return 0;
	}



int check_netmail_area(void)  	/* returns TRUE (area number) if there is a NETMAIL area */
	{
	int count;
	int found = 0;

	for (count = 0; count < cur_msgs; count++)
		{
		if (msgs[count]->msg_flags & MSG_NET)
			{
			found = msgs[count]->msg_number;
			break;
			}
		}
	return found;
	}



int msg_comp(struct msg **arg1,struct msg **arg2)
	{
	return (*arg1)->msg_number - (*arg2)->msg_number;
	}



int load_msgareas(char *fname)
	{
	struct msg tmsg;
	int count;
	FILE *msgfd;

	if (cur_msgs)		/* in case we are re-initializing */
		{
		for (count = 0; count < cur_msgs; count++)
			free(msgs[count]);
		free(msgs);
		msgs = NULL;
		cur_msgs = 0;
		max_msgs = 0;
		}

	if (msgfd = fopen(fname,"rb"))
		{
		min_msgarea = 10000;
		max_msgarea = 0;
		while (fread(&tmsg,sizeof(struct msg),1,msgfd))
			{
			if (cur_msgs >= max_msgs)
				{
				if (!(msgs = realloc(msgs,(max_msgs += 10) * sizeof(struct msg *))))
					_error(E_FATAL,"Error: Out of memory to allocate structures!");
				}
			if ((tmsg.msg_flags & MSG_ECHO) && !tmsg.msg_origin[0])
				strcpy(tmsg.msg_origin,cfg.cfg_origin);

			if (!(msgs[cur_msgs] = calloc(1,sizeof(struct msg))))
				_error(E_FATAL,"Error: Out of memory to allocate structures!");
			memcpy(msgs[cur_msgs],&tmsg,sizeof(struct msg));
			if (tmsg.msg_number < min_msgarea)
				min_msgarea = tmsg.msg_number;
			if (tmsg.msg_number > max_msgarea)
				max_msgarea = tmsg.msg_number;
			++cur_msgs;
			}
		if (cur_msgs)
			qsort(msgs,cur_msgs,sizeof(struct msg *),msg_comp);
		fclose(msgfd);
		}
	return cur_msgs;
	}



int get_minmsgarea(void)
	{
	return min_msgarea;
	}



int get_maxmsgarea(void)
	{
	return max_msgarea;
	}



struct msg *get_msgarea(int number)
	{
	int count;

	for (count = 0; count < cur_msgs; count++)
		if (number == msgs[count]->msg_number)
			return msgs[count];
	return NULL;
	}



void build_msgdata(void)
	{
	struct msgh tmsgh;
	int total = 0;
	int deleted = 0;
	int count;
	int kount;
	int found;

	for (count = 0; count < cur_msgcount; count++)
		msgcount[count].mc_msgs = 0;
	fseek(msghfd,0L,SEEK_SET);
	while (fread(&tmsgh,sizeof(struct msgh),1,msghfd))
		{
		++total;
		if (tmsgh.msgh_flags & MSGH_DELETED)
			++deleted;
		else
			{
			found = 0;
			for (count = 0; count < cur_msgcount; count++)
				{
				if (msgcount[count].mc_area == tmsgh.msgh_area)
					{
					++msgcount[count].mc_msgs;
					found = 1;
					break;
					}
				}
			if (!found)
				{
				for (count = 0; count < cur_msgs; count++)		/* create entries for boards only if it is valid */
					{
					if (msgs[count]->msg_number == tmsgh.msgh_area)
						{
						found = 1;
						break;
						}
					}

				if (found)
					{
					if (cur_msgcount >= max_msgcount)
						{
						if (!(msgcount = realloc(msgcount,(max_msgcount += 50) * sizeof(struct mc))))
							_error(E_FATAL,"Out of memory to load message area information!");
						}
					msgcount[cur_msgcount].mc_area = tmsgh.msgh_area;
					msgcount[cur_msgcount].mc_msgs = 1;
					++cur_msgcount;
					}
				}
			}
		}

	for (count = 0; count < cur_msgs; count++)		/* create entries for boards w/o messages */
		{
		for (kount = 0, found = 0; kount < cur_msgcount; kount++)
			{
			if (msgs[count]->msg_number == msgcount[kount].mc_area)
				{
				found = 1;
				break;
				}
			}
		if (!found)
			{
			if (cur_msgcount >= max_msgcount)
				{
				if (!(msgcount = realloc(msgcount,(max_msgcount += 50) * sizeof(struct mc))))
					_error(E_FATAL,"Out of memory to load message area information!");
				}
			msgcount[cur_msgcount].mc_area = msgs[count]->msg_number;
			msgcount[cur_msgcount].mc_msgs = 0;
			++cur_msgcount;
			}
		}

	mdata.mdata_msgs = total;
	mdata.mdata_del = deleted;

	fseek(msgdfd,0L,SEEK_SET);
	chsize(fileno(msgdfd),0L);
	fwrite(&mdata,sizeof(struct mdata),1,msgdfd);		/* write out data */
	for (count = 0; count < cur_msgcount; count++)
		fwrite(&msgcount[count],sizeof(struct mc),1,msgdfd);
	fflush(msgdfd);
	}



void load_msgdata(void)
	{
	struct mc tmc;
	long len;
	int found;
	int count;
	int kount;

	if (cur_msgs)
		{
		if (cur_msgcount)		/* in case we are re-initializing */
			{
			free(msgcount);
			msgcount = NULL;
			cur_msgcount = 0;
			max_msgcount = 0;
			}

		len = filelength(fileno(msghfd));
		fseek(msgdfd,0L,SEEK_SET);
		if (!fread(&mdata,sizeof(struct mdata),1,msgdfd))
			{
			mdata.mdata_msgs = 0;
			mdata.mdata_del = 0;
			}
		if (mdata.mdata_msgs != (int)(len / (long)sizeof(struct msgh)))
			{
			_error(E_WARNING,"Rebuilding message data file!");
			build_msgdata();
			}
		else
			{
			while (fread(&tmc,sizeof(struct mc),1,msgdfd))
				{
				if (cur_msgcount >= max_msgcount)
					{
					if (!(msgcount = realloc(msgcount,(max_msgcount += 50) * sizeof(struct mc))))
						_error(E_FATAL,"Out of memory to load message area information!");
					}
				memcpy(&msgcount[cur_msgcount],&tmc,sizeof(struct mc));
				++cur_msgcount;
				}
			}

		for (count = 0; count < cur_msgs; count++)		/* create entries for boards w/o messages */
			{
			for (kount = 0, found = 0; kount < cur_msgcount; kount++)
				{
				if (msgs[count]->msg_number == msgcount[kount].mc_area)
					{
					found = 1;
					break;
					}
				}
			if (!found)
				{
				if (cur_msgcount >= max_msgcount)
					{
					if (!(msgcount = realloc(msgcount,(max_msgcount += 50) * sizeof(struct mc))))
						_error(E_FATAL,"Out of memory to load message area information!");
					}
				msgcount[cur_msgcount].mc_area = msgs[count]->msg_number;
				msgcount[cur_msgcount].mc_msgs = 0;

				fseek(msgdfd,(long)sizeof(struct mdata) + (long)cur_msgcount * (long)sizeof(struct mc),SEEK_SET);
				fwrite(&msgcount[cur_msgcount],sizeof(struct mc),1,msgdfd);

				++cur_msgcount;
				}
			}
		}
	}



void build_msglink(void)
	{
	struct msgh tmsgh;
	struct mlink tmlink;
	char *cptr;

	fseek(msglfd,0L,SEEK_SET);
	chsize(fileno(msglfd),0L);
	fseek(msghfd,0L,SEEK_SET);
	while (fread(&tmsgh,sizeof(struct msgh),1,msghfd))
		{
		tmlink.mlink_area = tmsgh.msgh_area;
		tmlink.mlink_number = tmsgh.msgh_number;
		tmlink.mlink_flags = tmsgh.msgh_flags;
		tmlink.mlink_cksum = 0;
		cptr = tmsgh.msgh_to;
		while (*cptr)
			{
			tmlink.mlink_cksum += toupper(*cptr);
			++cptr;
			}
		fwrite(&tmlink,sizeof(struct mlink),1,msglfd);		/* write out data */
		}
	fflush(msglfd);
	}



void check_msglink(void)
	{
	long len;

	if (cur_msgs)
		{
		len = filelength(fileno(msglfd));
		if (mdata.mdata_msgs != (int)(len / (long)sizeof(struct mlink)))
			{
			_error(E_WARNING,"Rebuilding message link file -- length discrepancy!");
			build_msglink();
			}
		}
	}




/* MSGREAD.BBS consists of the following:
**
** INT		# of areas
** INT		area numbers[# of areas]
** INT		last systemwide message read[# of areas][# of users]
*/

void build_msglast(void)
	{
	int count;
	int kount;

	_error(E_WARNING,"Building lastread pointer file!");
	if (cur_lastread)		/* in case we are re-initializing */
		{
		for (count = 0; count < cur_lastread; count++)
			free(lastread[count]);
		free(lastread);
		lastread = NULL;
		cur_lastread = 0;
		}

	if (!(lastread = malloc(cur_msgs * sizeof(struct lr *))))
		_error(E_FATAL,"Out of memory to allocate lastread structures.");
	cur_lastread = cur_msgs;

	for (count = 0; count < cur_lastread; count++)
		{
		if (!(lastread[count] = malloc(sizeof(struct lr))))
			_error(E_FATAL,"Out of memory to allocate lastread structures.");

		lastread[count]->lr_area = msgs[count]->msg_number;
		lastread[count]->lr_prev = 0;
		lastread[count]->lr_new = 0;
		}

	/* now let us prepare our file */
	fseek(msgrfd,0L,SEEK_SET);
	chsize(fileno(msgrfd),0L);
	fwrite(&cur_lastread,sizeof(int),1,msgrfd);

	for (count = 0; count < cur_lastread; count++)
		fwrite(&lastread[count]->lr_area,sizeof(int),1,msgrfd);

	for (count = 0; count < total_users; count++)
		{
		for (kount = 0; kount < cur_lastread; kount++)
			fwrite(&lastread[kount]->lr_new,sizeof(int),1,msgrfd);
		}

	fflush(msgrfd);
	}



void add_msglast(void)			/* adds a new lastread pointer group for a new user */
	{
	int count;

	if (cur_lastread)
		{
		fseek(msgrfd,0L,SEEK_END);
		for (count = 0; count < cur_lastread; count++)
			{
			lastread[count]->lr_prev = 0;
			lastread[count]->lr_new = 0;

			fwrite(&lastread[count]->lr_new,sizeof(int),1,msgrfd);
			}
		fflush(msgrfd);
		}
	}



void rebuild_msglast(int total_areas)
	{
	char buffer[100];
	char buffer1[100];
	long tlen;
	long len;
	int quit;
	int *tlist;
	int count;
	int kount;
	int found;
	int tval;
	FILE *fd;

	_error(E_WARNING,"Rebuilding lastread pointer file!");

	/* set up our working structures */
	if (!(lastread = malloc(cur_msgs * sizeof(struct lr *))))
		_error(E_FATAL,"Out of memory to allocate lastread structures.");
	cur_lastread = cur_msgs;

	for (count = 0; count < cur_lastread; count++)
		{
		if (!(lastread[count] = malloc(sizeof(struct lr))))
			_error(E_FATAL,"Out of memory to allocate lastread structures.");

		lastread[count]->lr_area = msgs[count]->msg_number;
		lastread[count]->lr_prev = 0;
		lastread[count]->lr_new = 0;
		}

	/* now to get a working list of matching areas and match them with new ones */
	fseek(msgrfd,(long)sizeof(int),SEEK_SET);
	if (!(tlist = malloc(total_areas * sizeof(int))))
		_error(E_FATAL,"Out of memory to allocate lastread structures.");
	for (count = 0; count < total_areas; count++)
		{
		fread(&tlist[count],sizeof(int),1,msgrfd);
		for (kount = 0, found = 0; kount < cur_lastread; kount++)
			{
			if (tlist[count] == lastread[kount]->lr_area)
				{
				tlist[count] = kount;		/* put the actual offset of matchin area in there */
				found = 1;
				break;
				}
			}
		if (!found)
			tlist[count] = -1;
		}

	/* ok, it is now time to play shuffle with the files! */
	fclose(msgrfd);

	sprintf(buffer,"%smsgread.tmp",bbspath);
	sprintf(buffer1,"%smsgread.bbs",bbspath);
	unlink(buffer);
	rename(buffer1,buffer);		/* the BBS becomes a TMP file */

	if (!(fd = fopen(buffer,"rb")))		/* the old file gets opened */
		_error(E_FATAL,"Unable to open temporary lastread pointer file.");
	if (!(msgrfd = fopen(buffer1,"w+b")))
		_error(E_FATAL,"Unable to create and open new lastread pointer file!");

	/* files are now open, lets xlate everything */
	fseek(fd,((long)total_areas * (long)sizeof(int)) + (long)sizeof(int),SEEK_SET);		/* get to lastread pointers */

	/* prepare new file */
	fwrite(&cur_lastread,sizeof(int),1,msgrfd);
	for (count = 0; count < cur_lastread; count++)
		fwrite(&lastread[count]->lr_area,sizeof(int),1,msgrfd);

	quit = 0;
	while (!quit)
		{
		for (count = 0; count < cur_lastread; count++)
			lastread[count]->lr_prev = 0;

		for (count = 0; count < total_areas; count++)
			{
			if (!fread(&tval,sizeof(int),1,fd))
				{
				quit = 1;
				break;
				}

			if (tlist[count] != -1)
				lastread[tlist[count]]->lr_prev = tval;
			}

		if (!quit)
			{
			for (count = 0; count < cur_lastread; count++)
				fwrite(&lastread[count]->lr_prev,sizeof(int),1,msgrfd);
			}
		}

	fclose(fd);
	unlink(buffer);		/* kill the temp file */

	free(tlist);

	fflush(msgrfd);

	for (count = 0; count < cur_lastread; count++)		/* clean up lastread pointers */
		{
		lastread[count]->lr_prev = 0;
		lastread[count]->lr_new = 0;
		}

	fflush(msgrfd);

	/* lastly to make sure that we add on to the file for any new users */
	tlen = filelength(fileno(msgrfd));
	len = (long)(total_users + 1) *
		((long)cur_lastread * (long)sizeof(int)) +
		(long)sizeof(int);
	if (tlen != len)
		{
		tlen -= ((long)cur_lastread * (long)sizeof(int)) + (long)sizeof(int);		/* find an integral number of users */
		if (tlen < 0L)
			tval = 0;
		else 
			tval = (int)(tlen / ((long)cur_lastread * (long)sizeof(int)));

		if (tval < total_users)
			{
			tlen = (long)(tval + 1) * (long)cur_lastread * (long)sizeof(int);
			tlen += (long)sizeof(int);

			fseek(msgrfd,tlen,SEEK_SET);

			while (tlen < len)
				{
				for (count = 0; count < cur_lastread; count++)		/* write out 0's for each new user */
					fwrite(&lastread[count]->lr_new,sizeof(int),1,msgrfd);
				tlen += ((long)cur_lastread * (long)sizeof(int));
				}
			}
		else if (tval > total_users)
			{
			fseek(msgrfd,0L,SEEK_SET);
			chsize(fileno(msgrfd),len);
			}
		fflush(msgrfd);
		}
	}



void check_msglast(void)		/* checks to see if we need to rebuild lastread pointers */
	{
	long tlen;
	long len;
	int tot_areas;
	int rebuild = 0;
	int found;
	int tarea;
	int tval;
	int count;
	int kount;

	if (cur_msgs)
		{
		if (cur_lastread)		/* in case we are re-initializing */
			{
			for (count = 0; count < cur_lastread; count++)
				free(lastread[count]);
			free(lastread);
			lastread = NULL;
			cur_lastread = 0;
			}

		fseek(msgrfd,0L,SEEK_SET);
		if (!fread(&tot_areas,sizeof(int),1,msgrfd))		/* nothing there! */
			build_msglast();
		else
			{
			if (tot_areas != cur_msgs)
				{
				if (!tot_areas || tot_areas > 9999)
					build_msglast();
				else 
					rebuild_msglast(tot_areas);
				}
			else
				{
				/* read once to check areas are the same */
				for (count = 0; count < tot_areas; count++)
					{
					if (!fread(&tarea,sizeof(int),1,msgrfd))
						{
						rebuild = 1;
						break;
						}

					found = 0;
					for (kount = 0; kount < cur_msgs; kount++)
						{
						if (tarea == msgs[kount]->msg_number)
							{
							found = 1;
							break;
							}
						}
					if (!found)
						{
						rebuild = 1;
						break;
						}
					}

				if (rebuild)
					rebuild_msglast(tot_areas);
				else
					{
					/* read again to read in the areas */
					fseek(msgrfd,(long)sizeof(int),SEEK_SET);

					if (!(lastread = malloc(cur_msgs * sizeof(struct lr *))))
						_error(E_FATAL,"Out of memory to allocate lastread structures.");
					cur_lastread = cur_msgs;

					for (count = 0; count < cur_lastread; count++)
						{
						if (!(lastread[count] = malloc(sizeof(struct lr))))
							_error(E_FATAL,"Out of memory to allocate lastread structures.");

						fread(&lastread[count]->lr_area,sizeof(int),1,msgrfd);
						lastread[count]->lr_prev = 0;
						lastread[count]->lr_new = 0;
						}

					/* lastly to make sure that we add on to the file for any new users */
					tlen = filelength(fileno(msgrfd));
					len = (long)(total_users + 1) *
						((long)cur_lastread * (long)sizeof(int)) +
						(long)sizeof(int);
					if (tlen != len)
						{
						tlen -= ((long)cur_lastread * (long)sizeof(int)) + (long)sizeof(int);		/* find an integral number of users */
						if (tlen < 0L)
							tval = 0;
						else 
							tval = (int)(tlen / ((long)cur_lastread * (long)sizeof(int)));

						if (tval < total_users)
							{
							tlen = (long)(tval + 1) * (long)cur_lastread * (long)sizeof(int);
							tlen += (long)sizeof(int);

							fseek(msgrfd,tlen,SEEK_SET);

							while (tlen < len)
								{
								for (count = 0; count < cur_lastread; count++)		/* write out 0's for each new user */
									fwrite(&lastread[count]->lr_new,sizeof(int),1,msgrfd);
								tlen += ((long)cur_lastread * (long)sizeof(int));
								}
							}
						else if (tval > total_users)
							{
							fseek(msgrfd,0L,SEEK_SET);
							chsize(fileno(msgrfd),len);
							}
						}
					fflush(msgrfd);
					}
				}
			}
		}
	}



void load_msglast(void)		/* loads a user's lastread pointers */
	{
	int count;

	if (cur_lastread)
		{
		fseek(msgrfd,(long)(user_number + 1) *
			((long)cur_lastread * (long)sizeof(int))
			+ (long)sizeof(int),SEEK_SET);
		for (count = 0; count < cur_lastread; count++)
			{
			if (!fread(&lastread[count]->lr_prev,sizeof(int),1,msgrfd))
				lastread[count]->lr_prev = 0;
			lastread[count]->lr_new = 0;
			}
		}
	}



void update_msglast(void)	/* updates a user's lastread pointers */
	{
	int count;

	if (cur_msgs)
		{
		fseek(msgrfd,(long)(user_number + 1) *
			((long)cur_lastread * (long)sizeof(int))
			+ (long)sizeof(int),SEEK_SET);
		for (count = 0; count < cur_lastread; count++)
			{
			if (lastread[count]->lr_prev >= lastread[count]->lr_new)
				fwrite(&lastread[count]->lr_prev,sizeof(int),1,msgrfd);
			else 
				fwrite(&lastread[count]->lr_new,sizeof(int),1,msgrfd);
			}
		fflush(msgrfd);
		}
	}
