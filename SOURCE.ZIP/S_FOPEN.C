/* s_fopen.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 3 March 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_fopen.c_v  $
**                       $Date:   25 Oct 1992 14:07:04  $
**                       $Revision:   1.8  $
**
*/


#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <share.h>
#include <io.h>
#include "simplex.h"



/* these routines map to fopen() and fclose() but allow pending open
** files to be closed if carrier is dropped! */


#define MAX_FILES				15


static FILE _far *files[MAX_FILES];


void initf(void)
	{
	int count;

	for (count = 0; count < MAX_FILES; count++)
		files[count] = NULL;
	}



FILE *openf(char *name,char *flags)
	{
	int count;
	int which = MAX_FILES;
	int nflags = 0;
	int sflags = 0;
	int fh;
	FILE *file = NULL;

	for (count = 0; count < MAX_FILES; count++)
		{
		if (files[count] == NULL)
			{
			which = count;
			break;
			}
		}
	if (which < MAX_FILES)
		{
		if (!strcmp(flags,"w+b") || !strcmp(flags,"wb+"))
			nflags = O_CREAT | O_TRUNC | O_RDWR | O_BINARY;
		else if (!strcmp(flags,"r+b") || !strcmp(flags,"rb+"))
			nflags = O_RDWR | O_BINARY;
		else if (!strcmp(flags,"a+b") || !strcmp(flags,"ab+"))
			nflags = O_CREAT | O_APPEND | O_RDWR | O_BINARY;
		else if (!strcmp(flags,"wb"))
			nflags = O_CREAT | O_TRUNC | O_WRONLY | O_BINARY;
		else if (!strcmp(flags,"rb"))
			nflags = O_RDONLY | O_BINARY;
		else if (!strcmp(flags,"ab"))
			nflags = O_CREAT | O_APPEND | O_WRONLY | O_BINARY;
		else if (!strcmp(flags,"w+"))
			nflags = O_CREAT | O_TRUNC | O_RDWR | O_TEXT;
		else if (!strcmp(flags,"w"))
			nflags = O_CREAT | O_TRUNC | O_WRONLY | O_TEXT;
		else if (!strcmp(flags,"r+"))
			nflags = O_RDWR | O_TEXT;
		else if (!strcmp(flags,"r"))
			nflags = O_RDONLY | O_TEXT;
		else if (!strcmp(flags,"a+"))
			nflags = O_CREAT | O_APPEND | O_RDWR | O_TEXT;
		else if (!strcmp(flags,"a"))
			nflags = O_CREAT | O_APPEND | O_WRONLY | O_TEXT;

		if (share_installed)
			{
			if (flags[0] == 'w' || flags[0] == 'a')		/* sharing permissions */
				sflags = SH_DENYWR;
			else 
				sflags = SH_DENYNO;

			fh = sopen(name,nflags,sflags,S_IWRITE | S_IREAD);
			}
		else
			fh = open(name,nflags,S_IWRITE | S_IREAD);
		if (fh == -1)
			file = NULL;
		else
			file = fdopen(fh,flags);
		if (file)
			files[which] = file;
		}
	return file;
	}



int closef(FILE *file)
	{
	int count;

	for (count = 0; count < MAX_FILES; count++)
		{
		if (files[count] == file)
			{
			files[count] = NULL;
			break;
			}
		}
	return fclose(file);
	}



void closeallf(void)
	{
	int count;
	
	for (count = 0; count < MAX_FILES; count++)
		{
		if (files[count] != NULL)
			{
			fclose(files[count]);
			files[count] = NULL;
			}
		}
	}
