/* s_login.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 2 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_login.c_v  $
**                       $Date:   25 Oct 1992 14:06:42  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <time.h>
#include <io.h>
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
#include <ctype.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#else
	#include <dos.h>
	#ifdef __ZTC__
		#include <int.h>
	#endif
#endif
#include "simplex.h"



int user_online = 0;			/* flag that indicates that user is passworded in! */
int user_number;
int user_warning;				/* flag that user has been warned at 2 minute limit! */
struct user user;
long login_time;				/* absolute time when user logged in */
volatile long user_time;		/* time user has online this session */
extern jmp_buf reset_bbs;
TIME_T user_lasttime;
DATE_T user_lastdate;

char **nongrata = NULL;			/* list of personas-non-grata */
int cur_nongrata = 0;
int max_nongrata = 0;

char **badalias = NULL;			/* list of invalid aliases or root names in aliases */
int cur_badalias = 0;
int max_badalias = 0;

char _far user_firstname[41];
char _far user_lastname[41];
char _far tuser_name[41];
char _far last_user[41];		/* last user's name */
struct ui _far userinfo;		/* user-information to be written to the USERINFO.BBS file */
int update_priv_flag = 0;
int help_flag = 0;				/* flag set when in help */
int which_status = 0;
int logoff_notify = 0;			/* notify sysop when user logs off */



void show_help(void)
	{
	char *cptr;
	int cursor;
	int new_cursor;

	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 1) << 8;

	cptr = "ALT> C=Cht K=Kb F=Flags J=Shell P=Priv T=H/Up X=Ext  CTRL> PgUp=Time PgDn=Time";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}
	bios_setcurpos(cursor);
	help_flag = 1;
	}



void show_user(void)
	{
	struct tm *tmptr;
	char buffer[81];
	char *cptr;
	long tlong;
	int cursor;
	int new_cursor;
	int val = 1;
	int count;

	help_flag = 0;
	which_status = 3;
	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 1) << 8;
	bios_clrblk(new_cursor,new_cursor + 0x14f,status_color[0]);		/* clear top 2 lines of status */

	if (cfg.cfg_askaddress)
		sprintf(buffer,"%s OF %s, %s",user.user_name,user.user_city,user.user_state);
	else 
		sprintf(buffer,"%s OF %s",user.user_name,user.user_city);
	buffer[62] = (char)'\0';
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}

	new_cursor = ((bottom_line + 1) << 8) | 0x41;
	bios_setcurpos(new_cursor);
	cptr = "First=";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	new_cursor = ((bottom_line + 1) << 8) | 0x47;
	sprintf(buffer,"%02u/%02u/%02u",(user.user_firstdate >> 5) & 0xf,user.user_firstdate & 0x1f,((user.user_firstdate >> 9) + 80) % 100);
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = (bottom_line + 2) << 8;
	bios_setcurpos(new_cursor);
	cptr = "Priv=     Flags=                  Calls=       Left=      UL=        DL=";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	new_cursor = (bottom_line + 3) << 8;
	bios_setcurpos(new_cursor);
	bios_outchar(' ',status_color[0],74);
	cptr = "Baud=      Home=                Data=                Login=";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x5;
	sprintf(buffer,"%u",(int)user.user_priv);
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x10;
	for (count = 0; count < 16; count++)
		{
		if (user.user_uflags & val)
			buffer[count] = (char)('A' + count);
		else 
			buffer[count] = (char)('a' + count);
		val <<= 1;
		}
	buffer[16] = (char)'\0';
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x28;
	sprintf(buffer,"%u",user.user_calls);
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x34;
	tlong = user_time / 60L;
	if (tlong < 0L)
		tlong = 0L;
	sprintf(buffer,"%lu%s",tlong,(char *)(logoff_notify ? "*" : " "));
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x3d;
	tlong = user.user_uploadbytes;
	if (tlong >= 1024L)
		{
		tlong /= 1024L;
		if (tlong < 1024L)
			sprintf(buffer,"%luKB",tlong);
		else
			{
			tlong /= 1024L;
			sprintf(buffer,"%luMB",tlong);
			}
		}
	else
		sprintf(buffer,"%luB",tlong);

	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 2) << 8) | 0x48;
	tlong = user.user_dnloadbytes;
	if (tlong >= 1024L)
		{
		tlong /= 1024L;
		if (tlong < 1024L)
			sprintf(buffer,"%luKB",tlong);
		else
			{
			tlong /= 1024L;
			sprintf(buffer,"%luMB",tlong);
			}
		}
	else
		sprintf(buffer,"%luB",tlong);
	bios_setcurpos(new_cursor);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 3) << 8) | 0x5;
	if (user_baud)
		{
		sprintf(buffer,"%u",user_baud);
		cptr = buffer;
		}
	else
		cptr = "Local";
	bios_setcurpos(new_cursor);
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 3) << 8) | 0x10;
	cptr = user.user_home;
	bios_setcurpos(new_cursor);
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 3) << 8) | 0x25;
	cptr = user.user_data;
	bios_setcurpos(new_cursor);
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	new_cursor = ((bottom_line + 3) << 8) | 0x3b;
	tmptr = localtime((time_t *)&login_time);
	sprintf(buffer,"%02u:%02u",tmptr->tm_hour,tmptr->tm_min);
	cptr = buffer;
	bios_setcurpos(new_cursor);
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}

	if (yells)
		{
		new_cursor = ((bottom_line + 3) << 8) | 0x42;
		if (yells > 0)
			cptr = "*CHAT*";
		else
			cptr = "*YELL*";

		while (*cptr)
			{
			bios_setcurpos(new_cursor++);
			bios_outchar(*cptr++,status_color[3],1);
			}
		}
	bios_setcurpos(cursor);
	}



void clear_user(void)
	{
	char *cptr;
	int cursor;
	int new_cursor;

	user_online = 0;
	which_status = 0;
	chat_flag = 0;
	help_flag = 0;
	free_mark();
	yells = 0;
	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 1) << 8;
	bios_clrblk(new_cursor,new_cursor + 0x14f,status_color[0]);		/* clear top 2 lines of status */
	bios_setcurpos((bottom_line + 3) << 8);
	bios_outchar(' ',status_color[0],74);

	cptr = "Waiting for Call =-> Press Alt-L for local";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}
	user.user_flags = 0;		/* makes sure that more is off */
	bios_setcurpos(cursor);
	}



void login_user(void)
	{
	char buffer[15];
	char *cptr;
	int cursor;
	int new_cursor;

	user_online = 0;
	which_status = 1;
	help_flag = 0;
	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 1) << 8;
	bios_clrblk(new_cursor,new_cursor + 0x14f,status_color[0]);		/* clear top 2 lines of status */
	bios_setcurpos((bottom_line + 3) << 8);
	bios_outchar(' ',status_color[0],74);

	cptr = "Waiting for user login =-> Press Alt-T to terminate connection";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	new_cursor = (bottom_line + 3) << 8;
	cptr = "Baud=";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	if (user_baud)
		{
		sprintf(buffer,"%u",user_baud);
		cptr = buffer;
		}
	else
		cptr = "Local";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}
	bios_setcurpos(cursor);
	user.user_flags = 0;		/* makes sure that more is off */
	}



void show_username(void)
	{
	char buffer[21];
	int cursor;
	int new_cursor;
	char *cptr;

	user_online = 0;
	which_status = 2;
	help_flag = 0;
	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 1) << 8;
	bios_clrblk(new_cursor,new_cursor | 0x14f,status_color[0]);		/* clear top 2 lines of status */
	bios_setcurpos((bottom_line + 2) << 8);
	bios_outchar(' ',status_color[0],74);

	cptr = tuser_name;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}

	new_cursor = (bottom_line + 3) << 8;
	cptr = "Baud=";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[0],1);
		}

	if (user_baud)
		{
		sprintf(buffer,"%u",user_baud);
		cptr = buffer;
		}
	else
		cptr = "Local";
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[1],1);
		}
	bios_setcurpos(cursor);
	user.user_flags = 0;		/* makes sure that more is off */
	}



void update_flags(void)
	{
	char buffer[17];
	unsigned int tflags;
	int val = 1;
	int count;
	int quit = 0;
	int display;
	int cursor;
	int new_cursor;
	char *cptr;
	int key;

	cursor = bios_getcurpos();
	tflags = user.user_uflags;
	for (count = 0; count < 16; count++)
		{
		if (tflags & val)
			buffer[count] = (char)('A' + count);
		else 
			buffer[count] = (char)('a' + count);
		val <<= 1;
		}
	buffer[16] = '\0';

	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		if (peek_kb() != -1)
			{
			key = read_kb();
			switch (key)
				{
				case 0x1b:		/* esc */
					quit = 1;
					tflags = user.user_flags;
					break;
				case '\r':
				case '\n':
					quit = 1;
					break;
				case 'A':
				case 'a':
					if (tflags & UF_A)
						{
						tflags &= ~UF_A;
						buffer[0] = 'a';
						}
					else
						{
						tflags |= UF_A;
						buffer[0] = 'A';
						}
					display = 1;
					break;
				case 'B':
				case 'b':
					if (tflags & UF_B)
						{
						tflags &= ~UF_B;
						buffer[1] = 'b';
						}
					else
						{
						tflags |= UF_B;
						buffer[1] = 'B';
						}
					display = 1;
					break;
				case 'C':
				case 'c':
					if (tflags & UF_C)
						{
						tflags &= ~UF_C;
						buffer[2] = 'c';
						}
					else
						{
						tflags |= UF_C;
						buffer[2] = 'C';
						}
					display = 1;
					break;
				case 'D':
				case 'd':
					if (tflags & UF_D)
						{
						tflags &= ~UF_D;
						buffer[3] = 'd';
						}
					else
						{
						tflags |= UF_D;
						buffer[3] = 'D';
						}
					display = 1;
					break;
				case 'E':
				case 'e':
					if (tflags & UF_E)
						{
						tflags &= ~UF_E;
						buffer[4] = 'e';
						}
					else
						{
						tflags |= UF_E;
						buffer[4] = 'E';
						}
					display = 1;
					break;
				case 'F':
				case 'f':
					if (tflags & UF_F)
						{
						tflags &= ~UF_F;
						buffer[5] = 'f';
						}
					else
						{
						tflags |= UF_F;
						buffer[5] = 'F';
						}
					display = 1;
					break;
				case 'G':
				case 'g':
					if (tflags & UF_G)
						{
						tflags &= ~UF_G;
						buffer[6] = 'g';
						}
					else
						{
						tflags |= UF_G;
						buffer[6] = 'G';
						}
					display = 1;
					break;
				case 'H':
				case 'h':
					if (tflags & UF_H)
						{
						tflags &= ~UF_H;
						buffer[7] = 'h';
						}
					else
						{
						tflags |= UF_H;
						buffer[7] = 'H';
						}
					display = 1;
					break;
				case 'I':
				case 'i':
					if (tflags & UF_I)
						{
						tflags &= ~UF_I;
						buffer[8] = 'i';
						}
					else
						{
						tflags |= UF_I;
						buffer[8] = 'I';
						}
					display = 1;
					break;
				case 'J':
				case 'j':
					if (tflags & UF_J)
						{
						tflags &= ~UF_J;
						buffer[9] = 'j';
						}
					else
						{
						tflags |= UF_J;
						buffer[9] = 'J';
						}
					display = 1;
					break;
				case 'K':
				case 'k':
					if (tflags & UF_K)
						{
						tflags &= ~UF_K;
						buffer[10] = 'k';
						}
					else
						{
						tflags |= UF_K;
						buffer[10] = 'K';
						}
					display = 1;
					break;
				case 'L':
				case 'l':
					if (tflags & UF_L)
						{
						tflags &= ~UF_L;
						buffer[11] = 'l';
						}
					else
						{
						tflags |= UF_L;
						buffer[11] = 'L';
						}
					display = 1;
					break;
				case 'M':
				case 'm':
					if (tflags & UF_M)
						{
						tflags &= ~UF_M;
						buffer[12] = 'm';
						}
					else
						{
						tflags |= UF_M;
						buffer[12] = 'M';
						}
					display = 1;
					break;
				case 'N':
				case 'n':
					if (tflags & UF_N)
						{
						tflags &= ~UF_N;
						buffer[13] = 'n';
						}
					else
						{
						tflags |= UF_N;
						buffer[13] = 'N';
						}
					display = 1;
					break;
				case 'O':
				case 'o':
					if (tflags & UF_O)
						{
						tflags &= ~UF_O;
						buffer[14] = 'o';
						}
					else
						{
						tflags |= UF_O;
						buffer[14] = 'O';
						}
					display = 1;
					break;
				case 'P':
				case 'p':
					if (tflags & UF_P)
						{
						tflags &= ~UF_P;
						buffer[15] = 'p';
						}
					else
						{
						tflags |= UF_P;
						buffer[15] = 'P';
						}
					display = 1;
					break;
				}
			if (display)
				{
				cptr = buffer;
				new_cursor = ((bottom_line + 2) << 8) | 0x10;
				while (*cptr)
					{
					bios_setcurpos(new_cursor++);
					bios_outchar(*cptr++,status_color[1],1);
					}
				display = 0;
				}
			}
		else
			sleep(50);
		update_clock();
		}
	while (!quit);

	if (tflags != (unsigned int)user.user_uflags)
		{
		user.user_uflags = (int)tflags;
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		}
	show_user();
	bios_setcurpos(cursor);
	}



void update_priv(void)
	{
	char buffer[40];
	int cursor;
	int new_cursor;
	char *cptr;
	int new_priv;
	int key;
	int quit = 0;

	update_priv_flag = 1;
	cursor = bios_getcurpos();
	new_cursor = (bottom_line + 2) << 8;
	bios_setcurpos(new_cursor);
	bios_outchar(' ',status_color[0],46);
	sprintf(buffer,"Current Priv: %-3u   New Priv? ",(int)user.user_priv);
	cptr = buffer;
	while (*cptr)
		{
		bios_setcurpos(new_cursor++);
		bios_outchar(*cptr++,status_color[2],1);
		}
	bios_setcurpos(new_cursor++);
	
	cptr = buffer;
	*cptr = '\0';
	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		if (peek_kb() != -1)
			{
			key = read_kb();
			switch (key)
				{
				case 0x1b:		/* esc */
					new_priv = (int)user.user_priv;
					quit = 1;
					break;
				case '\b':
				case 0x7f:
					if ((cptr - buffer) > 0)
						{
						--new_cursor;
						bios_setcurpos(new_cursor);
						bios_outchar(' ',status_color[2],1);
						bios_setcurpos(new_cursor);
						--cptr;
						*cptr = '\0';
						}
					break;
				case '\r':
				case '\n':
					quit = 1;
					if (buffer[0])
						new_priv = atoi(buffer);
					else 
						new_priv = (int)user.user_priv;		/* no action w/o number */
					break;
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					*(cptr + 1) = '\0';
					*cptr = (char)key;
					new_priv = atoi(buffer);
					if (new_priv > 0xff)
						*cptr = '\0';
					else
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					break;
				}
			}
		else
			sleep(50);
		update_clock();
		}
	while (!quit);
	if (new_priv && new_priv != (int)user.user_priv)	/* priv 0 is invalid */
		{
		user.user_priv = (char)(new_priv > 0xff ? 0xff : new_priv);		/* change priv level */
		if (logon_times[(int)user.user_priv] <= user.user_timeused)		/* recalc users time */
			user_time = 1L;
		else 
			user_time = (long)(logon_times[(int)user.user_priv] - user.user_timeused) * 60L;		/* time in seconds */
		user_warning = 0;			/* set 2 minute warning flag off! */

		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,1,sizeof(struct user),userfd);
		fflush(userfd);
		}
	bios_setcurpos(cursor);
	show_user();
	update_priv_flag = 0;
	}



int is_namechar(int character)
	{
	if (isalpha(character))
		return 1;
	if (character == '-' || character == '\'')
		return 1;
	return 0;
	}



int get_login(void)
	{
	struct user tuser;
	struct uf tuf;
	char buffer[256];
	char first[41];
	char last[41];
	char *cptr;
	char *cptr1;
	int name_times = 0;
	int pwd_times = 0;
	int reenter;
	int retry;
	int found = 0;
	int quit = 0;
	int ttime;
	int date;
	int count;
	int ok;
	FILE *fd;

	if (!drop_flag)
		{
		do
			{
			ok = 0;
			do
				{
				reenter = 0;
				found = 0;
				do
					{
					cur_line = 0;		/* defeats more */
					quit = 0;
					send_string("\r\nEnter your FIRST and LAST name: ",NULL);
					get_field(buffer,40,1);
					if (buffer[0])
						{
						cptr = buffer;
						while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
							++cptr;

						cptr1 = first;
						while (*cptr && is_namechar(*cptr))
							*cptr1++ = *cptr++;
						*cptr1 = '\0';

						while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
							++cptr;

						cptr1 = last;
						while (*cptr && is_namechar(*cptr))
							*cptr1++ = *cptr++;
						*cptr1 = '\0';
						if (first[0] && last[0])
							{
							quit = 1;
							strcpy(user_firstname,first);
							strcpy(user_lastname,last);
							}
						else
							send_string("\r\n\aYou must enter a FIRST and LAST name!\r\n",NULL);
						}
					}
				while (!quit);

				if (user_baud)
					sprintf(buffer,"%s %s at %d baud",first,last,user_baud);
				else 
					sprintf(buffer,"%s %s from the Local console",first,last);

				log_entry(L_LOGIN,buffer);

				fseek(userfd,0L,SEEK_SET);
				sprintf(buffer,"%s %s",first,last);
				user_number = 0;
				while (!found && fread(&tuser,sizeof(struct user),1,userfd))
					{
					if (!stricmp(tuser.user_name,buffer))
						{
						found = 1;
						if (tuser.user_flags & USER_DELETED)
							{
							log_entry(L_INVALID_NAME,buffer);
							cur_line = 0;		/* defeats more */
							send_string("\r\n\r\n\aThe user name \"",NULL);
							send_string(buffer,NULL);
							send_string("\" already exists on this system.\r\n",NULL);
							send_string("   The user record has been marked as Deleted.  Please use another version\r\n",NULL);
							send_string("   of your name and attempt to log-in again.\r\n",NULL);
							reenter = 1;
							}
						else
							{
							memcpy(&user,&tuser,sizeof(struct user));
							reenter = 0;
							}
						break;
						}
					++user_number;
					}
				if (!found)
					{
					cur_line = 0;		/* defeats more */
					send_file(cfg.cfg_screenpath,"notfound.asc",1,NULL);
					send_string("\r\n\aYour name was not found in the user's list!\r\n",NULL);
					send_string("You entered \"",NULL);
					send_string(buffer,NULL);
					send_string("\". Is this correct (Y/n)? ",NULL);
					reenter = get_yn_enter(1) ? 0 : 1;
					if (reenter)
						log_entry(L_CHANGENAME,NULL);
					}
				}
			while (reenter);

			/* check to see if login is a persona-non-grata */
			sprintf(buffer,"%s %s",user_firstname,user_lastname);
			for (count = 0; count < cur_nongrata; count++)
				{
				if (!stricmp(buffer,nongrata[count]))
					{
					log_entry(L_NONGRATA,buffer);
					send_string("\r\n\aSorry, but for one reason or another, this is not valid on this system.\r\n",NULL);
					send_file(cfg.cfg_screenpath,"nongrata.asc",1,NULL);
					send_string("\r\n",NULL);
					if (hangup_flag)
						hangup();
					return 1;
					}
				}

			if (!found)					/* get new user's information */
				{
				if (cfg.cfg_flags & CFG_PRIVATEBBS)
					{
					/* buffer already has the user's name */
					log_entry(L_INVALID_NAME,buffer);
					send_string("\r\n\aSorry, but this BBS is configured only for preregistered users.\r\n",NULL);
					send_file(cfg.cfg_screenpath,"private.asc",1,NULL);
					send_string("\r\n",NULL);
					if (hangup_flag)
						hangup();
					return 1;
					}

				strcpy(tuser_name,buffer);
				show_username();
				log_entry(L_NEWUSER,buffer);

				memset(&tuser,0,sizeof(struct user));
				strcpy(tuser.user_name,buffer);
				tuser.user_screenlen = 24;
				quit = 0;
				cur_line = 0;		/* defeats more */
				send_string("\r\n",NULL);
				send_file(cfg.cfg_screenpath,"ansi.asc",1,p_handler);
				send_string("\r\nPlease answer the following questions.  The Yes/No answers are hotkeyed\r\n",NULL);
				send_string("   which means that you do not need to press [Enter] after pressing Y\r\n",NULL);
				send_string("   or N.  Pressing [Enter] will activate the choice which is capitalized.\r\n",NULL);
				send_string("   If you see (Y/n), pressing [Enter] will select \"Yes\".  Otherwise, if you\r\n",NULL);
				send_string("   see (y/N), pressing [Enter] will select \"No\".\r\n",NULL);

				purge_input(cfg.cfg_port);			/* start questions with a clean buffer */

				send_string("\r\nDoes your program support ANSI screen codes (y/N)? ",NULL);
				if (get_yn_enter(0))
					{
					tuser.user_flags |= USER_ANSI;
					user.user_flags |= USER_ANSI;		/* temporarily force ANSI on */
					send_string("Do you want screen clearing codes sent (Y/n)? ",NULL);
					if (get_yn_enter(1))
						tuser.user_flags |= USER_CLS;
					send_string("\r\nThe ANSI full-screen editor is a flexible message editor which\r\n",NULL);
					send_string("   allows features like reply quoting.  It is not recommended for\r\n",NULL);
					send_string("   beginners, however.  You can always change over to using it later\r\n",NULL);
					send_string("   in the configuration changing section of this BBS.\r\n",NULL);

					send_string("\r\nDo you want to use the ANSI full-screen editor (y/N)? ",NULL);
					if (get_yn_enter(0))
						tuser.user_flags |= USER_EDITOR;
					}
				send_string("How many lines fit on your screen [10-66] (ENTER=24)? ",NULL);
				tuser.user_screenlen = (char)get_number(9,66);
				if (tuser.user_screenlen == 9)
					tuser.user_screenlen = 24;
				send_string("Do you want to pause after each screen (Y/n)? ",NULL);
				if (get_yn_enter(1))
					tuser.user_flags |= USER_MORE;

				if (cfg.cfg_askaddress)
					{
					send_string("\r\nThe Sysop requires that you provide your complete mailing address.\r\n",NULL);
					send_string("    Please enter the information correctly:\r\n\r\n",NULL);
					do
						{
						send_string("\r\n",NULL);
						send_string("Street address (line 1 of 2): ",NULL);
						get_field(buffer,30,1);
						strcpy(tuser.user_address1,buffer);
						send_string("Street address (line 2 of 2): ",NULL);
						get_field(buffer,30,1);
						strcpy(tuser.user_address2,buffer);
						send_string("                        City: ",NULL);
						get_field(buffer,30,1);
						strcpy(tuser.user_city,buffer);
						send_string("        State and/or Country: ",NULL);
						get_field(buffer,15,1);
						strcpy(tuser.user_state,buffer);
						send_string("                     Zipcode: ",NULL);
						get_field(buffer,15,1);
						strcpy(tuser.user_zip,buffer);

						send_string("\r\n\r\nHere is your mailing information as you entered it:\r\n",NULL);
						send_string("     ",NULL);
						send_string(tuser.user_name,NULL);
						send_string("\r\n     ",NULL);
						send_string(tuser.user_address1,NULL);
						send_string("\r\n     ",NULL);
						send_string(tuser.user_address2,NULL);
						send_string("\r\n     ",NULL);
						send_string(tuser.user_city,NULL);
						send_string(", ",NULL);
						send_string(tuser.user_state,NULL);
						send_string("  ",NULL);
						send_string(tuser.user_zip,NULL);

						send_string("\r\n\r\n",NULL);
						send_string("Is this correct (Y/n)? ",NULL);
						}
					while (!get_yn_enter(1));
					}
				else
					{
					do
						{
						quit = 0;
						do
							{
							cur_line = 0;		/* defeats more */
							send_string("Where are you located [City, State OR Country]? ",NULL);
							get_field(buffer,30,1);
							if (buffer[0])
								{
								cptr = buffer;
								while (*cptr && !isalnum(*cptr))		/* trim leading spaces */
									++cptr;
								cptr1 = tuser.user_city;
								while (*cptr)
									*cptr1++ = *cptr++;
								*cptr1 = '\0';

								if (tuser.user_city[0])
									quit = 1;
								}
							}
						while (!quit);
						send_string("Is this correct (Y/n)? ",NULL);
						}
					while (!get_yn_enter(1));
					}
				send_string("\r\n",NULL);
				if (cfg.cfg_askhome)
					{
					do
						{
						cur_line = 0;		/* defeats more */
						send_string("What is your HOME number? ",NULL);
						get_phone(tuser.user_home,1);
						send_string("Is this correct (Y/n)? ",NULL);
						}
					while (!get_yn_enter(1));
					send_string("\r\n",NULL);
					}
				if (cfg.cfg_askdata)
					{
					do
						{
						cur_line = 0;		/* defeats more */
						send_string("What is your DATA (or WORK) number? ",NULL);
						get_phone(tuser.user_data,1);
						send_string("Is this correct (Y/n)? ",NULL);
						}
					while (!get_yn_enter(1));
					send_string("\r\n",NULL);
					}
				send_ansifile(cfg.cfg_screenpath,"password",1);
				send_string("\r\n",NULL);
				do
					{
					cur_line = 0;		/* defeats more */
					quit = 0;
					send_string("Please enter your PASSWORD: ",NULL);
					get_password(tuser.user_password,15);
					if (strlen(tuser.user_password) >= 4)
						{
						send_string("Please re-enter your PASSWORD: ",NULL);
						get_password(buffer,15);
						if (!stricmp(buffer,tuser.user_password))
							quit = 1;
						else
							send_string("\r\n\aYou mis-typed your password...please enter it again!\r\n",NULL);
						}
					else
						send_string("\r\n\aA password must be 4-15 characters long!\r\n",NULL);
					}
				while (!quit);


				tuser.user_priv = cfg.cfg_newpriv;
				tuser.user_uflags = cfg.cfg_newflags;
				tuser.user_credit = cfg.cfg_newcredit;
				tuser.user_firstdate = get_cdate();
				tuser.user_lastdate = get_cdate();
				tuser.user_lasttime = get_ctime();

				fseek(userfd,0L,SEEK_END);
				fwrite(&tuser,sizeof(struct user),1,userfd);
				memcpy(&user,&tuser,sizeof(struct user));

				send_ansifile(cfg.cfg_screenpath,"newuser",0);
				++total_users;
				add_msglast();
				ok = 1;
				}
			else				/* get regular user's password */
				{
				send_string("\r\nYour name was found in the userlist.  If you need another chance to enter a\r\n",NULL);
				send_string("   different name, press ENTER three times on the Password prompt.\r\n\r\n",NULL);
				for (retry = 0; retry < cfg.cfg_pwdtries; retry++)
					{
					pwd_times = 0;
					do
						{
						cur_line = 0;		/* defeats more */
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\rPassword: ",NULL);
						get_password(buffer,15);
						if (!buffer[0])
							{
							++pwd_times;
							if (pwd_times >= 3)
								{
								if (name_times >= 3)
									{
									send_string("\r\n\r\n\aSorry, but it appears that you don't even know your own name!\r\n",NULL);
									send_string("   After 3 times, I have to log you off.  Goodbye!\r\n",NULL);
									if (hangup_flag)
										hangup();
									return 1;
									}
								else
									{
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										{
										user.user_flags = 0;
										send_string("\x1b[0m\b\b\b\b    ",NULL);
										}
									send_string("\r\n\r\n\aSince you have trouble deciding on the password, here is another\r\n",NULL);
									send_string("   opportunity to re-enter your correct name.\r\n",NULL);
									log_entry(L_CHANGENAME,NULL);
									++name_times;
									}
								break;
								}
							}
						}
					while (!buffer[0]);
					if (buffer[0] && !stricmp(buffer,user.user_password))
						{
						ok = 1;
						break;
						}
					else if (!buffer[0])	/* i.e. getting another attempt to enter name */
						break;
					log_entry(L_INVALID_PWD,buffer);
					}
				if (retry >= cfg.cfg_pwdtries)
					{
					send_string("\r\n\r\n\aSorry, but it appears that you don't know your own password!\r\n",NULL);
					send_string("   Logging you off.  Goodbye!\r\n",NULL);
					if (hangup_flag)
						hangup();
					longjmp(reset_bbs,1);
					}
				}
			}
		while (!ok);
		}
	else		/* drop in with simplex.usr file */
		{
		sprintf(buffer,"%ssimplex.usr",bbspath); 		/* now, open and get file area */
		if (fd = fopen(buffer,"rb"))
			{
			if (fread(&tuf,1,sizeof(struct uf),fd) != sizeof(struct uf))
				{
				log_entry(L_DROPFILE_ERROR,"Incomplete record in \"simplex.usr\".");
				fclose(fd);
				return 1;
				}
			fclose(fd);

			strncpy(buffer,tuf.uf_name,41);
			buffer[40] = (char)'\0';
			cptr = buffer;
			while (*cptr && !isalnum(*cptr))		/* trim leading spaces */
				++cptr;

			cptr1 = first;
			while (*cptr && isalnum(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			while (*cptr && !isalnum(*cptr))		/* trim leading spaces */
				++cptr;

			cptr1 = last;
			while (*cptr && isalnum(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (first[0] && last[0])
				{
				strcpy(user_firstname,first);
				strcpy(user_lastname,last);
				}
			else
				{
				log_entry(L_DROPFILE_ERROR,"Missing FIRST and LAST name in \"simplex.usr\".");
				return 1;
				}

			if (user_baud)
				sprintf(buffer,"%s %s at %d baud",first,last,user_baud);
			else 
				sprintf(buffer,"%s %s from the Local console",first,last);
			log_entry(L_DROPFILE_LOGIN,buffer);
			sprintf(buffer,"%s %s",first,last);

			found = 0;
			user_number = 0;
			while (!found && fread(&tuser,sizeof(struct user),1,userfd))
				{
				if (!stricmp(tuser.user_name,buffer))
					{
					if (tuser.user_flags & USER_DELETED)
						{
						log_entry(L_INVALID_NAME,buffer);
						log_entry(L_DROPFILE_ERROR,"User in \"simplex.usr\" has been deleted.");
						return 1;
						}
					else
						{
						memcpy(&user,&tuser,sizeof(struct user));
						found = 1;
						break;
						}
					}
				++user_number;
				}

			fseek(userfd,0L,SEEK_SET);

			if (!found)
				{
				if (cfg.cfg_flags & CFG_PRIVATEBBS)
					{
					log_entry(L_INVALID_NAME,buffer);
					log_entry(L_DROPFILE_ERROR,"User in \"simplex.usr\" is not in userlist.");
					send_string("\r\nSorry, but this BBS is configured only for preregistered users.\r\n",NULL);
					send_file(cfg.cfg_screenpath,"private.asc",1,NULL);
					send_string("\r\n",NULL);
					if (hangup_flag)
						hangup();
					return 1;
					}

				strcpy(tuser_name,buffer);
				show_username();
				log_entry(L_NEWUSER,buffer);

				memset(&tuser,0,sizeof(struct user));
				strcpy(tuser.user_name,buffer);
				strcpy(tuser.user_password,tuf.uf_password);
				strcpy(tuser.user_city,tuf.uf_city);
				strcpy(tuser.user_home,tuf.uf_home);
				strcpy(tuser.user_data,tuf.uf_data);

				if (tuf.uf_screenlen < 10 || tuf.uf_screenlen > 66)
					tuser.user_screenlen = 24;
				else 
					tuser.user_screenlen = tuf.uf_screenlen;

				tuser.user_flags = tuf.uf_flags;

				tuser.user_priv = cfg.cfg_newpriv;
				tuser.user_uflags = cfg.cfg_newflags;
				tuser.user_credit = cfg.cfg_newcredit;

				tuser.user_firstdate = get_cdate();
				tuser.user_lastdate = get_cdate();
				tuser.user_lasttime = get_ctime();

				fseek(userfd,0L,SEEK_END);
				fwrite(&tuser,sizeof(struct user),1,userfd);
				memcpy(&user,&tuser,sizeof(struct user));

				send_ansifile(cfg.cfg_screenpath,"newuser",0);
				++total_users;
				add_msglast();
				}
			}
		else
			{
			log_entry(L_DROPFILE_ERROR,"Unable to find/open \"simplex.usr\".");
			return 1;
			}
		}

	/* update last-use statistics */
	user_lasttime = user.user_lasttime;
	user_lastdate = user.user_lastdate;
	++user.user_calls;
	date = get_cdate();
	if (user.user_flags & USER_GUEST || user.user_lastdate != date)
		{
		user.user_timeused = 0;			/* reset time used to 0 */
		user.user_lastdate = date;
		}
	user.user_lasttime = get_ctime();
	fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
	fwrite(&user,sizeof(struct user),1,userfd);
	fflush(userfd);

	if (!time_flag)
		{
		ttime = logon_times[(int)user.user_priv];
		ttime -= user.user_timeused;
		}
	else
		{
		ttime = time_flag;
		if (ttime > logon_times[(int)user.user_priv])
			ttime = logon_times[(int)user.user_priv];
		ttime -= user.user_timeused;
		}
	if (ttime < 2)
		ttime = 2;
	login_time = projected_time(0L);
	set_logofftime((long)ttime * 60L);
	user_time = remaining_time();

	/* prepare bitmapped message-areas */
	for (count = 0; count < MSG_AREAS; count++)
		areas_read[count] = (char)0;

	/* prepare and write the preliminary userinfo file */
	memset(&userinfo,0,sizeof(struct ui));
	strcpy(userinfo.ui_name,user.user_name);
	userinfo.ui_date = user.user_lastdate;
	userinfo.ui_time = user.user_lasttime;
	userinfo.ui_baud = user_baud;
	fseek(uinfofd,0L,SEEK_SET);
	fwrite(&userinfo,sizeof(struct ui),1,uinfofd);

#if defined(PROTECTED) && defined(MULTICHAT)
	login_mc(user_firstname,user_lastname,user.user_lastdate,user.user_lasttime);
#endif

	user_warning = 0;			/* set 2 minute warning flag off! */

	show_user();
	if (check_events())
		{
		user_online = 1;   			/* ok, start timing!!!! */
		show_user();
		get_enter();
		}
	else
		user_online = 1;   			/* ok, start timing!!!! */


	if (user_time < 120L)
		{
		user_warning = 1;
		system_message("Notice: You have less than 2 minutes left online!!");
		}
	load_msglast();

	cur_line = 0;		/* starts more at the top! */

	if (!(user.user_flags & USER_ANSWERED))		/* has the newuser questionaire been answered */
		{
		strcpy(buffer,cfg.cfg_screenpath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		strcat(buffer,"newuser.qf");
		if (!access(buffer,0))		/* does the newuser file exist? */
			{
			do_questionnaire("newuser");
			user.user_flags |= USER_ANSWERED;
			fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
			fwrite(&user,sizeof(struct user),1,userfd);
			fflush(userfd);
			}
		}

	if (!(user.user_flags & USER_GUEST))
		{
		if (user.user_calls < 5)
			send_ansifile(cfg.cfg_screenpath,"newuser2",0);
		}
	else
		send_ansifile(cfg.cfg_screenpath,"guest",0);
	send_ansifile(cfg.cfg_screenpath,"welcome",0);

	do_quote("dayquote",0);
	if (get_maxmsgarea() != 0)			/* do we have message areas? */
		{
		check_mail();
		read_urgent();
		}
	else
		get_enter();

	if (cfg.cfg_welcome[0])				/* run external program if there is one */
		run_program(cfg.cfg_welcome);

	send_ansifile(cfg.cfg_screenpath,"bulletin",0);
	do_quote("dayquot2",0);
	send_ansifile(cfg.cfg_screenpath,"info",0);
	send_ansifile(cfg.cfg_screenpath,"info2",0);
	return 0;
	}



void login(void)
	{
	char buffer[81];

	purge_output(cfg.cfg_port);
	purge_input(cfg.cfg_port);
	set_inactivetime();
#ifdef PROTECTED
	#ifdef MULTICHAT
		sprintf(buffer,"\r\nSIMPLEX/2-M (v %u.%02u.%02u%s): A Bulletin Board System for OS/2 with MultiChat.\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
	#else
		sprintf(buffer,"\r\nSIMPLEX/2 (v %u.%02u.%02u%s): A Bulletin Board System for OS/2.\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
	#endif
#elif defined(__ZTC__)
	sprintf(buffer,"\r\nSIMPLEX/S (v %u.%02u.%02u%s): A Bulletin Board System for DOS.\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#else
	sprintf(buffer,"\r\nSIMPLEX (v %u.%02u.%02u%s): A Bulletin Board System for DOS.\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION,(char *)(BETA != 0 ? "Beta" : ""));
#endif
	send_string(buffer,NULL);
	send_string("Copyright (c) 1989-93, Christopher Laforet and Chris Laforet Software.\r\n",NULL);
	send_string("All Rights Reserved.\r\n\r\n",NULL);
	if (user_baud)
		{
		if (locked_baud)
			sprintf(buffer,"You have connected at %u baud to a locked baud of %u\r\n",(unsigned int)user_baud,(unsigned int)locked_baud);
		else 
			sprintf(buffer,"You have connected at %u baud\r\n",(unsigned int)user_baud);
		}
	else 
		sprintf(buffer,"You have connected in local mode\r\n");
	send_string(buffer,NULL);
	sprintf(buffer,"    to \"%s\"....\r\n",cfg.cfg_bbsname);
	send_string(buffer,NULL);
								 
	fseek(uinfofd,0L,SEEK_SET);
	if (!fread(&userinfo,sizeof(struct ui),1,uinfofd))
		strcpy(last_user,"Unknown last user");
	else
		strcpy(last_user,userinfo.ui_name);

	logoff_notify = 0;

	login_user();
	send_file(cfg.cfg_screenpath,"logo.asc",1,ps_handler);
	if (!get_login())
		{
		do_menus();
		send_ansifile(cfg.cfg_screenpath,"goodbye",0);
		logout();
		if (user_baud)
			sleep(4000);   	/* make sure goodbye screen is sent before toggling hangup! */
		}
	}



void logout(void)
	{
	struct msg *tmsg;
	char buffer[81];
	long online = projected_time(0L) - login_time;
	int minutes;
	int seconds;
	int areanum;
	int count;
	int kount;

	if (user_online)
		{
		/**** update the user's file ****/
		minutes = (int)(online / 60L);
		if (online % 60L)
			++minutes;			/* update to next minute */
		user.user_timeused += minutes;
		fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
		fwrite(&user,sizeof(struct user),1,userfd);
		fflush(userfd);

		/**** update the userinfo file ****/
		userinfo.ui_online = minutes;
		fseek(uinfofd,0L,SEEK_SET);
		fwrite(&userinfo,sizeof(struct ui),1,uinfofd);
		fflush(uinfofd);

		/**** update user's lastread pointers ****/
		update_msglast();

		/**** Log users statistics and exit ****/
		sprintf(buffer,"%d message%s",userinfo.ui_msgposted,userinfo.ui_msgposted == 1 ? "" : "s");
		log_entry(L_USERSTAT_POSTED,buffer);
		sprintf(buffer,"%d message%s",userinfo.ui_msgread,userinfo.ui_msgread == 1 ? "" : "s");
		log_entry(L_USERSTAT_READ,buffer);
		sprintf(buffer,"%d file%s (%ld byte%s)",userinfo.ui_upload,userinfo.ui_upload == 1 ? "" : "s",userinfo.ui_uploadbytes,userinfo.ui_uploadbytes == 1 ? "" : "s");
		log_entry(L_USERSTAT_UPLOADED,buffer);
		sprintf(buffer,"%d file%s (%ld byte%s)",userinfo.ui_dnload,userinfo.ui_dnload == 1 ? "" : "s",userinfo.ui_dnloadbytes,userinfo.ui_dnloadbytes == 1 ? "" : "s");
		log_entry(L_USERSTAT_DOWNLOADED,buffer);
		minutes = (int)(online / 60L);
		seconds = (int)(online % 60L);
		sprintf(buffer,"%d minute%s %d second%s",minutes,minutes == 1 ? "" : "s",seconds,seconds == 1 ? "" : "s");
		log_entry(L_USERSTAT_TIMEON,buffer);
		for (count = 0; count < MSG_AREAS; count++)
			{
			for (kount = 0; kount < 8; kount++)
				{
				areanum = (count * 8) + kount;
				if (areas_read[count] & (1 << kount))
					{
					if (tmsg = get_msgarea(areanum))
						{
						sprintf(buffer,"%u (%s)",areanum,tmsg->msg_areaname);
						log_entry(L_USERSTAT_AREA_READ,buffer);
						}
					}
				}
			}

		log_entry(L_LOGOUT,user.user_name);
		user_online = 0;

#if defined(PROTECTED) && defined(MULTICHAT)
		logout_mc();
#endif

		if (logoff_notify)
			{
			sound_tone(784,250);	/* G */
			sound_tone(784,250);	/* G */
			sound_tone(784,375);	/* G */
			sound_tone(622,125);	/* E-flat */
			sound_tone(659,125);	/* E */
			sound_tone(523,500);	/* C */
			sound_tone(1047,500);	/* C' */
			}
		}
	}



/* NONGRATA.BBS is organized thusly:
** firstname lastname
*/

void load_nongrata(char *nongratafile)
	{
	char buffer[81];
	char first[41];
	char last[41];
	char *cptr;
	char *cptr1;
	FILE *fd;

	if (!(fd = fopen(nongratafile,"rb")))
		return;
	while (fgets(buffer,sizeof(buffer),fd))
		{
		if (buffer[0])
			{
			cptr = buffer;
			while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
				++cptr;

			cptr1 = first;
			while (*cptr && is_namechar(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';

			while (*cptr && !is_namechar(*cptr))		/* trim leading spaces */
				++cptr;

			cptr1 = last;
			while (*cptr && is_namechar(*cptr))
				*cptr1++ = *cptr++;
			*cptr1 = '\0';
			if (first[0] && last[0])
				{
				if (cur_nongrata >= max_nongrata)
					{
					if (!(nongrata = realloc(nongrata,(max_nongrata += 10) * sizeof(char *))))
						_error(E_FATAL,"Out of memory for NONGRATA list");
					}
				sprintf(buffer,"%s %s",first,last);
				if (!(nongrata[cur_nongrata] = malloc((strlen(buffer) + 1) * sizeof(char *))))
					_error(E_FATAL,"Out of memory for NONGRATA list");
				strcpy(nongrata[cur_nongrata],buffer);
				++cur_nongrata;
				}
			}
		}
	fclose(fd);
	}



/* BADALIAS.BBS is organized thusly:
** partial_name_to_suppress
*/


void load_badalias(char *badaliasfile)
	{
	char buffer[81];
	char *cptr;
	char *cptr1;
	FILE *fd;

	if (!(fd = fopen(badaliasfile,"rb")))
		return;
	while (fgets(buffer,sizeof(buffer),fd))
		{
		if (buffer[0])
			{
			cptr = buffer;
			while (*cptr && isspace(*cptr))		/* trim leading spaces */
				++cptr;

			cptr1 = cptr;
			while (*cptr1)
				++cptr1;
			--cptr1;
			while (cptr1 > cptr && isspace(*cptr1))		/* trim trailing spaces */
				--cptr1;
			if (!isspace(*cptr1))
				++cptr1;
			*cptr1 = (char)'\0';

			if (*cptr)
				{
				if (cur_badalias >= max_badalias)
					{
					if (!(badalias = realloc(badalias,(max_badalias += 10) * sizeof(char *))))
						_error(E_FATAL,"Out of memory for BADALIAS list");
					}
				if (!(badalias[cur_badalias] = malloc((strlen(cptr) + 1) * sizeof(char *))))
					_error(E_FATAL,"Out of memory for BADALIAS list");
				strupr(cptr);
				strcpy(badalias[cur_badalias],cptr);
				++cur_badalias;
				}
			}
		}
	fclose(fd);
	}
