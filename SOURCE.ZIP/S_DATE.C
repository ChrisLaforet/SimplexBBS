/* s_date.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 2 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_date.c_v  $
**                       $Date:   25 Oct 1992 14:08:22  $
**                       $Revision:   1.27  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"

#ifdef PROTECTED
	#define INCL_DOSDATETIME
	#include <os2.h>
#else
	#include <dos.h>
#endif


#ifdef PROTECTED		/* os/2 versions of get date and time functions */

DATE_T get_cdate(void)
	{
	DATETIME dt;

	DosGetDateTime(&dt);
	return (DATE_T)(((dt.year - 1980) << 9) | ((dt.month & 15) << 5) | (dt.day & 31));
	}



TIME_T get_ctime(void)
	{
	DATETIME dt;

	DosGetDateTime(&dt);
	return (TIME_T)((dt.hours << 11) | (dt.minutes << 5) | (dt.seconds >> 1));
	}


int get_cday(void)
	{
	DATETIME dt;

	DosGetDateTime(&dt);
	return dt.weekday;		/* sun = 0 */
	}


#elif defined(__ZTC__)				/* Zortech version of date functions */


DATE_T get_cdate(void)
	{
	struct dos_date_t date;

	dos_getdate(&date);
	return (DATE_T)(((date.year - 1980) << 9) | ((date.month & 15) << 5) | (date.day & 31));
	}



TIME_T get_ctime(void)
	{
	struct dos_time_t time;

	dos_gettime(&time);
	return (TIME_T)((time.hour << 11) | (time.minute << 5) | (time.second >> 1));
	}



int get_cday(void)
	{
	struct dos_date_t date;

	dos_getdate(&date);
	return date.dayofweek;			/* 0 = sun */
	}


#else			/* MS-C versions of get date and time functions */

DATE_T get_cdate(void)
	{
	struct dosdate_t date;

	_dos_getdate(&date);
	return (DATE_T)(((date.year - 1980) << 9) | ((date.month & 15) << 5) | (date.day & 31));
	}



TIME_T get_ctime(void)
	{
	struct dostime_t time;

	_dos_gettime(&time);
	return (TIME_T)((time.hour << 11) | (time.minute << 5) | (time.second >> 1));
	}



int get_cday(void)
	{
	struct dosdate_t date;

	_dos_getdate(&date);
	return date.dayofweek;			/* 0 = sun */
	}

#endif



int check_date(char *date)		/* check date formatted MM-DD-YY for validity: Returns TRUE if valid */
	{
	char buffer[9];
	int ok = 0;
	int day;
	int month;
	int year;

	if (date[0])
		{
		strcpy(buffer,date);
		buffer[2] = '\0';
		month = atoi(buffer);
		buffer[5] = '\0';
		day = atoi(buffer + 3);
		buffer[8] = '\0';
		year = atoi(buffer + 6);
		if (month && month < 13 && day)
			{
			switch (month)
				{
				case 4:
				case 6:
				case 9:
				case 11:
					if (day <= 30)
						ok = 1;
					break;
				case 2:
					if (!(year % 4))
						{
						if (day <= 29)
							ok = 1;
						}
					else if (day <= 28)
						ok = 1;
					break;
				default:
					if (day <= 31)
						ok = 1;
					break;
				}
			}
		}
	return ok;
	}



DATE_T convert_date(char *date)	/* convert date formatted MM-DD-YY to DOS type */
	{
	char buffer[9];
	int day;
	int month;
	int year;
	int ok = 0;
	DATE_T rtn_date = 0;

	if (date[0])
		{
		strcpy(buffer,date);
		buffer[2] = '\0';
		month = atoi(buffer);
		buffer[5] = '\0';
		day = atoi(buffer + 3);
		buffer[8] = '\0';
		year = atoi(buffer + 6);
		if (month && month < 13 && day)
			{
			switch (month)
				{
				case 4:
				case 6:
				case 9:
				case 11:
					if (day <= 30)
						ok = 1;
					break;
				case 2:
					if (!(year % 4))
						{
						if (day <= 29)
							ok = 1;
						}
					else if (day <= 28)
						ok = 1;
					break;
				default:
					if (day <= 31)
						ok = 1;
					break;
				}
			if (ok)
				{
				if (year < 80)
					year += 100;
				year += 1900;
				rtn_date = (DATE_T)((year - 1980) << 9) | (month << 5) | day;
				}
			}
		}
	return rtn_date;
	}



DATE_T new_date(DATE_T date,TIME_T days)
	{
	int day;
	int month;
	int year;
	int count;

	month = (date >> 5) & 0xf;
	day = date & 0x1f;
	year = date >> 9;
	for (count = 0; count < days; count++)
		{
		++day;
		switch (month)
			{
			case 4:
			case 6:
			case 9:
			case 11:
				if (day > 30)
					{
					day = 1;
					++month;
					}
				break;
			case 2:
				if (!(year % 4))
					{
					if (day > 29)
						{
						day = 1;
						++month;
						}
					}
				else if (day > 28)
					{
					day = 1;
					++month;
					}
				break;
			default:
				if (day > 31)
					{
					day = 1;
					++month;
					}
				break;
			}
		if (month > 12)
			{
			month = 1;
			++year;
			}
		}
	return (DATE_T)((year << 9) | (month << 5) | day);
	}

