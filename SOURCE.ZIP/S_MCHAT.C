/* s_mchat.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 17 February 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_mchat.c_v  $
**                       $Date:   25 Oct 1992 14:07:16  $
**                       $Revision:   1.9  $
**
*/


#if defined(PROTECTED) && defined(MULTICHAT)


#define INCL_DOSERRORS
#define INCL_DOSNMPIPES
#define INCL_DOSPROCESS


#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <process.h>
#include <os2.h>
#include "simplex.h"




#define MC_STACKSIZE			4096
#define MAX_MCYELL				8


struct mcyell
	{
	char mcyell_name[41];
	int mcyell_pid;
	};


HFILE mcpipe;
int mc_pid;
volatile int mc_active = 0;
volatile int mc_chatflag = 0;
int mcthread = 1;
TID mc_tid;
int mc_stack[MC_STACKSIZE / sizeof(int)];		/* word-align the stack */
long mcaccess_sem = 0L;
long mcread_sem = 0L;
long mc_resting = 0L;
int mchat_flag = 0;
char mchat_name[41];
int mchat_pid;
int mc_logged = 0;
char user_location[41];
struct mcyell mcyell[MAX_MCYELL];

extern jmp_buf reset_bbs;



void monitor_mc(void far *dummy)
	{
	struct mcmsg tmsg;
	USHORT inbytes;
	USHORT outbytes;
	int ok;
	int rtn;

	DosSetPrty(PRTYS_THREAD,PRTYC_TIMECRITICAL,PRTYD_MINIMUM,mc_tid);
	while (mcthread && mc_active)
		{
		DosSemClear(&mc_resting);
		if (!mc_chatflag)
			{
			memset(&tmsg,0,sizeof(struct mcmsg));
			rtn = DosRead(mcpipe,(void *)&tmsg,sizeof(struct mcmsg),&inbytes);
			if (!rtn && inbytes)
				{
				if (tmsg.mcmsg_type == MC_YELL)
					{
					if (mc_logged)
						{
						DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
						if (!user_location[0])		/* at a menu */
							{
							ok = 1;
							mchat_flag = 1;
							strncpy(mchat_name,tmsg.mcmsg_msg,41);
							mchat_pid = tmsg.mcmsg_pid;
							}
						else
							{
							ok = 0;
							mchat_flag = 0;
							sprintf(tmsg.mcmsg_msg,"%u %s",tmsg.mcmsg_pid,user_location);
							}
						DosSemClear(&mcaccess_sem);
						if (!ok)
							{
							tmsg.mcmsg_type = MC_INACCESSIBLE;
							tmsg.mcmsg_pid = mc_pid;
							tmsg.mcmsg_len = strlen(tmsg.mcmsg_msg);
							DosWrite(mcpipe,(void *)&tmsg,sizeof(struct mcmsg),&outbytes);
							}
						}
					}
				}
			}
		DosSemSet(&mc_resting);
		DosSleep(1000L);
		}
	_endthread();
	}



int open_mc(void)
	{
	char buffer[100];
	PIDINFO pidinfo;
	USHORT action;
	USHORT err;
	int mlen;
	int type;
	int pid;
	int ok = 0;
	int retry = 0;

	DosGetPID(&pidinfo);
	mc_pid = pidinfo.pid;
	sprintf(buffer,"Opening connection to MultiChat with PID %d.",mc_pid);
	_error(E_NOTICE,buffer);
	do
		{
		err = DosOpen("\\pipe\\multchat",&mcpipe,&action,0L,FILE_NORMAL,FILE_OPEN,OPEN_ACCESS_READWRITE | OPEN_SHARE_DENYNONE,0L);
		if (err)
			{
			if (retry >= 10)
				{
				_error(E_NOTICE,"Timeout: Unable to connect to pipe in 2.5 seconds!");
				return 0;
				}
			else
				{
				++retry;
				DosSleep(250L);
				}
			}
		}
	while (err);

	_error(E_NOTICE,"Sending MultiChat pipe request!");
	send_mc_message(MC_REQUEST,0,NULL);

	retry = 0;
	do
		{
		type = get_mc_message(&pid,&mlen,buffer);
		if (type == MC_ERROR)
			{
			_error(E_NOTICE,"Unable to connect to MultiChat pipe!");
			return 0;
			}
		else if (type == MC_PIPENAME)
			{
			buffer[mlen] = '\0';		/* just in case it is not nul-terminated */
			DosClose(mcpipe);
			ok = 1;
			}
		else
			{
			if (retry >= 20)
				{
				_error(E_NOTICE,"Timeout: Unable to get a pipe name in 2.5 seconds!");
				DosClose(mcpipe);
				return 0;
				}
			++retry;
			}
		}
	while (!ok);

	_error(E_NOTICE,"Attempting to connect to new MultiChat pipe name!");
	retry = 0;			/* now to open the REAL pipe! */
	do
		{
		err = DosOpen(buffer,&mcpipe,&action,0L,FILE_NORMAL,FILE_OPEN,OPEN_ACCESS_READWRITE | OPEN_SHARE_DENYNONE,0L);
		if (err)
			{
			if (retry >= 10)
				{
				_error(E_NOTICE,"Timeout: Unable to connect to pipe in 2.5 seconds!");
				return 0;
				}
			else
				{
				DosSleep(250L);
				++retry;
				}
			}
		}
	while (err);
	_error(E_NOTICE,"Connected to MultiChat and launching thread!");
	send_mc_message(MC_CONNECT,strlen(cfg.cfg_bbsname),cfg.cfg_bbsname);		/* let MultiChat know we are here! */
	if ((mc_tid = _beginthread(monitor_mc,mc_stack,MC_STACKSIZE,NULL)) == -1)
		{
		DosClose(mcpipe);
		return 0;
		}
	mc_active = 1;
	return 1;
	}



void close_mc(void)
	{
	if (mc_active)
		{
		_error(E_NOTICE,"Attempting to disconnect from MultiChat!");
		send_mc_message(MC_DISCONNECT,0,NULL);		/* let MultiChat know we are going bye-bye! */
		DosClose(mcpipe);
		mcthread = 0;		/* end thread */
		mc_active = 0;
		}
	}



void login_mc(char *fname,char *lname,DATE_T indate,TIME_T intime)
	{
	char buffer[100];
	int temp;
	char tdate[15];
	char ttime[6];

	if (mc_active)
		{
		DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
		strcpy(user_location,"Login");
		mc_logged = 1;
		DosSemClear(&mcaccess_sem);

		temp = ((indate >> 5) & 0xf) - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(tdate,"%02u %s %02u",indate & 0x1f,months_table[temp],((indate >> 9) + 80) % 100);
		sprintf(ttime,"%02u:%02u",intime >> 11,(intime >> 5) & 0x3f);

		sprintf(buffer,"\"%s\" \"%s\" \"%s\" \"%s\"",fname,lname,tdate,ttime);
		send_mc_message(MC_LOGIN,strlen(buffer),buffer);
		}
	}



void logout_mc(void)
	{
	if (mc_active)
		{
		DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
		mc_logged = 0;
		DosSemClear(&mcaccess_sem);
		send_mc_message(MC_LOGOUT,0,NULL);
		}
	}



void send_mc_message(int type,int len,char *message)
	{
	struct mcmsg tmsg;
	USHORT outbytes;

	memset(&tmsg,0,sizeof(struct mcmsg));
	tmsg.mcmsg_type = type;
	tmsg.mcmsg_pid = mc_pid;
	if (len > 100)
		len = 100;
	tmsg.mcmsg_len = len;
	if (len)
		strncpy(tmsg.mcmsg_msg,message,len);
	tmsg.mcmsg_msg[len] = '\0';

	DosWrite(mcpipe,(void *)&tmsg,sizeof(struct mcmsg),&outbytes);

	if (outbytes != sizeof(struct mcmsg))
		_error(E_NOTICE,"Error while writing to MultiChat pipe!");
	}



int get_mc_message(int *pid,int *len,char *message)
	{
	struct mcmsg tmsg;
	USHORT inbytes;
	int ok = 0;
	int retry = 0;
	int err;
	int rtn = MC_NOTHING;

	do
		{
		memset(&tmsg,0,sizeof(struct mcmsg));

		err = DosRead(mcpipe,(void *)&tmsg,sizeof(struct mcmsg),&inbytes);

		if (err)
			{
			if (err == ERROR_BROKEN_PIPE || err == ERROR_INVALID_HANDLE)
				{
				_error(E_ERROR,"MultiChat pipe has been broken!");
				mc_active = 0;
				return MC_ERROR;
				}
			}
		else if (inbytes)
			{
			*pid = tmsg.mcmsg_pid;
			*len = tmsg.mcmsg_len;
			if (*len > 100)
				*len = 100;
			strncpy(message,tmsg.mcmsg_msg,tmsg.mcmsg_len);
			rtn = tmsg.mcmsg_type;
			ok = 1;
			}
		else
			{
			if (retry >= 10)
				ok = 1;
			else
				{
				++retry;
				DosSleep(125L);
				}
			}
		}
	while (!ok);
	return rtn;
	}



int get_mc_char(void)
	{
	char buffer[10];
	long total_inactive;
	long timer;
	int sent_warning = 0;
	int save_color;
	int quit = 0;
	int key;
	int rtn;
	int ok;
	int pid;
	
	if (cfg.cfg_inactive)
		total_inactive = (long)cfg.cfg_inactive * 60L;
	else
		total_inactive = 300L;			/* 5 minutes default */

	DosSemRequest(&update_sem,SEM_INDEFINITE_WAIT);
	inactive_time = 0L;			/* start the inactivity meter ticking! */
	DosSemClear(&update_sem);

	set_mc_location("");

	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		else if (mchat_flag)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				save_color = cur_color;
				send_string(new_color(GREEN | BRIGHT),NULL);
				}
			send_string("\r\n\r\n\aYou are being called for a chat by \"",NULL);

			DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
			send_string(mchat_name,NULL);
			mchat_flag = 0;
			mc_chatflag = 1;
			pid = mchat_pid;
			DosSemClear(&mcaccess_sem);

			DosSemWait(&mc_resting,SEM_INDEFINITE_WAIT);

			send_string("\":\r\n",NULL);
			send_string("Do you wish to chat now [15 second timeout] (Y/n)? ",NULL);
			ok = 0;
			timer = projected_time(15L);
			do
				{
				if (key = get_kb())
					{
					if (key == '\r' || key == '\n' || key == 'Y' || key == 'y')
						{
						send_string("Yes\r\n\r\n",NULL);
						sprintf(buffer,"%u",pid);
						send_mc_message(MC_ANSWER,strlen(buffer),buffer);	/* accept chat */
						chat_mc();
						ok = 1;
						}
					else if (key == 'N' || key == 'n')
						{
						send_string("No\r\n\r\n",NULL);
						sprintf(buffer,"%u",pid);
						send_mc_message(MC_NOTIME,strlen(buffer),buffer);	/* decline chat */
						ok = 1;
						}
					}
				if (!ok && projected_time(0L) < timer)
					{
					send_string("Timeout\r\n\r\n",NULL);
					sprintf(buffer,"%u",pid);
					send_mc_message(MC_NOANSWER,strlen(buffer),buffer);		/* timeout */
					ok = 1;
					}
				}
			while (!ok);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(save_color),NULL);

			DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
			mc_chatflag = 0;
			DosSemClear(&mcaccess_sem);

			rtn = '\r';		/* cause menu to be redrawn! */
			quit = 1;					 
			}
		else if (key = get_kb())
			{
			rtn = key;
			quit = 1;
			}
		else if (user_baud && peek_input(cfg.cfg_port) != -1)
			{
			rtn = read_input(cfg.cfg_port);
			quit = 1;
			}
		else if (inactive_time >= total_inactive)
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(WHITE | BRIGHT | BLINK),NULL);
			send_string("\r\n\r\n\aSorry! Hanging up due to keyboard inactivity timeout!\r\n",NULL);
			hangup();
	 		longjmp(reset_bbs,2);
			}
		else if (!sent_warning && ((total_inactive - inactive_time) < 30L))
			{
			cur_line = 0;
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				save_color = cur_color;
				send_string(new_color(RED | BRIGHT | BLINK),NULL);
				}
			sent_warning = 1;
			send_string("\r\n\a\aPress a key or you will be disconnected within 30 seconds!!\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(save_color),NULL);
			}
		if (!quit)
			{
			sleep(30);
			update_clock();
			}
		}
	while (!quit);
	return rtn;
	}



void yell_mc(void)
	{
	char buffer[100];
	char buffer1[100];
	long timer;
	long last_time;
	int count;
	int kount = 0;
	int type;
	int len;
	int pid;
	int key;
	int ok = 0;
	int ansi = 0;
	int quit = 0;
	int retry = 0;


	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		ansi = 1;
	cur_line = 0;
	for (count = 0; count < MAX_MCYELL; count++)
		mcyell[count].mcyell_pid = 0;

	if (ansi)
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("\r\n\r\nWelcome to MultiChat Yell.  Who do you wish to yell for?\r\n\r\n",NULL);
	if (ansi)
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("  <0>  The Sysop (Local node).\r\n",NULL);

	DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
	mc_chatflag = 1;
	DosSemClear(&mcaccess_sem);

	DosSemWait(&mc_resting,SEM_INDEFINITE_WAIT);

	count = 0;
	send_mc_message(MC_QUERY,0,NULL);
	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		type = get_mc_message(&pid,&len,buffer);
		cur_line = 0;
		if (type == MC_USERNAME)
			{
			if (!pid || count >= MAX_MCYELL)
				quit = 1;
			else
				{
				mcyell[count].mcyell_pid = pid;
				buffer[len] = '\0';
				strcpy(mcyell[count].mcyell_name,buffer);
				++kount;
				sprintf(buffer,"  <%d>  %s (Other node)\r\n",kount,mcyell[count].mcyell_name);
				send_string(buffer,NULL);
				++count;
				}
			}
		else
			{
			++retry;
			if (retry >= 8)
				quit = 1;
			}
		if (!quit)
			DosSleep(250L);
		}
	while (!quit);

printf("\n Waiting...\n");
	DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
	mc_chatflag = 0;
	DosSemClear(&mcaccess_sem);
printf("\n Done!...\n");

	send_string("  <X>  Exit without yelling.\r\n",NULL);
	if (ansi)
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("\r\nWhat is your choice [ENTER=Exit]? ",NULL);
	do
		{
		key = get_char();
		if (key == '\r' || key == '\n' || key == 'X' || key == 'x')
			ok = 1;
		else if (key == '0')
			{
			yell();
			ok = 1;
			}
		else if (key <= (kount + '0'))
			{
			retry = 0;
			count = key - '1';
			if (ansi)
				send_string(new_color(GREEN | BRIGHT),NULL);
			sprintf(buffer,"\r\nYelling for %s [ESC quits]....",mcyell[count].mcyell_name);
			send_string(buffer,NULL);

			DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
			mc_chatflag = 1;
			DosSemClear(&mcaccess_sem);

			DosSemWait(&mc_resting,SEM_INDEFINITE_WAIT);

			last_time = 0;
			quit = 0;
			do
				{
				if (user_baud && !cd)
					longjmp(reset_bbs,1);
				if (get_kb() == '\x1b')
					quit = 1;
				else
					{
					if (!(retry % 10))
						{
						sprintf(buffer,"%u %d",mcyell[count].mcyell_pid,ansi);
						send_mc_message(MC_YELL,strlen(buffer),buffer);
						}
					type = get_mc_message(&pid,&len,buffer);
					buffer[len] = '\0';
					switch (type)
						{
						case MC_NOANSWER:
							send_string("No answer.\r\n",NULL);
							quit = 1;
							break;
						case MC_ANSWER:
							chat_mc(); 
							quit = 1;
							break;
						case MC_INACCESSIBLE:
							sprintf(buffer1,"User is at %s.\r\n",buffer);
							send_string(buffer1,NULL);
							quit = 1;
							break;
						case MC_NOTIME:
							send_string("User declined chat request.\r\n",NULL);
							quit = 1;
							break;
						default:
							++retry;
							break;
						}
					if (!quit && retry >= 30)
						{
						send_string("Timeout.  Unable to reach user.\r\n",NULL);
						quit = 1;
						}
					DosSleep(400L);
					}
				}
			while (!quit);

			DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
			mc_chatflag = 0;
			DosSemClear(&mcaccess_sem);

			get_enter();
			ok = 1;
			}
		}
	while (!ok);
	}



void chat_mc(void)
	{
	char buffer[100];
	int type;
	int len;
	int pid;
	int quit = 0;
	int key;

	send_string("\r\n*** Chat Mode Active: Press [Ctrl-Z] or [Ctrl-D] to exit ***\r\n",NULL);
	do
		{
		if (user_baud && !cd)
			longjmp(reset_bbs,1);
		if (key = get_kb())
			{
			if (key == '\x1a' || key == '\x4')
				{
				send_mc_message(MC_ENDCHAT,0,NULL);
				send_string("\r\n*** End of chat mode ***\r\n",NULL);
				quit = 1;
				}
			else if (key >= '\x20')
				{
				sprintf(buffer,"%c",(unsigned char)key);
				send_mc_message(MC_TYPED,1,buffer);
				}
			}
		else if ((type = get_mc_message(&pid,&len,buffer)) != MC_NOTHING)
			{
			switch (type)
				{
				case MC_SHOW:
					send_string(buffer,NULL);
					break;
				case MC_ENDCHAT:
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n*** Other side ended chat ***\r\n",NULL);
					quit = 1;
					break;
				}
			}
		DosSleep(30L);
		}
	while (!quit);
	}



void set_mc_location(char *location)
	{
	DosSemRequest(&mcaccess_sem,SEM_INDEFINITE_WAIT);
	strcpy(user_location,location);
	DosSemClear(&mcaccess_sem);
	}


#endif
