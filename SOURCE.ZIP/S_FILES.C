/* s_files.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 12 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_files.c_v  $
**                       $Date:   25 Oct 1992 14:07:04  $
**                       $Revision:   1.24  $
**
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "simplex.h"


static struct file **files = NULL;
static int cur_files = 0;
static int max_files = 0;
static int min_filearea;
static int max_filearea;




void deinit_fileareas(void)
	{
	int count;

	if (cur_files)		/* in case we are re-initializing */
		{
		for (count = 0; count < cur_files; count++)
			free(files[count]);
		free(files);
		files = NULL;
		cur_files = 0;
		max_files = 0;
		}
	}



int file_comp(struct file **arg1,struct file **arg2)
	{
	return((*arg1)->file_number - (*arg2)->file_number);
	}



int load_fileareas(char *fname)
	{
	struct file tfile;
	int count;
	FILE *filefd;

	if (cur_files)		/* in case we are re-initializing */
		{
		for (count = 0; count < cur_files; count++)
			free(files[count]);
		free(files);
		files = NULL;
		cur_files = 0;
		max_files = 0;
		}

	if (filefd = fopen(fname,"rb"))
		{
		min_filearea = 10000;
		max_filearea = 0;
		while (fread(&tfile,1,sizeof(struct file),filefd))
			{
			if (cur_files >= max_files)
				{
				if (!(files = realloc(files,(max_files += 10) * sizeof(struct file *))))
					{
					_error(E_FATAL,"Error: Out of memory to allocate structures!");
					exit(1);
					}
				}
			if (!(files[cur_files] = calloc(1,sizeof(struct file))))
				_error(E_FATAL,"Error: Out of memory to allocate structures!");
			memcpy(files[cur_files],&tfile,sizeof(struct file));
			if (tfile.file_number < min_filearea)
				min_filearea = tfile.file_number;
			if (tfile.file_number > max_filearea)
				max_filearea = tfile.file_number;
			++cur_files;
			}

		if (cfg.cfg_fapath[0])		/* make a dummy file area for file-attach */
			{
			if (cur_files >= max_files)
				{
				if (!(files = realloc(files,(max_files += 10) * sizeof(struct file *))))
					{
					_error(E_FATAL,"Error: Out of memory to allocate structures!");
					exit(1);
					}
				}
			if (!(files[cur_files] = calloc(1,sizeof(struct file))))
				_error(E_FATAL,"Error: Out of memory to allocate structures!");

			strcpy(files[cur_files]->file_areaname,"Local File-Attach Area");
			strcpy(files[cur_files]->file_pathname,cfg.cfg_fapath);
			files[cur_files]->file_descname[0] = '\0';
			files[cur_files]->file_number = 0;		/* an "invalid" file area number! */
			++cur_files;
			}

		/* set up for uploadable messages */
		if (cur_files >= max_files)
			{
			if (!(files = realloc(files,(max_files += 10) * sizeof(struct file *))))
				{
				_error(E_FATAL,"Error: Out of memory to allocate structures!");
				exit(1);
				}
			}
		if (!(files[cur_files] = calloc(1,sizeof(struct file))))
			_error(E_FATAL,"Error: Out of memory to allocate structures!");

		strcpy(files[cur_files]->file_areaname,"Mail Uploading Area");
		strcpy(files[cur_files]->file_pathname,bbspath);
		files[cur_files]->file_descname[0] = '\0';
		files[cur_files]->file_number = AREA_UPLOADMAIL;
		++cur_files;

		if (cur_files)
			qsort(files,cur_files,sizeof(struct file *),file_comp);
		fclose(filefd);
		}
	return cur_files;
	}



int get_minfilearea(void)
	{
	return min_filearea;
	}



int get_maxfilearea(void)
	{
	return max_filearea;
	}



struct file *get_filearea(int number)
	{
	int count;

	for (count = 0; count < cur_files; count++)
		{
		if (number == files[count]->file_number)
			return(files[count]);
		}
	return NULL;
	}






