/* s_scan.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 8 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_scan.c_v  $
**                       $Date:   25 Oct 1992 14:07:46  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"




int quickscan_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'R':
		case 'N':
		case 'S':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int scan_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'R':
		case 'N':
		case 'S':
		case 'C':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int scan_search_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'T':
		case 'F':
		case 'S':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



int pascal do_quickscan(int area,int current)
	{
	struct msgh tmsgh;
	struct msg *tmsg;
	char buffer[85];
	char *cptr;
	int found = 0;
	int key;

	tmsg = get_msgarea(area);		/* assuming calling function takes care of verifying this */
	fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
	fread(&tmsgh,sizeof(struct msgh),1,msghfd);
	cptr = get_addressee(tmsgh.msgh_to);
	if (!(tmsgh.msgh_flags & MSGH_PRIVATE) || ((tmsgh.msgh_flags & MSGH_PRIVATE) && (user.user_priv >= tmsg->msg_sysoppriv || check_name(cptr) || check_name(tmsgh.msgh_from))))
		{
		sprintf(buffer,"%5u %-24.24s  %-24.24s  %-20.20s\r\n",tmsgh.msgh_number,tmsgh.msgh_from,tmsgh.msgh_to,tmsgh.msgh_subject);
		send_string(buffer,NULL);
		found = 1;
		if (more_flag)
			return 1;
		}
	key = 0;
	if (user_baud)
		{
		if (peek_input(cfg.cfg_port) != -1)
			key = read_input(cfg.cfg_port);
		else 
			key = get_kb();
		}
	else
		key = get_kb();
	switch (key)
		{
		case 'S':
		case 's':
			return 1;
			break;
		case 'P':
		case 'p':
			if (dopause())
				return 1;
			break;
		}
	if (found)
		return -1;
	return 0;
	}



void do_quickscanheader(void)
	{
	cur_line = 0;
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Msg   From (Sender)             To (Receiver)             Subject\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("----- ------------------------- ------------------------- --------------------\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN),NULL);
	}



void quickscan(int area)
	{
	char buffer[100];
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	int key;
	char *cptr;
	int total_msgs;
	int current;
	int actual;
	int count;
	int kount;
	int quit = 0;
	int found;
	int done;
	int rtn;
	int ok;
	int end;
	int mode;

	if (!(tmsg = get_msgarea(area)))
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	if (user.user_priv < tmsg->msg_readpriv || (tmsg->msg_readflags & user.user_uflags) != tmsg->msg_readflags)
		{
		system_message("You have insufficient privilege to read messages here!");
		return;
		}
	for (count = 0; count < max_msgcount; count++)
		{
		if (msgcount[count].mc_area == area)
			{
			total_msgs = msgcount[count].mc_msgs;
			break;
			}
		}
	if (total_msgs)
		{
		do
			{
			cur_line = 0;			/* defeat more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Message QuickScan Menu ---\r\n\r\n",quickscan_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					key = send_string("<F> Qscan Forward <R> Qscan Reverse <N> Qscan New     <S> Qscan Search\r\n",quickscan_handler);
					if (!key)
						key = send_string("<?> Help!         <X> Exit\r\n\r\n",quickscan_handler);
					}
				else
					key = send_string("[ FRNS?X ]\r\n\r\n",quickscan_handler);
				if (!key)
					key = send_string("What is your choice (ENTER=Exit)? ",quickscan_handler);
				}
			ok = 0;
			more_flag = 0;
			do
				{
				if (!key)
					key = get_char();

				switch (key)
					{
					case 'F':
					case 'f':
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						send_string("Start scanning forward from which message (ENTER=1)? ",NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = 1;
						found = 0;
						actual = 1;
						do_quickscanheader();
						for (count = current, kount = 0; count <= total_msgs; count++)
							{
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									++kount;
								++actual;
								if (kount == count)
									break;
								}

							if (rtn = do_quickscan(area,actual - 1))
								{
								found = 1;
								if (rtn == 1)
									break;
								}
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'R':
					case 'r':
						cur_line = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						sprintf(buffer,"Start scanning backward from which message (ENTER=%u)? ",total_msgs);
						send_string(buffer,NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = total_msgs;
						found = 0;
						actual = mdata.mdata_msgs;
						do_quickscanheader();
						for (count = current, kount = total_msgs + 1; count; count--)
							{
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									--kount;
								if (kount == count)
									break;
								--actual;
								fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
								}
							if (actual)
								{
								if (rtn = do_quickscan(area,actual))
									{
									found = 1;
									if (rtn == 1)
										break;
									}
								--actual;
								}
							else
								break;
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'N':
					case 'n':
						cur_line = 0;
						current = 1;
						for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
							{
							if (area == lastread[count]->lr_area)
								{
								current = lastread[count]->lr_prev + 1;
								break;
								}
							}
						found = 0;
						actual = 1;
						kount = 0;
						fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
						while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
							{
							if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
								++kount;
							if (kount == current)
								{
								found = 1;
								break;
								}
							++actual;
							}
						if (found)
							{
							do_quickscanheader();
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									{
									if (rtn = do_quickscan(area,actual))
										{
										found = 1;
										if (rtn == 1)
											break;
										}
									}
								++actual;
								}
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No new messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'S':
					case 's':
						end = 0;
						do
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(menu_color),NULL);
							purge_input(cfg.cfg_port);
							key = send_string("\r\n\r\n--- QuickScan Search Menu ---\r\n\r\n",scan_search_handler);
							if (!key)
								{
								if (!(user.user_flags & USER_EXPERT))
									key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",scan_search_handler);
								else
									key = send_string("[ TFSX ]\r\n\r\n",scan_search_handler);
								if (!key)
									key = send_string("What is your choice (ENTER=Exit)? ",scan_search_handler);
								}
							done = 0;
							do
								{
								if (!key)
									key = get_char();
								switch (key)
									{
									case 'T':
									case 't':
									case 'F':
									case 'f':
									case 'S':
									case 's':
										cur_line = 0;
										if (key == 'T' || key == 't')
											mode = 0;
										else if (key == 'F' || key == 'f')
											mode = 1;
										else
											mode = 2;
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nMessage Area \"",NULL);
										send_string(tmsg->msg_areaname,NULL);
										send_string("\".\r\n",NULL);
										sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
										send_string(buffer,NULL);
										if (!mode)
											send_string("Search for what in TO (ENTER=quit)? ",NULL);
										else if (mode == 1)
											send_string("Search for what in FROM (ENTER=quit)? ",NULL);
										else 
											send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
										get_field(buffer,30,1);
										if (buffer[0])
											{
											bm_setup(buffer,1);
											found = 0;
											actual = 1;
											do_quickscanheader();
											fseek(msglfd,0L,SEEK_SET);
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
													{
													fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
													fread(&tmsgh,1,sizeof(struct msgh),msghfd);
													if (!mode)
														cptr = tmsgh.msgh_to;
													else if (mode == 1)
														cptr = tmsgh.msgh_from;
													else
														cptr = tmsgh.msgh_subject;
													if (bm_search(cptr) != -1)
														{
														if (rtn = do_quickscan(area,actual))
															{
															found = 1;
															if (rtn == 1)
																break;
															}
														}
													}
												++actual;
												}
											if (!found)
												{
												if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
													send_string(new_color(GREEN | BRIGHT),NULL);
												send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
												}
											}
										done = 1;
										break;
									case 'X':
									case 'x':
									case '\r':
									case '\n':
										done = 1;
										end = 1;
										break;
									}
								key = 0;
								}
							while (!done);
							}
						while (!end);
						ok = 1;
						break;
					case '?':
						cur_line = 0;
						send_string("\r\n\r\n",NULL);
						send_ansifile(cfg.cfg_screenpath,"QSHELP",0);
						ok = 1;
						break;
					case 'X':
					case 'x':
					case '\r':
					case '\n':
						ok = 1;
						quit = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (!quit);
		}
	else
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nNo messages are currently in this area!\r\n",NULL);
		send_string("Why not leave one?\r\n",NULL);
		get_enter();
		}
	}



int pascal do_scan(int area,int current,int mark_flag,int total_msgs)
	{
	struct msgh tmsgh;
	struct msgh tmsgh1;
	struct msg *tmsg;
	char buffer[85];
	char *cptr;
	int quit_flag = 0;
	int ok;
	int key;
	int found = 0;

	tmsg = get_msgarea(area);		/* assuming calling function takes care of verifying this */
	fseek(msghfd,(long)(current - 1) * (long)sizeof(struct msgh),SEEK_SET);
	fread(&tmsgh,sizeof(struct msgh),1,msghfd);
	cptr = get_addressee(tmsgh.msgh_to);
	if (!(tmsgh.msgh_flags & MSGH_PRIVATE) || ((tmsgh.msgh_flags & MSGH_PRIVATE) && (user.user_priv >= tmsg->msg_sysoppriv || check_name(cptr) || check_name(tmsgh.msgh_from))))
		{
		send_string("\r\n",NULL);
		if (more_flag)
			quit_flag = 1;

		if (mark_flag)
			cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(GREEN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string("\"",NULL);
		if (more_flag)
			quit_flag = 1;
		send_string(tmsg->msg_areaname,NULL);
		if (more_flag)
			quit_flag = 1;
		send_string("\"  -> ",NULL);
		if (more_flag)
			quit_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(BROWN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		sprintf(buffer,"Message #%u of %u\r\n",tmsgh.msgh_number,total_msgs);
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(BROWN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string(buffer,NULL);
		if (more_flag)
			quit_flag = 1;

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(CYAN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string("  Posted: ",NULL);
		if (more_flag)
			quit_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(WHITE | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		sprintf(buffer,"%02u/%02u/%02u at %02u:%02u\r\n",(tmsgh.msgh_date >> 5) & 0xf,tmsgh.msgh_date & 0x1f,((tmsgh.msgh_date >> 9) + 80) % 100,
				tmsgh.msgh_time >> 11,(tmsgh.msgh_time >> 5) & 0x3f);
		send_string(buffer,NULL);
		if (more_flag)
			quit_flag = 1;

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(CYAN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string("      To: ",NULL);
		if (more_flag)
			quit_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(RED | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string(tmsgh.msgh_to,NULL);
		if (more_flag)
			quit_flag = 1;
		if (tmsgh.msgh_flags & MSGH_NET)
			{
			sprintf(buffer," on %d:%d/%d",tmsgh.msgh_dzone,tmsgh.msgh_dnet,tmsgh.msgh_dnode);
			send_string(buffer,NULL);
			if (more_flag)
				quit_flag = 1;
			}
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(BROWN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		sprintf(buffer,"     %s%s%s\r\n",tmsgh.msgh_flags & MSGH_PRIVATE ? "(Restricted) " : "",tmsgh.msgh_flags & MSGH_RECEIVED ? "(Received) " : "",tmsgh.msgh_flags & MSGH_DELETED ? "(Deleted)" : "");
		send_string(buffer,NULL);
		if (more_flag)
			quit_flag = 1;

		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(CYAN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string("    From: ",NULL);
		if (more_flag)
			quit_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(MAGENTA | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string(tmsgh.msgh_from,NULL);
		if (more_flag)
			quit_flag = 1;
		if (tmsgh.msgh_flags & MSGH_NET)
			{
			sprintf(buffer," on %d:%d/%d",tmsgh.msgh_szone,tmsgh.msgh_snet,tmsgh.msgh_snode);
			send_string(buffer,NULL);
			if (more_flag)
				quit_flag = 1;
			}
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(CYAN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string("\r\n",NULL);
		if (more_flag)
			quit_flag = 1;

		send_string(" Subject: ",NULL);
		if (more_flag)
			quit_flag = 1;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			{
			send_string(new_color(GREEN | BRIGHT),NULL);
			if (more_flag)
				quit_flag = 1;
			}
		send_string(tmsgh.msgh_subject,NULL);
		if (more_flag)
			quit_flag = 1;
		send_string("\r\n",NULL);
		if (more_flag)
			quit_flag = 1;

		if (tmsgh.msgh_prev || tmsgh.msgh_next)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				send_string(new_color(RED | BRIGHT),NULL);
				if (more_flag)
					quit_flag = 1;
				}
			if (tmsgh.msgh_prev)
				{
				fseek(msghfd,(long)(tmsgh.msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh1,sizeof(struct msgh),1,msghfd);
				sprintf(buffer,"Prev message is #%u.  ",tmsgh1.msgh_number);
				send_string(buffer,NULL);
				if (more_flag)
					quit_flag = 1;
				}
			if (tmsgh.msgh_next)
				{
				fseek(msghfd,(long)(tmsgh.msgh_next - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh1,sizeof(struct msgh),1,msghfd);
				sprintf(buffer,"Next message is #%u.",tmsgh1.msgh_number);
				send_string(buffer,NULL);
				if (more_flag)
					quit_flag = 1;
				}

			send_string("\r\n",NULL);
			if (more_flag)
				quit_flag = 1;
			}

		if (mark_flag)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				{
				send_string(new_color(menu_color),NULL);
				if (more_flag)
					quit_flag = 1;
				}

			if (!(user.user_flags & USER_EXPERT))
				send_string("\r\n<M> Mark <N> Next <S> Stop (ENTER=Mark)? ",NULL);
			else
				send_string("\r\n[ MNS ] (ENTER=Mark)? ",NULL);
			if (more_flag)
				quit_flag = 1;
			purge_input(cfg.cfg_port);
			mark_field(4);
			ok = 0;
			do
				{
				key = get_char();
				switch (key)
					{
					case 'M':
					case 'm':
					case '\r':
					case '\n':
						send_string("Mark",NULL);
						mark(area,current);
						unmark_field();
						send_string("\r\n",NULL);
						ok = 1;
						return -1;
						break;
					case 'N':
					case 'n':
						send_string("Skip",NULL);
						unmark_field();
						send_string("\r\n",NULL);
						ok = 1;
						return -1;
						break;
					case 'S':
					case 's':
						send_string("Stop",NULL);
						unmark_field();
						send_string("\r\n",NULL);
						ok = 1;
						return 1;
						break;
					}
				}
			while (!ok);
			}
		found = 1;
		}

	if (quit_flag)
		return 1;

	key = 0;
	if (user_baud && peek_input(cfg.cfg_port) != -1)
		key = (char)read_input(cfg.cfg_port);
	else
		key = get_kb();
	switch (key)
		{
		case 'P':
		case 'p':
			if (dopause())
				return 1;
			break;
		case 'S':
		case 's':
			return 1;
			break;
		}
	if (found)
		return -1;
	return 0;
	}



void scan(int area)
	{
	char buffer[100];
	struct mlink tmlink;
	struct msgh tmsgh;
	struct msg *tmsg;
	char *cptr;
	int total_msgs;
	int key;
	int current;
	int count;
	int kount;
	int actual;
	int quit = 0;
	int found;
	int done;
	int rtn;
	int mark = 0;
	int ok;
	int end;
	int mode;

	if (!(tmsg = get_msgarea(area)))
		{
		sprintf(buffer,"Message area %u is not a valid message area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}
	if (user.user_priv < tmsg->msg_readpriv || (tmsg->msg_readflags & user.user_uflags) != tmsg->msg_readflags)
		{
		system_message("You have insufficient privilege to read messages here!");
		return;
		}

	for (count = 0; count < max_msgcount; count++)
		{
		if (msgcount[count].mc_area == area)
			{
			total_msgs = msgcount[count].mc_msgs;
			break;
			}
		}
	if (total_msgs)
		{
		do
			{
			cur_line = 0;			/* defeat more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Message Scan/Mark Menu ---\r\n\r\n",scan_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					key = send_string("<F> Scan Forward  <R> Scan Reverse  <N> Scan New      <S> Scan Search\r\n",scan_handler);
					if (!key)
						key = send_string("<C> Clear Marks   <?> Help!         <X> Exit\r\n\r\n",scan_handler);
					}
				else
					key = send_string("[ FRNSC?X ]\r\n\r\n",scan_handler);
				if (!key)
					key = send_string("What is your choice (ENTER=Exit)? ",scan_handler);
				}
			ok = 0;
			do
				{
				if (!key)
					key = get_char();
				switch (key)
					{
					case 'F':
					case 'f':
						cur_line = 0;
						more_flag = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						send_string("Start scanning forward from which message (ENTER=1)? ",NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = 1;
						send_string("\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
						if (get_yn_enter(0))
							mark = 1;
						else
							mark = 0;
						found = 0;
						actual = 1;
						for (count = current, kount = 0; count <= total_msgs; count++)
							{
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									++kount;
								++actual;
								if (kount == count)
									break;
								}

							if (rtn = do_scan(area,actual - 1,mark,total_msgs))
								{
								found = 1;
								if (rtn == 1)
									break;
								}
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'R':
					case 'r':
						cur_line = 0;
						more_flag = 0;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nMessage Area \"",NULL);
						send_string(tmsg->msg_areaname,NULL);
						send_string("\".\r\n",NULL);
						sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
						send_string(buffer,NULL);
						sprintf(buffer,"Start scanning backward from which message (ENTER=%u)? ",total_msgs);
						send_string(buffer,NULL);
						current = get_number(0,total_msgs);
						if (!current)
							current = total_msgs;
						send_string("\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
						if (get_yn_enter(0))
							mark = 1;
						else
							mark = 0;
						actual = mdata.mdata_msgs;
						found = 0;
						for (count = current, kount = total_msgs + 1; count; count--)
							{
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									--kount;
								if (kount == count)
									break;
								--actual;
								fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
								}
							if (actual)
								{
								if (rtn = do_scan(area,actual,mark,total_msgs))
									{
	 								found = 1;
									if (rtn == 1)
										break;
									}
								--actual;
								}
							else
								break;
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'N':
					case 'n':
						cur_line = 0;
						more_flag = 0;
						current = 1;
						for (count = 0; count < cur_lastread; count++)		/* get lastread pointers */
							{
							if (area == lastread[count]->lr_area)
								{
								current = lastread[count]->lr_prev + 1;
								break;
								}
							}
						found = 0;
						actual = 1;
						kount = 0;
						fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
						while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
							{
							if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
								++kount;
							if (kount == current)
								{
								found = 1;
								break;
								}
							++actual;
							}
						if (found)
							{
							send_string("\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
							if (get_yn_enter(0))
								mark = 1;
							else
								mark = 0;
							found = 0;
							fseek(msglfd,(long)(actual - 1) * (long)sizeof(struct mlink),SEEK_SET);
							while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
								{
								if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
									{
									if (rtn = do_scan(area,actual,mark,total_msgs))
										{
										found = 1;
										if (rtn == 1)
											break;
										}
									}
								++actual;
								}
							}
						if (!found)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							send_string("\r\nSorry. No new messages that you can access were found!\r\n",NULL);
							}
						ok = 1;
						break;
					case 'S':
					case 's':
						end = 0;
						do
							{
							cur_line = 0;
							more_flag = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(menu_color),NULL);
							purge_input(cfg.cfg_port);
							key = send_string("\r\n\r\n--- Scan Search Menu ---\r\n\r\n",scan_search_handler);
							if (!key)
								{
								if (!(user.user_flags & USER_EXPERT))
									key = send_string("<T> To Field      <F> From Field    <S> Subject       <X> Exit\r\n\r\n",scan_search_handler);
								else
									key = send_string("[ TFSX ]\r\n\r\n",scan_search_handler);
								if (!key)
									key = send_string("What is your choice (ENTER=Exit)? ",scan_search_handler);
								}
							done = 0;
							do
								{
								if (!key)
									key = get_char();
								switch (key)
									{
									case 'T':
									case 't':
									case 'F':
									case 'f':
									case 'S':
									case 's':
										cur_line = 0;
										if (key == 'T' || key == 't')
											mode = 0;
										else if (key == 'F' || key == 'f')
											mode = 1;
										else
											mode = 2;
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nMessage Area \"",NULL);
										send_string(tmsg->msg_areaname,NULL);
										send_string("\".\r\n",NULL);
										sprintf(buffer,"Messages are numbered from 1 to %u:\r\n",total_msgs);
										send_string(buffer,NULL);
										if (!mode)
											send_string("Search for what in TO (ENTER=quit)? ",NULL);
										else if (mode == 1)
											send_string("Search for what in FROM (ENTER=quit)? ",NULL);
										else 
											send_string("Search for what in SUBJECT (ENTER=quit)? ",NULL);
										get_field(buffer,30,1);
										if (buffer[0])
											{
											bm_setup(buffer,1);
											found = 0;
											actual = 1;
											count = 0;
											send_string("\r\nDo you want to mark messages for later retrieval (ENTER=No)? ",NULL);
											if (get_yn_enter(0))
												mark = 1;
											else
												mark = 0;
											fseek(msglfd,0L,SEEK_SET);
											search_message();
											while (fread(&tmlink,sizeof(struct mlink),1,msglfd))
												{
												if (tmlink.mlink_area == area && !(tmlink.mlink_flags & MSGH_DELETED))
													{
													fseek(msghfd,(long)(actual - 1) * (long)sizeof(struct msgh),SEEK_SET);
													fread(&tmsgh,1,sizeof(struct msgh),msghfd);
													if (!mode)
														cptr = tmsgh.msgh_to;
													else if (mode == 1)
														cptr = tmsgh.msgh_from;
													else
														cptr = tmsgh.msgh_subject;
													if (bm_search(cptr) != -1)
														{
														if (rtn = do_scan(area,actual,mark,total_msgs))
															{
															found = 1;
															if (rtn == 1)
																break;
															}
														search_message();
														}
													++count;
													if (count == 1 || !(count % 10))
														show_message_search(count);
													}	
												++actual;
												}
											if (!found)
									   			{
												if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
													send_string(new_color(GREEN | BRIGHT),NULL);
												send_string("\r\nSorry. No messages that you can access were found!\r\n",NULL);
												}
											}
										done = 1;
										break;
									case 'X':
									case 'x':
									case '\r':
									case '\n':
										end = 1;
										done = 1;
										break;
									}
								key = 0;
								}
							while (!done);
							}
						while (!end);
						ok = 1;
						break;
					case 'C':
					case 'c':
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nAre you sure that you want to clear your marked messages (ENTER=No)? ",NULL);
						if (get_yn_enter(0))
							free_mark();
						ok = 1;
						break;
					case '?':
						cur_line = 0;
						more_flag = 0;
						send_string("\r\n\r\n",NULL);
						send_ansifile(cfg.cfg_screenpath,"SCANHELP",0);
						ok = 1;
						break;
					case 'X':
					case 'x':
					case '\r':
					case '\n':
						ok = 1;
						quit = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (!quit);
		}
	else
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nNo messages are currently in this area!\r\n",NULL);
		send_string("Why not leave one?\r\n",NULL);
		get_enter();
		}
	}
