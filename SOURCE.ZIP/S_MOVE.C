/* s_move.c
**
** Copyright (c) 1992, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 11 August 1992
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_move.c_v  $
**                       $Date:   25 Oct 1992 14:07:26  $
**                       $Revision:   1.0  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef PROTECTED
	#define INCL_DOSFILEMGR
	#include <os2.h>
#else
	#include <dos.h>
#endif
#include "simplex.h"


#define MAX_COPYBUFFER			8192

extern char _far copybuffer[MAX_COPYBUFFER];		/* must be kept in sync with s_copy.c */



void do_filemove(int from,int to,struct fl **files,int total_files)
	{
	struct file *tfile;
	struct file *tfile1;
	struct file *tfile2;
	struct fe tfe;
	char spath[80];
	char dpath[80];
	char src[100];
	char bak[100];
	char dest[100];
	int count;
	int srcfh;
	int destfh;
	int error;
	int moved = 0;
	int found;
#ifdef PROTECTED
	FILESTATUS fs;
	FILESTATUS newfs;
#else
	unsigned short fdate;
	unsigned short ftime;
#endif
	int ret;
	int ok;
	FILE *sbbsfd;
	FILE *bbbsfd;
	FILE *dbbsfd;

	tfile = get_filearea(from);
	tfile1 = get_filearea(to);
	strcpy(spath,tfile->file_pathname);
	if (spath[0] && spath[strlen(spath) - 1] != P_CSEP)
		strcat(spath,P_SSEP);
	strcpy(dpath,tfile1->file_pathname);
	if (dpath[0] && dpath[strlen(dpath) - 1] != P_CSEP)
		strcat(dpath,P_SSEP);

	for (count = 0; count < total_files; count++)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("Now moving file \"",NULL);
		send_string(files[count]->fl_name,NULL);
		send_string("\"...\r\n",NULL);

		ok = 1;
		error = 0;
		if (files[count]->fl_location == from)
			sprintf(src,"%s%s",spath,files[count]->fl_name);
		else
			{
			if (tfile2 = get_filearea(files[count]->fl_location))
				{
				strcpy(src,tfile2->file_pathname);
				if (src[0] && src[strlen(src) - 1] != P_CSEP)
					strcat(src,P_SSEP);
				strcat(src,files[count]->fl_name);
				}
			else
				ok = 0;
			}
		if (ok)
			{
			sprintf(dest,"%s%s",dpath,files[count]->fl_name);
			if ((srcfh = open(src,O_BINARY | O_RDONLY)) != -1)
				{
				error = 0;
#ifdef PROTECTED
				DosQFileInfo(srcfh,1,(PBYTE)&fs,sizeof(FILESTATUS));
#else
	#ifdef __ZTC__
				dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
	#else
				_dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
	#endif
#endif
				if ((destfh = open(dest,O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,S_IREAD | S_IWRITE)) != -1)
					{
					while ((ret = read(srcfh,copybuffer,MAX_COPYBUFFER)) != -1 && ret)
						{
						if (write(destfh,copybuffer,ret) == -1)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("Error while moving file....deleting incomplete file....\r\n\r\n",NULL);
							close(destfh);
							close(srcfh);
							unlink(dest);
							error = 1;
							files[count]->fl_name[0] = (char)'\0';
							break;
							}
						}
					if (!error)
						{
#ifdef PROTECTED
						DosQFileInfo(destfh,1,(PBYTE)&newfs,sizeof(FILESTATUS));
						newfs.fdateCreation = fs.fdateCreation;
						newfs.ftimeCreation = fs.ftimeCreation;
						newfs.fdateLastAccess = fs.fdateLastAccess;
						newfs.ftimeLastAccess = fs.ftimeLastAccess;
						newfs.fdateLastWrite = fs.fdateLastWrite;
						newfs.ftimeLastWrite = fs.ftimeLastWrite;
						DosSetFileInfo(destfh,1,(char *)&newfs,sizeof(FILESTATUS));
#else
	#ifdef __ZTC__
						dos_setftime(destfh,fdate,ftime);		/* set date/time */
	#else
						_dos_setftime(destfh,fdate,ftime);		/* set date/time */
	#endif
#endif
						moved = 1;
						close(destfh);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("Unable to open destination \"",NULL);
					send_string(dest,NULL);
					send_string("\"...\r\n\r\n",NULL);
					files[count]->fl_name[0] = (char)'\0';
					error = 1;
					}
				if (!error)
					{
					close(srcfh);
					unlink(src);
					}
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Unable to open source \"",NULL);
				send_string(src,NULL);
				send_string("\"...\r\n\r\n",NULL);
				files[count]->fl_name[0] = (char)'\0';
				}
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Unable to locate source \"",NULL);
			send_string(src,NULL);
			send_string("\"...\r\n\r\n",NULL);
			files[count]->fl_name[0] = (char)'\0';
			}
		}

	if (moved)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("Moving description records....\r\n",NULL);
		strcpy(src,spath);
		strcpy(bak,spath);
		strcpy(dest,dpath);
		strcat(src,"filelist.bbs");
		strcat(bak,"filelist.bak");
		strcat(dest,"filelist.bbs");
		unlink(bak);
		if (!rename(src,bak))
			{
			if (bbbsfd = fopen(bak,"rb"))
				{
				if (sbbsfd = fopen(src,"wb"))
					{
					if (!(dbbsfd = fopen(dest,"r+b")))
						dbbsfd = fopen(dest,"wb");
					if (dbbsfd)
						{
						while (fread(&tfe,sizeof(struct fe),1,bbbsfd))
							{
							found = 0;
							for (count = 0; count < total_files; count++)
								{
								if (files[count]->fl_name[0])
									{
									if (!stricmp(tfe.fe_name,files[count]->fl_name))
										{
										found = 1;
										break;
										}
									}
								}
							if (found)
								{
								fseek(dbbsfd,0L,SEEK_END);
								tfe.fe_location = to;
								tfe.fe_priv = tfile1->file_priv;		/* set the new privs to that of the destination area */
								tfe.fe_flags = tfile1->file_flags;
								fwrite(&tfe,sizeof(struct fe),1,dbbsfd);
								}
							else
								fwrite(&tfe,sizeof(struct fe),1,sbbsfd);
							}
						fclose(dbbsfd);
						}
					else 
						{
						fclose(bbbsfd);
						bbbsfd = NULL;
						fclose(sbbsfd);
						sbbsfd = NULL;
						send_string(new_color(RED | BRIGHT),NULL);
						send_string("\r\nUnable to open destination filelist.bbs. Skipping description transfer.\r\n",NULL);
						unlink(src);
						rename(bak,src);
						}
					if (sbbsfd)
						fclose(sbbsfd);
					}
				else
					{
					fclose(bbbsfd);
					bbbsfd = NULL;
					send_string(new_color(RED | BRIGHT),NULL);
					send_string("\r\nUnable to open source filelist.bbs.  Skipping description transfer.\r\n",NULL);
					rename(bak,src);
					}
				if (bbbsfd)
					fclose(bbbsfd);
				}
			else
				{
				send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nUnable to open files.bak.  Skipping description transfer.\n",NULL);
				rename(bak,src);
				}
			}
		else 
			{
			send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nUnable to rename source filelist.bbs to files.bak.  Skipping description transfer.\n",NULL);
			}
		}
	}



void move_files(int area)
	{
	struct file *tfile;
	struct file *tfile1;
	char buffer[80];
	int count;
	int kount;
	int dest;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}

	if (get_minfilearea() == get_maxfilearea())
		{
		system_message("Sorry, you must have more than 1 file area before moving files!!\r\n");
		return;
		}

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nMove file(s) and description(s) to which of these file areas:\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN),NULL);

	dest = 0;
	for (count = get_minfilearea(); count <= get_maxfilearea(); count++)
		{
		if ((count != area) && (tfile1 = get_filearea(count)))
			{
			cur_line = 0;
			if (dest && !(dest % 3))
				send_string("\r\n",NULL);
			sprintf(buffer,"%4d: %.17s",count,tfile1->file_areaname);
			send_string(buffer,NULL);
			for (kount = (int)strlen(buffer); kount < 25; kount++)
				send_string(" ",NULL);
			++dest;
			}
		}

	do
		{
		cur_line = 0;
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(GREEN | BRIGHT),NULL);
		send_string("\r\n\r\nMove files(s) into which area (ENTER=Exit)? ",NULL);
		if (dest = get_number(0,9999))
			{
			if (!(tfile1 = get_filearea(dest)))
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\nInvalid file area number provided....please reenter!",NULL);
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\nMoving files over to area \"",NULL);
				send_string(tfile1->file_areaname,NULL);
				send_string("\".\r\nIs this correct (Y/n)? ",NULL);
				if (!get_yn_enter(1))
					tfile1 = NULL;
				send_string("\r\n",NULL);
				}
			}
		}
	while (dest && !tfile1);
	if (dest && tfile1)
		{
		if (get_movelist(tfile))
			{
			if (cur_flist)
				do_filemove(area,dest,flist,cur_flist);
			else 
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Invalid file name(s) provided....Copy cancelled!\r\n",NULL);
				get_enter();
				}
			}

		if (cur_flist)
			{
			for (count = 0; count < cur_flist; count++)
				{
				free(flist[count]->fl_name);
				free(flist[count]);
				}
			free(flist);
			flist = NULL;
			cur_flist = 0;
			max_flist = 0;
			}
		}
	}
