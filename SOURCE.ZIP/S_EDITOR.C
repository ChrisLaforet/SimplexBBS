/* s_editor.c
**
** Copyright (c) 1989, Christopher Laforet
** All Rights Reserved
**
** Started: 7 December 1989
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_editor.c_v  $
**                       $Date:   25 Oct 1992 14:06:58  $
**                       $Revision:   1.25  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include "simplex.h"




#define WRAP				72


extern jmp_buf reset_bbs;
char **mlines = NULL;
int cur_mlines = 0;		
int max_mlines = 0;



void free_msglines(void)
	{
	int count;

	if (max_mlines)
		{
		for (count = 0; count < cur_mlines; count++)
			free(mlines[count]);
		free(mlines);
		}
	}



int editor_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'C':
		case 'D':
		case 'I':
		case 'L':
		case 'E':
		case 'R':
		case 'S':
		case 'A':
		case '?':
			return key;
			break;
		}
	return 0;
	}



void pascal send_message_line(char *string)
	{
	char buffer[81];
	char *cptr = string;
	char *cptr1 = buffer;

	while (*cptr && *cptr != '\r' && *cptr != '\n' && *cptr != '\x8d')
		*cptr1++ = *cptr++;
	*cptr1++ = '\r';
	*cptr1++ = '\n';
	*cptr1 = '\0';
	send_string(buffer,p_handler);
	}



int line_edit_message(void)
	{
	char buffer[81];
	char buffer1[81];
	char buffer2[10];
	char buffer3[120];
	int quit = 0;
	int menu;
	int eol;
	int ok;
	int out;
	int show_menu;
	int current = 0;
	int count;
	int temp;
	int mode = 1;
	int len;
	int key;
	char *cptr;
	char *cptr1;

	cur_line = 0;			/* disable more */
	mlines = NULL;
	max_mlines = 0;
	cur_mlines = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	sprintf(buffer,"     Enter your message in the following lines.  Each line can be up to %d\r\n",WRAP);
	send_string(buffer,NULL);
	send_string("     characters.  The message may be up to 99 lines long.  Press ENTER on\r\n",NULL);
	send_string("     an empty line to pull up editing menu.\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string("    |",NULL);
	for (count = 0; count < 70; count++)
		send_string("-",NULL);
	send_string("|",NULL);

	buffer1[0] = '\0';			/* first time in make sure that there is no data on second line! */
	do
		{
		do
			{
			menu = 0;
			cur_line = 0;			/* disable more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			sprintf(buffer2,"\r\n%2d: ",current + 1);
			send_string(buffer2,NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN),NULL);
			strcpy(buffer,buffer1);
			cptr = (buffer + (strlen(buffer)));
			send_string(buffer,NULL);
			eol = 0;
			do
				{
				key = get_char();
				if (key == '\b' || key == 0x7f)
					{
					if ((cptr - buffer) > 0)
						{
						send_string("\b \b",NULL);
						--cptr;
						*cptr = '\0';
						}
					}
				else if (key == '\r')
					{
					eol = 2;			/* 2 is a hard-CR */ 
					buffer1[0] = '\0';
					if ((cptr - buffer) == 0)
						menu = 1;
					}
				else if (key >= ' ' && (key != 0x7f && key != 0xff))
					{
					if ((cptr - buffer) >= WRAP)
						{
						--cptr;
						if (isspace(*cptr))
							buffer1[0] = '\0';
						else
							{
							while (((cptr - buffer) > 0) && !isspace(*cptr))
								--cptr;
							++cptr;
							if ((len = (int)strlen(cptr)) <= WRAP / 2)		/* WRAP/2 key wrap limit */
								{
								for (count = 0; count < len; count++)
									send_string("\b",NULL);
								for (count = 0; count < len; count++)
									send_string(" ",NULL);
								strcpy(buffer1,cptr);			/* move the data to the new line */
								*cptr++ = ' ';					/* add a space to the end of the line */
								*cptr = '\0';					/* cut off the end of the string which is now on another line */
								}
							else
								buffer1[0] = '\0';
							}
						if (key != ' ' || (key == ' ' && strlen(buffer1)))
							{
							buffer1[strlen(buffer1) + 1] = '\0';
							buffer1[strlen(buffer1)] = (char)key;
							}
						eol = 1;		/* 1 is a soft-CR */
						}
					else
						{
						*cptr++ = (char)key;
						*cptr = '\0';
						buffer2[0] = (char)key;
						buffer2[1] = '\0';
						send_string(buffer2,NULL);
						}
					}
				}
			while (!eol);
			if (mode)
				{
				if (buffer[0])
					{
					if (cur_mlines >= max_mlines)
						{
						if (!(mlines = realloc(mlines,(max_mlines += 25) * sizeof(char *))))
							{
							system_message("Fatal error in editor: Out of memory.  Message aborted!");
							max_mlines = 0;
							cur_mlines = 0;
							return 0;
							}
						}
					if (!(cptr1 = calloc(81,sizeof(char))))
						{
						system_message("Fatal error in editor: Out of memory.  Message aborted!");
						for (count = 0; count < cur_mlines; count++)
							free(mlines[count]);
						free(mlines);
						mlines = NULL;
						max_mlines = 0;
						cur_mlines = 0;
						return 0;
						}
					cptr = (buffer + (strlen(buffer) - 1));
					out = 0;
					while (((cptr - buffer) > 0) && isspace(*cptr))
						{
						if ((cptr - buffer) == 0)
							{
							out = 1;
							break;
							}
						--cptr;					/* trim trailing spaces */
						}
					if (!out)
						++cptr;
					*cptr = '\0';
					strcpy(cptr1,buffer);
					if (eol == 2)
						strcat(cptr1,"\r");
					else
						strcat(cptr1,"\x8d");
					mlines[cur_mlines] = cptr1;
					++cur_mlines;
					}
				else
					menu = 1;
				}
			if (mode)
				{
				++current;
				if (current >= 99)
					menu = 1;
				}
			}
		while (!menu);
		show_menu = 1;
		do
			{
			cur_line = 0;			/* defeat more */
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(menu_color),NULL);
			purge_input(cfg.cfg_port);
			key = send_string("\r\n\r\n--- Editor Menu ---\r\n\r\n",editor_handler);
			if (!key)
				{
				if (!(user.user_flags & USER_EXPERT))
					{
					key = send_string("<C> Continue msg  <E> Edit line     <D> Delete line   <I> Insert line   \r\n",editor_handler);
					if (!key)
						key = send_string("<R> Replace line  <<> Left-justify  <^> Center line   <>> Right-justify\r\n",editor_handler);
					if (!key)
						key = send_string("<L> List message  <?> Help!         <S> Save message  <A> Abort message\r\n\r\n",editor_handler);
					}
				else
					key = send_string("[ CEDIR<^>L?SA ]\r\n\r\n",editor_handler);
				if (!key)
					key = send_string("What is your choice? ",editor_handler);
				}
			ok = 0;
			do
				{
				if (!key)
					key = get_char();
				switch (key)
					{
					case 'S':
					case 's':
						show_menu = 0;
						ok = 1;
						quit = 1;
						break;
					case 'A':
					case 'a':
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(GREEN | BRIGHT),NULL);
						send_string("\r\n\r\nDo you want to throw this message away (ENTER=No)? ",NULL);
						if (get_yn_enter(0))
							{
							if (max_mlines)
								{
								for (count = 0; count < cur_mlines; count++)
									free(mlines[count]);
								free(mlines);
								mlines = NULL;
								max_mlines = 0;
								cur_mlines = 0;
								}
							return 0;
							}
						ok = 1;
						break;
					case '\r':
						ok = 1;
						break;
					case 'L':
					case 'l':
						send_string("\r\n\r\n",NULL);
						cur_line = 0;
						out = 0;
						for (count = 0; !out && count < cur_mlines; count++)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(menu_color),NULL);
							sprintf(buffer2,"%2u: ",count + 1);
							send_string(buffer2,NULL);
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN),NULL);
							send_message_line(mlines[count]);
							++cur_line;
							if (user.user_flags & USER_MORE && cur_line >= user.user_screenlen)
								{
								if (dopause())
									out = 1;
								}
							if (!out)
								{
								key = 0;
								if (user_baud)
									{
									if (peek_input(cfg.cfg_port) != -1)
										key = read_input(cfg.cfg_port);
									else 
										key = get_kb();
									}
								else
									key = get_kb();
								switch (key)
									{
									case 'S':
									case 's':
										out = 1;
										break;
									case 'P':
									case 'p':
										if (dopause())
											out = 1;
										break;
									}
								}
							}
						ok = 1;
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(CYAN),NULL);
						break;
					case 'C':
					case 'c':
						send_string("\r\n\r\n",NULL);
						current = cur_mlines ? cur_mlines - 1 : 0;
						if (cur_mlines)
							{
							strcpy(buffer1,mlines[current]);
							cptr = (buffer1 + strlen(buffer1));
							out = 0;
							while (!*cptr || *cptr == '\r' || *cptr == '\n' || *cptr == '\x8d')	/* strip off trailing CR-LF pair */
								{
								if ((cptr - buffer1) == 0)
									{
									out = 1;
									break;
									}
								--cptr;
								}
							if (!out)
								++cptr;
							*cptr = '\0';
							--cur_mlines;
							free(mlines[cur_mlines]);
							}
						ok = 1;
						show_menu = 0;
						break;
					case '?':
						cur_line = 0;
						send_string("\r\n\r\n",NULL);
						send_ansifile(cfg.cfg_screenpath,"EDITHELP",0);
						ok = 1;
						break;
					case 'R':
					case 'r':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nReplace which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;
								strcpy(buffer,mlines[current]);

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nReplace the following line:\r\n",NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(menu_color),NULL);
								sprintf(buffer2,"%2u: ",current + 1);
								send_string(buffer2,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_message_line(mlines[current]);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nWith the following line (Press ENTER on blank line to cancel):\r\n",NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(menu_color),NULL);
								sprintf(buffer2,"%2u: ",current + 1);
								send_string(buffer2,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);

								cptr = buffer1;
								*cptr = '\0';
								eol = 0;
								do
									{
									key = get_char();
									if (key == '\b' || key == 0x7f)
										{
										if ((cptr - buffer1) != 0)
											{
											send_string("\b \b",NULL);
											--cptr;
											*cptr = '\0';
											}
										}
									else if (key == '\r')
										eol = 1;
									else if (key >= ' ' && (key != 0x7f && key != 0xff))
										{
										if ((cptr - buffer1) < WRAP)
											{
											*cptr++ = (char)key;
											*cptr = '\0';
											buffer2[0] = (char)key;
											buffer2[1] = '\0';
											send_string(buffer2,NULL);
											}
										}
									}
								while (!eol);

								if ((cptr - buffer1) != 0)
									{
									strcat(buffer1,"\r");
									strcpy(mlines[current],buffer1);
									}
								}
							send_string("\r\n",NULL);
							}
						ok = 1;
						break;
					case 'D':
					case 'd':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nDelete which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(menu_color),NULL);
								sprintf(buffer2,"%2u: ",current + 1);
								send_string(buffer2,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_message_line(mlines[current]);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("Are you sure that you want to delete this line (ENTER=No)? ",NULL);
								if (get_yn_enter(0))
									{
									free(mlines[current]);
									if (current < (cur_mlines - 1))
										memmove(mlines + current,mlines + (current + 1),(cur_mlines - (current + 1)) * sizeof(char *));
									--cur_mlines;
									if (!cur_mlines)		/* go into full editing mode */
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(BROWN | BRIGHT),NULL);
										send_string("\r\n    |",NULL);
										for (count = 0; count < 70; count++)
											send_string("-",NULL);
										send_string("|",NULL);
										buffer1[0] = '\0';
										current = 0;
										show_menu = 0;
										ok = 1;
										break;
										}
									}
								}
							send_string("\r\n",NULL);
							}
						ok = 1;
						break;
					case 'I':
					case 'i':
						if (cur_mlines)
							{
							cur_line = 0;
							if (cur_mlines >= 99)
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\n\aYou cannot have more than 99 lines in this editor!\r\n\r\n",NULL);
								ok = 1;
								break;
								}
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nInsert this line before which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nInsert the following line (Press ENTER on blank line to cancel):\r\n",NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(menu_color),NULL);
								sprintf(buffer2,"%2u: ",current + 1);
								send_string(buffer2,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);

								cptr = buffer1;
								*cptr = '\0';
								eol = 0;
								do
									{
									key = get_char();
									if (key == '\b' || key == 0x7f)
										{
										if ((cptr - buffer1) != 0)
											{
											send_string("\b \b",NULL);
											--cptr;
											*cptr = '\0';
											}
										}
									else if (key == '\r')
										eol = 1;
									else if (key >= ' ' && (key != 0x7f && key != 0xff))
										{
										if ((cptr - buffer1) < WRAP)
											{
											*cptr++ = (char)key;
											*cptr = '\0';
											buffer2[0] = (char)key;
											buffer2[1] = '\0';
											send_string(buffer2,NULL);
											}
										}
									}
								while (!eol);

								if ((cptr - buffer1) != 0)
									{
									if (cur_mlines >= max_mlines)
										{
										if (!(mlines = realloc(mlines,(max_mlines += 25) * sizeof(char *))))
											{
											system_message("Fatal error in editor: Out of memory.  Message aborted!");
											mlines = NULL;
											max_mlines = 0;
											cur_mlines = 0;
											return 0;
											}
										}
									if (!(cptr1 = calloc(81,sizeof(char))))
										{
										system_message("Fatal error in editor: Out of memory.  Message aborted!");
										if (max_mlines)
											{
											for (count = 0; count < cur_mlines; count++)
												free(mlines[count]);
											free(mlines);
											mlines = NULL;
											max_mlines = 0;
											cur_mlines = 0;
											}
										return 0;
										}
									while (((cptr - buffer) > 0) && isspace(*cptr))
										--cptr;					/* trim trailing spaces */
									if (!isspace(*cptr))
										++cptr;
									*cptr = '\0';

									memmove(mlines + (current + 1),mlines + current,(cur_mlines - current) * sizeof(char *));
									strcat(buffer1,"\r");
									strcpy(cptr1,buffer1);
									mlines[current] = cptr1;
									++cur_mlines;
									}
								}
							send_string("\r\n",NULL);
							}
						ok = 1;
						break;
					case 'E':
					case 'e':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nEdit which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(menu_color),NULL);
								sprintf(buffer2,"%2u: ",current + 1);
								send_string(buffer2,NULL);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN),NULL);
								send_message_line(mlines[current]);
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("Replace what pattern (ENTER quits)? ",NULL);
								get_field(buffer,30,0);
								if (buffer[0])
									{
						    		send_string("Replace that with what pattern?     ",NULL);
									get_field(buffer1,30,0);
									strcpy(buffer3,mlines[current]);
									cptr = buffer3;
									while (cptr = strstr(cptr,buffer))
										{
										memmove(cptr,cptr + strlen(buffer),(strlen(cptr) - strlen(buffer)) + 1);
										memmove(cptr + strlen(buffer1),cptr,strlen(cptr) + 1);
										strncpy(cptr,buffer1,strlen(buffer1));
										if (strlen(buffer3) > WRAP + 2)
											break;
										cptr += strlen(buffer1);
										}
									if (strlen(buffer3) > WRAP + 2)
										{
										buffer3[WRAP + 2] = '\0';
										sprintf(buffer,"\r\n\aLine longer than %d characters.  Truncated!\r\n",WRAP);
										send_string(buffer,NULL);
										}
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(menu_color),NULL);
									sprintf(buffer2,"\r\n%2u: ",current + 1);
									send_string(buffer2,NULL);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(CYAN),NULL);
									send_message_line(buffer3);
									if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
										send_string(new_color(GREEN | BRIGHT),NULL);
									send_string("\r\nShould I keep the changes to the above line (ENTER=No)? ",NULL);
									if (get_yn_enter(0))
										strcpy(mlines[current],buffer3);
									}
								}
							}
						ok = 1;
						break;
					case '^':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nCenter which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								strcpy(buffer,mlines[current]);
								cptr = buffer;
								while (*cptr && *cptr <= ' ')		/* strip leading spaces */
									++cptr;
								if (*cptr)
									{
									len = 0;
									eol = 0;
									cptr1 = cptr;
									while (*cptr)			/* count length of string */
										{
										++len;
										++cptr;
										}
									--cptr;
									while ((cptr - buffer) > 0 && *cptr <= ' ')		/* strip trailing spaces */
										{
										--len;
										--cptr;
										}
									temp = (unsigned int)(WRAP - len) >> 1;		/* center line */
									cptr = mlines[current];
									for (count = 0; count < temp; count++)
										*cptr++ = ' ';
									for (count = 0; count < len; count++)
										*cptr++ = *cptr1++;
	 								*cptr++ = '\r';		/* terminate with hard-CR for formatting sake */
									*cptr = '\0';
									}
								}
							}
						ok = 1;
						break;
					case '<':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nLeft-justify which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								strcpy(buffer,mlines[current]);
								cptr = buffer;
								while (*cptr && *cptr <= ' ')		/* strip leading spaces */
									++cptr;
								if (*cptr)
									{
									len = 0;
									eol = 0;
									cptr1 = cptr;
									while (*cptr)			/* count length of string */
										{
										++len;
										++cptr;
										}
									--cptr;
									while ((cptr - buffer) > 0 && *cptr <= ' ')		/* strip trailing spaces */
										{
										--len;
										--cptr;
										}
									cptr = mlines[current];
									for (count = 0; count < len; count++)
										*cptr++ = *cptr1++;
	 								*cptr++ = '\r';		/* terminate with hard-CR for formatting sake */
									*cptr = '\0';
									}
								}
							}
						ok = 1;
						break;
					case '>':
						if (cur_mlines)
							{
							cur_line = 0;
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(GREEN | BRIGHT),NULL);
							sprintf(buffer,"\r\n\r\nRight-justify which line number [1-%d] (ENTER quits)? ",cur_mlines);
							send_string(buffer,NULL);
							current = get_number(0,cur_mlines);
							if (current)
								{
								--current;

								strcpy(buffer,mlines[current]);
								cptr = buffer;
								while (*cptr && *cptr <= ' ')		/* strip leading spaces */
									++cptr;
								if (*cptr)
									{
									len = 0;
									eol = 0;
									cptr1 = cptr;
									while (*cptr)			/* count length of string */
										{
										++len;
										++cptr;
										}
									--cptr;
									while ((cptr - buffer) > 0 && *cptr <= ' ')		/* strip trailing spaces */
										{
										--len;
										--cptr;
										}
									temp = WRAP - len;		/* right-justify line */
									cptr = mlines[current];
									for (count = 0; count < temp; count++)
										*cptr++ = ' ';
									for (count = 0; count < len; count++)
										*cptr++ = *cptr1++;
	 								*cptr++ = '\r';		/* terminate with hard-CR for formatting sake */
									*cptr = '\0';
									}
								}
							}
						ok = 1;
						break;
					}
				key = 0;
				}
			while (!ok);
			}
		while (show_menu);
		}
	while (!quit);
	return 1;
	}



