/* s_zmodem.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 19 October 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_zmodem.c_v  $
**                       $Date:   25 Oct 1992 14:08:16  $
**                       $Revision:   1.18  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifndef __ZTC__
	#include <time.h>
#endif
#include "simplex.h"


#ifdef __ZTC__		/* with ZTC we have to kludge to avoid the sleep() redefintion */
	typedef long time_t;
	extern time_t time(time_t *);
#endif

#define MAX_BADCHAR				64
#define MAX_GARBAGE				(MAX_ZBUFFER / 4)

#define ZPKT_OK					0
#define ZPKT_TIMEOUT			1
#define ZPKT_TOOLONG			2
#define ZPKT_INVALID_ESC		3
#define ZPKT_CRC				4
#define ZPKT_ABORT				5

#define Z_TIMEOUT				1000
#define Z_RETRY					90

#define MAX_ATTN				32


char _far send[MAX_ZBUFFER + 6];		/* buffer for sending data (6 bytes extra for X and Ymodem) */
char _far attn[MAX_ATTN + 1];			/* buffer for saving the Attn sequence */



#define USE_ZMODEM_MACROS		/* undefine this if not in iAPX 80x86!  See note below */


#ifdef USE_ZMODEM_MACROS

/* ------------------------------------------------------------------------
** 5-19-91 : BRF
** Here, let's take advantage of the fact that CAF designed the byte
** encoding in these buffers exactly the way they are in the Intel
** archetecture.  These #defines probably won't port to non-Intel
** machines -- if it's a problem just #define the symbol GETPUT_FUNCTIONS
** somewhere above.  Of the three, get_zshort() is the ugliest (because
** it does have to reverse the bytes) but the macro generates very
** efficient code:
**                  mov ah,Byte Ptr [pb]
**                  sub al,al
**                  mov cl,Byte Ptr [pb+1]
**                  sub ch,ch
**                  or  ax,cx
** Of course, we could write one that does the same in two mov's but this
** is much better than the overhead of calling the function!  Actually,
** given the ability to write inline assembler (not with MCS 5.1!) I'd
** probably code it this way:
**                  mov  ax,Word Ptr [pb]
**                  xchg ah,al
**
** 5-27-91 : CML
** The functions below are to be used in non-iAPX 86 architectures or if
** the need so arises.
** --------------------------------------------------------------------- */

#define put_zlong(pb,lv)		(*(unsigned long *)(pb) = (lv))
#define get_zlong(pb)			(long)(*((unsigned long *)(pb)))
#define get_zshort(pb)			(int)((((unsigned short)(*(unsigned char *)(pb)))<<8)|(unsigned short)(*(unsigned char *)((pb)+1)))

#else

void put_zlong(char *buffer,long value)
	{
	buffer[ZP0] = (char)(unsigned char)value;
	buffer[ZP1] = (char)(unsigned char)((unsigned long)value >> 8L);
	buffer[ZP2] = (char)(unsigned char)((unsigned long)value >> 16L);
	buffer[ZP3] = (char)(unsigned char)((unsigned long)value >> 24L);
	}



long get_zlong(char *buffer)
	{
	unsigned long rtn;

	rtn = (unsigned long)(unsigned char)buffer[ZP0];
	rtn |= ((unsigned long)(unsigned char)buffer[ZP1] << 8L);
	rtn |= ((unsigned long)(unsigned char)buffer[ZP2] << 16L);
	rtn |= ((unsigned long)(unsigned char)buffer[ZP3] << 24L);
	return (long)rtn;
	}


int get_zshort(char *buffer)
	{
	unsigned int rtn;

	rtn = ((unsigned int)(unsigned char)buffer[ZP0] << 8);
	rtn |= (unsigned int)(unsigned char)buffer[ZP1];
	return (int)rtn;
	}

#endif



void send_attention(void)
	{
	char *cptr = attn;

	while (*cptr)
		{
		switch ((unsigned char)*cptr)
			{
			case ZBREAK:
				start_break(cfg.cfg_port);
				sleep(30);
				stop_break(cfg.cfg_port);
				break;
			case ZPAUSE:
				sleep(1000);
				break;
			default:
				output_wait(cfg.cfg_port,*cptr);
				break;
			}
		++cptr;
		}
	}




void pascal send_zbin_byte(unsigned char byte)
	{
	static unsigned char prev_byte = '\0';

	switch (byte)
		{
		case 0x18:				/* CAN or ZDLE */
		case 0x98:
		case 0x10:
		case 0x90:
		case 0x11:
		case 0x91:
		case 0x13:
		case 0x93:
			send_char_fast(ZDLE);
			send_char_fast((char)((byte | '\x40') & 0xff));
			break;
		case 0x7f:
			send_char_fast(ZDLE);
			send_char_fast(ZRUB0);
			break;
		case 0xff:
			send_char_fast(ZDLE);
			send_char_fast(ZRUB1);
			break;
		case 0xd:
		case 0x8d:
			if (prev_byte == 0x40 || prev_byte == 0xc0)
				{
				send_char_fast(ZDLE);
				send_char_fast((char)((byte | '\x40') & 0xff));
				}
			else
				send_char_fast((char)byte);
			break;
		default:
			send_char_fast((char)byte);
			break;
		}
	prev_byte = byte;
	}



void pascal send_zhex_byte(unsigned char byte)
	{
	char buf[3];

	sprintf(buf,"%02x",byte);
	send_char_fast(buf[0]);		/* high nibble first */
	send_char_fast(buf[1]);		/* low nibble next */
	}



void send_h16(struct zh16 *header,int hex)
	{
	char *cptr;
	int crc;
	int count;
	int len;

	if (hex)
		header->zh16_type = ZHEX;
	else
		header->zh16_type = ZBIN;

	cptr = (char *)header;
	len = sizeof(struct zh16);
	crc = (int)calc_crc16(5,++cptr);		/* CRC begins with frame type */

	header->zh16_crc[0] = (char)(unsigned char)((unsigned int)crc >> 8);
	header->zh16_crc[1] = (char)(unsigned char)crc;

	send_char_fast(ZPAD);
	if (hex)
		send_char_fast(ZPAD);
	send_char_fast(ZDLE);

	cptr = (char *)header;
	for (count = 0; count < len; count++)
		{
		if (hex)
			{
			if (!count)			/* send header type */
				send_char_fast(*cptr++);
			else 
				send_zhex_byte(*cptr++);
			}
		else 
			send_zbin_byte(*cptr++);
		}
	if (hex)
		{
		send_char_fast('\r');
		send_char_fast('\n');
		if (header->zh16_frame != ZACK && header->zh16_frame != ZFIN)
			send_char_fast(XON);
		}
	flush_output(cfg.cfg_port);
	if (header->zh16_frame != ZDATA)
		sleep(250);
	}



void send_h32(struct zh32 *header)
	{
	char *cptr;
	long crc;
	int count;
	int len;

	header->zh32_type = ZBIN32;

	len = sizeof(struct zh32);
	cptr = (char *)header;
	crc = (long)calc_crc32(5,++cptr);		/* CRC begins with frame type */
	crc = (long) ~(unsigned long)crc;

	for (count = 0; count < 4; count++)
		{
		header->zh32_crc[count] = (char)(crc & 0xffL);
		crc = (long)((unsigned long)crc >> 8L);
		}

	send_char_fast(ZPAD);
	send_char_fast(ZDLE);

	cptr = (char *)header;
	for (count = 0; count < len; count++)
		send_zbin_byte(*cptr++);
	flush_output(cfg.cfg_port);
	if (header->zh32_frame != ZDATA)
		sleep(250);
	}



int check_zheader_crc(void *vptr,int which)
	{
	long crc_32;
	int crc_16;
	int len = 5;
	char *cptr = vptr;

	++cptr;		/* skip header type */
	if (which)
		crc_32 = (long)calc_crc32(len,cptr);
	else 
		crc_16 = (int)calc_crc16(len,cptr);

	cptr += len;		/* point at CRC */

	if (which)
		{
		crc_32 = (long) ~(unsigned long)crc_32;
		if (crc_32 != get_zlong(cptr))
			return 1;
		}
	else
		{
		if (crc_16 != get_zshort(cptr))
			return 1;
		}
	return 0;
	}



int get_zheader_type(void)
	{
	int inbyte;

	if ((inbyte = recv_char_fast()) == -1)
		return 0;			/* nothing received */
	if (inbyte == ZPAD)		/* second ZPAD, means this is a hex header */
		{
		if ((inbyte = recv_char_fast()) == -1)
			return 0;			/* nothing received */
		}
	if (inbyte != ZDLE)
		return 0;

	if ((inbyte = recv_char_fast()) == -1)
		return 0;			/* nothing received */

	return inbyte;			/* return type of header */
	}



int pascal get_zbyte(int hex)
	{
	int inbyte;
	int tval1;
	int tval2;

	if (hex)
		{
		if ((inbyte = recv_char_fast()) == -1)		/* high nibble */
			return -1;			/* nothing received */
		if (isdigit(inbyte))
			tval1 = inbyte - '0';
		else if (inbyte >= 'a' && inbyte <= 'f')
			tval1 = (inbyte - 'a') + 10;
		else 
			return -1;		/* invalid character */

		if ((inbyte = recv_char_fast()) == -1)		/* low nibble */
			return -1;			/* nothing received */
		if (isdigit(inbyte))
			tval2 = inbyte - '0';
		else if (inbyte >= 'a' && inbyte <= 'f')
			tval2 = (inbyte - 'a') + 10;
		else 
			return -1;		/* invalid character */

		inbyte = (tval1 << 4) | tval2;
		}
	else
		{
		if ((inbyte = recv_char_fast()) == -1)
			return -1;			/* nothing received */
		if (inbyte == ZDLE)
			{
			if ((inbyte = recv_char_fast()) == -1)
				inbyte = -2;			/* possible CAN sequence */
			else
				{
				switch (inbyte)
					{
					case ZCRCE:
					case ZCRCG:
					case ZCRCQ:
					case ZCRCW:
						inbyte |= 0x8000;		/* set high bit */
						break;
					case ZRUB0:
						inbyte = 0x7f;
						break;
					case ZRUB1:
						inbyte = 0xff;
						break;
					case ZDLE:		/* could be a CAN-CAN sequence */
						inbyte = -3;
						break;
					default:
						if ((inbyte & 0x60) == 0x40)	/* valid escaped character? */
							inbyte ^= 0x40;
						else
							inbyte = -1;		/* error */
						break;
					}
				}
			}
		}
	return inbyte;
	}



void *get_zheader(int got_zpad,int *type)		/* type is set to 0 for 16 bit header, 1 for 32 bit header */
	{
	static struct zh16 tzh16;
	static struct zh32 tzh32;
	void *vptr;
	char *cptr;
	int which = 0;			/* 0 for 16 bit and 1 for 32 bit */
	int inbyte;
	int hex = 0;
	int htype;
	int len;
	int cans = 0;
	int gcount = 0;

	if (!got_zpad)
		{
		while (1)			/* code fragment added by Brady Flowers to be a garbage-disposal loop */
			{
			if ((inbyte = recv_protocol_char(Z_TIMEOUT)) == -1)
				return NULL;			/* nothing received */
			if (inbyte == ZPAD)
				break;
			else if (inbyte == CAN)		/* Brady on 9-8-91: We hadn't been reacting to CANs here before... */
				{
				if (++cans >= 5)
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZCAN;
					*type = 0;
					return &tzh16;		/* return as ZCAN was received -- too much garbage! */
					}
				}
#if 0
			/* commented out 9-9-91:  Brady thinks that this is causing problems with some systems */
			else if (++gcount > (2 * sizeof(struct zh32)))		/* purpose is to stick around for 2 * max-size of header to see if we can resync! */
				{
				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZCAN;
				*type = 0;
				return &tzh16;		/* return as ZCAN was received -- too much garbage! */
				}
#endif
			else if (++gcount > 2*(sizeof(struct zh32)))		/* Brady Flowers' changes */
				return NULL;
			else
				cans = 0;
			}
		}
	htype = get_zheader_type();
	switch (htype)
		{
		case ZBIN32:
		case ZBINR32:
		case ZVBIN32:
		case ZVBINR32:
			which = 1;
			vptr = &tzh32;
			memset(&tzh32,0,sizeof(struct zh32));
			cptr = (char *)&tzh32;
			len = sizeof(struct zh32) - 1;
			*type = 1;
			break;
		case ZBIN:
		case ZHEX:
		case ZVBIN:
		case ZVHEX:
			vptr = &tzh16;
			memset(&tzh16,0,sizeof(struct zh16));
			cptr = (char *)&tzh16;
			len = sizeof(struct zh16) - 1;
			*type = 0;
			if (htype == ZHEX || htype == ZVHEX)
				hex = 1;
			break;
		default:
			return NULL;		/* invalid header */
		}
	*cptr++ = (char)(unsigned char)htype;
	while (len)
		{
		if ((inbyte = get_zbyte(hex)) == -1)
			return NULL; 		/* nothing received */
		if (inbyte == -2 || inbyte == -3)		/** handle CANs **/
			{
			if (inbyte == -2)
				++cans;
			else
				cans += 2;
			if (cans >= 5)
				{
				if (which)
					tzh32.zh32_frame = ZCAN;
				else 
					tzh16.zh16_frame = ZCAN;
				return vptr;
				}
			}
		else
			{
			*cptr++ = (char)(unsigned char)inbyte;
			cans = 0;
			--len;
			}
		}
	if (hex)
		{
		recv_char_fast();			/* eat the CR */
		recv_char_fast();			/* eat the LF -- let the function eat the XON */
		if (tzh16.zh16_frame != ZACK && tzh16.zh16_frame != ZFIN)
			recv_char_fast();		/* eat the XON */
		}

	return vptr;
	}



void send_zpacket(char *buffer,int len,char frame_end,int whichcrc)
	{
	long crc_32;
	int crc_16;
	int count;
	
	if (whichcrc)
		crc_32 = (long)calc_crc32(len,buffer);
	else
		crc_16 = (int)calc_crc16(len,buffer);

	for (count = 0; count < len; count++)
		send_zbin_byte(buffer[count]);

	send_char_fast(ZDLE);
	if (whichcrc)
		crc_32 = docrc32(crc_32,frame_end);
	else 
		crc_16 = docrc16(crc_16,frame_end);
	send_zbin_byte(frame_end);
	
	if (whichcrc)
		{
		crc_32 = (long) ~(unsigned long)crc_32;
		for (count = 0; count < 4; count++)
			{
			send_zbin_byte((unsigned char)(crc_32 & 0xffL));
			crc_32 = (long)((unsigned long)crc_32 >> 8L);
			}
		}
	else
		{
		send_zbin_byte((char)(unsigned char)((unsigned int)crc_16 >> 8));
		send_zbin_byte((char)(unsigned char)crc_16);
		}
	if (frame_end == ZCRCW)
		{
		send_char_fast(XON);
		sleep(500);
		}
	}



int get_zpacket(int whichcrc,int *len,char *frame_end)
	{
	char crcbuf[4];
	long crc_32 = (long)CRC32START;
	int got_frameend = 0;
	int crclen = 0;
	int quit = 0;
	int offset = 0;
	int error = ZPKT_TIMEOUT;
	int crc_16 = CRC16START;
	int inbyte;
	int cans = 0;
	int retries = 0;
	int skip;

	*len = 0;
	*frame_end = '\0';
	do
		{
		inbyte = get_zbyte(0);
		switch ((unsigned int)inbyte)
			{
			case (unsigned int)-1:
				++retries;
				if (retries >= Z_RETRY)
					{
					error = ZPKT_TIMEOUT;
					quit = 1;
					}
				else
					sleep(50);
				skip = 1;
				cans = 0;
				break;
			case (unsigned int)-2:
			case (unsigned int)-3:		/* since ZDLE == CAN */
				if (inbyte == -2)
					++cans;
				else 
					cans += 2;
				if (cans >= 5)
					{
					error = ZPKT_ABORT;
					quit = 1;
					}
				retries = 0;
				skip = 1;
				break;
			case ZCRCE | 0x8000:
			case ZCRCG | 0x8000:
			case ZCRCQ | 0x8000:
			case ZCRCW | 0x8000:
				if (!got_frameend)
					{
					*frame_end = (char)(unsigned char)inbyte;
					if (whichcrc)
						crc_32 = (long)docrc32(crc_32,inbyte & 0xff);
					else 
						crc_16 = (int)docrc16(crc_16,inbyte & 0xff);
					got_frameend = 1;
					}
				retries = 0;
				cans = 0;
				skip = 1;
				break;
			default:
				retries = 0;
				cans = 0;
				skip = 0;
				break;
			}

		if (!skip && !quit)
			{
			if (got_frameend)
				{
				crcbuf[crclen] = (char)(unsigned char)inbyte;
				++crclen;
				if ((whichcrc && crclen >= 4) || (!whichcrc && crclen >= 2))
					{
					error = ZPKT_OK;
					quit = 1;
					}
				}
			else
				{
				if (offset >= MAX_ZBUFFER)
					{
					error = ZPKT_TOOLONG;
					quit = 1;
					}
				else
					{
					send[offset] = (char)(unsigned char)inbyte;
					if (whichcrc)
						crc_32 = (long)docrc32(crc_32,inbyte & 0xff);
					else
						crc_16 = (int)docrc16(crc_16,inbyte & 0xff);
					++offset;
					}
				}
			}
		}
	while (!quit);

	if (error == ZPKT_OK)		/* got everything ok?  let's check CRC! */
		{
		if (whichcrc)
			{
			crc_32 = (long) ~(unsigned long)crc_32;
			if (crc_32 != get_zlong(crcbuf))
				error = ZPKT_CRC;
			}
		else
			{
			if (crc_16 != get_zshort(crcbuf))
				error = ZPKT_CRC;
			}
		}

	if (error == ZPKT_OK)		/* got everything ok?  let's set length! */
		*len = offset;
	if (*frame_end == ZCRCW)
		recv_protocol_char(Z_TIMEOUT);		/* eat the XON that follows a ZCRCW */

	return error;
	}



/*********************** Send Function **************************/


void z_send(int area,struct fl **files,int total_files)
	{
	struct file *tfile;
	struct zh16 tzh16;
	struct zh32 tzh32;
	struct stat tstat;
	STATE state;
	STATE nextstate;
	void *vptr;
	char buffer[100];
	char buffer1[31];
	char *cptr;
	long last_position;
	long total_size = 0L;
	long total_chars;
	long cur_chars;
	long crc_32;
	long tlong;
	long tval;
	long remain;
	long eta = 0L;
	long actual_time;
	int new_cursor;
	int cursor;
	int goodtimes;
	int badtimes;
	int max_blocksize;
	int blocksize;
	int windowsize = 0;
	int whichcrc = 0;
	int current = 0;
	int retry;
	int inbyte;
	int gotinit;
	int headertype;
	int badchar = 0;
	int count;
	int kount;
	int cans;
	int len;
	int rtn;
	int out;
	int quit;
	FILE *fd = NULL;

	for (count = 0; count < total_files; count++)
		{
		if (tfile = get_filearea(files[count]->fl_location))
			{
			total_size += files[count]->fl_size;
			eta += xmit_time(PROT_ZMODEM,files[count]->fl_size);
			}
		}

	tfile = get_filearea(area);

	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("    File area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(tfile->file_areaname,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("  Zmodem send: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	len = 15;
	for (count = 0; count < total_files; count++)
		{
		if (tfile = get_filearea(files[count]->fl_location))
			{
			if ((len + strlen(files[count]->fl_name)) >= 78)
				{
				send_string("\r\n               ",NULL);
				len = 15;
				}
			send_string(files[count]->fl_name,NULL);
			send_string(" ",NULL);
			len += (int)strlen(files[count]->fl_name) + 1;
			}
		}
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Transfer size: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);

	tval = (int)(total_size / 1024L);
	remain = total_size % 1024L;
	tval += (int)(remain / 128L);
	tval += (remain % 128L ? 1 : 0);

	cptr = parse_long(total_size);
	strcpy(buffer1,cptr);
	cptr = parse_long(tval);
	sprintf(buffer,"%s bytes (%s blocks approx)",buffer1,cptr);
	
	send_string(buffer,NULL);
	send_string("\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Transfer time: ",NULL);
	sprintf(buffer,"%lu min %02lu sec",eta / 60L,eta % 60L);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	send_string(buffer,NULL);
	send_string(" (estimated)\r\n\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Start receiving now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);

	hold_protocol();
	actual_time = xfer_time();
	purge_input(cfg.cfg_port);
	state = _START;
	quit = 0;
	retry = 0;

	if (user_baud == 300)
		max_blocksize = 256;
	else if (user_baud == 1200)
		max_blocksize = 512;
	else
		max_blocksize = 1024;
	blocksize = max_blocksize;

	write_string(new_color(WHITE));
	write_string("Waiting for Zmodem Startup....");

	do
		{
		out = 0;

		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{
			case _START:
				send_char_fast('r');		/* send "rz\r" since some receivers require this for autotrigger */
				send_char_fast('z');
				send_char_fast('\r');
				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZRQINIT;
				send_h16(&tzh16,1);
				state = _GETINIT;
				gotinit = 0;
				sleep(500);				/* take a quick breather! */
				cans = 0;
				break;
			case _GETINIT:
				cur_chars = 0L;
				vptr = get_zheader(0,&headertype);
				whichcrc = 0;
				if (vptr)
					{
					if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
						state = _OTHER_ABORT;
					else if (check_zheader_crc(vptr,headertype))
						{
						write_string(new_color(RED | BRIGHT));
						write_string(" -> CRC Error in header.\r\n");
						memset(&tzh16,0,sizeof(struct zh16));
						tzh16.zh16_frame = ZNAK;
						send_h16(&tzh16,1);
						retry = 0;
					 	}
					else
						{
						memcpy(&tzh16,vptr,sizeof(struct zh16));
						if (tzh16.zh16_frame == ZRINIT)
							{
							if (tzh16.zh16_zpzf[ZF0] & ESCCTL || tzh16.zh16_zpzf[ZF0] & ESC8)		/* sorry, escaped ctrl and 8th bit stuff ain't done here */
								state = _ABORT;
							else
								{
								if (tzh16.zh16_zpzf[ZF0] & CANFC32)
									whichcrc = 1;
								windowsize = (int)(get_zlong(tzh16.zh16_zpzf) & 0xffffL);	/* get window size */

								gotinit = 1;

								if (current >= total_files)
									state = _ENDOFSESSION;
								else
									state = _SENDFILEINFO;
								retry = 0;
								}
							}
						else if (tzh16.zh16_frame == ZCHALLENGE)
							{
							tzh16.zh16_frame = ZACK;		/* return the number in a ZACK header */
							send_h16(&tzh16,1);
							retry = 0;
							}
						else
							{
							++retry;
							if (retry >= Z_RETRY)
								{
								state = _TIMEOUT;
								break;
								}
							else if (!(retry % 4) && !gotinit)
								{
								state = _START;
								sleep(750);
								}
							}
						}
					}
				else
					{
					++retry;
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					sleep(750);
					if (!(retry % 4) && !gotinit)
						{
						state = _START;
						sleep(750);
						}
					}
				break;
			case _SENDFILEINFO:
				if (current < total_files)
					{
					if (tfile = get_filearea(files[current]->fl_location))
						{
						strcpy(buffer,tfile->file_pathname);
						if (buffer[0])
							{
							if (buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							}
						strcat(buffer,files[current]->fl_name);
						}
					else
						{
						++current;
						break;
						}
					}
				else 
					{
					state = _ENDOFSESSION;
					break;
					}

				cur_chars = 0L;

				if (!(fd = openf(buffer,"rb")))
					{
					_error(E_ERROR,"Unable to open file for Zmodem send!");
					total_chars = 0L;
					state = _END;
					break;
					}
				write_string(new_color(BROWN | BRIGHT));
				if (whichcrc)
					write_string("\r\n\nZmodem CRC-32 Send: ");
				else 
					write_string("\r\n\nZmodem CRC-16 Send: ");
				write_string(new_color(WHITE | BRIGHT));
				write_string(files[current]->fl_name);
				total_chars = filelength(fileno(fd));
				write_string(new_color(GREEN | BRIGHT));
				cptr = parse_long(total_chars);
				sprintf(buffer," (%s bytes)",cptr);
				write_string(buffer);
				write_string("\r\n");
				write_string(new_color(WHITE));

				if (whichcrc)
					{
					memset(&tzh32,0,sizeof(struct zh32));
					tzh32.zh32_frame = ZFILE;
					tzh32.zh32_zpzf[ZF0] = ZCBIN;
					send_h32(&tzh32);
					}
				else
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZFILE;
					tzh16.zh16_zpzf[ZF0] = ZCBIN;
					send_h16(&tzh16,0);
					}

				cptr = send;
				strcpy(cptr,files[current]->fl_name);
				strlwr(cptr);
				cptr += strlen(files[current]->fl_name) + 1;
				sprintf(cptr,"%lu ",total_chars);
				cptr += strlen(cptr);
				
				/* put file last mod date and time in octal seconds here */
				*cptr++ = ' ';
				fstat(fileno(fd),&tstat);
				sprintf(cptr,"%lo",tstat.st_mtime);
				cptr += strlen(cptr);

				*cptr++ = '\0';

				send_zpacket(send,cptr - send,ZCRCW,whichcrc);

				state = _GETRESPONSE;
				retry = 0;
				sleep(1000);		/* take a quick breather! */
				break;

			case _GETRESPONSE:
				if (vptr = get_zheader(0,&headertype))
					{
					if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
						state = _OTHER_ABORT;
					else if (check_zheader_crc(vptr,headertype))
						{
						write_string(new_color(RED | BRIGHT));
						write_string(" -> CRC Error in header.\r\n");
						if (whichcrc)
							{
							memset(&tzh32,0,sizeof(struct zh32));
							tzh32.zh32_frame = ZNAK;
							send_h32(&tzh32);
							}
						else
							{
							memset(&tzh16,0,sizeof(struct zh16));
							tzh16.zh16_frame = ZNAK;
							send_h16(&tzh16,1);
							}
						retry = 0;
					 	}
					else
						{
						memcpy(&tzh16,vptr,sizeof(struct zh16));
						if (tzh16.zh16_frame == ZRPOS)
							{
							cur_chars = get_zlong(tzh16.zh16_zpzf);
							if (cur_chars != 0L)
								{
								write_string(new_color(RED | BRIGHT));
								sprintf(buffer,"Zmodem Resume send at %lu\r\n",cur_chars);
								write_string(buffer);
								write_string(new_color(WHITE));
								}

							last_position = cur_chars;
							goodtimes = 0;
							badtimes = 0;

							if (cur_chars == total_chars)
								state = _SENDEOF;
							else if (fseek(fd,cur_chars,SEEK_SET))
								state = _FILEERROR;
							else 
								state = _SENDFILEHEADER;
							retry = 0;
							}
						else if (tzh16.zh16_frame == ZSKIP)
							{
							total_chars = 0L;
							retry = 0;
							state = _END;
							}
						else if (tzh16.zh16_frame == ZCRC)
							{
							crc_32 = (long)CRC32START;
							while (rtn = (int)fread(send,sizeof(char),sizeof(send),fd))
								{
								for (count = 0; count < rtn; count++)
									crc_32 = docrc32(crc_32,send[count]);
								}
							for (count = 0; count < 4; count++)
								{
								tzh16.zh16_zpzf[count] = (char)(crc_32 & 0xffL);
								crc_32 = (long)((unsigned long)crc_32 >> 8L);
								}
/*							send_h16(&tzh16,0); */
							send_h16(&tzh16,1);
							retry = 0;
							state = _GETRESPONSE;
							}
						else if (tzh16.zh16_frame == ZNAK)		/* added by Brady Flowers -- A ZNAK should loop back to _SENDFILEINFO */
							{
							++retry;
							if (retry >= 15)
								state = _ABORT;
							else
								{
								sleep(750);
								state = _SENDFILEINFO;
								}
							}
						else
							{
							++retry;
							if (retry >= Z_RETRY)
								state = _TIMEOUT;
							else
								{
								sleep(750);
								state = _GETRESPONSE;
								}
							}
						}
					}
				else
					{
					++retry;
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					else
						{
						state = _GETRESPONSE;
						sleep(750);
						}
					}
				break;

			case _SENDFILEHEADER:
				if (whichcrc)
					{
					memset(&tzh32,0,sizeof(struct zh32));
					tzh32.zh32_frame = ZDATA;
					put_zlong(tzh32.zh32_zpzf,cur_chars);
					send_h32(&tzh32);
					}
				else
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZDATA;
					put_zlong(tzh16.zh16_zpzf,cur_chars);
					send_h16(&tzh16,0);
					}
				state = _SENDFILEDATA;
				break;

			case _SENDFILEDATA:
				if (max_blocksize != blocksize && goodtimes >= 10)
					{
					blocksize <<= 1;		/* double blocksize */
					if (blocksize > max_blocksize)
						blocksize = max_blocksize;
					goodtimes = 0;
					}

				if (rtn = (int)fread(send,sizeof(char),blocksize,fd))
					{
					sprintf(buffer,"\rSending from %lu through %lu (%u)   \b\b\b",cur_chars,cur_chars + (long)rtn,rtn);
					write_string(buffer);

					if (badchar >= MAX_BADCHAR)
						{
						 write_string(new_color(RED | BRIGHT));
						 write_string(" -> Garbage!  ZACK request ");
						 write_string(new_color(WHITE));

						send_zpacket(send,rtn,ZCRCW,whichcrc);		/* send ZCRCW -- we want a ZACK */
						badchar = 0;
						nextstate = _SENDFILEHEADER;
						state = _GETCRC;
						}
					else if (rtn == blocksize)
						{
						send_zpacket(send,rtn,ZCRCG,whichcrc);
						nextstate = _SENDFILEDATA;
						state = _LISTEN;
						}
					else 
						{
						send_zpacket(send,rtn,ZCRCE,whichcrc);
						if (feof(fd))
							state = _SENDEOF;
						else
							state = _FILEERROR;
						retry = 0;
						}
					cur_chars += (long)rtn;
					++goodtimes;
					}
				else 			/* EOF!  Send ZEOF header */
					{
					send_zpacket(send,0,ZCRCE,whichcrc);
					if (feof(fd))
						state = _SENDEOF;
					else
						state = _FILEERROR;
					retry = 0;
					}
				break;

			case _LISTEN:
				state = nextstate;		/* if nothing changes our mind, we carry on with what we were doing */
//				cans = 0;		/* THIS SHOULDN"T BE HERE!!! */
				retry = 0;
				while (!out && !peek_protocol_input(cfg.cfg_port))		/* bump'n'run approach developed by Brady Flowers!  While other is speaking, we are listening */
					{
					inbyte = recv_char_fast();
					if (inbyte == '*')		/* check for return info from receiver */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								{
								state = _OTHER_ABORT;
								out = 1;
								}
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string(" -> CRC Error in header.\r\n");
								if (whichcrc)
									{
									memset(&tzh32,0,sizeof(struct zh32));
									tzh32.zh32_frame = ZNAK;
									send_h32(&tzh32);
									}
								else
									{
									memset(&tzh16,0,sizeof(struct zh16));
									tzh16.zh16_frame = ZNAK;
									send_h16(&tzh16,1);
									}
								retry = 0;
								}
							else
								{
								memcpy(&tzh16,vptr,sizeof(struct zh16));
								if (tzh16.zh16_frame == ZRPOS)
									{
									cur_chars = get_zlong(tzh16.zh16_zpzf);

									if (last_position == cur_chars)
										{
										goodtimes = 0;
										++badtimes;
										if (badtimes > 3)
											{
											badtimes = 0;
											if (blocksize != 64)
												blocksize = (unsigned int)blocksize >> 1;
											}
										}
									else
										{
										last_position = cur_chars;
										goodtimes = 0;
										badtimes = 0;
										}

									write_string(new_color(RED | BRIGHT));
									sprintf(buffer," -> Resend @ %lu\r\n",cur_chars);
									write_string(buffer);
									write_string(new_color(WHITE));

									purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */

									send_zpacket(send,0,ZCRCE,whichcrc);	/* send blank ZCRCE */

									if (cur_chars == total_chars)
										{
										state = _SENDEOF;
										retry = 0;
										}
									else if (fseek(fd,cur_chars,SEEK_SET))
										state = _FILEERROR;
									else 
										state = _SENDFILEHEADER;
									out = 1;
									}
								else if (tzh16.zh16_frame == ZFERR)
									{
									state = _OTHER_ABORT;
									purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
									out = 1;
									}
								}
							}
						cans = 0;
						}
					else if (inbyte == CAN)		/* is it a CAN? */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							out = 1;
							break;
							}
						}
					else
						{
						cans = 0;
						++badchar;
						}
					}
				break;

			case _GETCRC:
				state = nextstate;		/* if nothing changes our mind, we carry on with what we were doing */

				cans = 0;
				retry = 0;
				while (!out)
					{
					inbyte = recv_protocol_char(Z_TIMEOUT);
					if (inbyte == '*')		/* check for ZACK */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								{
								state = _OTHER_ABORT;
								out = 1;
								}
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string(" -> CRC Error in header.\r\n");
								if (whichcrc)
									{
									memset(&tzh32,0,sizeof(struct zh32));
									tzh32.zh32_frame = ZNAK;
									send_h32(&tzh32);
									}
								else
									{
									memset(&tzh16,0,sizeof(struct zh16));
									tzh16.zh16_frame = ZNAK;
									send_h16(&tzh16,1);
									}
								retry = 0;
								}
							else
								{
								memcpy(&tzh16,vptr,sizeof(struct zh16));
								if (tzh16.zh16_frame == ZACK)
									{
									tlong = get_zlong(tzh16.zh16_zpzf);

									if (tlong == cur_chars)		/* ZACK is ok! */
										{
										write_string(new_color(RED | BRIGHT));
										sprintf(buffer," -> Ok.\r\n");
										write_string(buffer);
										write_string(new_color(WHITE));
										out = 1;
										}
									}
								else if (tzh16.zh16_frame == ZRPOS)
									{
									cur_chars = get_zlong(tzh16.zh16_zpzf);

									if (last_position == cur_chars)
										{
										goodtimes = 0;
										++badtimes;
										if (badtimes > 3)
											{
											badtimes = 0;
											if (blocksize != 64)
												blocksize >>= 1;
											}
										}
									else
										{
										last_position = cur_chars;
										goodtimes = 0;
										badtimes = 0;
										}

									write_string(new_color(RED | BRIGHT));
									sprintf(buffer," -> Resend @ %lu\r\n",cur_chars);
									write_string(buffer);
									write_string(new_color(WHITE));

									purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */

									send_zpacket(send,0,ZCRCE,whichcrc);	/* send blank ZCRCE */

									if (cur_chars == total_chars)
										{
										state = _SENDEOF;
										retry = 0;
										}
									else if (fseek(fd,cur_chars,SEEK_SET))
										state = _FILEERROR;
									else 
										state = _SENDFILEHEADER;
									out = 1;
									}
								else if (tzh16.zh16_frame == ZFERR)
									{
									state = _OTHER_ABORT;
									purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
									out = 1;
									}
								}
							}
						cans = 0;
						}
					else if (inbyte == CAN)		/* is it a CAN */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							out = 1;
							break;
							}
						}
					else
						{
						cans = 0;
						++badchar;
						}
					}
				break;

			case _SENDEOF:
				if (whichcrc)
					{
					memset(&tzh32,0,sizeof(struct zh32));
					tzh32.zh32_frame = ZEOF;
					put_zlong(tzh32.zh32_zpzf,cur_chars);
					send_h32(&tzh32);
					}
				else
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZEOF;
					put_zlong(tzh16.zh16_zpzf,cur_chars);
/*					send_h16(&tzh16,0); */
					send_h16(&tzh16,1);
					}

				state = _END;

				gotinit = 0;
				out = 0;
				cans = 0;
				while (!out && !gotinit)
					{
					if ((inbyte = recv_protocol_char(Z_TIMEOUT)) == '*')		/* check for return info from receiver */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								{
								state = _OTHER_ABORT;
								out = 1;
								}
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string(" -> CRC Error in header.\r\n");
								if (whichcrc)
									{
									memset(&tzh32,0,sizeof(struct zh32));
									tzh32.zh32_frame = ZNAK;
									send_h32(&tzh32);
									}
								else
									{
									memset(&tzh16,0,sizeof(struct zh16));
									tzh16.zh16_frame = ZNAK;
									send_h16(&tzh16,1);
									}
								retry = 0;
								}
							else
								{
								memcpy(&tzh16,vptr,sizeof(struct zh16));
								if (tzh16.zh16_frame == ZRPOS)
									{
									cur_chars = get_zlong(tzh16.zh16_zpzf);

									if (last_position == cur_chars)
										{
										goodtimes = 0;
										++badtimes;
										if (badtimes > 3)
											{
											badtimes = 0;
											if (blocksize != 64)
												blocksize = (unsigned int)blocksize >> 1;
											}
										}
									else
										{
										last_position = cur_chars;
										badtimes = 0;
										}

		  							write_string(new_color(RED | BRIGHT));
		  							sprintf(buffer,"-> Resend @ %lu\r\n",cur_chars);
		  							write_string(buffer);
		  							write_string(new_color(WHITE));

									purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */

									send_zpacket(send,0,ZCRCE,whichcrc);

		  							if (cur_chars == total_chars)
										{
										state = _SENDEOF;
										retry = 0;
										}
									else if (fseek(fd,cur_chars,SEEK_SET))
										state = _FILEERROR;
									else 
										state = _SENDFILEHEADER;
									retry = 0;
									out = 1;
									break;
									}
								else if (tzh16.zh16_frame == ZRINIT)
									{
									if (tzh16.zh16_zpzf[ZF0] & CANFC32)
										whichcrc = 1;
									else
										whichcrc = 0;

									windowsize = (int)(get_zlong(tzh16.zh16_zpzf) & 0xffffL);	/* get window size */
									state = _END;
									retry = 0;
									gotinit = 1;
									break;
									}
								else if (tzh16.zh16_frame == ZFERR)
									{
									state = _OTHER_ABORT;
									out = 1;
									}
								else
									{
									++retry;
									if (retry >= Z_RETRY)
										{
										state = _TIMEOUT;
										purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
										out = 1;
										break;
										}
									sleep(750);
									}
								}
							}
						cans = 0;
						retry = 0;
						}
					else if (inbyte == CAN)		/* is it a CAN */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							out = 1;
							break;
							}
						}
					else if (inbyte == -1)
						{
						cans = 0;
						++retry;
						if (retry >= Z_RETRY)
							{
							state = _TIMEOUT;
							out = 1;
							break;
							}
						else
							{
							cans = 0;
							sleep(750);
							if (!(retry % 5))
								{
								state = _SENDEOF;
								out = 1;
								}
							}
						}
					}
				break;

			case _FILEERROR:
				write_string(new_color(RED | BRIGHT));
				write_string(" -> File Error.  Aborting.\r\n");
				if (whichcrc)
					{
					memset(&tzh32,0,sizeof(struct zh32));
					tzh32.zh32_frame = ZFERR;
					send_h32(&tzh32);
					}
				else
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZFERR;
/*					send_h16(&tzh16,0); */
					send_h16(&tzh16,1);
					}
				state = _ABORT;
				break;

			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string(" -> Timeout.  Aborting.\r\n");
				state = _ABORT;
				break;

			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string(" -> Other side aborted.\r\n");
				state = _ABORT;		/* just to make sure other side knows we aborted too! */
				quit = 1;
				break;

			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;

			case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				
				quit = 1;
				break;

			case _END:
				if (fd)
					{
					closef(fd);
					fd = NULL;
					write_string(new_color(GREEN | BRIGHT));
					write_string(" -> File sent!\r\n");
					total_chars = cur_chars;		/* not quite correct -- later we will fix */

					sprintf(buffer,"\"%s\" in area %u.",files[current]->fl_name,files[current]->fl_location);
					log_entry(L_DOWNLOAD,buffer);

					++userinfo.ui_dnload;
					userinfo.ui_dnloadbytes += total_chars;
					++user.user_dnload;
					user.user_dnloadbytes += total_chars;
					fseek(userfd,(long)user_number * (long)sizeof(struct user),SEEK_SET);
					fwrite(&user,1,sizeof(struct user),userfd);
					fflush(userfd);

					files[current]->fl_update = update_downloads(files[current]->fl_location,files[current]->fl_name,get_cdate());
					}
				++current;
				write_string(new_color(WHITE));
				write_string("Waiting");
				if (!gotinit)
					state = _GETINIT;
				else
					{
					if (current >= total_files)
						state = _ENDOFSESSION;
					else
						state = _SENDFILEINFO;
					}
				gotinit = 0;
				retry = 0;
				break;

			case _ENDOFSESSION:
				write_string(new_color(CYAN | BRIGHT));
				write_string(" -> End of session\r\n");
				if (whichcrc)
					{
					memset(&tzh32,0,sizeof(struct zh32));
					tzh32.zh32_frame = ZFIN;
					send_h32(&tzh32);
					}
				else
					{
					memset(&tzh16,0,sizeof(struct zh16));
					tzh16.zh16_frame = ZFIN;
/*					send_h16(&tzh16,0);	*/
					send_h16(&tzh16,1);
					}
				if (vptr = get_zheader(0,&headertype))
					{
					if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
						state = _OTHER_ABORT;
					else
						{
						if (check_zheader_crc(vptr,headertype))
							{
							write_string(new_color(RED | BRIGHT));
							write_string(" -> CRC Error in header.\r\n");
							}
						memcpy(&tzh16,vptr,sizeof(struct zh16));
						if (tzh16.zh16_frame == ZFIN)
							{
							}
						}
					}

				send_char_fast('O');
				send_char_fast('O');
				flush_output(cfg.cfg_port);

				actual_time = xfer_time() - actual_time;
				sleep(2000);

				show_dlstats(total_size,eta,actual_time);
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);
				quit = 1;
				break;
			}
		update_clock();
		}
	while (!quit);
	if (fd)
		closef(fd);

	unhold_protocol();
	}



/*********************** Receive Function ***************************/

void z_recv(int area,FILE *listfd,int (*verify)(char *fname))
	{	   
	struct file *tfile;
	struct zh16 tzh16;
	struct zh32 tzh32;
	STATE state;
	char pathname[100];
	char fname[30];
	char ext[_MAX_EXT];
	char buffer[80];
	char buffer1[10];
	char file[128];
	char frametype;
	char *cptr;
	time_t challenge;
	time_t ftime;
	void *vptr;
	long total_size = 0L;
	long actual_time;
	long filelen;
	long curlen;
	int headertype;
	int new_cursor;
	int cursor;
	int retry;
	int garbage;
	int inbyte;
	int cans;
	int count;
	int kount;
	int error;
	int resume;
	int quit = 0;
	int len;
	FILE *fd = NULL;

	tfile = get_filearea(area);
	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("     File area: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	send_string(tfile->file_areaname,NULL);
	send_string("\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("    Disk space: ",NULL);
	cptr = parse_long(disk_size(tfile->file_pathname));
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string(cptr,NULL);
	send_string(" bytes free\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("Zmodem receive.\r\n\r\n\r\n",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("Start sending now.  Press Ctrl-X several times to cancel transfer\r\n\r\n",NULL);

	hold_protocol();
	actual_time = xfer_time();
	filelen = 0L;
	curlen = 0L;
	retry = 0;
	quit = 0;
	state = _START;
	write_string(new_color(BROWN | BRIGHT));
	write_string("\r\nZmodem receive\r\n");
	write_string("\r\n");
	write_string(new_color(WHITE));
	write_string("Waiting for Zmodem Startup....");

	do
		{
		if (peek_kb() != -1)
			{
			switch (read_kb())
				{
				case 0x1e00:			/* alt-a - abort transfer */
					state = _SYSOPABORT;
					break;
				case 0x2600:			/* alt-l - logoff notification toggle */
					logoff_notify = logoff_notify ? 0 : 1;
					cursor = bios_getcurpos();
					sprintf(buffer1,"%lu%s",user_time / 60L,(char *)(logoff_notify ? "*" : ""));
					new_cursor = ((bottom_line + 2) << 8) | 0x34;
					cptr = buffer1;
					while (*cptr)
						{
						bios_setcurpos(new_cursor++);
						bios_outchar(*cptr++,status_color[2],1);
						}
					bios_setcurpos(new_cursor);
					bios_outchar(' ',status_color[2],1);
					bios_setcurpos(cursor++);
					break;
				}
			}
		switch (state)
			{					
			case _START:
				attn[0] = (char)'\0';			/* Null attention string */
				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZRINIT;
				tzh16.zh16_zpzf[ZF0] = CANFDX | CANOVIO | CANFC32;
				send_h16(&tzh16,1);
				state = _GETINIT;
				cans = 0;
				break;

			case _GETINIT:
				vptr = get_zheader(0,&headertype);
				if (vptr)
					{
					if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
						state = _OTHER_ABORT;
					else if (check_zheader_crc(vptr,headertype))
						{
						write_string(new_color(RED | BRIGHT));
						write_string(" -> CRC Error in header.\r\n");
						memset(&tzh16,0,sizeof(struct zh16));
						tzh16.zh16_frame = ZNAK;
						send_h16(&tzh16,1);
						}
					else
						{
						if (headertype)
							{
							memcpy(&tzh32,vptr,sizeof(struct zh32));
							if (tzh32.zh32_frame == ZRQINIT)
								{
								retry = 0;
							/*	state = _GOTINIT;  -- might not work with some protocols! */
								state = _SENDINIT;
								}
							else if (tzh32.zh32_frame == ZFILE)		/* discovered by Brady Flowers -- some porgrams cut-thru the chase and send ZFILE right off the bat! */
								{
								retry = 0;
								state = _GETFILEINFO;
								}
							}
						else
							{
							memcpy(&tzh16,vptr,sizeof(struct zh16));
							if (tzh16.zh16_frame == ZRQINIT)
								{
								retry = 0;
							/*	state = _GOTINIT;  -- might not work with some protocols! */
								state = _SENDINIT;
								}
							else if (tzh16.zh16_frame == ZFILE)		/* discovered by Brady Flowers -- some porgrams cut-thru the chase and send ZFILE right off the bat! */
								{
								retry = 0;
								state = _GETFILEINFO;
								}
							}
						}

					if (state == _GETINIT)
						{
						++retry;		/* timeout every 2 seconds in get_zheader */
						if (retry >= Z_RETRY)			/* after 40 seconds, abort */
							{
							state = _TIMEOUT;
							break;
							}
						else if (!(retry % 5))		/* every 10 seconds resend init */
							{
							state = _START;
							sleep(2000);
							}
						}
					}
				else
					{
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						{
						state = _TIMEOUT;
						break;
						}
					else if (!(retry % 5))		/* every 10 seconds resend init */
						{
						state = _START;
						sleep(2000);
						}
					}
				break;

			case _GOTINIT:
				memset(&tzh16,0,sizeof(struct zh16));	/* not neccessary except some comm programs EXPECT it! */
				tzh16.zh16_frame = ZCHALLENGE;
				time(&challenge);
				put_zlong(tzh16.zh16_zpzf,(long)challenge);
				send_h16(&tzh16,1);

				state = _GETRESPONSE;		/* response to challenge! */

				retry = 0;
				cans = 0;
				break;

			case _GETRESPONSE:
				if ((inbyte = recv_char_fast()) != -1)
					{
					if (inbyte == '*')		/* check for return info from receiver */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								state = _OTHER_ABORT;
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string("CRC Error in received header.\r\n");
								memset(&tzh16,0,sizeof(struct zh16));
								tzh16.zh16_frame = ZNAK;
								send_h16(&tzh16,1);
								}
							else
								{
								if (headertype)
									{
									memcpy(&tzh32,vptr,sizeof(struct zh32));
									if (tzh32.zh32_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZACK)
										{
										if (get_zlong(tzh32.zh32_zpzf) != (long)challenge)
											state = _ABORT;
										else
											state = _SENDINIT;
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZNAK)
										state = _GOTINIT;
									else if (tzh32.zh32_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									}
								else
									{
									memcpy(&tzh16,vptr,sizeof(struct zh16));
									if (tzh16.zh16_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZACK)
										{
										if (get_zlong(tzh16.zh16_zpzf) != (long)challenge)
											state = _ABORT;
										else
											state = _SENDINIT;
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZNAK)
										state = _GOTINIT;
									else if (tzh16.zh16_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									}
								}
							cans = 0;
							}
						}
					else if (inbyte == CAN)		/* is it a CAN? */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							}
						}
					else
						cans = 0;
					}
				if (state == _GETRESPONSE && inbyte == -1)
					{
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					else
						sleep(750);
					}
				break;

			case _SENDINIT:
				write_string(new_color(MAGENTA | BRIGHT));
				write_string("Handshaking for Zmodem\r\n");

				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZRINIT;
				tzh16.zh16_zpzf[ZF0] = CANFDX | CANOVIO | CANFC32;
				send_h16(&tzh16,1);

				state = _LISTEN;

				retry = 0;
				cans = 0;
				break;

			case _LISTEN:		/* this is the catch-all which branches to the respective states */
				if ((inbyte = recv_char_fast()) != -1)
					{
					if (inbyte == '*')		/* check for return info from receiver */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								state = _OTHER_ABORT;
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string("CRC Error in received header.\r\n");
								memset(&tzh16,0,sizeof(struct zh16));
								tzh16.zh16_frame = ZNAK;
								send_h16(&tzh16,1);
								}
							else
								{
								if (headertype)
									{
									memcpy(&tzh32,vptr,sizeof(struct zh32));
									if (tzh32.zh32_frame == ZFILE)
										{
										state = _GETFILEINFO;
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZCOMMAND)	/* if we see this, we send back a completed status */
										{
										write_string(new_color(RED | BRIGHT));
										write_string("Got ZCOMMAND and returning ZCOMPL header.\r\n");
										memset(&tzh16,0,sizeof(struct zh16));		
										tzh16.zh16_frame = ZCOMPL;
										send_h16(&tzh16,1);
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZSINIT)
										{
										if (tzh32.zh32_zpzf[ZF0] & TESCCTL || tzh32.zh32_zpzf[ZF0] & TESC8)		/* sorry, escaped ctrl and 8th bit stuff ain't done here */
											state = _ABORT;
	 									else
											{
											/* check and collect Attn string */
											get_zpacket(headertype,&len,&frametype);
											if (len)
												{
												if (len > MAX_ATTN)
													len = MAX_ATTN;
												memcpy(attn,send,len);
												attn[len + 1] = (char)'\0';
												}

											memset(&tzh16,0,sizeof(struct zh16));
											tzh16.zh16_frame = ZACK;
											send_h16(&tzh16,1);
											}
										}
									else if (tzh32.zh32_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									}
								else
									{
									memcpy(&tzh16,vptr,sizeof(struct zh16));
									if (tzh16.zh16_frame == ZFILE)
										{
										state = _GETFILEINFO;
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZCOMMAND)	/* if we see this, we send back a completed status */
										{
										write_string(new_color(RED | BRIGHT));
										write_string("Got ZCOMMAND and returning ZCOMPL header.\r\n");
										memset(&tzh16,0,sizeof(struct zh16));		
										tzh16.zh16_frame = ZCOMPL;
										send_h16(&tzh16,1);
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZSINIT)
										{
										if (tzh16.zh16_zpzf[ZF0] & TESCCTL || tzh16.zh16_zpzf[ZF0] & TESC8)		/* sorry, escaped ctrl and 8th bit stuff ain't done here */
											state = _ABORT;
										else
											{
											/* check and collect Attn string */
											get_zpacket(headertype,&len,&frametype);
											if (len)
												{
												if (len > MAX_ATTN)
													len = MAX_ATTN;
												memcpy(attn,send,len);
												attn[len + 1] = (char)'\0';
												}

											memset(&tzh16,0,sizeof(struct zh16));
											tzh16.zh16_frame = ZACK;
											send_h16(&tzh16,1);
											}
										}
									else if (tzh16.zh16_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									}
								}
							cans = 0;
							}
						}
					else if (inbyte == CAN)		/* is it a CAN? */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							}
						}
					else
						cans = 0;
					}
				if (state == _LISTEN && inbyte == -1)
					{
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					else
						sleep(750);
					}
				break;

			case _GETFILEINFO:
				write_string(new_color(CYAN | BRIGHT));
				write_string("\rWaiting for filename....      \b\b\b\b\b\b");

				error = get_zpacket(headertype,&len,&frametype);
				if (error == ZPKT_OK)
					{
					count = 0;
					kount = 0;
					while (send[count] && send[count] != ' ' && count < len)
						{
						file[kount] = send[count];
						++kount;
						++count;
						}
					file[kount] = '\0';

					++count;
					kount = 0;
					while (send[count] != ' ' && count < len)
						{
						buffer[kount] = send[count];
						++kount;
						++count;
						}
					buffer[kount] = '\0';
					filelen = atol(buffer);

					++count;
					kount = 0;
					while (send[count] && send[count] != ' ' && count < len)		/* retrieve octal time string */
						{
						buffer[kount] = send[count];
						++kount;
						++count;
						}
					buffer[kount] = '\0';
					if (strlen(buffer) && isdigit(buffer[0]))
						ftime = (time_t)strtoul(buffer,&cptr,8);
					else
						ftime = (time_t)-1L;

					cptr = file;		/* in case we get a UNIX formatted filename */
					while (*cptr)
						{
						if (*cptr == '/')
							*cptr = P_CSEP;
						++cptr;
						}

					_splitpath(file,pathname,pathname,fname,ext);
					if (fname[8])
						fname[8] = '\0';
					_makepath(file,"","",fname,ext);

					if (verify == NULL || (*verify)(file))
						{
						if (!(fd = file_create(file,tfile->file_pathname)))
							{
							write_string(new_color(BROWN | BRIGHT));
							write_string("\rZmodem Receive: ");
							write_string(new_color(RED | BRIGHT));
							write_string("Unable to open \"");
							write_string(file);
							write_string("\" -> Aborted transfer\r\n");
							memset(&tzh16,0,sizeof(struct zh16));		
							tzh16.zh16_frame = ZFERR;
							send_h16(&tzh16,1);
							state = _ABORT;
							}
						else
							{
							write_string(new_color(BROWN | BRIGHT));
							if (headertype)
								write_string("\r\n\nZmodem CRC-32 Receive: ");
							else 
								write_string("\r\n\nZmodem CRC-16 Receive: ");
							write_string(new_color(WHITE | BRIGHT));
							write_string(file);
							if (filelen)
								{
								write_string(new_color(GREEN | BRIGHT));
								cptr = parse_long(filelen);
								sprintf(buffer," (%s bytes)",cptr);
								write_string(buffer);
								}
							write_string("\r\n");
							write_string(new_color(WHITE));
							write_string("Waiting...");

							curlen = 0L;

							memset(&tzh16,0,sizeof(struct zh16));		
							tzh16.zh16_frame = ZRPOS;
							put_zlong(tzh16.zh16_zpzf,curlen);
							send_attention();		/* send an Attn string if we have one! */
							send_h16(&tzh16,1);

							resume = 0;
							garbage = 0;
							state = _GETHEADER;
							}
						}
					else		/* verify function indicated to skip */
						{
						write_string(new_color(BROWN | BRIGHT));
						write_string("\rZmodem Receive: ");
						write_string(new_color(WHITE | BRIGHT));
						write_string(file);
						write_string(new_color(RED | BRIGHT));
						write_string(" -> Skipping\r\n");
						memset(&tzh16,0,sizeof(struct zh16));		
						tzh16.zh16_frame = ZSKIP;
						send_h16(&tzh16,1);
						state = _LISTEN;
						}
					}
				else if (error == ZPKT_TIMEOUT)
					{
					write_string(new_color(RED | BRIGHT));
					write_string(" -> Timeout\r\n");
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					}
				else if (error == ZPKT_ABORT)
					state = _OTHER_ABORT;
				else
					{
					write_string(new_color(RED | BRIGHT));
					write_string(" -> Packet Error: ");

					switch (error)
						{
						case ZPKT_CRC:
							write_string("Invalid CRC\r\n");
							break;
						case ZPKT_TOOLONG:
							write_string("Packet too long\r\n");
							break;
						case ZPKT_INVALID_ESC:
							write_string("Invalid ZDLE-escaped character\r\n");
							break;
						default:
							write_string("Unknown error\r\n");
							break;
						}

					memset(&tzh16,0,sizeof(struct zh16));		
					tzh16.zh16_frame = ZNAK;
					send_h16(&tzh16,1);

					purge_input(cfg.cfg_port);		/* purge buffers and swing around for another pass */
					state = _LISTEN;
					retry = 0;
					}
				break;

			case _GETFILEDATA:
				resume = 0;
				error = get_zpacket(headertype,&len,&frametype);
				if (error == ZPKT_OK)
					{
					if (len)
						{
						if (!fwrite(send,len,sizeof(char),fd))
							{
							write_string(new_color(RED | BRIGHT));
							write_string(" -> Error writing file -> Aborting\r\n");
							memset(&tzh16,0,sizeof(struct zh16));		
							tzh16.zh16_frame = ZFERR;
							send_h16(&tzh16,1);
							state = _ABORT;
							}
						else
							{
							fflush(fd);
							curlen += (long)len;
							sprintf(buffer,"\rReceived %ld bytes (%d)    \b\b\b\b",curlen,len);
							write_string(buffer);
							}
						}
					if (frametype == ZCRCQ || frametype == ZCRCW)
						{
						memset(&tzh16,0,sizeof(struct zh16));
						tzh16.zh16_frame = ZACK;
						put_zlong(tzh16.zh16_zpzf,curlen);
						send_h16(&tzh16,1);
						}
					if (frametype == ZCRCE || frametype == ZCRCW)
						{
						garbage = 0;
						state = _GETHEADER;
						}
					retry = 0;
					}
				else if (error == ZPKT_TIMEOUT)
					{
					write_string(new_color(RED | BRIGHT));
					write_string(" -> Timeout\r\n");
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					}
				else if (error == ZPKT_ABORT)
					state = _OTHER_ABORT;
				else
					{
					write_string(new_color(RED | BRIGHT));
					write_string(" -> Packet Error: ");

					switch (error)
						{
						case ZPKT_CRC:
							write_string("Invalid CRC\r\n");
							break;
						case ZPKT_TOOLONG:
							write_string("Packet too long\r\n");
							break;
						case ZPKT_INVALID_ESC:
							write_string("Invalid ZDLE-escaped character\r\n");
							break;
						default:
							write_string("Unknown error\r\n");
							break;
						}

					state = _FILEERROR;
					retry = 0;
					}
				break;

			case _GETHEADER:
				if ((inbyte = recv_char_fast()) != -1)
					{
					if (inbyte == '*')		/* check for return info from receiver */
						{
						if (vptr = get_zheader(1,&headertype))
							{
							if (((struct zh16 *)vptr)->zh16_frame == ZCAN)
								state = _OTHER_ABORT;
							else if (check_zheader_crc(vptr,headertype))
								{
								write_string(new_color(RED | BRIGHT));
								write_string("CRC Error in received header.\r\n");
								memset(&tzh16,0,sizeof(struct zh16));
								tzh16.zh16_frame = ZNAK;
								send_h16(&tzh16,1);
								}
							else
								{
								if (headertype)
									{
									memcpy(&tzh32,vptr,sizeof(struct zh32));
									if (tzh32.zh32_frame == ZEOF)
										{
										if (get_zlong(tzh32.zh32_zpzf) == curlen)
											{
											write_string(new_color(GREEN | BRIGHT));
											write_string(" -> Received!\r\n");
											state = _END;
											}
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZDATA)
										{
										if (get_zlong(tzh32.zh32_zpzf) == curlen)
											state = _GETFILEDATA;
										else
											{
											memset(&tzh16,0,sizeof(struct zh16));		
											tzh16.zh16_frame = ZRPOS;
											put_zlong(tzh16.zh16_zpzf,curlen);
											send_attention();		/* send an Attn string if we have one! */
											send_h16(&tzh16,1);
											}
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									else if (tzh32.zh32_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									}
								else
									{
									memcpy(&tzh16,vptr,sizeof(struct zh16));
									if (tzh16.zh16_frame == ZEOF)
										{
										if (get_zlong(tzh16.zh16_zpzf) == curlen)
											{
											write_string(new_color(GREEN | BRIGHT));
											write_string(" -> Received!\r\n");
											state = _END;
											}
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZDATA)
										{
										if (get_zlong(tzh16.zh16_zpzf) == curlen)
											state = _GETFILEDATA;
										else
											{
											memset(&tzh16,0,sizeof(struct zh16));		
											tzh16.zh16_frame = ZRPOS;
											put_zlong(tzh16.zh16_zpzf,curlen);
											send_attention();		/* send an Attn string if we have one! */
											send_h16(&tzh16,1);
											}
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZFERR)
										{
										state = _OTHER_ABORT;
										retry = 0;
										}
									else if (tzh16.zh16_frame == ZFIN)
										{
										state = _ENDOFSESSION;
										retry = 0;
										}
									}
								}
							cans = 0;
							}
						}
					else if (inbyte == CAN)		/* is it a CAN? */
						{
						++cans;
						if (cans >= 5)
							{
							state = _OTHER_ABORT;
							purge_output(cfg.cfg_port);		/* purge buffers and swing around for another pass */
							}
						}
					else
						{
						cans = 0;
						++garbage;
						if (resume && garbage >= MAX_GARBAGE)
							{
							write_string(new_color(RED | BRIGHT));
							write_string("-> Garbage?\r\n");
							state = _FILEERROR;
							}
						}
					}
				if (state == _GETHEADER && inbyte == -1)
					{
					++retry;		/* timeout every 2 seconds int get_zheader */
					if (retry >= Z_RETRY)
						state = _TIMEOUT;
					else
						sleep(1000);
					}
				break;

			case _FILEERROR:
				write_string(new_color(WHITE));
				sprintf(buffer,"Resume at %ld",curlen);
				write_string(buffer);

				purge_input(cfg.cfg_port);

				memset(&tzh16,0,sizeof(struct zh16));		
				tzh16.zh16_frame = ZRPOS;
				put_zlong(tzh16.zh16_zpzf,curlen);
				send_attention();		/* send an Attn string if we have one! */
				send_h16(&tzh16,1);

				resume = 1;
				garbage = 0;
				state = _GETHEADER;
				break;

			case _TIMEOUT:
				write_string(new_color(RED | BRIGHT));
				write_string(" -> Timeout.  Aborting\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;

			case _OTHER_ABORT:
				write_string(new_color(RED | BRIGHT));
				write_string(" -> Other side aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;

			case _SYSOPABORT:
				write_string(new_color(RED | BRIGHT));
				write_string("-> Sysop aborted transfer\r\n");
				write_string(new_color(WHITE));
				state = _ABORT;
				break;

            case _ABORT:
				for (count = 0; count < 2; count++)
					{
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast(CAN);
						sleep(50);
						}
					sleep(500);
					for (kount = 0; kount < 8; kount++)
						{
						send_char_fast('\b');
						sleep(50);
						}
					sleep(1000);
					}
			
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was aborted!\r\n",NULL);
				quit = 1;
				break;

            case _END:
				write_string(new_color(WHITE));
				write_string("Closing file...");
				if (fd)
					{
					if (ftime != (time_t)-1L)			/* set correct file times */
						set_filetime(fileno(fd),(long)ftime);
					
					fprintf(listfd,"OK  %s %lu\r\n",file,curlen);
					closef(fd);
					fd = NULL;
					}

				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZRINIT;
				tzh16.zh16_zpzf[ZF0] = CANFDX | CANOVIO | CANFC32;
				send_h16(&tzh16,1);
				total_size += curlen;
				sleep(2000);

				filelen = 0L;
				curlen = 0L;
				retry = 0;
				state = _LISTEN;
				break;

			case _ENDOFSESSION:
				write_string(new_color(CYAN | BRIGHT));
				write_string(" -> End of session\r\n");
				memset(&tzh16,0,sizeof(struct zh16));
				tzh16.zh16_frame = ZFIN;
				send_h16(&tzh16,1);
				actual_time = xfer_time() - actual_time;
				sleep(1000);

				/* wait for "OO" */
				if ((inbyte = recv_protocol_char(Z_TIMEOUT)) == 'O')
					recv_protocol_char(Z_TIMEOUT);

				show_ulstats(total_size,actual_time,PROT_ZMODEM);
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("\r\n\r\nTransfer was completed successfully!\r\n",NULL);
				quit = 1;
				break;
			}
		update_clock();
		}
	while (!quit);
	if (fd)
		{
		fprintf(listfd,"BAD %s 0\r\n",file);
		closef(fd);
		}
	fflush(listfd);

	unhold_protocol();
	if (!(user.user_flags & USER_ANSI) || (user_baud < cfg.cfg_ansibaud && user_baud))
		write_string(new_color(WHITE));
	get_enter();
	}
