/* s_drop.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 10 June 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_drop.c_v  $
**                       $Date:   25 Oct 1992 14:06:56  $
**                       $Revision:   1.4  $
**
*/


#include <stdio.h>
#include "simplex.h"



struct uf
	{
	char uf_name[41];				/* nul-terminated user name, first last */
	char uf_password[16];			/* nul-terminated password */
	char uf_city[31];				/* nul-terminated city, state */
	char uf_home[15];				/* nul-terminated user's home number */
	char uf_data[15];				/* nul-terminated user's data/business number */
	char uf_screenlen;				/* length of users screen in lines */
	int uf_flags;					/* bit mapped flags for options */
	};



