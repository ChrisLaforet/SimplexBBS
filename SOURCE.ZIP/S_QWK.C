/* s_qwk.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 14 December 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_qwk.c_v  $
**                       $Date:   25 Oct 1992 14:07:42  $
**                       $Revision:   1.1  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include <process.h>
#include <setjmp.h>
#ifdef PROTECTED
	#define INCL_DOSPROCESS
	#include <os2.h>
#endif
#ifdef XSPAWN
	#include <xspawn.h>
#endif
#include "simplex.h"



#ifndef PROTECTED
	extern int stdout_flag;
#endif


static int arc_flags = 0;
extern jmp_buf reset_bbs;


char _far qwk_welcome[20];
char _far qwk_news[20];
char _far qwk_goodbye[20];



int qwkarc_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'A':
			if (arc_flags & ARC_FLAG)
				return 'A';
			break;
		case 'Z':
			if (arc_flags & ZIP_FLAG)
				return 'Z';
			break;
		case 'L':
			if (arc_flags & LZH_FLAG)
				return 'L';
			break;
		case 'R':
			if (arc_flags & ARJ_FLAG)
				return 'R';
			break;
		case 'O':
			if (arc_flags & ZOO_FLAG)
				return 'O';
			break;
		case 'X':
			return 'X';
			break;
		}
	return 0;
	}



#if 0
	long basic2long(long bval)
		{
		long lval;
		int neg = 0;
		int exp = 0;

		if (bval & 0x800000L)
			neg = 1;
		exp = (int)((bval >> 24L) & 0xffL);
		lval = bval & 0x7fffffL;
		lval |= 0x800000L;
		exp -= 152;
		if (!exp)
			lval = 0;
		else if (exp < 0)
			{
			exp = 0 - exp;
			lval >>= exp;
			}
		else 
			lval <<= exp;
		if (neg)
			lval = 0L - lval;
		return lval;
		}
#endif



long long2basic(long lval)
	{
	long bval = 0L;
	int neg = 0;
	int exp;

	if (lval)
		{
		if (lval < 0L)
			{
			neg = 1;
			lval = 0L - lval;
			}
		exp = 152;
		if (lval < 0x7fffffL)
			{
			while (!(lval & 0x800000L))
				{
				lval <<= 1L;
				--exp;
				}
			}
		else
			{
			while (lval & 0xff000000L)
				{
				lval >>= 1L;
				++exp;
				}
			}
		lval &= 0x7fffffL;
		if (neg)
			lval |= 0x800000L;
		bval = lval | ((long)exp << 24L);
		}
	return bval;
	}



int qwk_control(void)
	{
	struct msg *tmsg;
	char buffer[100];
	char buffer1[20];
	char fname[100];
	DATE_T tdate;
	TIME_T ttime;
	int areas = 0;
	int count;
	FILE *fd;

	strcpy(buffer,cfg.cfg_fapath);
	if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
		strcat(buffer,P_SSEP);
	strcat(buffer,"messages.dat");
	unlink(buffer);

	strcpy(fname,cfg.cfg_fapath);
	if (fname[0] && fname[strlen(fname) - 1] != P_CSEP)
		strcat(fname,P_SSEP);
	strcat(fname,"control.dat");
	if (fd = fopen(fname,"wb"))
		{
		if (!fprintf(fd,"%s\r\n",cfg.cfg_bbsname))
			{
			fclose(fd);
			return 1;
			}
		if (!fprintf(fd,"Unknown\r\n"))			/* city, state */
			{
			fclose(fd);
			return 1;
			}
		if (!fprintf(fd,"000-000-0000\r\n"))	/* phone */
			{
			fclose(fd);
			return 1;
			}
		if (!fprintf(fd,"%s,Sysop\r\n",cfg.cfg_sysopname))
			{
			fclose(fd);
			return 1;
			}
		if (cfg.cfg_qwkname[0])
			{
			strupr(cfg.cfg_qwkname);
			if (!fprintf(fd,"0,%s\r\n",cfg.cfg_qwkname))
				{
				fclose(fd);
				return 1;
				}
			}
		else
			{
			if (!fprintf(fd,"0,SIMPLEX\r\n"))
				{
				fclose(fd);
				return 1;
				}
			}
		tdate = get_cdate();
		ttime = get_ctime();
		sprintf(buffer,"%02u-%02u-%02u,%02u:%02u:00",(tdate >> 5) & 0xf,tdate & 0x1f,((tdate >> 9) + 80) % 100,
			ttime >> 11,(ttime >> 5) & 0x3f);
		if (!fprintf(fd,"%s\r\n",buffer))
			{
			fclose(fd);
			return 1;
			}
		sprintf(buffer,"%s %s",user_firstname,user_lastname);
		strupr(buffer);
		if (!fprintf(fd,"%s\r\n",buffer))
			{
			fclose(fd);
			return 1;
			}
		if (!fprintf(fd,"\r\n0\r\n0\r\n"))
			{
			fclose(fd);
			return 1;
			}

		for (count = get_minmsgarea(); count <= get_maxmsgarea(); count++)
			{
			if (tmsg = get_msgarea(count))
				{
				if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
					++areas;
				}
			}
		if (!fprintf(fd,"%u\r\n",areas - 1))
			{
			fclose(fd);
			return 1;
			}

		for (count = get_minmsgarea(); count <= get_maxmsgarea(); count++)
			{
			if (tmsg = get_msgarea(count))
				{
				strcpy(buffer,cfg.cfg_fapath);
				if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
					strcat(buffer,P_SSEP);
				sprintf(buffer1,"%03u.ndx",count);
				strcat(buffer,buffer1);
				unlink(buffer);

				if (user.user_priv >= tmsg->msg_readpriv && (tmsg->msg_readflags & user.user_uflags) == tmsg->msg_readflags)
					{
					if (!fprintf(fd,"%u\r\n",tmsg->msg_number))
						{
						fclose(fd);
						return 1;
						}

					if (!fprintf(fd,"%.12s\r\n",tmsg->msg_areaname))
						{
						fclose(fd);
						return 1;
						}
					}
				}
			}

		strcpy(buffer,cfg.cfg_screenpath);
		if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);

		sprintf(fname,"%sWELCOME.ANS",buffer);
		if (!access(fname,0))
			strcpy(qwk_welcome,"WELCOME.ANS");
		else
			{
			sprintf(fname,"%sWELCOME.ASC",buffer);
			if (!access(fname,0))
				strcpy(qwk_welcome,"WELCOME.ASC");
			else 
				qwk_welcome[0] = (char)'\0';
			}

		if (!fprintf(fd,"%s\r\n",qwk_welcome))
			{
			fclose(fd);
			return 1;
			}

		sprintf(fname,"%sBULLETIN.ANS",buffer);
		if (!access(fname,0))
			strcpy(qwk_news,"BULLETIN.ANS");
		else
			{
			sprintf(fname,"%sBULLETIN.ASC",buffer);
			if (!access(fname,0))
				strcpy(qwk_news,"BULLETIN.ASC");
			else 
				qwk_news[0] = (char)'\0';
			}

		if (!fprintf(fd,"%s\r\n",qwk_news))
			{
			fclose(fd);
			return 1;
			}


		sprintf(fname,"%sGOODBYE.ANS",buffer);
		if (!access(fname,0))
			strcpy(qwk_goodbye,"GOODBYE.ANS");
		else
			{
			sprintf(fname,"%sGOODBYE.ASC",buffer);
			if (!access(fname,0))
				strcpy(qwk_goodbye,"GOODBYE.ASC");
			else 
				qwk_goodbye[0] = (char)'\0';
			}

		if (!fprintf(fd,"%s\r\n",qwk_goodbye))
			{
			fclose(fd);
			return 1;
			}

		fclose(fd);

		strcpy(fname,cfg.cfg_fapath);
		if (fname[0] && fname[strlen(fname) - 1] != P_CSEP)
			strcat(fname,P_SSEP);
		strcat(fname,"door.id");
		if (fd = fopen(fname,"wb"))
			{
#ifdef PROTECTED
			if (!fprintf(fd,"DOOR = Simplex/2 BBS\r\n"))
#else
			if (!fprintf(fd,"DOOR = Simplex BBS\r\n"))
#endif
				{
				fclose(fd);
				return 1;
				}
			if (!fprintf(fd,"VERSION = %u.%02u.%02u\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION))
				{
				fclose(fd);
				return 1;
				}
#ifdef PROTECTED
			if (!fprintf(fd,"SYSTEM = Simplex/2 %u.%02u.%02u\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION))
#else
			if (!fprintf(fd,"SYSTEM = Simplex %u.%02u.%02u\r\n",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION))
#endif
				{
				fclose(fd);
				return 1;
				}

			fclose(fd);
			return 0;
			}
		}
	return 1;
	}



int pascal qwk_message(int msg_num,int total_msgs,struct msg *tmsg,int new,FILE *fd,FILE *ndxfd)
	{
	struct msgh tmsgh;
	struct msgh tmsgh1;
	struct mlink tmlink;
	struct qwkh tqwkh;
	struct qwkndx tqwkndx;
	char block[130];
	char buffer[100];
	char from[41];
	char to[41];
	char *cptr;
	char *cptr1;
	long total = 0L;
	long offset;
	long diff;
	int tlen;
	int len;
	int blocks = 1;

	if (fd)
		{
		fseek(msghfd,(long)(msg_num - 1) * (long)sizeof(struct msgh),SEEK_SET);
		fread(&tmsgh,1,sizeof(struct msgh),msghfd);

		strcpy(to,get_addressee(tmsgh.msgh_to));
		strcpy(from,get_addressee(tmsgh.msgh_from));
		if (!(tmsgh.msgh_flags & MSGH_PRIVATE) || ((tmsgh.msgh_flags & MSGH_PRIVATE) &&
			(user.user_priv >= tmsg->msg_sysoppriv || check_name(to) || check_name(from) || (tmsgh.msgh_flags & MSGH_URGENT))))
			{
			++user.user_msgread;			/* increment the messages read in userfile */
			++userinfo.ui_msgread;			/* increment the messages read this session counter */
			mark_read(tmsgh.msgh_area);		/* indicates area was read from */

			if (!(tmsgh.msgh_flags & MSGH_LOCAL_FILEATTACH) && check_name(to) && !(tmsgh.msgh_flags & MSGH_RECEIVED))
				{
				tmsgh.msgh_flags |= MSGH_RECEIVED;
				fseek(msghfd,(long)(msg_num - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fwrite(&tmsgh,1,sizeof(struct msgh),msghfd);
				fflush(msghfd);

				fseek(msglfd,(long)(msg_num - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fread(&tmlink,sizeof(struct mlink),1,msglfd);
				tmlink.mlink_flags |= MSGH_RECEIVED;
				fseek(msglfd,(long)(msg_num - 1) * (long)sizeof(struct mlink),SEEK_SET);
				fwrite(&tmlink,sizeof(struct mlink),1,msglfd);
				fflush(msglfd);							  
				}

			/* let's prepare the QWK header */
			memset(&tqwkh,' ',sizeof(struct qwkh));

			if (tmsgh.msgh_flags & MSGH_RECEIVED)
				{
				if (tmsgh.msgh_flags & MSGH_PRIVATE)
					tqwkh.qwkh_status = '*';
				else 
					tqwkh.qwkh_status = '-';
				}
			else
				{
				if (tmsgh.msgh_flags & MSGH_PRIVATE)
					tqwkh.qwkh_status = '+';
				else 
					tqwkh.qwkh_status = ' ';
				}
			sprintf(buffer,"%u",tmsgh.msgh_number);
			strncpy(tqwkh.qwkh_number,buffer,strlen(buffer));

			sprintf(buffer,"%02u-%02u-%02u",(tmsgh.msgh_date >> 5) & 0xf,tmsgh.msgh_date & 0x1f,((tmsgh.msgh_date >> 9) + 80) % 100);
			strncpy(tqwkh.qwkh_date,buffer,8);

			sprintf(buffer,"%02u:%02u",tmsgh.msgh_time >> 11,(tmsgh.msgh_time >> 5) & 0x3f);
			strncpy(tqwkh.qwkh_time,buffer,5);

			if (tmsgh.msgh_flags & MSGH_URGENT)
				strcpy(buffer,user.user_name);
			else
				strcpy(buffer,tmsgh.msgh_to);
			strupr(buffer);
			len = (int)strlen(buffer);
			if (len > 25)
				len = 25;
			strncpy(tqwkh.qwkh_to,buffer,len);

			strcpy(buffer,tmsgh.msgh_from);
			strupr(buffer);
			len = (int)strlen(buffer);
			if (len > 25)
				len = 25;
			strncpy(tqwkh.qwkh_from,buffer,len);

			strcpy(buffer,tmsgh.msgh_subject);
			strupr(buffer);
			len = (int)strlen(buffer);
			if (len > 25)
				len = 25;
			strncpy(tqwkh.qwkh_subject,buffer,len);

			if (tmsgh.msgh_prev)
				{
				fseek(msghfd,(long)(tmsgh.msgh_prev - 1) * (long)sizeof(struct msgh),SEEK_SET);
				fread(&tmsgh1,sizeof(struct msgh),1,msghfd);

				sprintf(buffer,"%u",tmsgh1.msgh_number);			/* previous message */
				strncpy(tqwkh.qwkh_refnum,buffer,strlen(buffer));
				}
			if (tmsgh.msgh_flags & MSGH_DELETED)
				tqwkh.qwkh_flag = (char)0xe2;
			else 
				tqwkh.qwkh_flag = (char)0xe1;
			tqwkh.qwkh_conf = tmsg->msg_number;

			fseek(fd,0L,SEEK_END);
			offset = ftell(fd);				/* hold our position for later use */

			if (!offset)		/* this is the first message header -> we must put out a packet header */
				{
				memset(block,' ',sizeof(block));
#ifdef PROTECTED
				sprintf(block,"Produced by Simplex/2 BBS (v %d.%02d.%02d).",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION);
#else
				sprintf(block,"Produced by Simplex BBS (v %d.%02d.%02d).",MAJOR_VERSION,MINOR_VERSION,SUB_VERSION);
#endif
				if (!fwrite(block,128,1,fd))
					return 1;

				offset = ftell(fd);				/* hold our position for later use */
				}

			if (!fwrite(&tqwkh,sizeof(struct qwkh),1,fd))
				return 1;

			/* prepare and enter the index */
			memset(&tqwkndx,0,sizeof(struct qwkndx));
			tqwkndx.qwkndx_ptr = long2basic((offset / 128L) + 1L);
			fseek(ndxfd,0L,SEEK_END);
			if (!fwrite(&tqwkndx,sizeof(struct qwkndx),1,ndxfd))
				return 1;

			memset(block,' ',sizeof(block));
			cptr1 = block;

			if (tmsg->msg_flags & MSG_NET)		/* per Brady Flowers: Maximus does it this way */
				{
				sprintf(block,"From: %u:%u/%u\r\n",tmsgh.msgh_szone,tmsgh.msgh_snet,tmsgh.msgh_snode);
				cptr1 = block + strlen(block);
				*cptr1 = ' ';
				}

			fseek(msgbfd,tmsgh.msgh_offset,SEEK_SET);
			while (total < tmsgh.msgh_length)
				{
				diff = tmsgh.msgh_length - total;
				if (diff >= (long)sizeof(buffer))
					len = sizeof(buffer);
				else
					len = (int)diff;

				fread(buffer,len,1,msgbfd);
	
				cptr = buffer;
				tlen = 0;
				while (tlen < len)
					{
					while (*cptr && *cptr != '\r' && *cptr != '\n' && *cptr != '\x8d' && tlen < len)
						{
						if (*cptr != '\x1')			/* Ctrl-A */
							*cptr1++ = *cptr++;
						else
							{
							*cptr1++ = '^';
							if ((cptr1 - block) >= 128)
								{
								if (!fwrite(block,128,1,fd))
									return 1;
								++blocks;
								memset(block,' ',sizeof(block));
								cptr1 = block;
								}
							*cptr1++ = 'a';
							++cptr;
							}
						if ((cptr1 - block) >= 128)
							{
							if (!fwrite(block,128,1,fd))
								return 1;
							++blocks;
							memset(block,' ',sizeof(block));
							cptr1 = block;
							}
						++tlen;
						}
					if (tlen < len)
						{
						if (*cptr == '\r' || *cptr == '\n')
							*cptr1++ = (char)0xe3;
						++tlen;
						++cptr;
						}

					if ((cptr1 - block) >= 128)
						{
						if (!fwrite(block,128,1,fd))
							return 1;
						++blocks;
						memset(block,' ',sizeof(block));
						cptr1 = block;
						}
					}
				total += (long)len;
				}

			if (cptr1 - block)
				{
				if (!fwrite(block,128,1,fd))
					return 1;
				++blocks;
				}

			/* Correct the number of blocks in the header! */
			fseek(fd,offset,SEEK_SET);
			sprintf(buffer,"%u",blocks);
			strncpy(tqwkh.qwkh_blks,buffer,strlen(buffer));
			if (!fwrite(&tqwkh,sizeof(struct qwkh),1,fd))
				return 1;
			fseek(fd,0L,SEEK_END);
			}
		}
	return 0;
	}



void init_archiver(void)
	{
	/* close file handles and spawn archiver */
	fclose(userfd);
	fclose(uinfofd);
	if (msghfd)
		fclose(msghfd);
	if (msgbfd)
		fclose(msgbfd);
	if (msglfd)
		fclose(msglfd);
	if (msgdfd)
		fclose(msgdfd);
	if (msgrfd)
		fclose(msgrfd);
	if (nlstfd)
		fclose(nlstfd);
	if (nidxfd)
		fclose(nidxfd);
	if (combfd)
		fclose(combfd);

#ifndef PROTECTED
	if (stdout_flag)
		freopen("con","w",stdout);		/* stdout is now pointing to the console device (for fossil signon message!) */
#endif

	bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,WHITE);		/* clear status lines */
	}



void deinit_archiver(void)
	{
	set_inactivetime();

	open_files(1);			/* reinitialize the system */

	if ((bios_getcurpos() >> 8) > bottom_line)
		bios_scrollup(0x0,(bottom_line << 8) | 0x4f,(bios_getcurpos() >> 8) - bottom_line,WHITE);

	bios_clrblk((bottom_line + 1) << 8,((bottom_line + 3) << 8) | 0x4f,status_color[0]);		/* prepare status lines */
	show_user();

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE),NULL);
	else 
		write_string(new_color(WHITE));
	}




int archive_qwk_mail(char *cmdline,char *path,char *filename,int log)
	{
	char **args = NULL;
	int cur_args = 0;
	int max_args = 0;
	char cbuffer[100];
	char buffer[150];
	char buffer1[150];
	char tbuf[100];
	char *cptr;
	char *cptr0;
	char *cptr1;
	char *cptr2;
	int gotfile = 0;
	int gotarc = 0;
	int ok = 0;
	int ctype;
	int rtn;

	strcpy(cbuffer,cmdline);
	cptr = cbuffer;
	cptr0 = cptr;
	while (*cptr0 && *cptr0 != ' ')
		++cptr0;

	while (*cptr)
		{
		if (*cptr0)
			*cptr0++ = (char)'\0';
		ctype = 0;
		cptr1 = cptr;
		while (*cptr1 && *(cptr1 + 1))
			{
			if (*cptr1 == (char)'%')
				{
				if (*(cptr1 + 1) == (char)'a' || *(cptr1 + 1) == (char)'A')
					{
					ctype = 1;
					break;
					}
				if (*(cptr1 + 1) == (char)'f' || *(cptr1 + 1) == (char)'F')
					{
					ctype = 2;
					break;
					}
				}
			++cptr1;
			}

		if ((cur_args + 1) >= max_args)
			{
			if (!(args = realloc(args,(max_args += 5) * sizeof(char *))))
				{
				_error(E_ERROR,"Out of memory to allocate archive args");
				return -1;
				}
			}

		cptr1 = cptr;
		while (isspace(*cptr1))		/* walk off leading spaces */
			++cptr1;
		if (!ctype)
			args[cur_args++] = cptr1;
		else if (ctype == 1)
			{
			cptr2 = buffer;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'a' || *(cptr1 + 1) == (char)'A'))
					{
					strcpy(tbuf,cfg.cfg_fapath);
					if (tbuf[0] && tbuf[strlen(tbuf) - 1] != P_CSEP)
						strcat(tbuf,P_SSEP);
					if (cfg.cfg_qwkname[0])
						{
						strcat(tbuf,cfg.cfg_qwkname);
						strcat(tbuf,".qwk");
						}
					else 
						strcat(tbuf,"simplex.qwk");

					strcpy(cptr2,tbuf);
					cptr2 += strlen(tbuf);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotarc = 1;
			args[cur_args++] = buffer;
			}
		else
			{
			cptr2 = buffer1;
			while (*cptr1)
				{
				if (*cptr1 == (char)'%' && (*(cptr1 + 1) == (char)'f' || *(cptr1 + 1) == (char)'F'))
					{
					strcpy(tbuf,path);
					if (tbuf[0] && tbuf[strlen(tbuf) - 1] != P_CSEP)
						strcat(tbuf,P_SSEP);
					strcat(tbuf,filename);
					strcpy(cptr2,tbuf);
					cptr2 += strlen(tbuf);
					cptr1 += 2;
					}
				else 
					*cptr2++ = *cptr1++;
				}
			gotfile = 1;
			args[cur_args++] = buffer1;
			}
		args[cur_args] = NULL;

		cptr = cptr0;
		while (*cptr0 && *cptr0 != ' ')		/* get next token */
			++cptr0;
		}

	if (gotarc && gotfile)
		{
		if (log)
		 	log_entry(L_DMAIL_ARCHIVE,args[0]);

#ifndef PROTECTED
		stop_timer();
#endif


#ifdef XSPAWN
		rtn = xspawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#else
		rtn = spawnvp(P_WAIT,args[0],args);			/* spawn the archiver */
#endif

#ifndef PROTECTED
		if (!start_timer())
			{
			cptr = "Unable to restart timer process.  Hanging up!";
			_error(E_ERROR,cptr);
			system_message(cptr);
			hangup();
			longjmp(reset_bbs,2);
			}
#endif

		if (!local_flag)
			reinit_fossil(cfg.cfg_port);		/* reinits when BBS is reentered  */

		if (rtn == -1)
			{
			sprintf(buffer,"Failed to spawn archiver (%s).",args[0]);
		 	log_entry(L_DMAIL_ARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else if (rtn)
			{
			sprintf(buffer,"Archiver (%s) failed and reported error %d.",args[0],rtn);
		 	log_entry(L_DMAIL_ARCHIVE_FAILED,buffer);
			system_message(buffer);
			}
		else 
			ok = 1;
		free(args);
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Error: No %A or %F options were found on archiver command.  Notify Sysop!\r\n\r\n",NULL);
		}

	if (!ok)
		return 1;
	return 0;
	}



int send_qwk_mail(void)
	{
	struct fl *tflist[1];
	struct fl tfl;
	char sendname[100];
	char buffer[100];
	char buffer1[20];
	char keys[15];
	int autoarc = 0;
	int retval = 0;
	int quit = 0;
	int err = 0;
	int ok = 0;
	int key;
	int rtn;

	arc_flags = 0;
	if (cfg.cfg_arc[0])
		arc_flags |= ARC_FLAG;
	if (cfg.cfg_zip[0])
		arc_flags |= ZIP_FLAG;
	if (cfg.cfg_lzh[0])
		arc_flags |= LZH_FLAG;
	if (cfg.cfg_arj[0])
		arc_flags |= ARJ_FLAG;
	if (cfg.cfg_zoo[0])
		arc_flags |= ZOO_FLAG;

	strcpy(sendname,cfg.cfg_fapath);
	if (sendname[0] && sendname[strlen(sendname) - 1] != P_CSEP)
		strcat(sendname,P_SSEP);

	if (cfg.cfg_qwkname[0])
		sprintf(buffer1,"%s.qwk",cfg.cfg_qwkname);
	else 
		strcpy(buffer1,"simplex.qwk");
	strcat(sendname,buffer1);

	if (arc_flags)
		{
		if ((tcomb.comb_flags & COMB_USEARC) && (arc_flags & ARC_FLAG))
			{
	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while arcing mail....this will take a while.\r\n\r\n",NULL);

			init_archiver();

			if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"control.dat",1))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"door.id",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"messages.dat",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"*.ndx",0))
				err = 1;
			else
				{
				if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
					archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_welcome,0);
				if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
					archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_news,0);
				if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
					archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_goodbye,0);
				autoarc = 1;
				}
			deinit_archiver();
			}
		else if ((tcomb.comb_flags & COMB_USEZIP) && (arc_flags & ZIP_FLAG))
			{
	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while zipping mail....this will take a while.\r\n\r\n",NULL);

			init_archiver();
			if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"control.dat",1))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"door.id",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"messages.dat",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"*.ndx",0))
				err = 1;
			else
				{
				if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
					archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_welcome,0);
				if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
					archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_news,0);
				if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
					archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_goodbye,0);
				autoarc = 1;
				}
			deinit_archiver();
			}
		else if ((tcomb.comb_flags & COMB_USELZH) && (arc_flags & LZH_FLAG))
			{
	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while lharcing mail....this will take a while.\r\n\r\n",NULL);
	
			init_archiver();
			if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"control.dat",1))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"door.id",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"messages.dat",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"*.ndx",0))
				err = 1;
			else
				{
				if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
					archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_welcome,0);
				if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
					archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_news,0);
				if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
					archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_goodbye,0);
				autoarc = 1;
				}
			deinit_archiver();
			}
		else if ((tcomb.comb_flags & COMB_USEARJ) && (arc_flags & ARJ_FLAG))
			{
	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while arjing mail....this will take a while.\r\n\r\n",NULL);

			init_archiver();
			if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"control.dat",1))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"door.id",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"messages.dat",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"*.ndx",0))
				err = 1;
			else
				{
				if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
					archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_welcome,0);
				if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
					archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_news,0);
				if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
					archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_goodbye,0);
				autoarc = 1;
				}
			deinit_archiver();
			}
		else if ((tcomb.comb_flags & COMB_USEZOO) && (arc_flags & ZOO_FLAG))
			{
	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			send_string("\r\nPlease wait while zooing mail....this will take a while.\r\n\r\n",NULL);

			init_archiver();
			if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"control.dat",1))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"door.id",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"messages.dat",0))
				err = 1;
			else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"*.ndx",0))
				err = 1;
			else
				{
				if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
					archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_welcome,0);
				if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
					archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_news,0);
				if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
					archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_goodbye,0);
				autoarc = 1;
				}
			deinit_archiver();
			}

		if (!autoarc)
			{
			do
				{
				buffer[0] = '\0';
				strcpy(keys,"[ ");
	 			if (arc_flags & ARC_FLAG)
					{
					strcat(buffer,"<A> Arc  ");
					strcat(keys,"A");
					}
	 			if (arc_flags & ZIP_FLAG)
					{
					strcat(buffer,"<Z> Zip  ");
					strcat(keys,"Z");
					}
	 			if (arc_flags & LZH_FLAG)
					{
					strcat(buffer,"<L> Lzh  ");
					strcat(keys,"L");
					}
	 			if (arc_flags & ARJ_FLAG)
					{
					strcat(buffer,"<R> Arj  ");
					strcat(keys,"R");
					}
	 			if (arc_flags & ZOO_FLAG)
					{
					strcat(buffer,"<O> Zoo  ");
					strcat(keys,"O");
					}
				strcat(buffer,"<X> Exit (no d/l)\r\n\r\n");
				strcat(keys,"X ]\r\n\r\n");

				cur_line = 0;			/* defeat more */
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);
				purge_input(cfg.cfg_port);
				key = send_string("\r\n\r\n--- QWK Download Archive Menu ---\r\n\r\n",qwkarc_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						key = send_string(buffer,qwkarc_handler);
					else
						key = send_string(keys,qwkarc_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Exit)? ",qwkarc_handler);
					}
				do
					{
					cur_line = 0;			/* defeat more */
					if (!key)
						key = get_char();
					switch (key)
						{
						case 'A':
						case 'a':
				 			if (arc_flags & ARC_FLAG)
								{
	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while arcing mail....this will take a while.\r\n\r\n",NULL);
						
								init_archiver();
								if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"control.dat",1))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"door.id",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"messages.dat",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arc,cfg.cfg_fapath,"*.ndx",0))
									err = 1;
								else
									{
									if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
										archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_welcome,0);
									if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
										archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_news,0);
									if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
										archive_qwk_mail(cfg.cfg_arc,cfg.cfg_screenpath,qwk_goodbye,0);
									}
								deinit_archiver();
								if (!err)
									quit = 1;
								}
							ok = 1;
							break;
						case 'Z':
						case 'z':
				 			if (arc_flags & ZIP_FLAG)
								{
	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while zipping mail....this will take a while.\r\n\r\n",NULL);

								init_archiver();
								if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"control.dat",1))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"door.id",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"messages.dat",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zip,cfg.cfg_fapath,"*.ndx",0))
									err = 1;
								else
									{
									if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
										archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_welcome,0);
									if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
										archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_news,0);
									if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
										archive_qwk_mail(cfg.cfg_zip,cfg.cfg_screenpath,qwk_goodbye,0);
									}
								deinit_archiver();
								if (!err)
									quit = 1;
								}
							ok = 1;
							break;
						case 'L':
						case 'l':
				 			if (arc_flags & LZH_FLAG)
								{
	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while lharcing mail....this will take a while.\r\n\r\n",NULL);
						
								init_archiver();
								if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"control.dat",1))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"door.id",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"messages.dat",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_fapath,"*.ndx",0))
									err = 1;
								else
									{
									if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
										archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_welcome,0);
									if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
										archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_news,0);
									if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
										archive_qwk_mail(cfg.cfg_lzh,cfg.cfg_screenpath,qwk_goodbye,0);
									}
								deinit_archiver();
								if (!err)
									quit = 1;
								}
							ok = 1;
							break;
						case 'R':
						case 'r':
				 			if (arc_flags & ARJ_FLAG)
								{
	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while arjing mail....this will take a while.\r\n\r\n",NULL);

								init_archiver();
								if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"control.dat",1))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"door.id",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"messages.dat",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_arj,cfg.cfg_fapath,"*.ndx",0))
									err = 1;
								else
									{
									if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
										archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_welcome,0);
									if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
										archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_news,0);
									if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
										archive_qwk_mail(cfg.cfg_arj,cfg.cfg_screenpath,qwk_goodbye,0);
									}
								deinit_archiver();
								if (!err)
									quit = 1;
								}
							ok = 1;
							break;
						case 'O':
						case 'o':
				 			if (arc_flags & ZOO_FLAG)
								{
	 							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 								send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\nPlease wait while zooing mail....this will take a while.\r\n\r\n",NULL);

								init_archiver();
								if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"control.dat",1))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"door.id",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"messages.dat",0))
									err = 1;
								else if (archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_fapath,"*.ndx",0))
									err = 1;
								else
									{
									if ((tcomb.comb_flags & COMB_WELCOME) && qwk_welcome[0])
										archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_welcome,0);
									if ((tcomb.comb_flags & COMB_NEWS) && qwk_news[0])
										archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_news,0);
									if ((tcomb.comb_flags & COMB_GOODBYE) && qwk_goodbye[0])
										archive_qwk_mail(cfg.cfg_zoo,cfg.cfg_screenpath,qwk_goodbye,0);
									}
								deinit_archiver();
								if (!err)
									quit = 1;
								}
							ok = 1;
							break;
						case 'X':
						case 'x':
						case '\r':
						case '\n':
							return 0;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!quit);
			}

		if (!err)
			{
			send_string("\a\a",NULL);
			if (cfg.cfg_qwkname[0])
				sprintf(buffer1,"%s.qwk",cfg.cfg_qwkname);
			else 
				strcpy(buffer1,"simplex.qwk");

			if (!user_baud)
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\n\r\nCopy to where (ENTER=Quit)? ",NULL);
				get_fname(buffer,48,0,1);
				if (buffer[0])
					{
					if (buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
//					strcpy(tfl.fl_name,buffer1);
					tfl.fl_name = buffer1;
					tfl.fl_location = AREA_FATTACH;
					tflist[0] = &tfl;
					copy_out(AREA_FATTACH,buffer,tflist,1);
					}
				}
			else
				{
				do
					{
					rtn = xmit_onefile(AREA_FATTACH,buffer1,1);
					if (!rtn || rtn == 2)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("\nAn error was reported while downloading.\n\n",NULL);
						}
					else if (rtn == 3)
						retval = 1;
					}
				while (!rtn || rtn == 2);
				}
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Error: Unable to prepare QWK file!\r\n\r\n",NULL);
			get_enter();
			}
		}
	else
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(RED | BRIGHT),NULL);
		send_string("Error: No archivers are available to prepare QWK file.  Notify Sysop!\r\n\r\n",NULL);
		get_enter();
		}

	return retval;
	}
