/* s_ads.c
**
** Copyright (c) 1990, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 26 September 1990
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_ad.c_v  $
**                       $Date:   25 Oct 1992 14:08:36  $
**                       $Revision:   1.18  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "simplex.h"





int adread_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'R':
		case 'I':
		case 'S':
		case '?':
		case 'X':
			return key;
			break;
		}
	return 0;
	}





int adread_search_handler(int key)
	{
	key = toupper(key);
	switch (key)
		{
		case 'F':
		case 'S':
		case 'X':
			return key;
			break;
		}
	return 0;
	}



void enter_ads(char *filename,int days,int replies)
	{
	struct adh tadh;
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int kill_date;
	int save = 0;
	int count;
	int ok;
	long offset = -1L;
	FILE *fd;
	int temp;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nPlease wait a few moments...\r\n",NULL);

	strcpy(buffer,bbspath);		/* bulletin/ad files go in main BBS directory */
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	_makepath(buffer,drive,path,fname,".ad");

	if (!(fd = openf(buffer,"r+b")))	
		fd = openf(buffer,"w+b");		/* attempt to create if cannot open */

	if (fd)
		{
		/* now walk the chain of ads to the end */
		while (fread(&tadh,1,sizeof(struct adh),fd))
			{
			offset = ftell(fd) - (long)sizeof(struct adh);
			if (tadh.adh_next == -1L)
				break;
			fseek(fd,tadh.adh_next,SEEK_SET);
			}
		
		memset(&tadh,0,sizeof(struct adh));
		strcpy(tadh.adh_from,user.user_name);
		tadh.adh_date = get_cdate();
		tadh.adh_time = get_ctime();
		tadh.adh_prev = offset;
		tadh.adh_next = -1L;

 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("\r\n\r\nThis will be an advertisement to ALL users.\r\n",NULL);

 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(GREEN | BRIGHT),NULL);
 		send_string("   From: ",NULL);
 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(field_color),NULL);
		send_string(tadh.adh_from,NULL);

 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(GREEN | BRIGHT),NULL);
 		send_string("\r\n Posted: ",NULL);
 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(field_color),NULL);
		temp = ((tadh.adh_date >> 5) & 0xf) - 1;
		if (temp && (temp >= 12 || temp < 0))
			temp = 11;
		sprintf(buffer,"%u %s %02u at %02u:%02u",tadh.adh_date & 0x1f,months_table[temp],((tadh.adh_date >> 9) + 80) % 100,
				tadh.adh_time >> 11,(tadh.adh_time >> 5) & 0x3f);
		send_string(buffer,NULL);

 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
 			send_string(new_color(GREEN | BRIGHT),NULL);
 		send_string("\r\nSubject: ",NULL);
 		get_field(tadh.adh_subject,60,0);
		if (!tadh.adh_subject[0])
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("\r\nBulletin aborted!\r\n",NULL);
			get_enter();
			}
		else
			{
			if (replies)
				{
		 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		 			send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\nDo you want to allow replies to this bulletin (y/N)? ",NULL);
				if (get_yn_enter(0))
					tadh.adh_flags |= ADH_REPLIES;
				}

	 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 			send_string(new_color(GREEN | BRIGHT),NULL);
			kill_date = new_date(tadh.adh_date,days);
			temp = ((kill_date >> 5) & 0xf) - 1;
			if (temp && (temp >= 12 || temp < 0))
				temp = 11;
 			sprintf(buffer,"\r\nDeletion of this bulletin will be in %d days on %u %s %02u.\r\n",days,kill_date & 0x1f,months_table[temp],((kill_date >> 9) + 80) % 100);
 			send_string(buffer,NULL);

			send_string("Do you want to specify a date before this (y/N)? ",NULL);
			if (get_yn_enter(0))
				{
				ok = 0;
				do
					{
					send_string("\r\nEnter date to kill this bulletin [MM-DD-YY] (ENTER=Quit] ",NULL);
					get_date(buffer);
					if (buffer[0])
						{
						if (check_date(buffer))
							{
							temp = convert_date(buffer);
							if (temp > tadh.adh_date && temp <= kill_date)
								{
								tadh.adh_killdate = temp;
								ok = 1;
								}
							else
								{
						 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						 			send_string(new_color(RED | BRIGHT),NULL);
								temp = ((kill_date >> 5) & 0xf) - 1;
								if (temp && (temp >= 12 || temp < 0))
									temp = 11;
 								sprintf(buffer,"\aSorry!  Date must be between today and %u %s %02u!\r\n",kill_date & 0x1f,months_table[temp],((kill_date >> 9) + 80) % 100);
								send_string(buffer,NULL);
						 		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						 			send_string(new_color(GREEN | BRIGHT),NULL);
								}
							}
						else
							{
						 	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						 		send_string(new_color(RED | BRIGHT),NULL);
							send_string("\aInvalid date entered.  Date must be in MM-DD-YY format!\r\n",NULL);
						 	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						 		send_string(new_color(GREEN | BRIGHT),NULL);
							}
						}
					else
						{
	 					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
	 						send_string(new_color(RED | BRIGHT),NULL);
						temp = ((kill_date >> 5) & 0xf) - 1;
						if (temp && (temp >= 12 || temp < 0))
							temp = 11;
 						sprintf(buffer,"\aDeletion of this bulletin defaulted to %d days on %u %s %02u!\r\n",days,kill_date & 0x1f,months_table[temp],((kill_date >> 9) + 80) % 100);
 						send_string(buffer,NULL);
						get_enter();
						tadh.adh_killdate = kill_date;
						ok = 1;
						}
					}
				while (!ok);
				}
			else
				tadh.adh_killdate = kill_date;

			/* now to allow entry of the ad's body */
			if (ask_message_upload())
				save = upload_message();
			else if (user.user_flags & USER_ANSI && (user_baud >= cfg.cfg_ansibaud || !user_baud) && user.user_flags & USER_EDITOR)
				{
				save = fullscreen_edit_message(0,0);
				if (save == -1)
					save = line_edit_message();
				}
			else
				save = line_edit_message();

			if (save)
				{
				/* trim off trailing lines */
				if (cur_mlines)
					{
					count = cur_mlines - 1;
					while (1)
						{
						if (!mlines[count][0] || mlines[count][0] == '\r' || mlines[count][0] == '\x8d')
							{
							free(mlines[count]);
							--cur_mlines;
							}
						else
							break;
						if (!count)
							break;
						--count;
						}
					}
				if (!cur_mlines)
					{
					cur_line = 0;
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(GREEN | BRIGHT),NULL);
					send_string("\r\n\r\nNothing to save as an advertisement!  Cancelling save.",NULL);
					get_enter();
					save = 0;
					}
				}
			if (save)
				{
				cur_line = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(GREEN | BRIGHT),NULL);
				send_string("\r\n\r\nSaving advertisement to disk....",NULL);

				fseek(fd,0L,SEEK_END);
				offset = ftell(fd);
				fwrite(&tadh,1,sizeof(struct adh),fd);	/* reserve our space for header */

				/* now to write out the advertisement body */
				tadh.adh_length = 0L;
				if (max_mlines)
					{
					for (count = 0; count < cur_mlines; count++)
						{
						tadh.adh_length += (long)strlen(mlines[count]);
						fputs(mlines[count],fd);		/* add check for space? */
						free(mlines[count]);
						}
					free(mlines);
					mlines = NULL;
					cur_mlines = 0;
					max_mlines = 0;
					}

				/* update header and write it out */
				fseek(fd,offset,SEEK_SET);
				fwrite(&tadh,1,sizeof(struct adh),fd);
				if (tadh.adh_prev != -1L)		/* update previous header */
					{
					fseek(fd,tadh.adh_prev,SEEK_SET);
					fread(&tadh,1,sizeof(struct adh),fd);
					tadh.adh_next = offset;
					fseek(fd,-(long)sizeof(struct adh),SEEK_CUR);
					fwrite(&tadh,1,sizeof(struct adh),fd);
					}

				log_entry(L_ADENTERED,fname);
				}
			}
		closef(fd);
		}
	else
		{
		sprintf(buffer,"Unable to open bulletin file \"%s\"!!",fname);
		_error(E_ERROR,buffer);
		sprintf(buffer,"Unable to open bulletin file \"%s\" or there are no ads!!",fname);
		system_message(buffer);
		}
	}



void scan_ads(char *filename)
	{
	struct adh tadh;
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	DATE_T today;
	int total = 0;
	int deleted = 0;
	int count;
	int quit = 0;
	int temp;
	int key;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nPlease wait a few moments...\r\n",NULL);

	strcpy(buffer,bbspath);		/* bulletin files go in main BBS directory */
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	_makepath(buffer,drive,path,fname,".ad");

	if (fd = openf(buffer,"r+b"))	
		{
		today = get_cdate();
		/* now walk the chain of ads to the end */
		while (fread(&tadh,1,sizeof(struct adh),fd))
			{
			++total;
			if (tadh.adh_flags & ADH_DELETED)
				++deleted;
			else
				{
				if (tadh.adh_killdate <= today)		/* while scanning, check date of deletion and delete! */
					{
					tadh.adh_flags |= ADH_DELETED;
					++deleted;
					fseek(fd,-(long)sizeof(struct adh),SEEK_CUR);
					fwrite(&tadh,1,sizeof(struct adh),fd);
					fflush(fd);
					}
				}
			if (tadh.adh_next == -1L)
				break;
			fseek(fd,tadh.adh_next,SEEK_SET);
			}

		if (deleted == total)
			{
			cur_line = 0;
			send_string("\r\n\r\nNo advertisements are currently in this area!\r\n",NULL);
			send_string("Why do you not leave one?\r\n",NULL);
			get_enter();
			}
		else
			{
			cur_line = 0;
			send_string("\r\Bul#  From (Sender)                  Posted     Subject\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(BROWN | BRIGHT),NULL);
			send_string("----- -----------------------------  ---------  ------------------------------\r\n",NULL);
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(CYAN),NULL);

			count = 0;
			fseek(fd,0L,SEEK_SET);
			while (fread(&tadh,1,sizeof(struct adh),fd))
				{
				if (!(tadh.adh_flags & ADH_DELETED))
					{
					++count;
					temp = ((tadh.adh_date >> 5) & 0xf) - 1;
					if (temp && (temp >= 12 || temp < 0))
						temp = 11;
					sprintf(buffer,"%5u %-29.29s  %2u %s %02u  %-30.30s\r\n",count,tadh.adh_from,tadh.adh_date & 0x1f,months_table[temp],((tadh.adh_date >> 9) + 80) % 100,tadh.adh_subject);
					send_string(buffer,NULL);
					}
				key = 0;
				if (user_baud)
					{
					if (peek_input(cfg.cfg_port) != -1)
						key = read_input(cfg.cfg_port);
					else 
						key = get_kb();
					}
				else
					key = get_kb();
				switch (key)
					{
					case 'S':
					case 's':
						quit = 1;
						break;
					case 'P':
					case 'p':
						pause_character();
						break;
					}

				if (tadh.adh_next == -1L || quit)
					break;
				fseek(fd,tadh.adh_next,SEEK_SET);
				}
			get_enter();
			}
		closef(fd);
		}
	else
		{
		cur_line = 0;
		send_string("\r\n\r\nNo advertisements are currently in this area!\r\n",NULL);
		send_string("Why do you not leave one?\r\n",NULL);
		get_enter();
		}
	}



int read_individual_ad(int current,struct adh *tadh,FILE *fd)
	{
	char buffer[100];
	long total;
	long diff;
	int temp;
	int len;
	int rtn;

	temp = ((tadh->adh_date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;

	if (user.user_flags & USER_CLS)
		send_string("\f",NULL);
	else
		send_string("\r\n\r\n",NULL);
	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("Bulletin #: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(BROWN | BRIGHT),NULL);
	sprintf(buffer,"%u",current);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n    Posted: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(RED | BRIGHT),NULL);
	temp = ((tadh->adh_date >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"%u %s %02u at %02u:%02u",tadh->adh_date & 0x1f,months_table[temp],((tadh->adh_date >> 9) + 80) % 100,
			tadh->adh_time >> 11,(tadh->adh_time >> 5) & 0x3f);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n   Kill On: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(WHITE | BRIGHT),NULL);
	temp = ((tadh->adh_killdate >> 5) & 0xf) - 1;
	if (temp && (temp >= 12 || temp < 0))
		temp = 11;
	sprintf(buffer,"%u %s %02u",tadh->adh_killdate & 0x1f,months_table[temp],((tadh->adh_killdate >> 9) + 80) % 100);
	send_string(buffer,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n      From: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string(tadh->adh_from,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN | BRIGHT),NULL);
	send_string("\r\n   Subject: ",NULL);
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(MAGENTA | BRIGHT),NULL);
	send_string(tadh->adh_subject,NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN),NULL);
	send_string("\r\n------------------------------------------------------------------------------\r\n\r\n",NULL);

	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(CYAN),NULL);
	total = 0L;
	rtn = 0;
	while (total < tadh->adh_length)
		{
		diff = tadh->adh_length - total;
		if (diff >= (long)sizeof(buffer))
			len = sizeof(buffer);
		else
			len = (int)diff;

		fread(buffer,len,1,fd);

		if (rtn = display_message_line(buffer,len,1,0))
			return rtn;		/* 1 or -1 for next or stop */
		total += (long)len;
		}
	send_string("\r\n",NULL);
	return 0;
	}



int find_individual_ad(int number,int direction,int next,int change,int replies,FILE *fd)
	{
	struct adh tadh;
	char *tonames[2];
	char buffer[100];
	int count;
	int found = 0;
	int rtn = 0;
	int key;
	int ok;
	int quit;
	long offset;

	count = 0;
	fseek(fd,0L,SEEK_SET);
	while (fread(&tadh,1,sizeof(struct adh),fd))
		{
		if (!(tadh.adh_flags & ADH_DELETED))
			{
			++count;
			if (count == number)
				found = 1;
			offset = ftell(fd) - (long)sizeof(struct adh);
			}
		if (found || !tadh.adh_next)
			break;
		fseek(fd,tadh.adh_next,SEEK_SET);
		}
	if (found)
		{
		do
			{
			quit = 1;
			rtn = read_individual_ad(number,&tadh,fd);
			if (rtn != 1)		/* not Next pressed */
				{
				rtn = 0;
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(BROWN | BRIGHT),NULL);
				if (!(user.user_flags & USER_EXPERT))
					send_string(direction == 1 ? "Forward:  " : direction == -1 ? "Backward: " : "Indiv: ",NULL);
				if (next)
					{
					if (!(user.user_flags & USER_EXPERT))
						send_string("<N> Next ",NULL);
					else
						send_string("N",NULL);
					}
				if (change)
					{
					if (!(user.user_flags & USER_EXPERT))
						send_string("<C> Chng Direction ",NULL);
					else
						send_string("C",NULL);
					}
				if (!(user.user_flags & USER_EXPERT))
					send_string("<A> Again ",NULL);
				else
					send_string("A",NULL);
				if (replies && (tadh.adh_flags & ADH_REPLIES))
					{
					if (!(user.user_flags & USER_EXPERT))
						send_string("<R> Reply ",NULL);
					else
						send_string("R",NULL);
					}
				if (check_name(tadh.adh_from) || user.user_priv == 0xff)	/* highest priv we assume is sysop! */
					{
					if (!(user.user_flags & USER_EXPERT))
						send_string("<D> Delete ",NULL);
					else
						send_string("D",NULL);
					}
				if (!(user.user_flags & USER_EXPERT))
					send_string("<X> Exit? ",NULL);
				else
					send_string("X ]? ",NULL);

				ok = 0;
				do
					{
					key = get_char();
					switch (key)
						{
						case 'N':
						case 'n':
							if (next)
								ok = 1;
							break;
						case '\r':
						case '\n':
							ok = 1;
							break;
						case 'C':
						case 'c':
							if (change)
								{
								rtn = -1;
								ok = 1;
								}
							break;
						case 'A':
						case 'a':
							fseek(fd,offset + (long)sizeof(struct adh),SEEK_SET);
							quit = 0;
							ok = 1;
							break;
						case 'R':
						case 'r':
							if (replies && (tadh.adh_flags & ADH_REPLIES))
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nAre you sure that you want to reply to this message (ENTER=Yes)? ",NULL);
								if (get_yn_enter(1))
									{
									sprintf(buffer,"Re: %s",tadh.adh_subject);
									buffer[70] = '\0';		/* cut it down to size in case */

									tonames[0] = tadh.adh_from;
									tonames[1] = NULL;
									do_message(user.user_name,tonames,buffer,replies,0xff,0xffff,0,MESSAGE_PRIVATE,0,0,0,0,0);
									}
								fseek(fd,offset + (long)sizeof(struct adh),SEEK_SET);
								quit = 0;
								ok = 1;
								}
							break;
						case 'D':
						case 'd':
							if (check_name(tadh.adh_from) || user.user_priv == 0xff)
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								send_string("\r\n\r\nAre you sure that you want to delete this message (ENTER=No)? ",NULL);
								if (get_yn_enter(0))
									{
									tadh.adh_flags |= ADH_DELETED;
									fseek(fd,offset,SEEK_SET);
									fwrite(&tadh,1,sizeof(struct adh),fd);
									fseek(fd,0L,SEEK_SET);
									rtn = 2;
									}
								else
									{
									fseek(fd,offset + (long)sizeof(struct adh),SEEK_SET);
									quit = 0;
									}
								ok = 1;
								}
							break;
						case 'X':
						case 'x':
							rtn = 1;
							ok = 1;
							break;
						}
					}
				while (!ok);
				}
			else 
				rtn = 0;		/* returns 0 to go to next! */
			}
		while (!quit);
		}
	return rtn;
	}



void read_ads(char *filename,int replies)
	{
	struct adh tadh;
	char buffer[100];
	char drive[_MAX_DRIVE];
	char path[_MAX_PATH];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int total_ads = 0;
	int deleted = 0;
	DATE_T today;
	int quit;
	int mode;
	int end = 0;
	int rtn;
	int key;
	int ok;
	int direction = 1;
	int found;
	int current;
	long offset;
	FILE *fd;

	cur_line = 0;
	if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
		send_string(new_color(GREEN | BRIGHT),NULL);
	send_string("\r\n\r\nPlease wait a few moments...\r\n",NULL);

	strcpy(buffer,bbspath);		/* bulletin files go in main BBS directory */
	if (buffer[0])
		{
		if (buffer[strlen(buffer) - 1] != P_CSEP)
			strcat(buffer,P_SSEP);
		}
	strcat(buffer,filename);
	_splitpath(buffer,drive,path,fname,ext);
	_makepath(buffer,drive,path,fname,".ad");

	if (fd = openf(buffer,"r+b"))	
		{
		today = get_cdate();
		/* now walk the chain of ads to the end */
		while (fread(&tadh,1,sizeof(struct adh),fd))
			{
			++total_ads;
			if (tadh.adh_flags & ADH_DELETED)
				++deleted;
			else
				{
				if (tadh.adh_killdate <= today)		/* while scanning, check date of deletion and delete! */
					{
					tadh.adh_flags |= ADH_DELETED;
					++deleted;
					fseek(fd,-(long)sizeof(struct adh),SEEK_CUR);
					fwrite(&tadh,1,sizeof(struct adh),fd);
					fflush(fd);
					}
				}
			if (tadh.adh_next == -1L)
				break;
			fseek(fd,tadh.adh_next,SEEK_SET);
			}

		if (deleted == total_ads)
			{
			cur_line = 0;
			send_string("\r\n\r\nNo advertisements are currently in this area!\r\n",NULL);
			send_string("Why do you not leave one?\r\n",NULL);
			get_enter();
			}
		else
			{
			do
				{
				cur_line = 0;			/* defeat more */
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(menu_color),NULL);
				purge_input(cfg.cfg_port);
				key = send_string("\r\n\r\n--- Bulletin Read Menu ---\r\n\r\n",adread_handler);
				if (!key)
					{
					if (!(user.user_flags & USER_EXPERT))
						{
						key = send_string("<F> Read Forward  <R> Read Reverse  <I> Read Individual\r\n",adread_handler);
						if (!key)
							key = send_string("<S> Read Search   <?> Help!  <X> Exit\r\n\r\n",adread_handler);
						}
					else
						key = send_string("[ FRIS?X ]\r\n\r\n",adread_handler);
					if (!key)
						key = send_string("What is your choice (ENTER=Exit)? ",adread_handler);
					}
				ok = 0;
				do
					{
					if (!key)
						key = get_char();
					switch (key)
						{
						case 'F':
						case 'f':
							current = 1;
							direction = 1;
							quit = 0;
							do
								{
								rtn = find_individual_ad(current,direction,1,1,replies,fd);
								if (rtn == 2)		/* bulletin was deleted */
									{
									++deleted;
									if (direction == 1)
										--current;
									}
								if (rtn == 1)
									quit = 1;
								else
									{
									if (rtn == -1)
										direction = direction == 1 ? -1 : 1;
									if (direction == 1)
										++current;
									else
										--current;
									if ((direction == 1 && current > (total_ads - deleted)) || (direction == -1 && !current))
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of advertisements....",NULL);
										quit = 1;
										}
									}
								}
							while (!quit);
							ok = 1;
							break;
						case 'R':
						case 'r':
							current = total_ads - deleted;
							direction = -1;
							quit = 0;
							do
								{
								rtn = find_individual_ad(current,direction,1,1,replies,fd);
								if (rtn == 2)		/* bulletin was deleted */
									{
									++deleted;
									if (direction == 1)
										--current;
									}
								if (rtn == 1)
									quit = 1;
								else
									{
									if (rtn == -1)
										direction = direction == 1 ? -1 : 1;
									if (direction == 1)
										++current;
									else
										--current;
									if ((direction == 1 && current > (total_ads - deleted)) || (direction == -1 && !current))
										{
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										send_string("\r\n\r\nEnd of advertisements....",NULL);
										quit = 1;
										}
									}
								}
							while (!quit);
							ok = 1;
							break;
						case 'I':
						case 'i':
							do
								{
								cur_line = 0;
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(GREEN | BRIGHT),NULL);
								sprintf(buffer,"\r\n\r\nBulletins are numbered from 1 to %u:\r\n",total_ads - deleted);
								send_string(buffer,NULL);
								send_string("Read which bulletin (ENTER to quit)? ",NULL);
								current = get_number(0,total_ads - deleted);

								if (current)
									if (find_individual_ad(current,0,0,0,replies,fd))		/* someone hit X! */
										current = 0;
								}
							while (current);
							ok = 1;
							break;
						case 'S':
						case 's':
							cur_line = 0;

							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(menu_color),NULL);
							purge_input(cfg.cfg_port);

							key = send_string("\r\n\r\n--- Read Search Menu ---\r\n\r\n",adread_search_handler);
							if (!key)
								{
								if (!(user.user_flags & USER_EXPERT))
									key = send_string("<F> From Field    <S> Subject       <X> Exit\r\n\r\n",adread_search_handler);
								else
									key = send_string("[ FSX ]\r\n\r\n",adread_search_handler);
								if (!key)
									key = send_string("What is your choice (ENTER=Exit)? ",adread_search_handler);
								}
							do
								{
								quit = 0;
								if (!key)
									key = get_char();
								switch (key)
									{
									case 'F':
									case 'f':
									case 'S':
									case 's':
										cur_line = 0;
										if (key == 'F' || key == 'f')
											mode = 0;
										else
											mode = 1;
										if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
											send_string(new_color(GREEN | BRIGHT),NULL);
										if (!mode)
											send_string("\r\n\r\nSearch for what in FROM (ENTER=quit)? ",NULL);
										else 
											send_string("\r\n\r\nSearch for what in SUBJECT (ENTER=quit)? ",NULL);
										get_field(buffer,30,1);
										if (buffer[0])
											{
											bm_setup(buffer,1);
											found = 0;
											current = 0;
											offset = 0L;
											quit = 0;

											while (!quit)
												{
												fseek(fd,offset,SEEK_SET);
												if (!fread(&tadh,1,sizeof(struct adh),fd))
													break;
												offset = tadh.adh_next;
												if (!(tadh.adh_flags & ADH_DELETED))
													{
													++current;
													if (mode)
														{
														if (bm_search(tadh.adh_subject) != -1)
															{
															if (find_individual_ad(current,0,1,0,replies,fd) == 1)
																quit = 1;
															found = 1;
															}
														}
													else
														{
														if (bm_search(tadh.adh_from) != -1)
															{
															if (find_individual_ad(current,0,1,0,replies,fd) == 1)
																quit = 1;
															found = 1;
															}
														}
													}
												if (!offset)
													quit = 1;
												}

											if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
												send_string(new_color(GREEN | BRIGHT),NULL);
											if (found)
												send_string("\r\n\r\nEnd of advertisements....",NULL);
											else
												send_string("\r\nSorry. No advertisements were found that met the search criteria!\r\n",NULL);
											}
										quit = 1;
										break;
									case 'X':
									case 'x':
									case '\n':
									case '\r':
										quit = 1;
										break;
									}
								key = 0;
								}
							while (!quit);
							ok = 1;
							break;
						case '?':
							cur_line = 0;
							send_string("\r\n\r\n",NULL);
							cur_line = 0;
							send_ansifile(cfg.cfg_screenpath,"ADHELP",0);
							ok = 1;
							break;
						case 'X':
						case 'x':
						case '\n':
						case '\r':
							ok = 1;
							end = 1;
							break;
						}
					key = 0;
					}
				while (!ok);
				}
			while (!end && deleted != total_ads);


			}
		closef(fd);
		}
	else
		{
		cur_line = 0;
		send_string("\r\n\r\nNo advertisements are currently in this area!\r\n",NULL);
		send_string("Why do you not leave one?\r\n",NULL);
		get_enter();
		}
	}







