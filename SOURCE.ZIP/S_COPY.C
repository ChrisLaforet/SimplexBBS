/* s_copy.c
**
** Copyright (c) 1991, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 17 January 1991
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_copy.c_v  $
**                       $Date:   25 Oct 1992 14:06:52  $
**                       $Revision:   1.12  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef PROTECTED
	#define INCL_DOSFILEMGR
	#include <os2.h>
#else
	#include <dos.h>
#endif
#include "simplex.h"



#define MAX_COPYBUFFER			8192


char _far copybuffer[MAX_COPYBUFFER];			/* must be kept in sync with s_move.c */




void copy_out(int area,char *destpath,struct fl **files,int total_files)
	{
	struct file *tfile;
	struct file *tfile1;
	char src[100];
	char dest[100];
	int count;
	int srcfh;
	int destfh;
	int error;
	int ok;
#ifdef PROTECTED
	FILESTATUS fs;
	FILESTATUS newfs;
#else
	unsigned short fdate;
	unsigned short ftime;
#endif
	int ret;

	tfile = get_filearea(area);
	strcpy(filepath,tfile->file_pathname);
	if (filepath[0] && filepath[strlen(filepath) - 1] != P_CSEP)
		strcat(filepath,P_SSEP);
	for (count = 0; count < total_files; count++)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("Now copying file \"",NULL);
		send_string(files[count]->fl_name,NULL);
		send_string("\"...\r\n",NULL);

		ok = 1;
		if (files[count]->fl_location == area)
			sprintf(src,"%s%s",filepath,files[count]->fl_name);
		else
			{
			if (tfile1 = get_filearea(files[count]->fl_location))
				{
				strcpy(src,tfile1->file_pathname);
				if (src[0] && src[strlen(src) - 1] != P_CSEP)
					strcat(src,P_SSEP);
				strcat(src,files[count]->fl_name);
				}
			else
				ok = 0;
			}
		if (ok)
			{
			sprintf(dest,"%s%s",destpath,files[count]->fl_name);
			if ((srcfh = open(src,O_BINARY | O_RDONLY)) != -1)
				{
				error = 0;
#ifdef PROTECTED
				DosQFileInfo(srcfh,1,(PBYTE)&fs,sizeof(FILESTATUS));
#else
	#ifdef __ZTC__
				dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
	#else
				_dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
	#endif
#endif
				if ((destfh = open(dest,O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,S_IREAD | S_IWRITE)) != -1)
					{
					while ((ret = read(srcfh,copybuffer,MAX_COPYBUFFER)) != -1 && ret)
						{
						if (write(destfh,copybuffer,ret) == -1)
							{
							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(RED | BRIGHT),NULL);
							send_string("Error while copying file....deleting incomplete file....\r\n\r\n",NULL);
							close(destfh);
							close(srcfh);
							unlink(dest);
							error = 1;
							break;
							}
						}
					if (!error)
						{
#ifdef PROTECTED
						DosQFileInfo(destfh,1,(PBYTE)&newfs,sizeof(FILESTATUS));
						newfs.fdateCreation = fs.fdateCreation;
						newfs.ftimeCreation = fs.ftimeCreation;
						newfs.fdateLastAccess = fs.fdateLastAccess;
						newfs.ftimeLastAccess = fs.ftimeLastAccess;
						newfs.fdateLastWrite = fs.fdateLastWrite;
						newfs.ftimeLastWrite = fs.ftimeLastWrite;
						DosSetFileInfo(destfh,1,(PBYTE)&newfs,sizeof(FILESTATUS));
#else
	#ifdef __ZTC__
						dos_setftime(destfh,fdate,ftime);		/* set date/time */
	#else
						_dos_setftime(destfh,fdate,ftime);		/* set date/time */
	#endif
#endif

						files[count]->fl_update = update_downloads(files[count]->fl_location,files[count]->fl_name,get_cdate());

						close(destfh);
						}
					}
				else
					{
					if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
						send_string(new_color(RED | BRIGHT),NULL);
					send_string("Unable to open destination \"",NULL);
					send_string(dest,NULL);
					send_string("\"...\r\n\r\n",NULL);
					}
				if (!error)
					close(srcfh);
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Unable to open source \"",NULL);
				send_string(src,NULL);
				send_string("\"...\r\n\r\n",NULL);
				}
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Unable to locate destination \"",NULL);
			send_string(src,NULL);
			send_string("\"...\r\n\r\n",NULL);
			}
		}
	}



void copy_in(int area,char *srcpath,char **files,int total_files,int descrip)
	{
	struct file *tfile;
	struct fe tfe;
	char buffer[100];
	char path[80];
	char src[100];
	char dest[100];
	long tlong;
	int count;
	int kount;
	int srcfh;
	int destfh;
	int error;
	int ret;
	int copied = 0;
#ifdef PROTECTED
	FILESTATUS fs;
	FILESTATUS newfs;
#else
	unsigned short fdate;
	unsigned short ftime;
#endif
	FILE *bbsfd;

	tfile = get_filearea(area);
	strcpy(path,tfile->file_pathname);
	if (path[0] && path[strlen(path) - 1] != P_CSEP)
		strcat(path,P_SSEP);
	for (count = 0; count < total_files; count++)
		{
		if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
			send_string(new_color(BROWN | BRIGHT),NULL);
		send_string("Now copying file \"",NULL);
		send_string(files[count],NULL);
		send_string("\"...\r\n",NULL);
		sprintf(src,"%s%s",srcpath,files[count]);
		sprintf(dest,"%s%s",path,files[count]);
		if ((srcfh = open(src,O_BINARY | O_RDONLY)) != -1)
			{
			error = 0;
#ifdef PROTECTED
			DosQFileInfo(srcfh,1,(PBYTE)&fs,sizeof(FILESTATUS));
#else
#ifdef __ZTC__
			dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
#else
			_dos_getftime(srcfh,&fdate,&ftime);		/* get date/time */
#endif
#endif
			if ((destfh = open(dest,O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,S_IREAD | S_IWRITE)) != -1)
				{
				while ((ret = read(srcfh,copybuffer,MAX_COPYBUFFER)) != -1 && ret)
					{
					if (write(destfh,copybuffer,ret) == -1)
						{
						if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
							send_string(new_color(RED | BRIGHT),NULL);
						send_string("Error while copying file....deleting incomplete file....\r\n\r\n",NULL);
						close(destfh);
						close(srcfh);
						files[count][0] = '\0';
						unlink(dest);
						error = 1;
						break;
						}
					}
				if (!error)
					{
					copied = 1;
#ifdef PROTECTED
					DosQFileInfo(destfh,1,(PBYTE)&newfs,sizeof(FILESTATUS));
					newfs.fdateCreation = fs.fdateCreation;
					newfs.ftimeCreation = fs.ftimeCreation;
					newfs.fdateLastAccess = fs.fdateLastAccess;
					newfs.ftimeLastAccess = fs.ftimeLastAccess;
					newfs.fdateLastWrite = fs.fdateLastWrite;
					newfs.ftimeLastWrite = fs.ftimeLastWrite;
					DosSetFileInfo(destfh,1,(char *)&newfs,sizeof(FILESTATUS));
#else
#ifdef __ZTC__
					dos_setftime(destfh,fdate,ftime);		/* set date/time */
#else
					_dos_setftime(destfh,fdate,ftime);		/* set date/time */
#endif
#endif
					close(destfh);
					}
				}
			else
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(RED | BRIGHT),NULL);
				send_string("Unable to open destination \"",NULL);
				send_string(dest,NULL);
				send_string("\"...\r\n\r\n",NULL);
				files[count][0] = '\0';
				}
			if (!error)
				close(srcfh);
			}
		else
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(RED | BRIGHT),NULL);
			send_string("Unable to open source \"",NULL);
			send_string(src,NULL);
			send_string("\"...\r\n\r\n",NULL);
			files[count][0] = '\0';
			}
		}
	if (copied && descrip)
		{
		if (tfile->file_descname[0])
			strcpy(buffer,tfile->file_descname);
		else 
			strcpy(buffer,tfile->file_pathname);
		if (buffer[0])
			{
			if (buffer[strlen(buffer) - 1] != P_CSEP)
				strcat(buffer,P_SSEP);
			}
		strcat(buffer,"filelist.bbs");

		for (count = 0, kount = 0; count < total_files; count++)
			{
			if (files[count][0])
				{
				if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
					send_string(new_color(CYAN | BRIGHT),NULL);

				tlong = file_size(tfile->file_pathname,files[count]);
				++kount;
				strupr(files[count]);

				memset(&tfe,0,sizeof(struct fe));
				strcpy(tfe.fe_name,files[count]);
				strcpy(tfe.fe_uploader,user.user_name);
				tfe.fe_location = tfile->file_number;
				tfe.fe_priv = tfile->file_priv;
				tfe.fe_flags = tfile->file_flags;
				tfe.fe_uldate = get_cdate();

				edit_description(kount,files[count],tlong,tfe.fe_descrip);

				/* now we must open the filelist, get to the end and write the new record */
				if (tfile->file_descname[0])
					strcpy(buffer,tfile->file_descname);
				else 
					strcpy(buffer,tfile->file_pathname);
				if (buffer[0])
					{
					if (buffer[strlen(buffer) - 1] != P_CSEP)
						strcat(buffer,P_SSEP);
					}
				strcat(buffer,"filelist.bbs");

				if (bbsfd = open_filelist_write(buffer))
					{
					fseek(bbsfd,0L,SEEK_END);
					fwrite(&tfe,sizeof(struct fe),1,bbsfd);
					closef(bbsfd);
					}
				else
					{
					sprintf(buffer,"\"%s\" in file area %u.",tfe.fe_name,tfile->file_number);
					log_entry(L_DESCRIP_ERROR,buffer);
					}
				}
			}
		}
	}
