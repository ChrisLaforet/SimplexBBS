/* s_bm.c
**
** Copyright (c) 1992, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 12 February 1992
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_bm.c_v  $
**                       $Date:   25 Oct 1992 14:06:48  $
**                       $Revision:   1.1  $
**
*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "simplex.h"



#define NOSKIP				(unsigned char)0xff


static unsigned char _far bm_skip[256];
static unsigned char _far bm_key[256];
static int bm_case;



int bm_setup(char *key,int case_sensitive)		/* Boyer-Moore string searching */
	{
	int count;
	int ch;

	if (!key[0] || strlen(key) > 254)
		return 1;
	memset(bm_skip,NOSKIP,sizeof(bm_skip));
	bm_case = case_sensitive;
	strcpy(bm_key,key);
	strrev(bm_key);
	for (count = 0; count < (int)strlen(key); count++)
		{
		ch = (int)(unsigned char)bm_key[count];
		if (case_sensitive)
			ch = toupper(ch);
		if (bm_skip[ch] == NOSKIP)
			bm_skip[ch] = (unsigned char)count;
		}
	strcpy(bm_key,key);
	return 0;
	}



int bm_search(char *string)
	{
	int keyoffset = 0;
	int stoffset = 0;
	int keylen = (int)strlen(bm_key);
	int stlen = (int)strlen(string);
	int stch;
	int keych;
	int skip;

	if (keylen <= stlen)
		{
		while (stoffset <= (stlen - keylen))
			{
			keyoffset = keylen - 1;
			while (keyoffset >= 0)
				{
				stch = string[stoffset + keyoffset];
				if (bm_case)
					stch = toupper(stch);
				skip = bm_skip[stch];
				if (skip != NOSKIP)
					{
					keych = bm_key[keyoffset];
					if (bm_case)
						keych = toupper(keych);
					if (keych != stch)
						{
						++stoffset;
						break;
						}
					else if (!keyoffset)
						return stoffset;
					}
				else
					{
					stoffset += keylen;
					break;
					}
				--keyoffset;
				}
			}
		}
	return -1;
	}
