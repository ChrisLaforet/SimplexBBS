/* s_kill.c
**
** Copyright (c) 1992, Chris Laforet Software/Chris Laforet
** All Rights Reserved
**
** Started: 15 August 1992
**
** Revision Information: $Logfile:   G:/simplex/vcs/s_kill.c_v  $
**                       $Date:   25 Oct 1992 14:07:16  $
**                       $Revision:   1.0  $
**
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include "simplex.h"





void kill_files(int area)
	{
	struct file *tfile;
	struct file *tfile1;
	struct fe tfe;
	struct fi tfi;
	char listpath[100];
	char buffer[100];
	char buffer1[100];
	int found;
	int count;
	int skip;
	int ok;
	FILE *sfd;
	FILE *dfd;

	if (!(tfile = get_filearea(area)))
		{
		sprintf(buffer,"File area %u is not a valid file area!",area);
		_error(E_ERROR,buffer);
		system_message(buffer);
		return;
		}

	if (tfile->file_descname[0])
		strcpy(listpath,tfile->file_descname);
	else 
		strcpy(listpath,tfile->file_pathname);
	if (listpath[0] && listpath[strlen(listpath) - 1] != P_CSEP)
		strcat(listpath,P_SSEP);

	if (get_killlist(tfile,listpath))
		{
		if (cur_flist)
			{
			if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
				send_string(new_color(GREEN | BRIGHT),NULL);
			sprintf(buffer,"\r\nAre you SURE that you want to delete %s %u file%s/descrip%s (y/N)? ",(char *)(cur_flist == 1 ? "this" : "these"),cur_flist,(char *)(cur_flist == 1 ? "" : "s"),(char *)(cur_flist == 1 ? "" : "s"));
			send_string(buffer,NULL);
			if (get_yn_enter(0))
				{
				send_string("\r\n",NULL);
				for (count = 0; count < cur_flist; count++)
					{
					if (flist[count]->fl_update)		/* check "flag" to see if file is here */
						{
						skip = 0;

						if (flist[count]->fl_location == area)
							strcpy(buffer,tfile->file_pathname);
						else
							{
							if (tfile1 = get_filearea(flist[count]->fl_location))
								strcpy(buffer,tfile1->file_pathname);
							else 
								skip = 1;
							}

						if (!skip)
							{
							if (buffer[0] && buffer[strlen(buffer) - 1] != P_CSEP)
								strcat(buffer,P_SSEP);
							strcat(buffer,flist[count]->fl_name);

							if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
								send_string(new_color(CYAN | BRIGHT),NULL);
							send_string(" > Deleting \"",NULL);
							send_string(flist[count]->fl_name,NULL);
							send_string("\"...",NULL);

							if (unlink(buffer))
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(RED | BRIGHT),NULL);
								send_string("Unable to delete!\r\n",NULL);

								flist[count]->fl_name[0] = (char)'\0';
								}
							else
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(MAGENTA | BRIGHT),NULL);
								send_string("Deleted!\r\n",NULL);

								sprintf(buffer,"\"%s\" from file area %u (while in area %u)",flist[count]->fl_name,flist[count]->fl_location,area);
								log_entry(L_FILEDELETED,buffer);
								}
							}
						}
					}

				strcpy(buffer,listpath);
				strcat(buffer,"filelist.bak");
				unlink(buffer);

				strcpy(buffer1,listpath);
				strcat(buffer1,"filelist.bbs");

				ok = 1;
				if (get_firstfile(&tfi,buffer1))		/* we need to check file size */
					{
					if (tfi.fi_size >= disk_size(listpath))
						ok = 0;
					}
				else
					ok = 0;

				if (ok)
					{
					if (!rename(buffer1,buffer))
						{
						if (!(sfd = openf(buffer,"rb")))	/* open the BAK */
							rename(buffer,buffer1);
						else
							{
							if (!(dfd = openf(buffer1,"wb")))	/* open the BBS */
								{
								closef(sfd);
								sfd = NULL;
								rename(buffer,buffer1);
								}
							else
								{
								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(BROWN | BRIGHT),NULL);
								send_string("\r\n > Removing description lines....",NULL);

								while (fread(&tfe,sizeof(struct fe),1,sfd))
									{
									for (count = 0; count < cur_flist; count++)
										{
										found = 0;
										if (flist[count]->fl_name[0])
											{
											if (!stricmp(tfe.fe_name,flist[count]->fl_name))
												{
												found = 1;
												break;
												}
											}
										}
									if (!found)
										fwrite(&tfe,sizeof(struct fe),1,dfd);
									}
								closef(dfd);
								closef(sfd);

								if ((user.user_flags & USER_ANSI) && (user_baud >= cfg.cfg_ansibaud || !user_baud))
									send_string(new_color(CYAN | BRIGHT),NULL);
								send_string("Finished!\r\n",NULL);
								}
							}
						}
					else
						rename(buffer,buffer1);
					}
				}
			else
				{
				for (count = 0; count < cur_flist; count++)
					{
					if (flist[count]->fl_name[0])
						{
						sprintf(buffer,"\"%s\" in file area %u.",flist[count]->fl_name,area);
						log_entry(L_KILL_ERROR,buffer);
						}
					}
				
				}

			/* free up memory */
			for (count = 0; count < cur_flist; count++)
				{
				free(flist[count]->fl_name);
				free(flist[count]);
				}
			free(flist);
			flist = NULL;
			cur_flist = 0;
			max_flist = 0;
			}
		}
	}
